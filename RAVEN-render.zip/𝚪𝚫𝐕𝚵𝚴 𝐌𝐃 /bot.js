// bot.js — RAVEN MD (Telegraf pairing bot)
// Developer: KIRA TECH
// ✨ Style adapted: Rich Messages + Slideshow + Audio + Colored Buttons

require('./setting/config');
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const yts = require('yt-search');
const { ytdl } = require('./allfunc/scrape-ytdl');
const startpairing = require('./pair');
const { BOT_TOKEN } = require('./token');
const { Telegraf } = require('telegraf');
const {
  default: makeWASocket,
  useMultiFileAuthState,
  jidNormalizedUser
} = require('@whiskeysockets/baileys');

// ---------------------------------------------------------------------------
// Optional tg-rich-messages (auto-install fallback)
// ---------------------------------------------------------------------------
(() => {
  try {
    require.resolve('tg-rich-messages');
  } catch (e) {
    console.log('📦 "tg-rich-messages" not installed, trying auto-install...');
    try {
      const { execSync } = require('child_process');
      execSync('npm install tg-rich-messages', { stdio: 'inherit', cwd: __dirname });
      console.log('✅ "tg-rich-messages" installed.');
    } catch (installErr) {
      console.error('⚠️ Auto-install failed:', installErr.message);
      console.error('⚠️ Rich Message will fall back to plain messages.');
    }
  }
})();

// ---------------------------------------------------------------------------
// Branding / config
// ---------------------------------------------------------------------------
const BOT_NAME = 'RAVEN MD';
const DEV_NAME = 'ᴋɪʀᴀ Dev 🇦🇱';
const DEV_URL = 'https://t.me/dev_kira';
const CHANNEL_URL = 'https://t.me/kira4hub';
const ROOM_URL = 'https://t.me/kiragroup1';

// 🔒 Les 4 chaînes/groupes obligatoires. 
// ⚠️ Si les groupes sont privés, remplace les @ par les IDs -100...
const REQUIRED_CHANNELS = [
  '@kira4hub',
  '@kirahub2',
  '@kiragroup1',
  '@kiragroup3'
];

const START_PHOTOS = [
  'https://k.top4top.io/p_3945p1sfq1.jpg',
  'https://i.top4top.io/p_3945spzhc1.jpg',
  'https://l.top4top.io/p_3945u5tla1.jpg',
  'https://j.top4top.io/p_3945367951.jpg'
];

const START_AUDIO = 'https://www.image2url.com/r2/default/audio/1792473339789-d2d8f297-52b9-41ed-a1bc-f66a69a57f4d.m4a';

const START_LOADING_STAGES = [
  '🔎 Checking server...',
  '📡 Connecting to script...',
  '📊 Counting bot statistics...',
  '🖼️ Preparing menu display...',
  '✅ Ready!'
];
const START_STAGE_DELAY_MS = 500;
const START_DRAFT_ID = 1;

const adminFilePath = './database/admintele.json';
const bannedPath = './richstore/pairing/banned.json';
const userStore = './richstore/pairing/users.json';
const premium_file = './premium.json';
const pairingPath = './richstore/pairing';
const MAX_SESSIONS = 700;

const ITEMS_PER_PAGE = 10;
const pagedListPairs = {};
const botStartTime = Date.now();

// ---------------------------------------------------------------------------
// Ensure files/folders
// ---------------------------------------------------------------------------
if (!fs.existsSync('./database')) fs.mkdirSync('./database', { recursive: true });
if (!fs.existsSync(pairingPath)) fs.mkdirSync(pairingPath, { recursive: true });
if (!fs.existsSync(userStore)) fs.writeFileSync(userStore, JSON.stringify([]));
if (!fs.existsSync(bannedPath)) fs.writeFileSync(bannedPath, JSON.stringify([]));
if (!fs.existsSync(adminFilePath)) {
  const defaultAdmin = [String(process.env.OWNER_ID || '7921095103')];
  fs.writeFileSync(adminFilePath, JSON.stringify(defaultAdmin, null, 2));
}

const adminIDs = JSON.parse(fs.readFileSync(adminFilePath, 'utf8'));

let premiumUsers = [];
try {
  premiumUsers = fs.existsSync(premium_file)
    ? JSON.parse(fs.readFileSync(premium_file, 'utf-8'))
    : [];
  if (!fs.existsSync(premium_file)) fs.writeFileSync(premium_file, JSON.stringify([]));
} catch (e) {
  console.error('Failed to load premium users:', e);
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
const bot = new Telegraf(BOT_TOKEN);
const userStates = {};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function trackUser(id) {
  try {
    const users = JSON.parse(fs.readFileSync(userStore));
    if (!users.includes(id)) {
      users.push(id);
      fs.writeFileSync(userStore, JSON.stringify(users, null, 2));
    }
  } catch (e) {
    console.error('trackUser error:', e.message);
  }
}

function getPushName(ctx) {
  return ctx.from.first_name || ctx.from.username || 'User';
}

function formatRuntime(seconds) {
  const pad = (s) => (s < 10 ? '0' + s : s);
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  return `${pad(hrs)}h ${pad(mins)}m ${pad(secs)}s`;
}

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

async function checkJoinedChannels(ctx) {
  const userId = ctx.from.id;
  for (const channel of REQUIRED_CHANNELS) {
    try {
      const member = await ctx.telegram.getChatMember(channel, userId);
      if (['left', 'kicked'].includes(member.status)) return { ok: false, channel };
    } catch (e) {
      return { ok: false, channel, error: e.message };
    }
  }
  return { ok: true };
}

// ✅ Vérification réelle d'une session
function isSessionValid(sessionFolder) {
  try {
    const credsPath = path.join(pairingPath, sessionFolder, 'creds.json');
    if (!fs.existsSync(credsPath)) return false;
    const creds = JSON.parse(fs.readFileSync(credsPath, 'utf8'));
    return !!(creds && creds.registered === true && creds.me && creds.me.id);
  } catch {
    return false;
  }
}

function getRealPairedDevices() {
  if (!fs.existsSync(pairingPath)) return [];
  return fs.readdirSync(pairingPath, { withFileTypes: true })
    .filter((e) => e.isDirectory() && /^\d+@s\.whatsapp\.net$/.test(e.name))
    .map((e) => e.name)
    .filter(isSessionValid);
}

// ---------------------------------------------------------------------------
// 🎨 VISUAL DESIGN SYSTEM
// ---------------------------------------------------------------------------
const SEPARATOR = '━━━━━━━━━━━━━━';
const TITLE_START = '『 𝗥𝗔𝗩𝗘𝗡 𝗠𝗗 』';
const STATUS_OK   = '<tg-emoji emoji-id="6269243378332864932">✅</tg-emoji>';
const STATUS_ERR  = '<tg-emoji emoji-id="5787672755839176187">❌</tg-emoji>';
const STATUS_WARN = '<tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji>';
const STATUS_TIME = '<tg-emoji emoji-id="6098230596788556786">🕐</tg-emoji>';

const headerBox = (subtitle = '') => `
<blockquote><tg-emoji emoji-id="5411301743738777449">🎩</tg-emoji>°${TITLE_START}</blockquote>
${subtitle ? `<blockquote>${subtitle}</blockquote>` : ''}
`;

const infoCard = (rows, title = 'INFORMATION') => {
  const body = rows.map(([k, v]) => `↯ ${k} : <b>${v}</b>`).join('\n');
  return `<blockquote><tg-emoji emoji-id="5398052521249881872">📊</tg-emoji> <b>${title}</b>\n${body}</blockquote>`;
};

const successBox = (title, rows = []) => {
  const body = rows.map(([k, v]) => `↯ ${k} : <b>${v}</b>`).join('\n');
  return `<blockquote>${STATUS_OK} <b>${title}</b>\n${body}</blockquote>`;
};

const errorBox = (msg) => `<blockquote>${STATUS_ERR} <b>${msg}</b></blockquote>`;
const warnBox = (msg) => `<blockquote>${STATUS_WARN} ${msg}</blockquote>`;

// ---------------------------------------------------------------------------
// 🎨 Photo slideshow
// ---------------------------------------------------------------------------
async function sendPhotoSlideshow(ctx, photos, caption, keyboard) {
  const chatId = ctx.chat.id;
  let sentMsg;

  try {
    sentMsg = await ctx.replyWithPhoto(photos[0], {
      caption,
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: keyboard }
    });
  } catch (e) {
    return ctx.reply(caption, { parse_mode: 'HTML', reply_markup: { inline_keyboard: keyboard } });
  }

  (async () => {
    for (let i = 1; i < photos.length; i++) {
      await sleep(3000);
      try {
        await ctx.telegram.editMessageMedia(
          chatId,
          sentMsg.message_id,
          undefined,
          { type: 'photo', media: photos[i], caption, parse_mode: 'HTML' },
          { reply_markup: { inline_keyboard: keyboard } }
        );
      } catch (_) { break; }
    }
  })();

  return sentMsg;
}

// ---------------------------------------------------------------------------
// Loading animation
// ---------------------------------------------------------------------------
async function sendThinkingDraft(chatId, text) {
  return axios.post(`https://api.telegram.org/bot${BOT_TOKEN}/sendRichMessageDraft`, {
    chat_id: chatId,
    draft_id: START_DRAFT_ID,
    rich_message: { html: `<tg-thinking>${escapeHtml(text)}</tg-thinking>` }
  }, { timeout: 10000 });
}

async function playStartLoadingAnimation(chatId) {
  let richSupported = true;
  for (const stage of START_LOADING_STAGES) {
    try {
      await sendThinkingDraft(chatId, stage);
    } catch (err) {
      richSupported = false;
      break;
    }
    await sleep(START_STAGE_DELAY_MS);
  }

  if (!richSupported) {
    try {
      const msg = await bot.telegram.sendMessage(chatId, START_LOADING_STAGES[0]);
      for (let i = 1; i < START_LOADING_STAGES.length; i++) {
        await sleep(START_STAGE_DELAY_MS);
        await bot.telegram.editMessageText(chatId, msg.message_id, undefined, START_LOADING_STAGES[i]).catch(() => {});
      }
      await bot.telegram.deleteMessage(chatId, msg.message_id).catch(() => {});
    } catch (e) { /* ignore */ }
  }
}

// ---------------------------------------------------------------------------
// 🎨 RICH START CARD
// ---------------------------------------------------------------------------
async function sendRichStartCard(ctx) {
  const chatId = ctx.chat.id;
  const username = escapeHtml(getPushName(ctx));
  const uptime = formatRuntime(Math.floor((Date.now() - botStartTime) / 1000));
  const serverTime = new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC';

  const buttons = [
    [{ text: '👑 ᴋɪʀᴀ Dev', url: DEV_URL, style: 'primary',  icon_custom_emoji_id: '5463039890449003865' }],
    [
      { text: '𝙲𝚑𝚊𝚗𝚗𝚎𝚕', url: CHANNEL_URL, style: 'success', icon_custom_emoji_id: '5409087245716056598' },
      { text: '𝚁𝚘𝚘𝚖',    url: ROOM_URL,    style: 'danger',  icon_custom_emoji_id: '5363787894932662327' }
    ]
  ];

  try {
    const {
      doc, heading, paragraph, slideshow, audio, divider,
      details, table, emoji, bold, link, pullquote
    } = await import('tg-rich-messages');

    const richDoc = doc(
      slideshow(START_PHOTOS.map((url) => ({ url }))),
      heading(2, [emoji('6253453459350100040', '👑'), ` ${BOT_NAME}`]),
      divider(),
      paragraph([
        emoji('5879770735999717115', '👤'), ' Welcome ', bold(username), ' !'
      ]),
      details(
        'INFORMATION',
        [
          table(
            [
              [{ content: bold('SYSTEM'), header: true }, { content: bold('DETAIL'), header: true }],
              [{ content: [emoji('5879770735999717115', '👤'), ' User'] }, { content: bold(username) }],
              [{ content: [emoji('5402355073458123173', '⌛️'), ' Runtime'] }, { content: bold(uptime) }],
              [{ content: [emoji('5992087137267225105', '💻'), ' Server Time'] }, { content: bold(serverTime) }],
              [{ content: [emoji('5841403144604487992', '🔔'), ' Version'] }, { content: bold('1.0.0') }],
            ],
            { bordered: true, striped: true, compact: true, caption: 'SYSTEM INFORMATION' }
          )
        ],
        { open: true }
      ),
      divider(),
      details(
        'ABOUT',
        'RAVEN MD is a multi-device WhatsApp pairing bot. Use /pair to link a new device, /listpair to view linked nodes, and /delpair to remove one.',
        { open: false }
      ),
      audio(START_AUDIO),
      divider(),
      pullquote([
        emoji('5271604874419647061', '🔗'), ' ',
        link(DEV_NAME, DEV_URL)
      ])
    );

    await axios.post(`https://api.telegram.org/bot${BOT_TOKEN}/sendRichMessage`, {
      chat_id: chatId,
      rich_message: richDoc.toInputRichMessage({ skipEntityDetection: true }),
      reply_markup: { inline_keyboard: buttons }
    }, { timeout: 20000 });

    return true;
  } catch (err) {
    console.error('⚠️ sendRichMessage (start) failed:', err.response?.data?.description || err.message);
    return false;
  }
}

// ---------------------------------------------------------------------------
// 🎨 FALLBACK START
// ---------------------------------------------------------------------------
async function sendStartFallback(ctx) {
  const username = escapeHtml(getPushName(ctx));
  const uptime = formatRuntime(Math.floor((Date.now() - botStartTime) / 1000));
  const serverTime = new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC';

  const caption = `${headerBox('𝚆𝙴𝙻𝙲𝙾𝙼𝙴 𝚃𝙾 𝚁𝙰𝚅𝙴𝙽 𝙼𝙳')}
${SEPARATOR}
<blockquote>${infoCard([
    ['👤 User',        username],
    ['⌛️ Runtime',    uptime],
    ['💻 Server',      serverTime],
    ['🔔 Version',     '1.0.0'],
    ['🔗 Pairing',     `${getRealPairedDevices().length} nodes`]
  ], 'SYSTEM INFORMATION')}</blockquote>
${SEPARATOR}
<blockquote><tg-emoji emoji-id="5231200819986047254">⚙️</tg-emoji> <b>COMMANDS</b>
↯ /pair 123xxx  →  Link a new device
↯ /listpair    →  List linked nodes
↯ /delpair     →  Remove a node
↯ /runtime     →  Bot uptime</blockquote>
${SEPARATOR}
<blockquote><tg-emoji emoji-id="6165775219580472827">☠</tg-emoji> Please choose a menu below.</blockquote>`;

  const keyboard = [
    [{ text: '👑 ᴋɪʀᴀ Dev', url: DEV_URL, style: 'primary',  icon_custom_emoji_id: '5463039890449003865' }],
    [
      { text: '𝙲𝚑𝚊𝚗𝚗𝚎𝚕', url: CHANNEL_URL, style: 'success', icon_custom_emoji_id: '5409087245716056598' },
      { text: '𝚁𝚘𝚘𝚖',    url: ROOM_URL,    style: 'danger',  icon_custom_emoji_id: '5363787894932662327' }
    ]
  ];

  await sendPhotoSlideshow(ctx, START_PHOTOS, caption, keyboard);
}

// ---------------------------------------------------------------------------
// 🎨 Pagination helpers
// ---------------------------------------------------------------------------
function sendListPairPage(ctx, userID, pageIndex) {
  const pairedDevices = pagedListPairs[userID] || [];
  const totalPages = Math.max(1, Math.ceil(pairedDevices.length / ITEMS_PER_PAGE));
  pageIndex = Math.min(Math.max(pageIndex, 0), totalPages - 1);

  const start = pageIndex * ITEMS_PER_PAGE;
  const currentPage = pairedDevices.slice(start, start + ITEMS_PER_PAGE);

  const rows = currentPage.length
    ? currentPage.map((id, i) => `↯ ${start + i + 1}. <code>${id}</code>`).join('\n')
    : '↯ <i>No paired devices found.</i>';

  const text = `${headerBox('𝙻𝙸𝚂𝚃 𝙾𝙵 𝙻𝙸𝙽𝙺𝙴𝙳 𝙽𝙾𝙳𝙴𝚂')}
<blockquote><tg-emoji emoji-id="5931718859366075705">📂</tg-emoji> <b>Paired Bots</b>
↯ Page : <b>${pageIndex + 1}/${totalPages}</b>
↯ Total : <b>${pairedDevices.length}</b>

${rows}</blockquote>`;

  const navButtons = [];
  if (pageIndex > 0)              navButtons.push({ text: '⬅️ Back', callback_data: `listpair_page_${pageIndex - 1}`, style: 'danger',  icon_custom_emoji_id: '5258236805890710909' });
  if (pageIndex < totalPages - 1) navButtons.push({ text: 'Next ➡️', callback_data: `listpair_page_${pageIndex + 1}`, style: 'primary', icon_custom_emoji_id: '5260450573768990626' });

  ctx.editMessageText(text, {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: navButtons.length ? [navButtons] : [] }
  }).catch(() => {
    ctx.reply(text, {
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: navButtons.length ? [navButtons] : [] }
    });
  });
}

function sendDelPairPage(ctx, userID, pageIndex) {
  const pairedDevices = pagedListPairs[userID] || [];
  const totalPages = Math.max(1, Math.ceil(pairedDevices.length / ITEMS_PER_PAGE));
  pageIndex = Math.min(Math.max(pageIndex, 0), totalPages - 1);

  const start = pageIndex * ITEMS_PER_PAGE;
  const currentPage = pairedDevices.slice(start, start + ITEMS_PER_PAGE);

  const keyboard = currentPage.map((id) => [
    { text: `🗑️ ${id}`, callback_data: `delpair_${id}`, style: 'danger', icon_custom_emoji_id: '4956612582816351459' }
  ]);

  const navButtons = [];
  if (pageIndex > 0)              navButtons.push({ text: '⬅️ Back', callback_data: `delpair_page_${pageIndex - 1}`, style: 'danger',  icon_custom_emoji_id: '5258236805890710909' });
  if (pageIndex < totalPages - 1) navButtons.push({ text: 'Next ➡️', callback_data: `delpair_page_${pageIndex + 1}`, style: 'primary', icon_custom_emoji_id: '5260450573768990626' });
  if (navButtons.length) keyboard.push(navButtons);

  const text = pairedDevices.length
    ? `${headerBox('𝙳𝙴𝙻𝙴𝚃𝙴 𝙰 𝙽𝙾𝙳𝙴')}
<blockquote><tg-emoji emoji-id="5931718859366075705">📂</tg-emoji> <b>Delete Paired Devices</b>
↯ Page : <b>${pageIndex + 1}/${totalPages}</b>

↯ Tap an ID to remove it.</blockquote>`
    : `${headerBox('𝙳𝙴𝙻𝙴𝚃𝙴 𝙰 𝙽𝙾𝙳𝙴')}<blockquote>↯ <i>No paired devices found.</i></blockquote>`;

  ctx.deleteMessage().catch(() => {});
  ctx.reply(text, { parse_mode: 'HTML', reply_markup: { inline_keyboard: keyboard } });
}

// ---------------------------------------------------------------------------
// Commands
// ---------------------------------------------------------------------------
bot.command('runtime', async (ctx) => {
  const uptime = Math.floor((Date.now() - botStartTime) / 1000);
  await ctx.reply(
    `${headerBox('𝚄𝙿𝚃𝙸𝙼𝙴')}
<blockquote>${STATUS_TIME} ${BOT_NAME} has been online for <b>${formatRuntime(uptime)}</b></blockquote>`,
    { parse_mode: 'HTML' }
  );
});

bot.start(async (ctx) => {
  const userId = ctx.from.id;
  trackUser(userId);

  // 🔒 VÉRIFICATION GLOBALE AU /START
  const check = await checkJoinedChannels(ctx);
  
  if (!check.ok) {
    return ctx.reply(
      `${headerBox('𝙰𝙲𝙲𝙴𝚂𝚂 𝙳𝙴𝙽𝙸𝙴𝙳')}
${warnBox(`To use <b>${BOT_NAME}</b>, you must join <b>all</b> our official channels and groups.\n\n↯ Missing: <code>${escapeHtml(String(check.channel))}</code>`)}`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: 'Main Channel', url: 'https://t.me/kira4hub', style: 'primary', icon_custom_emoji_id: '6098421155897545579' }],
            [{ text: 'Kira Bio', url: 'https://t.me/kirahub2', style: 'primary', icon_custom_emoji_id: '6098421155897545579' }],
            [{ text: 'Main Group', url: 'https://t.me/kiragroup1', style: 'success', icon_custom_emoji_id: '5936067938955039275' }],
            [{ text: 'Support Group', url: 'https://t.me/kiragroup3', style: 'success', icon_custom_emoji_id: '5936067938955039275' }],
            [{ text: '✅ Verify / Confirmer', callback_data: 'check_join_start', style: 'danger' }]
          ]
        }
      }
    );
  }

  // Si tout est bon, on lance l'animation et le menu
  await playStartLoadingAnimation(ctx.chat.id);
  const sent = await sendRichStartCard(ctx);
  if (!sent) await sendStartFallback(ctx);
});

// ✅ /pair corrigé
bot.command(['pair', 'connect'], async (ctx) => {
  try {
    const userId = ctx.from.id;

    const check = await checkJoinedChannels(ctx);
    if (!check.ok) {
      return ctx.reply(
        `${warnBox(`You must join all required channels/groups first.\n↯ Missing: <code>${escapeHtml(String(check.channel))}</code>`)}`,
        {
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [{ text: '📢 KIRA4HUB', url: CHANNEL_URL, style: 'primary', icon_custom_emoji_id: '6098421155897545579' }],
              [{ text: '📢 KIRAHUB2', url: 'https://t.me/kirahub2', style: 'primary', icon_custom_emoji_id: '6098421155897545579' }],
              [{ text: '💬 KIRAGROUP1', url: ROOM_URL, style: 'success', icon_custom_emoji_id: '5936067938955039275' }],
              [{ text: '💬 KIRAGROUP3', url: 'https://t.me/KIRAGROUP3', style: 'success', icon_custom_emoji_id: '5936067938955039275' }],
              [{ text: '✅ Confirm', callback_data: 'check_join', style: 'danger' }]
            ]
          }
        }
      );
    }

    const text = ctx.message.text.split(' ')[1];
    if (!text) {
      return ctx.reply(warnBox('Format : <code>/pair 123xxxxxxxx</code>'), { parse_mode: 'HTML' });
    }

    if (/[a-z]/i.test(text)) {
      return ctx.reply(errorBox('Invalid number.'), { parse_mode: 'HTML' });
    }

    if (!/^\d{7,15}(\|\d{1,10})?$/.test(text)) {
      return ctx.reply(warnBox('Expected format : <code>123xxxxxx</code> (digits only ❌)'), { parse_mode: 'HTML' });
    }

    if (text.startsWith('0')) {
      return ctx.reply(errorBox('Please use a different number format.'), { parse_mode: 'HTML' });
    }

    const target = text.split('|')[0];
    const Xreturn = ctx.message.reply_to_message
      ? ctx.message.reply_to_message.from.id
      : target.replace(/[^0-9]/g, '') + '@s.whatsapp.net';

    if (!Xreturn) return ctx.reply(errorBox('This number is not registered on WhatsApp'), { parse_mode: 'HTML' });

    const countryCode = text.slice(0, 3);
    const prefixxx = text.slice(0, 1);
    if (['252', '201', '.', '0'].includes(countryCode) || prefixxx === '0') {
      return ctx.reply(errorBox('Country code / prefix not supported.'), { parse_mode: 'HTML' });
    }

    const realSessions = getRealPairedDevices().length;
    if (realSessions >= MAX_SESSIONS) {
      return ctx.reply(errorBox(`Limit reached (${MAX_SESSIONS} sessions).`), { parse_mode: 'HTML' });
    }

    await startpairing(Xreturn, async (pairingCode, error) => {
      if (error) {
        return ctx.reply(
          `${headerBox('𝙿𝙰𝙸𝚁𝙸𝙽𝙶 𝙵𝙰𝙸𝙻𝙴𝙳')}
${errorBox(`Unable to generate a pairing code for <code>${target}</code>`)}
<blockquote>↯ Reason : <code>${escapeHtml(error.message || String(error))}</code>
↯ Session conservée. Réessayez <code>/pair ${target}</code> après quelques secondes.</blockquote>`,
          { parse_mode: 'HTML' }
        );
      }

      await ctx.reply(
        `${headerBox('𝙿𝙰𝙸𝚁𝙸𝙽𝙶 𝙲𝙾𝙳𝙴')}
<blockquote>${STATUS_OK} <b>Code generated successfully!</b>
↯ Number : <code>${target}</code>
↯ Code   : <b>${pairingCode}</b></blockquote>
${SEPARATOR}
<blockquote>📱 WhatsApp → Linked devices → Link a device → <b>Link with phone number</b> → enter the code.</blockquote>`,
        { parse_mode: 'HTML' }
      );
    });
  } catch (error) {
    console.error('Error in /pair:', error);
    ctx.reply(errorBox(`An error occurred: ${escapeHtml(error.message)}`), { parse_mode: 'HTML' });
  }
});

bot.action('check_join', async (ctx) => {
  const check = await checkJoinedChannels(ctx);
  if (check.ok) {
    ctx.reply(successBox('Verification successful', [['Status', 'All channels joined 🎉']]), { parse_mode: 'HTML' });
  } else {
    ctx.answerCbQuery(`❌ Still missing: ${check.channel}`, { show_alert: true });
  }
});

bot.command('listpair', async (ctx) => {
  const userID = ctx.from.id.toString();
  if (!adminIDs.includes(userID)) return ctx.reply(errorBox('Access denied (admin only).'), { parse_mode: 'HTML' });

  const pairedDevices = getRealPairedDevices();
  if (pairedDevices.length === 0) return ctx.reply(errorBox('No paired devices found.'), { parse_mode: 'HTML' });

  pagedListPairs[userID] = pairedDevices;
  sendListPairPage(ctx, userID, 0);
});

bot.command('deluser', async (ctx) => {
  const userID = ctx.from.id.toString();
  if (!adminIDs.includes(userID)) return ctx.reply(errorBox('Access denied.'), { parse_mode: 'HTML' });

  const pairedDevices = getRealPairedDevices();
  if (pairedDevices.length === 0) return ctx.reply(errorBox('No paired devices found.'), { parse_mode: 'HTML' });

  pagedListPairs[userID] = pairedDevices;
  sendDelPairPage(ctx, userID, 0);
});

bot.command('broadcast', async (ctx) => {
  const senderId = ctx.from.id;
  const message = ctx.message.text.split(' ').slice(1).join(' ');

  if (!adminIDs.includes(senderId.toString())) {
    return ctx.reply(errorBox('Access denied.'), { parse_mode: 'HTML' });
  }

  if (!message) {
    return ctx.reply(warnBox('Usage : <code>/broadcast Hello users!</code>'), { parse_mode: 'HTML' });
  }

  const users = JSON.parse(fs.readFileSync(userStore));

  const statusMsg = await ctx.reply(
    `${headerBox('𝙱𝚁𝙾𝙰𝙳𝙲𝙰𝚂𝚃')}
<blockquote>${STATUS_TIME} Broadcasting in progress...
↯ Targets : <b>${users.length}</b>
↯ Sent    : 0
↯ Failed  : 0</blockquote>`,
    { parse_mode: 'HTML' }
  );

  let success = 0;
  let failed = 0;
  for (const userId of users) {
    try {
      await ctx.telegram.sendMessage(userId,
        `${headerBox('𝙱𝚁𝙾𝙰𝙳𝙲𝙰𝚂𝚃 𝙼𝙴𝚂𝚂𝙰𝙶𝙴')}\n${escapeHtml(message)}`,
        { parse_mode: 'HTML' }
      );
      success++;
    } catch {
      failed++;
    }
    if ((success + failed) % 5 === 0) {
      ctx.telegram.editMessageText(
        ctx.chat.id,
        statusMsg.message_id,
        undefined,
        `${headerBox('𝙱𝚁𝙾𝙰𝙳𝙲𝙰𝚂𝚃')}
<blockquote>${STATUS_TIME} Broadcasting in progress...
↯ Targets : <b>${users.length}</b>
↯ Sent    : <b>${success}</b>
↯ Failed  : <b>${failed}</b></blockquote>`,
        { parse_mode: 'HTML' }
      ).catch(() => {});
    }
  }

  await ctx.telegram.editMessageText(
    ctx.chat.id,
    statusMsg.message_id,
    undefined,
    `${headerBox('𝙱𝚁𝙾𝙰𝙳𝙲𝙰𝚂𝚃 𝙲𝙾𝙼𝙿𝙻𝙴𝚃𝙴𝙳')}
${successBox('Broadcast finished', [
      ['Sent',   success],
      ['Failed', failed],
      ['Total',  users.length]
    ])}`,
    { parse_mode: 'HTML' }
  );
});

bot.command('xreport', async (ctx) => {
  const args = ctx.message.text.split(' ').slice(1);
  if (args.length === 0) return ctx.reply(warnBox('Usage : <code>/xreport 123xxxxxxxx</code>'), { parse_mode: 'HTML' });

  const targetNumber = args[0].replace(/\D/g, '');
  if (!targetNumber) return ctx.reply(errorBox('Invalid number.'), { parse_mode: 'HTML' });

  const targetJid = jidNormalizedUser(`${targetNumber}@s.whatsapp.net`);

  if (!fs.existsSync(pairingPath)) return ctx.reply(errorBox('No active paired devices found.'), { parse_mode: 'HTML' });

  const sessions = fs.readdirSync(pairingPath, { withFileTypes: true })
    .filter((e) => e.isDirectory())
    .map((e) => path.join(pairingPath, e.name));

  if (sessions.length === 0) return ctx.reply(errorBox('No active WhatsApp sessions.'), { parse_mode: 'HTML' });

  await ctx.reply(
    `${headerBox('𝙼𝙰𝚂𝚂 𝚁𝙴𝙿𝙾𝚁𝚃')}
<blockquote><tg-emoji emoji-id="6098230596788556786">🚨</tg-emoji> Starting <b>mass-report</b> on <code>+${targetNumber}</code>
↯ Sessions : <b>${sessions.length}</b></blockquote>`,
    { parse_mode: 'HTML' }
  );

  for (const sessionPath of sessions) {
    try {
      const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
      const rich = makeWASocket({ auth: state });
      rich.ev.on('creds.update', saveCreds);

      for (let i = 0; i < 30; i++) {
        try {
          await rich.ws.sendNode({
            tag: 'iq',
            attrs: { to: 's.whatsapp.net', type: 'set', xmlns: 'w:report' },
            content: [{
              tag: 'report',
              attrs: { to: targetJid, type: 'spam', id: rich.generateMessageTag() },
              content: []
            }]
          });
          console.log(`✅ Report ${i + 1} sent from ${path.basename(sessionPath)}`);
          await sleep(2000);
        } catch (err) {
          console.error(`❌ Report attempt ${i + 1} failed for ${path.basename(sessionPath)}:`, err.message);
        }
      }
    } catch (err) {
      console.error(`❌ Error with session ${path.basename(sessionPath)}:`, err.message);
    }
  }

    await ctx.reply(
    `${headerBox('𝙼𝙰𝚂𝚂 𝚁𝙴𝙿𝙾𝚁𝚃 𝙲𝙾𝙼𝙿𝙻𝙴𝚃𝙴𝙳')}
${successBox('Reports finished', [['Target', `+${targetNumber}`]])}`,
    { parse_mode: 'HTML' }
  );
});

bot.command('delpair', async (ctx) => {
  const text = ctx.message.text.trim();
  const args = text.split(' ').slice(1);
  if (args.length === 0) {
    return ctx.reply(warnBox('Usage : <code>/delpair 123xxxxxxxx</code>'), { parse_mode: 'HTML' });
  }
  const inputNumber = args[0].replace(/\D/g, '');
  const jidSuffix = `${inputNumber}@s.whatsapp.net`;
  if (!fs.existsSync(pairingPath)) return ctx.reply(errorBox('No paired devices found.'), { parse_mode: 'HTML' });
  const entries = fs.readdirSync(pairingPath, { withFileTypes: true });
  const matched = entries.find((e) => e.isDirectory() && e.name.endsWith(jidSuffix));
  if (!matched) {
    return ctx.reply(errorBox(`No paired device found for number <code>${inputNumber}</code>`), { parse_mode: 'HTML' });
  }
  const targetPath = path.join(pairingPath, matched.name);
  const wasValid = isSessionValid(matched.name);
  // Suppression uniquement après une demande explicite via /delpair.
  fs.rmSync(targetPath, { recursive: true, force: true });
  await ctx.reply(
    `${headerBox('𝙽𝙾𝙳𝙴 𝚁𝙴𝙼𝙾𝚅𝙴𝙳')}\n${successBox('Paired user removed', [
      ['📱 Phone', `<code>${inputNumber}</code>`],
      ['🆔 ID',    `<code>${matched.name}</code>`],
      ['🔐 Was valid', wasValid ? 'Yes ✅' : 'No (ghost) 🧹']
    ])}`,
    { parse_mode: 'HTML' }
  );
});
// ---------------------------------------------------------------------------
// Pagination callbacks
// ---------------------------------------------------------------------------
bot.action(/^listpair_page_(\d+)$/, async (ctx) => {
  const pageIndex = parseInt(ctx.match[1], 10);
  const userID = ctx.from.id.toString();
  if (!pagedListPairs[userID]) return ctx.answerCbQuery('Session expired.');
  await ctx.answerCbQuery();
  sendListPairPage(ctx, userID, pageIndex);
});

bot.action(/^delpair_page_(\d+)$/, async (ctx) => {
  const pageIndex = parseInt(ctx.match[1], 10);
  const userID = ctx.from.id.toString();
  if (!pagedListPairs[userID]) return ctx.answerCbQuery('Session expired.');
  await ctx.answerCbQuery();
  sendDelPairPage(ctx, userID, pageIndex);
});

bot.action(/^delpair_(.+)$/, async (ctx) => {
  const userID = ctx.from.id.toString();
  if (!adminIDs.includes(userID)) return ctx.answerCbQuery('Unauthorized.', { show_alert: true });
  const target = ctx.match[1];
  const targetPath = path.join(pairingPath, target);
  if (fs.existsSync(targetPath)) {
    // Suppression uniquement après clic explicite sur le bouton.
    fs.rmSync(targetPath, { recursive: true, force: true });
    await ctx.answerCbQuery(`Deleted ${target}`, { show_alert: true });
  } else {
    await ctx.answerCbQuery('Not found.', { show_alert: true });
  }
  sendDelPairPage(ctx, userID, 0);
});

// ---------------------------------------------------------------------------
// Song search state
// ---------------------------------------------------------------------------
bot.on('text', async (ctx) => {
  const userId = ctx.from.id;

  if (userStates[userId] === 'waiting_for_song') {
    const text = ctx.message.text;
    try {
      await ctx.reply(
        `${headerBox('𝚂𝙴𝙰𝚁𝙲𝙷𝙸𝙽𝙶')}
<blockquote>${STATUS_TIME} Looking for <b>${escapeHtml(text)}</b>...</blockquote>`,
        { parse_mode: 'HTML' }
      );

      const search = await yts(text);
      const url = search.all[0].url;
      const response = await ytdl(url);
      const mp3 = response.data.mp3;

      await ctx.replyWithAudio({ url: mp3 }, {
        caption: `${headerBox('𝙼𝚄𝚂𝙸𝙲 𝙵𝙾𝚄𝙽𝙳')}
<blockquote>${STATUS_OK} <b>${escapeHtml(search.all[0].title)}</b>
↯ Duration : <b>${search.all[0].timestamp}</b></blockquote>`,
        parse_mode: 'HTML'
      });

      await ctx.reply(
        successBox('Download complete', [['Status', 'Song sent successfully 🎵']]),
        { parse_mode: 'HTML' }
      );
    } catch (error) {
      console.error(error);
      await ctx.reply(
        errorBox('An error occurred while downloading the song. Please try again later.'),
        { parse_mode: 'HTML' }
      );
    }
    delete userStates[userId];
  }
});

// ---------------------------------------------------------------------------
// Launch
// ---------------------------------------------------------------------------
bot.launch()
  .then(() => console.log(`✅ ${BOT_NAME} running | Dev: ${DEV_NAME}`))
  .catch((err) => console.error('Error while running bot:', err));

module.exports = bot;