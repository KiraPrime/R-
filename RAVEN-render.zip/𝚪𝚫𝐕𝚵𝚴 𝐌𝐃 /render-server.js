'use strict';

const express = require('express');
const path = require('path');
const fs = require('fs');
const startPairing = require('./pair');

const app = express();
const PORT = Number(process.env.PORT || 10000);
const PUBLIC_DIR = path.join(__dirname, 'public');
const PAIRING_ROOT = process.env.PAIRING_ROOT || path.join(__dirname, 'richstore', 'pairing');
const pending = new Set();

fs.mkdirSync(PAIRING_ROOT, { recursive: true });
app.disable('x-powered-by');
app.use(express.static(PUBLIC_DIR, { extensions: ['html'] }));

app.get('/healthz', (_req, res) => {
  res.json({ ok: true, service: 'raven-md-web', pairing: 'available' });
});

function normalizeNumber(value) {
  return String(value || '').replace(/[^0-9]/g, '');
}

function isValidNumber(number) {
  return /^\d{7,15}$/.test(number) && !number.startsWith('0');
}

function sessionPath(number) {
  return path.join(PAIRING_ROOT, `${number}@s.whatsapp.net`);
}

app.get('/code', async (req, res) => {
  const number = normalizeNumber(req.query.number);
  if (!isValidNumber(number)) {
    return res.status(400).json({ ok: false, error: 'Numéro international invalide.' });
  }
  if (pending.has(number)) {
    return res.status(429).json({ ok: false, error: 'Une demande est déjà en cours pour ce numéro.' });
  }

  const credsFile = path.join(sessionPath(number), 'creds.json');
  if (fs.existsSync(credsFile)) {
    try {
      const creds = JSON.parse(fs.readFileSync(credsFile, 'utf8'));
      if (creds.registered || creds.me) {
        return res.status(409).json({ ok: false, error: 'Ce numéro possède déjà une session. Utilisez une autre session ou /delpair.' });
      }
    } catch (_) {
      // Keep the files for recovery; pairing can report the real Baileys error.
    }
  }

  pending.add(number);
  let answered = false;
  const finish = (status, body) => {
    if (answered || res.headersSent) return;
    answered = true;
    pending.delete(number);
    res.status(status).json(body);
  };

  const timeout = setTimeout(() => {
    finish(504, { ok: false, error: 'Délai dépassé : WhatsApp n’a pas encore renvoyé de code.' });
  }, 45_000);

  try {
    await startPairing(`${number}@s.whatsapp.net`, (code, error) => {
      clearTimeout(timeout);
      if (error) return finish(502, { ok: false, error: error.message || String(error) });
      finish(200, { ok: true, code });
    });
  } catch (error) {
    clearTimeout(timeout);
    finish(500, { ok: false, error: error.message || String(error) });
  }
});

app.get('*', (_req, res) => res.sendFile(path.join(PUBLIC_DIR, 'index.html')));

const server = app.listen(PORT, '0.0.0.0', () => {
  console.log(`[WEB] RAVEN MD listening on 0.0.0.0:${PORT}`);
  console.log(`[WEB] Persistent pairing path: ${PAIRING_ROOT}`);
});
server.keepAliveTimeout = 65_000;
server.headersTimeout = 70_000;

// Restore existing sessions after the HTTP service is ready.
try {
  require('./autoload').autoLoadPairs({ batchSize: 8 }).catch(error =>
    console.error('[WEB] Session restore failed:', error.message)
  );
} catch (error) {
  console.error('[WEB] Could not start session restore:', error.message);
}

function shutdown(signal) {
  console.log(`[WEB] ${signal}: closing HTTP listener; session files are preserved.`);
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 10_000).unref();
}
process.once('SIGTERM', () => shutdown('SIGTERM'));
process.once('SIGINT', () => shutdown('SIGINT'));
