# Déployer RAVEN MD sur Render

Cette version transforme `public/index.html` en interface web et ajoute `render-server.js`, un serveur Express qui expose `/code?number=...` et `/healthz`.

## Déploiement

1. Placez le projet dans un dépôt GitHub privé.
2. Dans Render, créez un **Web Service** depuis ce dépôt ou utilisez le Blueprint `render.yaml`.
3. Utilisez `npm ci` comme commande de build et `node render-server.js` comme commande de démarrage.
4. Conservez `token.js` et `.env` uniquement comme variables/secrets du serveur si le reste du bot Telegram est également déployé.
5. Montez un disque persistant sur `/var/data` et définissez `PAIRING_ROOT=/var/data/pairing`.

Le service doit être un processus toujours actif. Un hébergement qui s'endort ou un disque éphémère fera perdre les sessions WhatsApp au redémarrage.

## Vérification

```bash
curl https://VOTRE-SERVICE.onrender.com/healthz
```

Réponse attendue :

```json
{"ok":true,"service":"raven-md-web","pairing":"available"}
```

La page appelle ensuite :

```text
GET /code?number=241xxxxxxxx
```

Le code est généré par Baileys côté serveur. Les identifiants WhatsApp ne sont jamais envoyés au navigateur.

## Sécurité

Ajoutez une authentification ou une limitation de débit avant de rendre `/code` public. Sinon n'importe qui peut demander des tentatives de pairing. Ne commitez jamais `.env`, `token.js` contenant un secret, `creds.json` ou le contenu de `richstore/pairing`.
