'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const S = require("./rimuru-store");
async function handler(sock,m,args,ctx={}){
 const me=S.get(ctx.sender||m.sender,ctx.pushname||m.pushName);
 const reply=(text,opts)=>ctx.reply?ctx.reply(text,opts):sock.sendMessage(ctx.chatId||m.key?.remoteJid,{text,...(opts||{})});
 const amount=Math.max(1,parseInt(args[0])||100);if(me.cash<amount)return reply("❌ Insufficient cash.");const win=Math.random()<.5;me.cash+=win?amount:-amount;S.save();return reply(`${win?"🪙 HEADS — YOU WIN!":"🪙 TAILS — YOU LOSE!"}\n\n${win?"Profit":"Loss"}: *$${S.money(amount)}*\nBalance: *$${S.money(me.cash)}*`);
}
module.exports={command:"coinflip",aliases:['cf'],category:"rpg",description:'Play coin flip with $',handler};
