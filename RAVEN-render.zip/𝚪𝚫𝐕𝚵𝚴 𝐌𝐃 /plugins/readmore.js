/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const more = String.fromCharCode(8206);
const readMore = more.repeat(4001);
module.exports = {
    command: 'readmore',
    aliases: ['rmadd', 'readadd'],
    category: 'tools',
    description: 'Hide text using read more',
    usage: '.readmore text\n.readmore text1|text2',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const text = args.join(' ').trim();
        if (!text) {
            return await sendMessageWithChannel(sock, chatId, { text: 'Usage:\n.readmore text\n.readmore text1|text2' }, { quoted: message });
        }
        let output;
        if (text.includes('|')) {
            const parts = text.split('|');
            const firstPart = parts.shift();
            const rest = parts.join('|');
            output = firstPart + readMore + rest;
        }
        else {
            output = text + readMore;
        }
        await sendMessageWithChannel(sock, chatId, { text: output }, { quoted: message });
    }
};
