/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: 'quote',
    aliases: ['quotes', 'quotetext'],
    category: 'quotes',
    description: 'Get a random quote',
    usage: '.quote',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            const apiKey = 'shizo';
            const res = await fetch(`https://shizoapi.onrender.com/api/texts/quotes?apikey=${apiKey}`);
            if (!res.ok)
                throw await res.text();
            const json = await res.json();
            const quoteMessage = json.result;
            await sendMessageWithChannel(sock, chatId, { text: quoteMessage }, { quoted: message });
        }
        catch (error) {
            console.error('Quote Command Error:', error);
            await sendMessageWithChannel(sock, chatId, {
                text: '❌ Failed to get quote. Please try again later!'
            }, { quoted: message });
        }
    }
};
