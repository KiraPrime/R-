/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');
const path = require('path');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
module.exports = {
    command: 'readqr',
    aliases: ['qrread', 'decodeqr'],
    category: 'tools',
    description: 'Read QR code from an image',
    usage: 'Reply to an image with .readqr',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            if (!quoted?.imageMessage) {
                return await sendMessageWithChannel(sock, chatId, { text: '🧾 *QR Reader*\n\n📌 Reply to an image that contains a QR code\n\nUsage:\n.readqr' }, { quoted: message });
            }
            await sendMessageWithChannel(sock, chatId, {
                react: { text: '🔍', key: message.key }
            });
            const stream = await downloadContentFromMessage(quoted.imageMessage, 'image');
            let buffer = Buffer.from([]);
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }
            const tempFile = path.join(process.cwd(), `qr_${Date.now()}.png`);
            fs.writeFileSync(tempFile, buffer);
            const form = new FormData();
            form.append('apikey', 'guru');
            form.append('image', fs.createReadStream(tempFile));
            const res = await axios.post('https://discardapi.dpdns.org/api/tools/readqr', form, { headers: form.getHeaders(), timeout: 60000 });
            fs.unlinkSync(tempFile);
            if (!res?.data?.status)
                throw new Error('Decode failed');
            await sendMessageWithChannel(sock, chatId, {
                text: `✅ *QR Code Decoded*

📄 *Result:*
\`\`\`
${res.data.result}
\`\`\`

👤 ${res.data.creator}
`
            }, { quoted: message });
        }
        catch (err) {
            console.error('QR Reader Error:', err);
            await sendMessageWithChannel(sock, chatId, { text: '❌ Failed to read QR code. Please try a clearer image.' }, { quoted: message });
        }
    }
};
