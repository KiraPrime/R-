/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const { initConfig } = require('./autoreply.js');
module.exports = {
    command: 'listreplies',
    aliases: ['autoreplies', 'replylist', 'replies'],
    category: 'owner',
    description: 'List all configured auto-reply triggers',
    usage: '.listreplies',
    ownerOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const channelInfo = context.channelInfo || {};
        const config = await initConfig();
        if (config.replies.length === 0) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `📭 *No auto-replies configured yet*\n\nStatus: ${config.enabled ? '✅ Enabled' : '❌ Disabled'}\n\nUse \`.addreply <trigger> | <response>\` to add one!`,
                ...channelInfo
            }, { quoted: message });
        }
        const lines = config.replies.map((r, i) => {
            const preview = r.response.length > 40
                ? `${r.response.substring(0, 40) }...`
                : r.response;
            const matchIcon = r.exactMatch ? '🎯' : '🔍';
            return `${i + 1}. ${matchIcon} *${r.trigger}*\n    ↳ ${preview}`;
        }).join('\n\n');
        await sendMessageWithChannel(sock, chatId, {
            text: `*🤖 AUTO-REPLIES (${config.replies.length})*\n` +
                `*Status:* ${config.enabled ? '✅ Enabled' : '❌ Disabled'}\n\n` +
                `${lines}\n\n` +
                `🎯 = exact match | 🔍 = contains\n` +
                `_Use .delreply <trigger> to remove one_`,
            ...channelInfo
        }, { quoted: message });
    }
};
