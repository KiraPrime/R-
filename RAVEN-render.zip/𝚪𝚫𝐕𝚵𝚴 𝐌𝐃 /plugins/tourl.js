'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const fs     = require('node:fs');
const path   = require('node:path');
const crypto = require('node:crypto');
const { downloadMediaMessage, getContentType, generateWAMessageFromContent, generateWAMessage, proto } = require('@whiskeysockets/baileys');

// ─── Optional deps ────────────────────────────────────────────────
let FormData;
try { FormData = require('form-data'); } catch { FormData = global.FormData; }

let mime;
try { mime = require('mime-types'); } catch { mime = null; }

// ══════════════════════════════════════════════════════════════════
// ─── IMGDROP SCRAPER (inlined) ────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const IMGDROP_BASE    = 'https://imgdrop.web.id';
const IMGDROP_UPLOAD  = `${IMGDROP_BASE}/upload.php`;
const IMGDROP_REFERER = `${IMGDROP_BASE}/?i=1`;

function _randomBoundary() {
    const rand = crypto.randomBytes(12).toString('base64url').replace(/[^a-zA-Z0-9]/g, '');
    return `----WebKitFormBoundary${rand.slice(0, 16)}`;
}

function _guessMime(filename) {
    const ext = path.extname(filename).toLowerCase();
    const map = {
        '.jpg':  'image/jpeg',
        '.jpeg': 'image/jpeg',
        '.png':  'image/png',
        '.webp': 'image/webp',
        '.gif':  'image/gif',
        '.bmp':  'image/bmp',
        '.svg':  'image/svg+xml',
    };
    return map[ext] || 'application/octet-stream';
}

function _toHex(buffer) {
    return Buffer.from(buffer).toString('hex').toLowerCase();
}

function _solveJsChallenge(html) {
    const match = html.match(
        /var a=toNumbers\("([^"]+)"\),b=toNumbers\("([^"]+)"\),c=toNumbers\("([^"]+)"\)/
    );
    if (!match) return '';

    const key       = Buffer.from(match[1], 'hex');
    const iv        = Buffer.from(match[2], 'hex');
    const encrypted = Buffer.from(match[3], 'hex');

    const decipher = crypto.createDecipheriv('aes-128-cbc', key, iv);
    decipher.setAutoPadding(false);

    const decrypted = Buffer.concat([decipher.update(encrypted), decipher.final()]);
    return `__test=${_toHex(decrypted)}`;
}

function _parseSetCookie(headers) {
    const cookies = [];
    if (typeof headers.getSetCookie === 'function') {
        for (const c of headers.getSetCookie()) cookies.push(c.split(';')[0]);
    } else {
        const raw = headers.get('set-cookie');
        if (raw) cookies.push(raw.split(';')[0]);
    }
    return cookies.join('; ');
}

function _mergeCookies(...cookieStrings) {
    const map = new Map();
    for (const str of cookieStrings) {
        if (!str) continue;
        for (const item of str.split('; ')) {
            const [name] = item.split('=');
            if (name) map.set(name, item);
        }
    }
    return [...map.values()].join('; ');
}

async function _getSessionCookie() {
    const manual = process.env.IMGDROP_COOKIE;
    if (manual) return manual;

    const res = await fetch(IMGDROP_REFERER, {
        method: 'GET',
        redirect: 'manual',
        headers: {
            'user-agent':      'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36',
            'accept':          'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'accept-language': 'en-US,en;q=0.9',
        },
    });

    const headerCookie    = _parseSetCookie(res.headers);
    const text            = await res.text();
    const challengeCookie = _solveJsChallenge(text);
    return _mergeCookies(headerCookie, challengeCookie);
}

function _createMultipartBody({ fieldName, filename, mime: mimeType, fileBuffer, boundary }) {
    const head = Buffer.from(
        `--${boundary}\r\n` +
        `Content-Disposition: form-data; name="${fieldName}"; filename="${filename}"\r\n` +
        `Content-Type: ${mimeType}\r\n\r\n`,
        'utf8'
    );
    const tail = Buffer.from(`\r\n--${boundary}--\r\n`, 'utf8');
    return Buffer.concat([head, fileBuffer, tail]);
}

async function _requestUpload(fileBuffer, filename, cookie = '') {
    const mimeType = _guessMime(filename);
    const boundary = _randomBoundary();

    const body = _createMultipartBody({
        fieldName:  'file',
        filename,
        mime:       mimeType,
        fileBuffer,
        boundary,
    });

    const headers = {
        'user-agent':         'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36',
        'accept':             '*/*',
        'accept-language':    'en-US,en;q=0.9',
        'content-type':       `multipart/form-data; boundary=${boundary}`,
        'content-length':     String(body.length),
        'origin':             IMGDROP_BASE,
        'referer':            IMGDROP_REFERER,
        'sec-ch-ua-platform': '"Android"',
        'sec-ch-ua':          '"Google Chrome";v="147", "Not.A/Brand";v="8", "Chromium";v="147"',
        'sec-ch-ua-mobile':   '?1',
        'sec-fetch-site':     'same-origin',
        'sec-fetch-mode':     'cors',
        'sec-fetch-dest':     'empty',
        'priority':           'u=1, i',
    };
    if (cookie) headers.cookie = cookie;

    const res = await fetch(IMGDROP_UPLOAD, {
        method:   'POST',
        redirect: 'manual',
        headers,
        body,
    });
    const responseText = await res.text();
    return { res, responseText, cookie };
}

async function uploadImage(buffer, filename) {
    let cookie = await _getSessionCookie();
    let result = await _requestUpload(buffer, filename, cookie);

    if (result.responseText.includes('slowAES.decrypt') || result.responseText.includes('__test=')) {
        const challengeCookie = _solveJsChallenge(result.responseText);
        if (challengeCookie) {
            cookie = _mergeCookies(cookie, challengeCookie);
            result = await _requestUpload(buffer, filename, cookie);
        }
    }

    let json = null;
    try { json = JSON.parse(result.responseText); } catch {}

    return {
        status:   result.res.ok && Boolean(json?.success),
        code:     result.res.status,
        url:      json?.url      || '',
        size:     json?.size     || '',
        filename: json?.filename || '',
    };
}

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function lookupMime(filename) {
    if (mime?.lookup) return mime.lookup(filename) || 'application/octet-stream';
    return _guessMime(filename);
}

function getFileExtension(mimetype) {
    const map = {
        'image/jpeg':      'jpg',
        'image/png':       'png',
        'image/gif':       'gif',
        'image/webp':      'webp',
        'video/mp4':       'mp4',
        'video/3gpp':      '3gp',
        'video/quicktime': 'mov',
        'audio/mpeg':      'mp3',
        'audio/ogg':       'ogg',
        'audio/wav':       'wav',
        'audio/mp4':       'm4a',
        'application/pdf': 'pdf',
        'application/zip': 'zip',
    };
    return map[mimetype] || 'bin';
}

// ══════════════════════════════════════════════════════════════════
// ─── UPLOADERS ────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════

// ─── ImgDrop ──────────────────────────────────────────────────────
async function uploadToImgDrop(buffer, filename) {
    const data = await uploadImage(buffer, filename);
    if (!data.status || !data.url) throw new Error('ImgDrop failed');
    return { host: 'ImgDrop', url: data.url, expires: 'Permanent' };
}

// ─── Catbox (permanent) ───────────────────────────────────────────
async function uploadToCatbox(buffer, filename) {
    const form = new FormData();
    form.append('reqtype', 'fileupload');
    form.append('fileToUpload', buffer, { filename, contentType: lookupMime(filename) });

    const res = await fetch('https://catbox.moe/user/api.php', {
        method:  'POST',
        body:    form,
        headers: form.getHeaders ? form.getHeaders() : {},
    });

    if (!res.ok) throw new Error('Catbox failed');
    const url = (await res.text()).trim();
    if (!url.startsWith('http')) throw new Error('Invalid response');
    return { host: 'Catbox', url, expires: 'Permanent' };
}

// ─── Pone.rs ──────────────────────────────────────────────────────
async function uploadToPone(buffer, filename) {
    const form = new FormData();
    form.append('files[]', buffer, { filename, contentType: lookupMime(filename) });

    const res = await fetch('https://pone.rs/upload.php', {
        method:  'POST',
        body:    form,
        headers: {
            ...(form.getHeaders ? form.getHeaders() : {}),
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36',
            'accept':     '*/*',
            'origin':     'https://pone.rs',
            'referer':    'https://pone.rs/',
        },
    });

    if (!res.ok) throw new Error('Pone failed');
    const data = await res.json();
    const url  = data?.files?.[0]?.url?.replaceAll('\\/', '/') || null;
    if (!data?.success || !url) throw new Error('Invalid response');
    return { host: 'Pone', url, expires: 'Permanent' };
}

// ─── Kappa.lol ────────────────────────────────────────────────────
async function uploadToKappa(buffer, filename) {
    const form = new FormData();
    form.append('file', buffer, { filename, contentType: lookupMime(filename) });

    const res = await fetch('https://kappa.lol/api/upload', {
        method:  'POST',
        body:    form,
        headers: {
            ...(form.getHeaders ? form.getHeaders() : {}),
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36',
            'Origin':     'https://kappa.lol',
            'Referer':    'https://kappa.lol/',
        },
    });

    if (!res.ok) throw new Error('Kappa failed');
    const data = JSON.parse(await res.text());
    if (!data?.link) throw new Error('Invalid response');
    return { host: 'Kappa', url: data.link, expires: 'Permanent' };
}

// ─── Uguu.se (48h) ────────────────────────────────────────────────
async function uploadToUguu(buffer, filename) {
    const form = new FormData();
    form.append('files[]', buffer, { filename, contentType: lookupMime(filename) });

    const res = await fetch('https://uguu.se/upload.php', {
        method:  'POST',
        body:    form,
        headers: {
            ...(form.getHeaders ? form.getHeaders() : {}),
            'origin':     'https://uguu.se',
            'referer':    'https://uguu.se/',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36',
        },
    });

    if (!res.ok) throw new Error('Uguu failed');
    const data = await res.json();
    if (!data?.success || !data?.files?.[0]?.url) throw new Error('Invalid response');
    return { host: 'Uguu', url: data.files[0].url, expires: '48h' };
}

// ─── Qu.ax ────────────────────────────────────────────────────────
async function uploadToQuax(buffer, filename) {
    const form = new FormData();
    form.append('file', buffer, { filename, contentType: lookupMime(filename) });

    const res = await fetch('https://qu.ax/upload.php', {
        method:  'POST',
        body:    form,
        headers: form.getHeaders ? form.getHeaders() : {},
    });

    if (!res.ok) throw new Error('Qu.ax failed');
    const data = await res.json();
    if (!data?.success || !data?.files?.[0]?.url) throw new Error('Invalid response');
    return { host: 'Qu.ax', url: data.files[0].url, expires: 'Permanent' };
}

// ─── Nekohime ─────────────────────────────────────────────────────
async function uploadToNekohime(buffer, filename) {
    const form = new FormData();
    form.append('file', buffer, { filename, contentType: lookupMime(filename) });

    const res = await fetch('https://cdn.nekohime.site/upload', {
        method:  'POST',
        body:    form,
        headers: form.getHeaders ? form.getHeaders() : {},
    });

    if (!res.ok) throw new Error('Nekohime failed');
    const data = await res.json();
    const url  = data?.files?.[0]?.url || data?.files?.url || (Array.isArray(data?.files) ? data.files[0] : data.files);
    if (!url) throw new Error('Nekohime failed');
    return { host: 'Nekohime', url, expires: 'Permanent' };
}

// ─── Faddlaninco ──────────────────────────────────────────────────
async function uploadToFaddlaninco(buffer, filename) {
    const form = new FormData();
    form.append('file', buffer, { filename, contentType: lookupMime(filename) });

    const res = await fetch('https://cdn.faddlaninco.dev/api/upload', {
        method:  'POST',
        body:    form,
        headers: form.getHeaders ? form.getHeaders() : {},
    });

    if (!res.ok) throw new Error('Faddlaninco failed');
    const data = await res.json();
    if (!data.success || !data.url) throw new Error(data.error || 'Faddlaninco failed');
    return { host: 'Faddlaninco', url: data.url, expires: 'Permanent' };
}

// ─── Unggah.web.id ────────────────────────────────────────────────
async function uploadToUnggah(buffer, filename) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let randomPart = '';
    for (let i = 0; i < 16; i++) randomPart += chars.charAt(Math.floor(Math.random() * chars.length));
    const boundary = `WebKitFormBoundary${randomPart}`;

    const contentType = lookupMime(filename);
    const head = Buffer.from(
        `------${boundary}\r\n` +
        `Content-Disposition: form-data; name="file"; filename="${filename}"\r\n` +
        `Content-Type: ${contentType}\r\n\r\n`
    );
    const tail = Buffer.from(`\r\n------${boundary}--\r\n`);
    const body = Buffer.concat([head, buffer, tail]);

    const res = await fetch('https://unggah.web.id/api/unggah', {
        method:  'POST',
        headers: {
            'content-type': `multipart/form-data; boundary=----${boundary}`,
            'accept':       '*/*',
            'origin':       'https://unggah.web.id',
            'referer':      'https://unggah.web.id/pengunggah',
            'user-agent':   'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36',
        },
        body,
    });

    if (!res.ok) throw new Error('Unggah failed');
    const data = await res.json();
    if (!data?.url) throw new Error('Invalid response');
    return { host: 'Unggah', url: data.url, expires: 'Permanent' };
}

// ══════════════════════════════════════════════════════════════════
// ─── UPLOADERS LIST ───────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const UPLOADERS = [
    { name: 'ImgDrop',     fn: uploadToImgDrop },
    { name: 'Catbox',      fn: uploadToCatbox },
    { name: 'Pone',        fn: uploadToPone },
    { name: 'Kappa',       fn: uploadToKappa },
    { name: 'Uguu',        fn: uploadToUguu },
    { name: 'Qu.ax',       fn: uploadToQuax },
    { name: 'Nekohime',    fn: uploadToNekohime },
    { name: 'Faddlaninco', fn: uploadToFaddlaninco },
    { name: 'Unggah',      fn: uploadToUnggah },
];

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'tourl',
    aliases:     ['upload', 'url'],
    category:    'tools',
    description: 'Upload media to multiple hosts and get URLs — © 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
    usage:       '.tourl (reply/send media)',

    async handler(sock, message, args, context) {
        const { chatId, reply, prefix, command } = context;

        let media    = null;
        let mimetype = null;
        let filename = 'file';

        // ── Case 1: reply to a message ────────────────────
        const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        if (quoted) {
            const type = getContentType(quoted);
            if (!type || type === 'conversation' || type === 'extendedTextMessage') {
                return reply('⚠️ Please reply to a media file (image / video / audio / document).');
            }

            try {
                media = await downloadMediaMessage(
                    { key: message.key, message: quoted },
                    'buffer',
                    {},
                    { reuploadRequest: sock.updateMediaMessage }
                );
                const content = quoted[type];
                mimetype = content?.mimetype || 'application/octet-stream';
                filename = content?.fileName || `file.${getFileExtension(mimetype)}`;
            } catch (e) {
                console.error('[TOURL] reply download failed:', e?.message);
                return reply('❌ Failed to download the replied media.');
            }
        }
        // ── Case 2: direct media sent with caption ────────
        else {
            const type = getContentType(message.message);
            if (!type || type === 'conversation' || type === 'extendedTextMessage') {
                return reply(
                    `📤 *MEDIA UPLOADER*\n\n` +
                    `> Send media with the caption \`${prefix}${command}\`\n` +
                    `> Or reply to a media with \`${prefix}${command}\``
                );
            }

            try {
                media = await downloadMediaMessage(
                    message,
                    'buffer',
                    {},
                    { reuploadRequest: sock.updateMediaMessage }
                );
                const content = message.message[type];
                mimetype = content?.mimetype || 'application/octet-stream';
                filename = content?.fileName || `file.${getFileExtension(mimetype)}`;
            } catch (e) {
                console.error('[TOURL] direct download failed:', e?.message);
                return reply('❌ Failed to download the media.');
            }
        }

        if (!media || media.length === 0) {
            return reply('❌ Media could not be read. Try sending it again.');
        }

        await sock.sendMessage(chatId, { react: { text: '🕕', key: message.key } }).catch(() => {});

        // ── Upload to all hosts ───────────────────────────
        const results = [];
        const failed  = [];

        for (const uploader of UPLOADERS) {
            try {
                const result = await uploader.fn(media, filename);
                results.push(result);
            } catch (e) {
                console.error(`[TOURL] ${uploader.name} failed:`, e?.message);
                failed.push(uploader.name);
            }
        }

        if (results.length === 0) {
            await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } }).catch(() => {});
            return reply(`❌ All uploads failed.\n\n> Failed hosts: ${failed.join(', ')}`);
        }

        // ── Build result text ─────────────────────────────
        let text = `🚀 *UPLOAD SUCCESSFUL!*\n\n`;
        text += `Your media has been uploaded. Pick a link below:\n\n`;

        results.forEach((r, i) => {
            const status = r.expires === 'Permanent' ? '∞ Permanent' : r.expires;
            text += `☁️ *Host:* ${r.host}\n`;
            text += `⏳ *Expires:* ${status}\n`;
            text += `🔗 *URL:* ${r.url}`;
            if (i < results.length - 1) text += `\n\n`;
        });

        if (failed.length > 0) {
            text += `\n\n⚠️ _Failed on: ${failed.join(', ')}_`;
        }

        // ── Try interactive message with copy buttons ─────
        try {
            let headerMedia = null;
            if (mimetype.startsWith('image') || mimetype.startsWith('video')) {
                const mediaKey = mimetype.startsWith('image') ? 'image' : 'video';
                const preMsg = await generateWAMessage(
                    chatId,
                    { [mediaKey]: media },
                    { userJid: sock.user.id }
                );
                headerMedia = mimetype.startsWith('image')
                    ? { imageMessage: preMsg.message.imageMessage }
                    : { videoMessage: preMsg.message.videoMessage };
            }

            const msg = generateWAMessageFromContent(chatId, {
                viewOnceMessage: {
                    message: {
                        messageContextInfo: {
                            deviceListMetadata: {},
                            deviceListMetadataVersion: 2,
                        },
                        interactiveMessage: proto.Message.InteractiveMessage.create({
                            body:   proto.Message.InteractiveMessage.Body.create({ text }),
                            footer: proto.Message.InteractiveMessage.Footer.create({ text: global.botName || '𝚪𝚫𝐕𝚵𝚴 𝐌𝐃' }),
                            header: proto.Message.InteractiveMessage.Header.create({
                                title: 'T O U R L',
                                hasMediaAttachment: !!headerMedia,
                                ...(headerMedia || {}),
                            }),
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                buttons: results.slice(0, 5).map((r, i) => ({
                                    name: 'cta_copy',
                                    buttonParamsJson: JSON.stringify({
                                        display_text: `📋 Copy ${r.host}`,
                                        id: `copy_${i}`,
                                        copy_code: r.url,
                                    }),
                                })),
                            }),
                        }),
                    },
                },
            }, { quoted: message });

            await sock.relayMessage(chatId, msg.message, { messageId: msg.key.id });
        } catch (err) {
            console.error('[TOURL] interactive failed:', err?.message);
            await reply(text);
        }

        await sock.sendMessage(chatId, { react: { text: '✅', key: message.key } }).catch(() => {});
    },
};