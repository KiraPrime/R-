'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const axios = require('axios');

// ══════════════════════════════════════════════════════════════════
// ─── FORWARD NEWSLETTER CONTEXT ───────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── CONFIG ───────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const CFG = {
    apiBase: 'https://kyzznekoo.zone.id/api/alightmotion/download',
    timeout: 60000,
    ua:      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',
};

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {}
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'amdl',
    aliases:     ['alightmotiondl', 'alight', 'amlink'],
    category:    'downloader',
    description: 'Download an Alight Motion preset / project',
    usage:       '.amdl <alight_link>',

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix } = context;

        const text = (args.join(' ') || '').trim();

        // ── No arg → help ─────────────────────────────────────────
        if (!text) {
            return reply(
                `📥 *ALIGHT MOTION DOWNLOADER*\n\n` +
                `> Download a project or preset from Alight Motion.\n\n` +
                `*Usage:*\n` +
                `> \`${prefix}amdl <alight_link>\`\n\n` +
                `*Example:*\n` +
                `> \`${prefix}amdl https://alight.link/xxxxx\``,
            );
        }

        await react(sock, chatId, m.key, '🕕');

        try {
            const apiUrl =
                `${CFG.apiBase}?url=${encodeURIComponent(text)}`;

            const response = await axios.get(apiUrl, {
                headers: {
                    'User-Agent': CFG.ua,
                    'Content-Type': 'application/json',
                },
                timeout: CFG.timeout,
            });

            const data = response.data;

            if (!data?.status || !data?.data?.url) {
                await react(sock, chatId, m.key, '❌');
                return reply(
                    `❌ *DOWNLOAD FAILED*\n\n` +
                    `> The Alight Motion link is invalid or the project has been deleted.`,
                );
            }

            const downloadUrl = data.data.url;
            const botName = (global.botName || 'Raven').replace(/[^a-zA-Z0-9_-]/g, '_');

            await sendMessageWithChannel(sock, chatId, {
                document: { url: downloadUrl },
                mimetype: 'application/zip',
                fileName: `AlightMotion_${botName}.zip`,
                caption:  `✅ Successfully downloaded the Alight Motion preset!`,
            }, { quoted: m });

            await react(sock, chatId, m.key, '✅');

        } catch (error) {
            console.error('[AMDL]', error?.message || error);
            await react(sock, chatId, m.key, '☢');
            return reply(global.mess?.error?.fitur || 'Alight Motion download failed.');
        }
    },
};