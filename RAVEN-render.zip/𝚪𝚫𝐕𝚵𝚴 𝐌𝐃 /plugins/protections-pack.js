'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const fs   = require('fs');
const path = require('path');

// ══════════════════════════════════════════════════════════════════
// ─── FORWARD NEWSLETTER CONTEXT ───────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── STORE (auto-created) ─────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const DATA_DIR   = path.join(__dirname, 'protections-data');
const STORE_PATH = path.join(DATA_DIR, 'store.json');

const DEFAULT_STORE = { groups: {} };

let _store = null;
let _saveTimer = null;

function ensureDir() {
    try { if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true }); }
    catch (e) { console.error('[PROTECTIONS] mkdir failed:', e?.message); }
}

function loadStore() {
    ensureDir();
    try {
        if (fs.existsSync(STORE_PATH)) {
            const raw = fs.readFileSync(STORE_PATH, 'utf8').trim();
            if (raw) {
                const parsed = JSON.parse(raw);
                _store = { groups: { ...(parsed.groups || {}) } };
                return _store;
            }
        }
    } catch (e) {
        console.error('[PROTECTIONS] corrupted, rebuilding:', e?.message);
        try {
            const backup = STORE_PATH + '.corrupted.' + Date.now() + '.bak';
            if (fs.existsSync(STORE_PATH)) fs.copyFileSync(STORE_PATH, backup);
        } catch {}
    }
    _store = JSON.parse(JSON.stringify(DEFAULT_STORE));
    writeStoreSync();
    return _store;
}

function writeStoreSync() {
    try {
        ensureDir();
        const tmp = STORE_PATH + '.tmp';
        fs.writeFileSync(tmp, JSON.stringify(_store, null, 2), 'utf8');
        fs.renameSync(tmp, STORE_PATH);
    } catch (e) { console.error('[PROTECTIONS] write failed:', e?.message); }
}

function scheduleSave() {
    if (_saveTimer) clearTimeout(_saveTimer);
    _saveTimer = setTimeout(() => { _saveTimer = null; writeStoreSync(); }, 500);
    if (_saveTimer.unref) _saveTimer.unref();
}

function getSetting(jid, key, def = null) {
    if (!_store) loadStore();
    const g = _store.groups?.[jid];
    if (!g) return def;
    const v = g[key];
    return v === undefined ? def : v;
}

function setSetting(jid, key, value) {
    if (!_store) loadStore();
    if (!_store.groups[jid]) _store.groups[jid] = {};
    _store.groups[jid][key] = value;
    scheduleSave();
}

loadStore();
process.on('exit', () => { try { writeStoreSync(); } catch {} });
process.on('SIGINT', () => { try { writeStoreSync(); } catch {} process.exit(0); });

// ══════════════════════════════════════════════════════════════════
// ─── TOXIC WORDS ──────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const DEFAULT_TOXIC_WORDS = [
    // English
    'fuck', 'shit', 'bitch', 'bastard', 'asshole', 'dick',
    'cunt', 'whore', 'slut', 'retard', 'moron', 'idiot',
    'stupid', 'dumbass', 'jackass', 'prick',
    // French
    'connard', 'salope', 'putain', 'merde', 'enculé', 'bordel',
    'fdp', 'ntm', 'pd', 'batard',
];

function isToxic(text, toxicList) {
    if (!text || typeof text !== 'string') return { toxic: false, word: null };
    const lowerText = text.toLowerCase().trim();
    if (!lowerText) return { toxic: false, word: null };

    const words = (toxicList && toxicList.length > 0) ? toxicList : DEFAULT_TOXIC_WORDS;

    for (const word of words) {
        if (!word) continue;
        const lowerWord = word.toLowerCase().trim();
        if (!lowerWord) continue;

        const escapedWord = lowerWord.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const regex = new RegExp(`(^|\\s|[^a-zA-Z0-9])${escapedWord}($|\\s|[^a-zA-Z0-9])`, 'i');
        if (regex.test(lowerText)) return { toxic: true, word };
    }
    return { toxic: false, word: null };
}

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function numOf(jid) {
    if (!jid) return '';
    return String(jid).split(':')[0].split('@')[0].replace(/[^0-9]/g, '');
}

function getParticipantJid(p) {
    if (!p) return '';
    if (p.jid && !p.jid.endsWith('@lid')) return p.jid;
    if (p.phoneNumber && !p.phoneNumber.endsWith('@lid')) return p.phoneNumber;
    if (p.id && !p.id.endsWith('@lid')) return p.id;
    const raw = p.id || p.jid || p.lid || '';
    return raw.endsWith('@lid') ? raw.replace('@lid', '@s.whatsapp.net') : raw;
}

function getMessageText(raw) {
    return (
        raw?.message?.conversation ||
        raw?.message?.extendedTextMessage?.text ||
        raw?.message?.imageMessage?.caption ||
        raw?.message?.videoMessage?.caption ||
        raw?.message?.documentMessage?.caption ||
        ''
    );
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch { /* ignore */ }
}

async function deleteMessage(sock, chatJid, raw) {
    try {
        await sock.sendMessage(chatJid, { delete: raw.key });
        return true;
    } catch {
        try {
            await sock.sendMessage(chatJid, {
                delete: {
                    remoteJid: chatJid,
                    fromMe: false,
                    id: raw.key.id,
                    participant: raw.key.participant || raw.key.remoteJid,
                },
            });
            return true;
        } catch { return false; }
    }
}

// ══════════════════════════════════════════════════════════════════
// ─── COMMAND HANDLERS ─────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function cmdGenericToggle(sock, m, args, context, opts) {
    const { chatId, reply, isGroup, isOwner, isAdmin } = context;
    const { key, label, helpText } = opts;

    if (!isGroup) return reply(global.mess?.only?.group || 'Group only.');
    if (!isAdmin && !isOwner) return reply(global.mess?.only?.admin || 'Admin only.');

    const action = (args[0] || '').toLowerCase();

    if (!action) {
        const status = getSetting(chatId, key, 'off');
        return reply(
            `${label}\n\n` +
            `> Status: *${String(status).toUpperCase()}*\n\n` +
            `${helpText}`,
        );
    }

    if (action === 'on') {
        setSetting(chatId, key, 'on');
        await react(sock, chatId, m.key, '✅');
        return reply(`✅ *${key} ENABLED*`);
    }

    if (action === 'off') {
        setSetting(chatId, key, 'off');
        await react(sock, chatId, m.key, '❌');
        return reply(`❌ *${key} DISABLED*`);
    }

    return reply(`❌ Invalid option. Use \`on\` or \`off\`.`);
}

async function cmdAntiToxic(sock, m, args, context) {
    const { chatId, reply, isGroup, isOwner, isAdmin, prefix } = context;

    if (!isGroup) return reply(global.mess?.only?.group || 'Group only.');
    if (!isAdmin && !isOwner) return reply(global.mess?.only?.admin || 'Admin only.');

    const sub = (args[0] || '').toLowerCase();

    if (!sub) {
        const status  = getSetting(chatId, 'antitoxic', false) ? '✅ ON' : '❌ OFF';
        const warnMax = getSetting(chatId, 'toxicMaxWarn', 3);
        const method  = getSetting(chatId, 'toxicMethod', 'kick');
        return reply(
            `🛡️ *ANTITOXIC*\n\n` +
            `> Status: *${status}*\n` +
            `> Max warnings: *${warnMax}*\n` +
            `> Method: *${method}*\n\n` +
            `*Commands:*\n` +
            `> \`${prefix}antitoxic on/off\`\n` +
            `> \`${prefix}antitoxic warn <1-10>\`\n` +
            `> \`${prefix}antitoxic method kick/delete\``,
        );
    }

    if (sub === 'on') {
        setSetting(chatId, 'antitoxic', true);
        await react(sock, chatId, m.key, '✅');
        return reply(`✅ *ANTITOXIC ENABLED*`);
    }
    if (sub === 'off') {
        setSetting(chatId, 'antitoxic', false);
        await react(sock, chatId, m.key, '❌');
        return reply(`❌ *ANTITOXIC DISABLED*`);
    }
    if (sub === 'warn') {
        const count = parseInt(args[1], 10);
        if (!count || count < 1 || count > 10) {
            return reply(`❌ Enter a number 1-10\n> Example: \`${prefix}antitoxic warn 5\``);
        }
        setSetting(chatId, 'toxicMaxWarn', count);
        await react(sock, chatId, m.key, '✅');
        return reply(`✅ Max warnings set to *${count}*`);
    }
    if (['method', 'metode', 'mode'].includes(sub)) {
        const method = (args[1] || '').toLowerCase();
        if (!['kick', 'delete'].includes(method)) {
            return reply(`❌ Choose method: *kick* or *delete*`);
        }
        setSetting(chatId, 'toxicMethod', method);
        await react(sock, chatId, m.key, '✅');
        return reply(`✅ Method set to *${method}*`);
    }

    return reply(`❌ Unknown sub-command. Type \`${prefix}antitoxic\` to see commands.`);
}

// ══════════════════════════════════════════════════════════════════
// ─── EVENT HOOK: messages.upsert ──────────────────────────────────
// ══════════════════════════════════════════════════════════════════
let _bound = false;
let _boundSock = null;

const _toxicWarns = new Map();

async function handleMessage(sock, raw) {
    try {
        const chatJid = raw?.key?.remoteJid || '';
        if (!chatJid.endsWith('@g.us')) return;
        if (raw?.key?.fromMe) return;

        const meta = await sock.groupMetadata(chatJid).catch(() => null);
        if (!meta || !Array.isArray(meta.participants)) return;

        const sender = raw.key.participant || raw.key.remoteJid || '';
        const senderNum = numOf(sender);
        const senderP = meta.participants.find(p => numOf(getParticipantJid(p)) === senderNum);
        const senderIsAdmin = ['admin', 'superadmin'].includes(senderP?.admin);

        const botNum = numOf(sock.user?.id);
        const botP = meta.participants.find(p => numOf(getParticipantJid(p)) === botNum);
        const botIsAdmin = ['admin', 'superadmin'].includes(botP?.admin);

        if (senderIsAdmin) return;

        const body = getMessageText(raw);
        const msgType = Object.keys(raw.message || {})[0] || '';

        // 1. ANTITOXIC
        if (getSetting(chatJid, 'antitoxic', false) === true && body) {
            const toxicWords = getSetting(chatJid, 'toxicWords', null);
            const { toxic } = isToxic(body, toxicWords);
            if (toxic) {
                if (botIsAdmin) await deleteMessage(sock, chatJid, raw);

                const key = `${chatJid}_${senderNum}`;
                const warnMax = getSetting(chatJid, 'toxicMaxWarn', 3);
                const method  = getSetting(chatJid, 'toxicMethod', 'kick');
                const warn = (_toxicWarns.get(key) || 0) + 1;
                _toxicWarns.set(key, warn);

                const tag = senderNum;

                if (warn >= warnMax) {
                    if (method === 'kick' && botIsAdmin) {
                        try {
                            await sock.groupParticipantsUpdate(chatJid, [sender], 'remove');
                            await sendMessageWithChannel(sock, chatJid, {
                                text: `🚫 @${tag} was kicked for toxic behaviour. (${warn}/${warnMax})`,
                                mentions: [sender],
                            });
                        } catch { /* ignore */ }
                    } else {
                        await sendMessageWithChannel(sock, chatJid, {
                            text: `🚫 @${tag} — toxic behaviour detected. (${warn}/${warnMax})`,
                            mentions: [sender],
                        });
                    }
                    _toxicWarns.delete(key);
                } else {
                    await sendMessageWithChannel(sock, chatJid, {
                        text: `⚠️ @${tag} said something rude.\nWarning ${warn}/${warnMax}, next one may lead to ${method}.`,
                        mentions: [sender],
                    });
                }
                return;
            }
        }

        // 2. ANTITAGSW
        if (getSetting(chatJid, 'antitagsw', 'off') === 'on') {
            const isStatusTag =
                raw.message?.groupStatusMentionMessage ||
                raw.message?.extendedTextMessage?.contextInfo?.groupStatusMentionMessage;
            if (isStatusTag) {
                if (botIsAdmin) await deleteMessage(sock, chatJid, raw);
                return;
            }
        }

        // 3. ANTISWGC
        if (getSetting(chatJid, 'antiswgc', 'off') === 'on') {
            const ctx = raw.message?.extendedTextMessage?.contextInfo || {};
            const isSW =
                raw.message?.groupMentionedMessage ||
                raw.message?.statusMentionMessage ||
                ctx.groupMentions ||
                ctx.groupStatusMentionMessage;
            if (isSW) {
                if (botIsAdmin) await deleteMessage(sock, chatJid, raw);
                return;
            }
        }

        // 4. ANTISTICKER
        if (getSetting(chatJid, 'antisticker', false) === true) {
            if (msgType === 'stickerMessage') {
                if (botIsAdmin) await deleteMessage(sock, chatJid, raw);
                await sendMessageWithChannel(sock, chatJid, {
                    text: `⚠️ Stickers are not allowed here. @${senderNum}`,
                    mentions: [sender],
                });
                return;
            }
        }

        // 5. ANTIMEDIA
        if (getSetting(chatJid, 'antimedia', false) === true) {
            const isMedia = ['imageMessage', 'videoMessage', 'audioMessage', 'documentMessage', 'stickerMessage'].includes(msgType);
            if (isMedia) {
                if (botIsAdmin) await deleteMessage(sock, chatJid, raw);
                await sendMessageWithChannel(sock, chatJid, {
                    text: `⚠️ Media is not allowed here. @${senderNum}`,
                    mentions: [sender],
                });
                return;
            }
        }

        // 6. ANTIDOCUMENT
        if (getSetting(chatJid, 'antidocument', false) === true) {
            const isDoc = ['documentMessage', 'documentWithCaptionMessage'].includes(msgType);
            if (isDoc) {
                if (botIsAdmin) await deleteMessage(sock, chatJid, raw);
                await sendMessageWithChannel(sock, chatJid, {
                    text: `⚠️ Documents are not allowed here. @${senderNum}`,
                    mentions: [sender],
                });
                return;
            }
        }

    } catch (e) {
        console.error('[PROTECTIONS-EVENT]', e?.message);
    }
}

// ─── Protocol message hook (antiremove) ───────────────────────────
async function handleProtocolMessage(sock, raw) {
    try {
        const chatJid = raw?.key?.remoteJid || '';
        if (!chatJid.endsWith('@g.us')) return;

        const proto = raw?.message?.protocolMessage;
        if (!proto || proto.type !== 0) return;

        const enabled = getSetting(chatJid, 'antiremove', 'off');
        if (enabled !== 'on') return;

        const sender = proto.key?.participant || proto.key?.remoteJid || '';
        const tag = numOf(sender);

        await sendMessageWithChannel(sock, chatJid, {
            text: `🗑️ A message was deleted by @${tag}.`,
            mentions: sender ? [sender] : [],
        });
    } catch (e) {
        console.error('[ANTIREMOVE]', e?.message);
    }
}

async function onMessagesUpsert(payload) {
    const sock = _boundSock;
    if (!sock) return;
    const messages = Array.isArray(payload?.messages) ? payload.messages : [];
    for (const raw of messages) {
        if (!raw?.message || !raw?.key) continue;

        const chatJid = raw.key.remoteJid || '';
        if (!chatJid.endsWith('@g.us')) continue;

        const body = getMessageText(raw);
        const prefix = global.xprefix || '.';
        if (body && body.startsWith(prefix)) continue;

        if (raw.message.protocolMessage) {
            await handleProtocolMessage(sock, raw);
            continue;
        }

        if (raw.key.fromMe) continue;
        await handleMessage(sock, raw);
    }
}

function bindSock(sock) {
    if (_bound || !sock || !sock.ev) return;
    _bound = true;
    _boundSock = sock;
    try {
        sock.ev.on('messages.upsert', onMessagesUpsert);
        console.log('[PROTECTIONS] event hook registered');
    } catch (e) {
        console.error('[PROTECTIONS] failed to bind:', e?.message);
        _bound = false;
    }
}

function tryBindFromGlobals() {
    const candidates = [global.sock, global.conn, global.Hanz, global.client];
    for (const c of candidates) {
        if (c && c.ev) { bindSock(c); return; }
    }
}

tryBindFromGlobals();
let _retryCount = 0;
const _retryTimer = setInterval(() => {
    if (_bound) return clearInterval(_retryTimer);
    if (++_retryCount >= 10) return clearInterval(_retryTimer);
    tryBindFromGlobals();
}, 3000);
if (_retryTimer.unref) _retryTimer.unref();

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'antitoxic',
    aliases:     [
        'toxic', 'antitoxik',
        'antitagsw', 'antitag', 'antistatustag',
        'antiswgc', 'antiswgroup', 'antiswmentiongc', 'antiswtaggc',
        'antisticker', 'as', 'nosticker',
        'antiremove', 'antidelete',
        'antimedia', 'am', 'nomedia',
        'antidocument', 'antidoc', 'nodocument', 'nodoc',
    ],
    category:    'group',
    description: 'Group content protections (toxic, sticker, media, doc, tagsw, swgc, antiremove)',
    usage:       'Various — see .antitoxic for the entry point',

    async handler(sock, m, args, context) {
        if (!_bound) bindSock(sock);

        const cmd = (context.command || '').toLowerCase();

        try {
            if (['antitoxic', 'toxic', 'antitoxik'].includes(cmd)) {
                return cmdAntiToxic(sock, m, args, context);
            }

            const TOGGLES = {
                antitagsw:       { key: 'antitagsw',   label: '📢 *ANTITAGSW*',    helpText: `> \`${context.prefix}antitagsw on/off\`` },
                antitag:         { key: 'antitagsw',   label: '📢 *ANTITAGSW*',    helpText: `> \`${context.prefix}antitagsw on/off\`` },
                antistatustag:   { key: 'antitagsw',   label: '📢 *ANTITAGSW*',    helpText: `> \`${context.prefix}antitagsw on/off\`` },

                antiswgc:        { key: 'antiswgc',    label: '📡 *ANTISWGC*',     helpText: `> \`${context.prefix}antiswgc on/off\`` },
                antiswgroup:     { key: 'antiswgc',    label: '📡 *ANTISWGC*',     helpText: `> \`${context.prefix}antiswgc on/off\`` },
                antiswmentiongc: { key: 'antiswgc',    label: '📡 *ANTISWGC*',     helpText: `> \`${context.prefix}antiswgc on/off\`` },
                antiswtaggc:     { key: 'antiswgc',    label: '📡 *ANTISWGC*',     helpText: `> \`${context.prefix}antiswgc on/off\`` },

                antisticker:     { key: 'antisticker', label: '🎭 *ANTISTICKER*',  helpText: `> \`${context.prefix}antisticker on/off\`` },
                as:              { key: 'antisticker', label: '🎭 *ANTISTICKER*',  helpText: `> \`${context.prefix}antisticker on/off\`` },
                nosticker:       { key: 'antisticker', label: '🎭 *ANTISTICKER*',  helpText: `> \`${context.prefix}antisticker on/off\`` },

                antiremove:      { key: 'antiremove',  label: '🗑️ *ANTIREMOVE*',   helpText: `> \`${context.prefix}antiremove on/off\`` },
                antidelete:      { key: 'antiremove',  label: '🗑️ *ANTIREMOVE*',   helpText: `> \`${context.prefix}antiremove on/off\`` },

                antimedia:       { key: 'antimedia',   label: '🖼️ *ANTIMEDIA*',    helpText: `> \`${context.prefix}antimedia on/off\`` },
                am:              { key: 'antimedia',   label: '🖼️ *ANTIMEDIA*',    helpText: `> \`${context.prefix}antimedia on/off\`` },
                nomedia:         { key: 'antimedia',   label: '🖼️ *ANTIMEDIA*',    helpText: `> \`${context.prefix}antimedia on/off\`` },

                antidocument:    { key: 'antidocument', label: '📄 *ANTIDOCUMENT*', helpText: `> \`${context.prefix}antidocument on/off\`` },
                antidoc:         { key: 'antidocument', label: '📄 *ANTIDOCUMENT*', helpText: `> \`${context.prefix}antidocument on/off\`` },
                nodocument:      { key: 'antidocument', label: '📄 *ANTIDOCUMENT*', helpText: `> \`${context.prefix}antidocument on/off\`` },
                nodoc:           { key: 'antidocument', label: '📄 *ANTIDOCUMENT*', helpText: `> \`${context.prefix}antidocument on/off\`` },
            };

            if (TOGGLES[cmd]) {
                return cmdGenericToggle(sock, m, args, context, TOGGLES[cmd]);
            }

            return context.reply(`❌ Unknown protection command: \`${cmd}\``);

        } catch (err) {
            console.error(`[PROTECTIONS:${cmd}]`, err?.message || err);
            await react(sock, context.chatId, m.key, '❌');
            return context.reply(global.mess?.error?.fitur || 'Protection error.');
        }
    },
};