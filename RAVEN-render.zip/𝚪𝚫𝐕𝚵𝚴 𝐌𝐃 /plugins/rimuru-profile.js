'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const S = require("./rimuru-store");
async function handler(sock,m,args,ctx={}){
 const me=S.get(ctx.sender||m.sender,ctx.pushname||m.pushName);
 const reply=(text,opts)=>ctx.reply?ctx.reply(text,opts):sock.sendMessage(ctx.chatId||m.key?.remoteJid,{text,...(opts||{})});
 return reply(`👤 *PROFILE*\n\nName: *${me.name}*\nCash: *$${S.money(me.cash)}*\nLevel: *${me.level}*\nEXP: *${S.money(me.exp)}*\nItems: *${Object.values(me.inventory).reduce((a,b)=>a+b,0)}*`);
}
module.exports={command:"profile",aliases:['me'],category:"rpg",description:'Show your profile',handler};
