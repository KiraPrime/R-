'use strict';

/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║  ASSET STORE — centralized binary resources for Raven plugins    ║
 * ║                                                                  ║
 * ║  Usage from any plugin:                                          ║
 * ║    const { getAsset, getAssetUrl } = require('./assets/store.js');║
 * ║    const buf = getAsset('welcome-bg');    // Buffer or null      ║
 * ║    const url = getAssetUrl('welcome-bg'); // Buffer or { url }   ║
 * ║                                                                  ║
 * ║  Adding a new asset:                                             ║
 * ║    1. Drop the file into plugins/assets/                         ║
 * ║    2. Add an entry in ASSETS below                               ║
 * ║    3. Use getAsset('your-key') anywhere                          ║
 * ╚══════════════════════════════════════════════════════════════════╝
 */

const fs = require('fs');
const path = require('path');

const ASSETS_DIR = __dirname; // plugins/assets/

// ══════════════════════════════════════════════════════════════════
// ─── ASSET REGISTRY ───────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const ASSETS = {
    // ─── WELCOME ─────────────────────────────────────────────────
    'welcome-bg': {
        file: 'welcome-bg.jpg',
        url:  'https://files.catbox.moe/k28dhp.mp4',
        type: 'jpg',
    },
    'welcome-gif': {
        file: 'welcome.mp4',
        url:  'https://files.catbox.moe/90t25m.mp4',
        type: 'mp4',
    },
    'welcome-pp': {
        file: 'welcome-pp.jpg',
        url:  'https://cdn.gimita.id/download/pp%20kosong%20wa%20default%20(1)_1769506608569_52b57f5b.jpg',
        type: 'jpg',
    },

    // ─── GOODBYE ─────────────────────────────────────────────────
    'goodbye-bg': {
        file: 'goodbye-bg.jpg',
        url:  'https://c.top4top.io/p_3937k0qzh3.jpg',
        type: 'jpg',
    },
    'goodbye-gif': {
        file: 'goodbye.mp4',
        url:  'https://d.top4top.io/p_39370lisf0.gif',
        type: 'mp4',
    },
    'goodbye-pp': {
        file: 'goodbye-pp.jpg',
        url:  'https://l.top4top.io/p_3937pcggl0.jpg',
        type: 'jpg',
    },

    // ─── GENERAL FALLBACK ────────────────────────────────────────
    'default-pp': {
        file: 'default-pp.jpg',
        url:  'https://cdn.gimita.id/download/pp%20kosong%20wa%20default%20(1)_1769506608569_52b57f5b.jpg',
        type: 'jpg',
    },
    'default-thumb': {
        file: 'default-thumb.jpg',
        url:  'https://files.catbox.moe/u6oxd2.jpg',
        type: 'jpg',
    },

    // ─── MENU / BRANDING ─────────────────────────────────────────
    'menu-thumb': {
        file: 'menu-thumb.jpg',
        url:  'https://c.top4top.io/p_3932ngc6w0.jpg',
        type: 'jpg',
    },
    'menu-video': {
        file: 'menu.mp4',
        url:  'https://videotourl.com/videos/1791350231951-18971143-4050-43b8-918f-785933869af1.mp4',
        type: 'mp4',
    },
    'menu-audio': {
        file: 'menu.mp3',
        url:  'https://www.image2url.com/r2/default/audio/1791350866934-95a0892a-5cab-47cd-914f-7448d94337d2.mp3',
        type: 'mp3',
    },

    // ─── PANEL (Pterodactyl) ─────────────────────────────────────
    'panel-𝚪𝚫𝐕𝚵𝚴 𝐌𝐃-v8': {
        file: 'panel-v8.jpg',
        url:  'https://files.catbox.moe/zmwnc8.jpg',
        type: 'jpg',
    },
    'panel-𝚪𝚫𝐕𝚵𝚴 𝐌𝐃-daftar': {
        file: 'panel-daftar.png',
        url:  'https://d.top4top.io/p_39375hija0.jpg',
        type: 'png',
    },
    'panel-𝚪𝚫𝐕𝚵𝚴 𝐌𝐃-demote': {
        file: 'panel-demote.jpg',
        url:  'https://a.top4top.io/p_3937nsjgl0.jpg',
        type: 'jpg',
    },
    'panel-𝚪𝚫𝐕𝚵𝚴 𝐌𝐃-promote': {
        file: 'panel-promote.png',
        url:  'https://f.top4top.io/p_39373h19s0.jpg',
        type: 'png',
    },
    'panel-𝚪𝚫𝐕𝚵𝚴 𝐌𝐃-store': {
        file: 'panel-store.png',
        url:  'https://files.catbox.moe/31h3re.png',
        type: 'png',
    },
    'panel-𝚪𝚫𝐕𝚵𝚴 𝐌𝐃-landscape': {
        file: 'panel-landscape.jpg',
        url:  'https://files.catbox.moe/dokjwu.jpg',
        type: 'jpg',
    },

    // ─── RPG ─────────────────────────────────────────────────────
    'rpg-dungeon-1': {
        file: 'dungeon1.jpg',
        url:  null,
        type: 'jpg',
    },
    'rpg-dungeon-2': {
        file: 'dungeon2.jpg',
        url:  null,
        type: 'jpg',
    },
    'rpg-dungeon-3': {
        file: 'dungeon3.jpg',
        url:  null,
        type: 'jpg',
    },
    'rpg-levelup': {
        file: 'rpg-levelup.jpg',
        url:  'https://j.top4top.io/p_3937bw1290.jpg',
        type: 'jpg',
    },
    'rpg-games': {
        file: 'rpg-games.png',
        url:  'https://files.catbox.moe/gw8tg2.png',
        type: 'png',
    },
    'rpg-rpg': {
        file: 'rpg-main.jpg',
        url:  'https://files.catbox.moe/t4m0fl.jpg',
        type: 'jpg',
    },
    'rpg-winner': {
        file: 'rpg-winner.jpg',
        url:  'https://files.catbox.moe/r98yoe.jpg',
        type: 'jpg',
    },
    'rpg-rules': {
        file: 'rpg-rules.jpg',
        url:  'https://files.catbox.moe/tpjx2v.jpg',
        type: 'jpg',
    },
    'rpg-minecraft': {
        file: 'rpg-minecraft.jpg',
        url:  'https://files.catbox.moe/7go19u.jpg',
        type: 'jpg',
    },

    // ─── STICKER ─────────────────────────────────────────────────
    'sticker-pack-icon': {
        file: 'sticker-icon.png',
        url:  null,
        type: 'png',
    },
    'sticker-default': {
        file: 'sticker-default.webp',
        url:  null,
        type: 'webp',
    },

    // ─── FONTS ───────────────────────────────────────────────────
    'font-𝚪𝚫𝐕𝚵𝚴 𝐌𝐃': {
        file: '𝚪𝚫𝐕𝚵𝚴 𝐌𝐃-font.ttf',
        url:  null,
        type: 'ttf',
    },

    // ─── ANIME / WAIFU ───────────────────────────────────────────
    'waifu-fallback-1': {
        file: null,
        url:  'https://i.pinimg.com/originals/e3/30/66/e33066f3cdbddd7ba3e37d2d576e8b66.jpg',
        type: 'jpg',
    },
    'waifu-fallback-2': {
        file: null,
        url:  'https://i.pinimg.com/originals/9b/2d/65/9b2d652e8f9742d6e6767a5eb3424df6.png',
        type: 'png',
    },
    'waifu-fallback-3': {
        file: null,
        url:  'https://i.pinimg.com/originals/ee/c1/d8/eec1d883e44ef0a61d11fc6fe3c6d827.jpg',
        type: 'jpg',
    },
    'waifu-fallback-4': {
        file: null,
        url:  'https://i.pinimg.com/originals/7d/cd/4e/7dcd4eedebe7da3d4e9567ede11439e8.jpg',
        type: 'jpg',
    },
    'waifu-fallback-5': {
        file: null,
        url:  'https://i.pinimg.com/originals/42/ca/20/42ca20ce567b97ac89eec4e7ed79f1e1.png',
        type: 'png',
    },

    // ─── HUSBU GACHA ─────────────────────────────────────────────
    'husbu-placeholder': {
        file: null,
        url:  'https://i.pinimg.com/736x/8f/3e/2a/8f3e2a77ec65cdbcfad4ff3bc17e825f.jpg',
        type: 'jpg',
    },

    // ─── GROUP / SWAPADMIN ───────────────────────────────────────
    'group-shield': {
        file: 'group-shield.jpg',
        url:  null,
        type: 'jpg',
    },
    'swapadmin-icon': {
        file: 'swapadmin.png',
        url:  null,
        type: 'png',
    },

    // ─── ANTIBOT ─────────────────────────────────────────────────
    'antibot-icon': {
        file: 'antibot.png',
        url:  'https://e.top4top.io/p_3937pkxea0.jpg',
        type: 'png',
    },

    // ─── AUTOREPLY ───────────────────────────────────────────────
    'autoreply-icon': {
        file: 'autoreply.png',
        url:  null,
        type: 'png',
    },

    // ─── AUDIO / VOICE ───────────────────────────────────────────
    'audio-menu': {
        file: 'menu-audio.mp3',
        url:  'https://www.image2url.com/r2/default/audio/1791350866934-95a0892a-5cab-47cd-914f-7448d94337d2.mp3',
        type: 'mp3',
    },
    'audio-notify': {
        file: 'notify.mp3',
        url:  null,
        type: 'mp3',
    },
    'audio-𝚪𝚫𝐕𝚵𝚴 𝐌𝐃-mp3': {
        file: '𝚪𝚫𝐕𝚵𝚴 𝐌𝐃-mp3.mp3',
        url:  'https://files.catbox.moe/t6xzd2',
        type: 'mp3',
    },

    // ─── 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 BRANDING (bonus) ─────────────────────────────────
    '𝚪𝚫𝐕𝚵𝚴 𝐌𝐃-main': {
        file: '𝚪𝚫𝐕𝚵𝚴 𝐌𝐃.jpg',
        url:  'https://files.catbox.moe/tfkuf4.jpg',
        type: 'jpg',
    },
    '𝚪𝚫𝐕𝚵𝚴 𝐌𝐃-v2': {
        file: '𝚪𝚫𝐕𝚵𝚴 𝐌𝐃-v2.jpg',
        url:  'https://files.catbox.moe/n4kh4f.jpg',
        type: 'jpg',
    },
    '𝚪𝚫𝐕𝚵𝚴 𝐌𝐃-v3': {
        file: '𝚪𝚫𝐕𝚵𝚴 𝐌𝐃-v3.jpg',
        url:  'https://files.catbox.moe/uu2q0l.jpg',
        type: 'jpg',
    },
    '𝚪𝚫𝐕𝚵𝚴 𝐌𝐃-kertas': {
        file: '𝚪𝚫𝐕𝚵𝚴 𝐌𝐃-kertas.jpg',
        url:  'https://files.catbox.moe/8j4d2s.jpg',
        type: 'jpg',
    },
    '𝚪𝚫𝐕𝚵𝚴 𝐌𝐃-fishit': {
        file: '𝚪𝚫𝐕𝚵𝚴 𝐌𝐃-fishit.jpg',
        url:  'https://files.catbox.moe/d7mzg4.jpg',
        type: 'jpg',
    },
    '𝚪𝚫𝐕𝚵𝚴 𝐌𝐃-riooxdzz': {
        file: '𝚪𝚫𝐕𝚵𝚴 𝐌𝐃-riooxdzz.png',
        url:  'https://files.catbox.moe/tvgwvn.png',
        type: 'png',
    },
    '𝚪𝚫𝐕𝚵𝚴 𝐌𝐃-mp4': {
        file: '𝚪𝚫𝐕𝚵𝚴 𝐌𝐃.mp4',
        url:  'https://files.catbox.moe/90t25m.mp4',
        type: 'mp4',
    },

    // ═════════════════════════════════════════════════════════════
    // ═══ ADD NEW ASSETS BELOW AS PLUGINS REQUIRE THEM ════════════
    // ═════════════════════════════════════════════════════════════
};

// ══════════════════════════════════════════════════════════════════
// ─── INTERNAL CACHE ───────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const _bufferCache = new Map();
const _urlCache    = new Map();

function _ensureDir() {
    try {
        if (!fs.existsSync(ASSETS_DIR)) fs.mkdirSync(ASSETS_DIR, { recursive: true });
    } catch (e) {
        console.error('[ASSETS] mkdir failed:', e?.message);
    }
}

function _localPath(entry) {
    if (!entry?.file) return null;
    return path.join(ASSETS_DIR, entry.file);
}

// ══════════════════════════════════════════════════════════════════
// ─── PUBLIC API ───────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════

function getAsset(key) {
    const entry = ASSETS[key];
    if (!entry) return null;

    if (_bufferCache.has(key)) return _bufferCache.get(key);

    const p = _localPath(entry);
    if (p && fs.existsSync(p)) {
        try {
            const buf = fs.readFileSync(p);
            _bufferCache.set(key, buf);
            return buf;
        } catch (e) {
            console.error(`[ASSETS] read failed for ${key}:`, e?.message);
        }
    }
    return null;
}

function getAssetUrl(key) {
    const entry = ASSETS[key];
    if (!entry) return null;

    const local = getAsset(key);
    if (local) return local;

    if (_urlCache.has(key)) return _urlCache.get(key);
    if (entry.url) {
        const ref = { url: entry.url };
        _urlCache.set(key, ref);
        return ref;
    }
    return null;
}

function reloadAsset(key) {
    _bufferCache.delete(key);
    _urlCache.delete(key);
    return getAsset(key);
}

function registerAsset(key, entry) {
    if (!key || !entry) return false;
    ASSETS[key] = entry;
    _bufferCache.delete(key);
    _urlCache.delete(key);
    return true;
}

function listAssets() {
    return Object.keys(ASSETS);
}

function getAssetEntry(key) {
    return ASSETS[key] || null;
}

function hasLocalAsset(key) {
    const entry = ASSETS[key];
    if (!entry?.file) return false;
    return fs.existsSync(path.join(ASSETS_DIR, entry.file));
}

function saveLocalAsset(key, buffer) {
    const entry = ASSETS[key];
    if (!entry?.file) return false;
    try {
        _ensureDir();
        const p = path.join(ASSETS_DIR, entry.file);
        fs.writeFileSync(p, buffer);
        _bufferCache.set(key, buffer);
        return true;
    } catch (e) {
        console.error(`[ASSETS] save failed for ${key}:`, e?.message);
        return false;
    }
}

// ══════════════════════════════════════════════════════════════════
// ─── INIT ─────────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
_ensureDir();

// ══════════════════════════════════════════════════════════════════
// ─── EXPORTS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    // Core API
    getAsset,
    getAssetUrl,
    reloadAsset,
    registerAsset,
    listAssets,
    getAssetEntry,

    // Extra helpers
    hasLocalAsset,
    saveLocalAsset,

    // Constants
    ASSETS_DIR,
    ASSETS,
};