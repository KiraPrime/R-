/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const pkg = require('api-qasim');
const QasimAny = pkg;
module.exports = {
    command: 'npmstalk',
    aliases: ['npmstlk'],
    category: 'stalk',
    description: 'Get details about an NPM package',
    usage: '.npmstalk <package-name>',
    async handler(sock, message, args, context) {
        const { chatId } = context;
        if (!args[0]) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `✳️ Please provide an NPM package name.\n\nExample:\n.npmstalk axios`
            }, { quoted: message });
        }
        try {
            const res = await QasimAny.npmStalk(args[0]);
            if (!res || !res.result) {
                throw new Error('Package not found or API error.');
            }
            const data = res.result;
            const authorName = (typeof data.author === 'object') ? data.author.name : (data.author || 'Unknown');
            const versionCount = data.versions ? Object.keys(data.versions).length : 0;
            let te = `┌──「 *NPM PACKAGE INFO* 」\n`;
            te += `▢ *🔖Name:* ${data.name}\n`;
            te += `▢ *🔖Creator:* ${authorName}\n`;
            te += `▢ *👥Total Versions:* ${versionCount}\n`;
            te += `▢ *📌Description:* ${data.description || 'No description'}\n`;
            te += `▢ *🧩Repository:* ${data.repository?.url || 'No repository available'}\n`;
            te += `▢ *🌍Homepage:* ${data.homepage || 'No homepage available'}\n`;
            te += `▢ *🏷️Latest:* ${data['dist-tags']?.latest || 'N/A'}\n`;
            te += `▢ *🔗Link:* https://npmjs.com/package/${data.name}\n`;
            te += `└────────────`;
            await sendMessageWithChannel(sock, chatId, { text: te }, { quoted: message });
        }
        catch (error) {
            console.error('NPM Stalk Error:', error);
            await sendMessageWithChannel(sock, chatId, { text: `✳️ Error: Package not found or API issue.` }, { quoted: message });
        }
    }
};
