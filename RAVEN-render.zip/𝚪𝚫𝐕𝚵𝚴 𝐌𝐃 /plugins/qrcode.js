/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const QRCode = require('qrcode');
module.exports = {
    command: 'qrcode',
    aliases: ['qr'],
    category: 'tools',
    description: 'Generate a QR code from text',
    usage: '.qrcode <text>',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const text = args?.join(' ')?.trim();
        if (!text) {
            return await sendMessageWithChannel(sock, chatId, { text: '*Provide text to generate QR*\nExample: .qrcode Hello World' }, { quoted: message });
        }
        try {
            const qr = await QRCode.toDataURL(text.slice(0, 2048), {
                errorCorrectionLevel: 'H',
                scale: 8
            });
            await sendMessageWithChannel(sock, chatId, { image: { url: qr }, caption: '✅ QR Code Generated' }, { quoted: message });
        }
        catch (err) {
            console.error('QR plugin error:', err);
            await sendMessageWithChannel(sock, chatId, { text: '❌ Failed to generate QR code.' }, { quoted: message });
        }
    }
};
