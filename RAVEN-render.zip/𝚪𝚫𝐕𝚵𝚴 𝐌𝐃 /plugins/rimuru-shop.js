'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const S = require("./rimuru-store");
async function handler(sock,m,args,ctx={}){
 const me=S.get(ctx.sender||m.sender,ctx.pushname||m.pushName);
 const reply=(text,opts)=>ctx.reply?ctx.reply(text,opts):sock.sendMessage(ctx.chatId||m.key?.remoteJid,{text,...(opts||{})});
 const items={potion:[100,50],bread:[30,15],energy:[200,100],wood:[20,10],stone:[30,15],iron:[100,50],diamond:[1000,500]};const action=(args[0]||"list").toLowerCase(),key=(args[1]||"").toLowerCase(),n=Math.max(1,parseInt(args[2])||1);if(action==="list"||!items[key])return reply(`🛒 *SHOP*\n\n${Object.entries(items).map(([k,v])=>`• ${k}: buy $${v[0]} / sell $${v[1]}`).join("\n")}\n\nUse: *.shop buy <item> <amount>*`);const item=items[key];if(action==="buy"){const total=item[0]*n;if(me.cash<total)return reply(`❌ You need *$${S.money(total-me.cash)}* more.`);me.cash-=total;me.inventory[key]=(me.inventory[key]||0)+n;S.save();return reply(`✅ Bought *${n}x ${key}* for *$${S.money(total)}*.`);}if(action==="sell"){const have=me.inventory[key]||0;if(have<n)return reply(`❌ You only have *${have}x ${key}*.`);const total=item[1]*n;me.inventory[key]-=n;me.cash+=total;S.save();return reply(`✅ Sold *${n}x ${key}* for *$${S.money(total)}*.`);}
}
module.exports={command:"shop",aliases:['store'],category:"rpg",description:'Buy and sell RPG items',handler};
