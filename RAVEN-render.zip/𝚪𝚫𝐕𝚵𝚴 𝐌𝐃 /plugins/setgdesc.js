/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: 'setgdesc',
    aliases: ['setdesc', 'groupdesc'],
    category: 'admin',
    description: 'Change group description',
    usage: '.setgdesc <new description>',
    groupOnly: true,
    adminOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const desc = args.join(' ').trim();
        if (!desc) {
            await sendMessageWithChannel(sock, chatId, {
                text: '❌ *Please provide a description*\n\nUsage: `.setgdesc <description>`'
            }, { quoted: message });
            return;
        }
        try {
            await sock.groupUpdateDescription(chatId, desc);
            await sendMessageWithChannel(sock, chatId, {
                text: '✅ *Group description updated successfully!*'
            }, { quoted: message });
        }
        catch (error) {
            console.error('Error updating group description:', error);
            await sendMessageWithChannel(sock, chatId, {
                text: '❌ *Failed to update group description*\n\nMake sure the bot is an admin.'
            }, { quoted: message });
        }
    }
};
