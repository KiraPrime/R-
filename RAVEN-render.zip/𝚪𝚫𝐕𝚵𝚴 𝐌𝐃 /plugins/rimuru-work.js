'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const S = require("./rimuru-store");
async function handler(sock,m,args,ctx={}){
 const me=S.get(ctx.sender||m.sender,ctx.pushname||m.pushName);
 const reply=(text,opts)=>ctx.reply?ctx.reply(text,opts):sock.sendMessage(ctx.chatId||m.key?.remoteJid,{text,...(opts||{})});
 const now=Date.now(),last=me.cooldowns.work||0;if(now-last<60000)return reply(`⏳ You are tired. Try again in *${S.cooldown(last+60000-now)}*.`);const cash=300+Math.floor(Math.random()*1200),exp=50+Math.floor(Math.random()*100);me.cash+=cash;me.exp+=exp;me.cooldowns.work=now;if(me.exp>=me.level*1000){me.exp-=me.level*1000;me.level++;}S.save();return reply(`💼 *WORK COMPLETE*\n\n💵 Salary: *+$${S.money(cash)}*\n✨ EXP: *+${S.money(exp)}*\n📈 Level: *${me.level}*`);
}
module.exports={command:"work",aliases:['job'],category:"rpg",description:'Work for cash and experience',handler};
