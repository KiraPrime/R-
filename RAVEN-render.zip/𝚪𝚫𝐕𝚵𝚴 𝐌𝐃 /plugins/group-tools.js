'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const fs = require('fs');
const path = require('path');

// ══════════════════════════════════════════════════════════════════
// ─── FORWARD NEWSLETTER CONTEXT (mandatory on all plugins) ────────
// ══════════════════════════════════════════════════════════════════
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── INTERNAL STORE ───────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const DATA_DIR   = path.join(__dirname, 'group-tools-data');
const STORE_PATH = path.join(DATA_DIR, 'store.json');

const DEFAULT_STORE = {
    global: {},
    groups: {
        // "<jid>": {
        //   antilinkgc: 'on', antilinkgcMode: 'remove',
        //   antilinkall: 'on', antilinkallMode: 'remove',
        //   antilinkch: true,
        //   antispam: true, antispamAction: 'warning', antispamDelay: 2000,
        //   antilinkList: ['tiktok.com', ...],
        //   mutedMembers: ['123@s.whatsapp.net'],
        //   notifDemote: false, notifPromote: false,
        // }
    },
};

let _store = null;
let _saveTimer = null;

function ensureDir() {
    try { if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true }); }
    catch (e) { console.error('[GROUP-TOOLS] mkdir failed:', e?.message); }
}

function loadStore() {
    ensureDir();
    try {
        if (fs.existsSync(STORE_PATH)) {
            const raw = fs.readFileSync(STORE_PATH, 'utf8').trim();
            if (raw) {
                const parsed = JSON.parse(raw);
                _store = {
                    global: { ...DEFAULT_STORE.global, ...(parsed.global || {}) },
                    groups: { ...(parsed.groups || {}) },
                };
                return _store;
            }
        }
    } catch (e) {
        console.error('[GROUP-TOOLS] store corrupted, rebuilding:', e?.message);
    }
    _store = JSON.parse(JSON.stringify(DEFAULT_STORE));
    writeStoreSync();
    return _store;
}

function writeStoreSync() {
    try {
        ensureDir();
        const tmp = STORE_PATH + '.tmp';
        fs.writeFileSync(tmp, JSON.stringify(_store, null, 2), 'utf8');
        fs.renameSync(tmp, STORE_PATH);
    } catch (e) { console.error('[GROUP-TOOLS] store write failed:', e?.message); }
}

function scheduleSave() {
    if (_saveTimer) clearTimeout(_saveTimer);
    _saveTimer = setTimeout(() => { _saveTimer = null; writeStoreSync(); }, 500);
    if (_saveTimer.unref) _saveTimer.unref();
}

function getSetting(jid, key, def = null) {
    if (!_store) loadStore();
    if (!jid) return def;
    if (jid === 'global') {
        const v = _store.global?.[key];
        return v === undefined ? def : v;
    }
    const g = _store.groups?.[jid];
    if (!g) return def;
    const v = g[key];
    return v === undefined ? def : v;
}

function setSetting(jid, key, value) {
    if (!_store) loadStore();
    if (!jid) return;
    if (jid === 'global') {
        _store.global = _store.global || {};
        _store.global[key] = value;
        scheduleSave();
        return;
    }
    if (!_store.groups[jid]) _store.groups[jid] = {};
    _store.groups[jid][key] = value;
    scheduleSave();
}

loadStore();
process.on('exit', () => { try { writeStoreSync(); } catch {} });
process.on('SIGINT', () => { try { writeStoreSync(); } catch {} process.exit(0); });

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function jidToNumber(jid) {
    if (!jid) return '';
    return String(jid).split(':')[0].split('@')[0].replace(/[^0-9]/g, '');
}

function getMentions(m) {
    const ctx =
        m?.message?.extendedTextMessage?.contextInfo ||
        m?.message?.imageMessage?.contextInfo ||
        m?.message?.videoMessage?.contextInfo ||
        null;
    return ctx?.mentionedJid || [];
}

function getMessageText(m) {
    return (
        m?.message?.conversation ||
        m?.message?.extendedTextMessage?.text ||
        m?.message?.imageMessage?.caption ||
        m?.message?.videoMessage?.caption ||
        ''
    );
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch { /* ignore */ }
}

// ══════════════════════════════════════════════════════════════════
// ─── LINK DETECTION PATTERNS ──────────────────────────────────────
// ══════════════════════════════════════════════════════════════════

// WhatsApp channel links: whatsapp.com/channel/xxx
const CHANNEL_LINK_RE = /https?:\/\/(www\.)?whatsapp\.com\/channel\/[^\s]+/i;

// WhatsApp group/wa.me links: chat.whatsapp.com/xxx or wa.me/xxx
const WA_LINK_RE = /(?:https?:\/\/)?(?:chat\.whatsapp\.com|wa\.me|api\.whatsapp\.com)\/[^\s]+/i;

// Generic link (http/https/www/domain.tld, plus shortlink domains)
const GENERIC_LINK_RE =
    /(?:(?:https?:\/\/)|(?:www\.))\S+|(?:[a-z0-9-]+\.)+(?:com|net|org|io|id|co|me|xyz|info|biz|tv|cc|link|site|online|store|app|dev|us|uk|ru|jp|cn|in|br|au|de|fr|it|es|nl|be|ch|se|no|dk|fi|pl|cz|sk|hu|ro|bg|gr|tr|il|sa|ae|eg|za|ng|ke|gh|pk|bd|lk|np|mm|th|vn|my|sg|ph|kr|tw|hk|mx|ar|cl|pe|ve|uy|py|bo|ec|cu|do|gt|hn|ni|pa|pr|sv|cr|tn|dz|ma|ly|sd|et|tz|ug|zm|zw|mw|mz|ao|cm|ci|sn|ml|bf|ne|tg|bj|ga|cg|cd|cf|td|mr|so|dj|er|rw|bi|mg|mu|sc|cv|st|gw|gm|sl|lr|gn|gh|ci|bf|ml|ne|td|sd|ss|et|so|dj|er|mg|km|sc|mu|re|yt|pf|nc|vu|fj|pg|sb|to|ws|tv|ki|nr|fm|mh|pw|gu|mp|as|ck|nu|tk|wf|pf|nc|sh|ac|ta|pn|io|cc|ws|bz|ai|vg|tc|ms|gd|vc|lc|bb|tt|jm|ht|bs|pr|vi|ky|bm|aq|hm|tf|bv|gs|sj|im|je|gg|ax|fo|gl|pm|wf|yt|re|mu|sc|km|m|bzh|cat|eus|gal|cym|gla|sco|wales|irish|london|nyc|berlin|paris|amsterdam|brussels|vienna|madrid|rome|moscow|tokyo|beijing|delhi|dubai|istanbul|oslo|stockholm|copenhagen|helsinki|reykjavik|tallinn|vilnius|riga|warsaw|prague|budapest|sofia|bucharest|athens|zagreb|belgrade|sarajevo|skopje|tirana|podgorica|pristina|chisinau|kyiv|minsk|tbilisi|yerevan|baku|astana|tashkent|bishkek|dushanbe|ashgabat|ulaanbaatar|pyongyang|seoul|hanoi|phnompenh|vientiane|bangkok|kualalumpur|singapore|jakarta|manila|bandarseribegawan|dili|portmoresby|suva|apia|nukualofa|tarawa|funafuti|honiara|portvila|noumea|papeete|honolulu|wellington|canberra|auckland)\b/i;

// ══════════════════════════════════════════════════════════════════
// ─── COMMAND: resetlinkgc ─────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function cmdResetLink(sock, m, args, context) {
    const { chatId, reply, prefix } = context;
    await react(sock, chatId, m.key, '🔄');
    try {
        await sock.groupRevokeInvite(chatId);
        await react(sock, chatId, m.key, '✅');
        return reply(
            `✅ *GROUP LINK RESET*\n\n` +
            `> Old invite link is now invalid.\n` +
            `> Use \`${prefix}linkgc\` to get the new one.`,
        );
    } catch (err) {
        await react(sock, chatId, m.key, '☢');
        return reply(global.mess?.error?.fitur || 'Feature error.');
    }
}

// ══════════════════════════════════════════════════════════════════
// ─── COMMAND: opentime ────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function cmdOpenTime(sock, m, args, context) {
    const { chatId, reply, prefix } = context;

    const time = parseInt(args[0]);
    const unit = (args[1] || '').toLowerCase();

    if (!time || !unit) {
        return reply(
            `*Usage:*\n${prefix}opentime 10 second\n\n` +
            `*Units:*\nsecond\nminute\nhour\nday`,
        );
    }

    let ms;
    switch (unit) {
        case 'second': case 'seconds': ms = time * 1000; break;
        case 'minute': case 'minutes': ms = time * 60000; break;
        case 'hour':   case 'hours':   ms = time * 3600000; break;
        case 'day':    case 'days':    ms = time * 86400000; break;
        default:
            return reply('*Invalid unit!*\nUse: second, minute, hour, or day');
    }

    await reply(`⏳ Group will be opened in *${time} ${unit}*...`);

    setTimeout(async () => {
        try {
            await sock.groupSettingUpdate(chatId, 'not_announcement');
            await sendMessageWithChannel(sock, chatId, {
                text: '*[ OPEN TIME ]*\nThe group is open again. All members can send messages now.',
            });
        } catch (e) {
            console.error('[OPENTIME]', e?.message);
        }
    }, ms);
    return true;
}

// ══════════════════════════════════════════════════════════════════
// ─── COMMAND: antilinkch ──────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function cmdAntiLinkCh(sock, m, args, context) {
    const { chatId, reply } = context;
    const opt = (args[0] || '').toLowerCase();

    if (!opt) return reply(`Use:\n.antilinkch on / off`);

    const current = getSetting(chatId, 'antilinkch', false);

    if (opt === 'on') {
        if (current === true) return reply('Antilink channel is already active.');
        setSetting(chatId, 'antilinkch', true);
        return reply('✅ Antilink channel enabled.');
    }
    if (opt === 'off') {
        if (current !== true) return reply('Antilink channel is already inactive.');
        setSetting(chatId, 'antilinkch', false);
        return reply('❌ Antilink channel disabled.');
    }
    return reply('Invalid option.\nUse:\n.antilinkch on / off');
}

// ══════════════════════════════════════════════════════════════════
// ─── COMMAND: antilinkgc ──────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function cmdAntiLinkGc(sock, m, args, context) {
    const { chatId, reply, prefix } = context;
    const option = (args[0] || '').toLowerCase();
    const subArg = (args[1] || '').toLowerCase();

    if (!option) {
        const status = getSetting(chatId, 'antilinkgc', 'off');
        const mode   = getSetting(chatId, 'antilinkgcMode', 'remove');
        return reply(
            `🔗 *ANTILINK WA*\n\n` +
            `╭┈┈⬡「 📋 *STATUS* 」\n` +
            `┃ ◦ Status: *${String(status).toUpperCase()}*\n` +
            `┃ ◦ Mode: *${String(mode).toUpperCase()}*\n` +
            `╰┈┈⬡\n\n` +
            `*DETECTION:*\n` +
            `> • chat.whatsapp.com (group)\n` +
            `> • wa.me (contact)\n` +
            `> • whatsapp.com/channel (channel)\n\n` +
            `*USAGE:*\n` +
            `> \`${prefix}antilinkgc on\`\n` +
            `> \`${prefix}antilinkgc off\`\n` +
            `> \`${prefix}antilinkgc metode kick\`\n` +
            `> \`${prefix}antilinkgc metode remove\``,
        );
    }

    if (option === 'on') {
        setSetting(chatId, 'antilinkgc', 'on');
        return reply(`✅ *ANTILINK WA* enabled!\n\n> WA links will be auto-handled.`);
    }
    if (option === 'off') {
        setSetting(chatId, 'antilinkgc', 'off');
        return reply(`❌ *ANTILINK WA* disabled!`);
    }
    if (option === 'metode') {
        if (subArg === 'kick') {
            setSetting(chatId, 'antilinkgc', 'on');
            setSetting(chatId, 'antilinkgcMode', 'kick');
            return reply(`✅ *ANTILINK WA* KICK mode enabled!`);
        }
        if (subArg === 'remove' || subArg === 'delete') {
            setSetting(chatId, 'antilinkgc', 'on');
            setSetting(chatId, 'antilinkgcMode', 'remove');
            return reply(`✅ *ANTILINK WA* REMOVE mode enabled!`);
        }
        return reply(`❌ Invalid method! Use \`kick\` or \`remove\``);
    }
    if (option === 'kick') {
        setSetting(chatId, 'antilinkgc', 'on');
        setSetting(chatId, 'antilinkgcMode', 'kick');
        return reply(`✅ *ANTILINK WA* KICK mode enabled!`);
    }
    if (option === 'remove' || option === 'delete') {
        setSetting(chatId, 'antilinkgc', 'on');
        setSetting(chatId, 'antilinkgcMode', 'remove');
        return reply(`✅ *ANTILINK WA* REMOVE mode enabled!`);
    }
    return reply(`❌ Invalid option! Use \`on\`, \`off\`, \`metode kick\`, \`metode remove\``);
}

// ══════════════════════════════════════════════════════════════════
// ─── COMMAND: antilinkall ─────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function cmdAntiLinkAll(sock, m, args, context) {
    const { chatId, reply, prefix } = context;
    const option = (args[0] || '').toLowerCase();
    const subArg = (args[1] || '').toLowerCase();

    if (!option) {
        const status = getSetting(chatId, 'antilinkall', 'off');
        const mode   = getSetting(chatId, 'antilinkallMode', 'remove');
        return reply(
            `🔗 *ANTILINK ALL*\n\n` +
            `> Status: *${status === 'on' ? 'Active ✅' : 'Inactive ❌'}*\n` +
            `> Mode: *${String(mode).toUpperCase()}*\n\n` +
            `*DETECTION:*\n` +
            `> • https:// / http://\n` +
            `> • www.\n` +
            `> • Domain extension (.com, .id, .io, …)\n` +
            `> • Shortlinks (bit.ly, t.me, tinyurl, …)\n\n` +
            `*USAGE:*\n` +
            `> *${prefix}antilinkall on*\n` +
            `> *${prefix}antilinkall off*\n` +
            `> *${prefix}antilinkall metode kick*\n` +
            `> *${prefix}antilinkall metode remove*`,
        );
    }

    if (option === 'on') {
        setSetting(chatId, 'antilinkall', 'on');
        return reply(`✅ *ANTILINK ALL enabled!*`);
    }
    if (option === 'off') {
        setSetting(chatId, 'antilinkall', 'off');
        return reply(`❌ *ANTILINK ALL disabled!*`);
    }
    if (option === 'metode') {
        if (subArg === 'kick') {
            setSetting(chatId, 'antilinkall', 'on');
            setSetting(chatId, 'antilinkallMode', 'kick');
            return reply(`✅ *ANTILINK ALL* — KICK mode`);
        }
        if (subArg === 'remove' || subArg === 'delete') {
            setSetting(chatId, 'antilinkall', 'on');
            setSetting(chatId, 'antilinkallMode', 'remove');
            return reply(`✅ *ANTILINK ALL* — REMOVE mode`);
        }
        return reply(`❌ Invalid method! Use \`kick\` or \`remove\``);
    }
    if (option === 'kick') {
        setSetting(chatId, 'antilinkall', 'on');
        setSetting(chatId, 'antilinkallMode', 'kick');
        return reply(`✅ *ANTILINK ALL* — KICK mode`);
    }
    if (option === 'remove' || option === 'delete') {
        setSetting(chatId, 'antilinkall', 'on');
        setSetting(chatId, 'antilinkallMode', 'remove');
        return reply(`✅ *ANTILINK ALL* — REMOVE mode`);
    }
    return reply(`❌ Invalid option! Use \`on\`, \`off\`, \`metode kick\`, \`metode remove\``);
}

// ══════════════════════════════════════════════════════════════════
// ─── COMMAND: antispam ────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const spamTracker = new Map(); // "<chat>_<sender>" → { count, lastMessage, warnings }

async function cmdAntiSpam(sock, m, args, context) {
    const { chatId, reply, prefix } = context;
    const action = (args[0] || '').toLowerCase();
    const delayMatch = action.match(/^(\d+)(s|ms)?$/);

    if (!action || (!['on','off','warning','kick','delete'].includes(action) && !delayMatch)) {
        return reply(
            `🛡️ *ANTI SPAM GROUP*\n\n` +
            `Protects the group from members sending messages repeatedly at high speed.\n\n` +
            `*Usage:*\n` +
            `> \`${prefix}antispam on\`\n` +
            `> \`${prefix}antispam off\`\n\n` +
            `*Methods:*\n` +
            `> \`${prefix}antispam warning\`\n` +
            `> \`${prefix}antispam kick\`\n` +
            `> \`${prefix}antispam delete\`\n\n` +
            `*Delay:*\n` +
            `> \`${prefix}antispam 2\` (2s)\n` +
            `> \`${prefix}antispam 1500\` (1500ms)`,
        );
    }

    if (delayMatch) {
        let delayMs = parseInt(delayMatch[1], 10);
        if (delayMatch[2] === 's' || (delayMs >= 1 && delayMs <= 10)) delayMs *= 1000;
        if (delayMs < 500)   delayMs = 500;
        if (delayMs > 10000) delayMs = 10000;
        setSetting(chatId, 'antispamDelay', delayMs);
        return reply(
            `🛡️ *ANTISPAM DELAY UPDATED*\n\n` +
            `> Max delay: *${delayMs} ms* (${(delayMs/1000).toFixed(1)}s)`,
        );
    }

    if (action === 'on' || action === 'off') {
        const enable = action === 'on';
        const current = getSetting(chatId, 'antispam', false);
        if (current === enable) {
            return reply(`✅ Antispam already ${enable ? 'active' : 'inactive'} in this group.`);
        }
        setSetting(chatId, 'antispam', enable);
        return reply(
            `🛡️ *ANTISPAM UPDATED*\n\n` +
            `> Status: *${enable ? 'ACTIVE ✅' : 'INACTIVE ❌'}*`,
        );
    }

    // Other action = method
    setSetting(chatId, 'antispamAction', action);
    let textAction = '';
    if (action === 'warning') textAction = 'Give warnings';
    if (action === 'kick')    textAction = 'Kick the member';
    if (action === 'delete')  textAction = 'Delete the spam messages';
    return reply(
        `🛡️ *ANTISPAM ACTION UPDATED*\n\n` +
        `> Method: *${action.toUpperCase()}*\n\n` +
        `Bot will *${textAction}* on spam detection.`,
    );
}

// ══════════════════════════════════════════════════════════════════
// ─── COMMAND: delantilink ─────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function cmdDelAntiLink(sock, m, args, context) {
    const { chatId, reply, prefix } = context;
    const link = (args.join(' ') || '').trim().toLowerCase();
    const list = getSetting(chatId, 'antilinkList', []) || [];

    if (!link) {
        if (list.length === 0) return reply(`📋 Antilink list is empty!`);
        let txt = `🔗 *ANTILINK LIST*\n\n`;
        list.forEach((l, i) => { txt += `> ${i + 1}. \`${l}\`\n`; });
        txt += `\n> Total: *${list.length}* links`;
        txt += `\n\n\`${prefix}delantilink <domain>\` to remove`;
        return reply(txt);
    }

    const idx = list.findIndex(l => l === link);
    if (idx === -1) return reply(`⚠️ Link \`${link}\` not found in list!`);

    list.splice(idx, 1);
    setSetting(chatId, 'antilinkList', list);
    return reply(
        `✅ *ANTILINK REMOVED*\n\n` +
        `> Link: \`${link}\`\n` +
        `> Remaining: *${list.length}* links`,
    );
}

// ══════════════════════════════════════════════════════════════════
// ─── COMMAND: setnamegc ───────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function cmdSetNameGc(sock, m, args, context) {
    const { chatId, reply, prefix } = context;
    const newName = (args.join(' ') || '').trim();

    if (!newName) {
        return reply(`⚠️ *USAGE*\n\n> \`${prefix}setnamegc New Group Name\``);
    }
    if (newName.length < 1 || newName.length > 100) {
        return reply(`⚠️ *VALIDATION*\n\n> Group name must be 1-100 characters.`);
    }
    try {
        await sock.groupUpdateSubject(chatId, newName);
        return reply(`✅ Group name changed to *${newName}*`);
    } catch (error) {
        return reply(
            `❌ *FAILED*\n\n` +
            `> Could not change group name.\n` +
            `> _${error.message}_`,
        );
    }
}

// ══════════════════════════════════════════════════════════════════
// ─── COMMAND: mutemember ──────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function resolveMuteTarget(m, args) {
    let raw = '';
    if (m.quoted) raw = m.quoted.sender || '';
    else if (getMentions(m).length) raw = getMentions(m)[0];
    else if (args[0]) raw = args[0];

    if (!raw) return '';
    raw = String(raw);
    if (raw.endsWith('@lid')) raw = raw.replace('@lid', '@s.whatsapp.net');
    if (!raw.includes('@')) raw = raw.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
    return raw;
}

async function cmdMuteMember(sock, m, args, context) {
    const { chatId, reply, prefix, groupMetadata } = context;
    const targetJid = resolveMuteTarget(m, args);

    if (!targetJid) {
        return reply(
            `🔇 *MUTE MEMBER*\n\n` +
            `> Mute a specific member in this group\n` +
            `> Their messages will be deleted by the bot\n\n` +
            `\`Examples:\`\n` +
            `> ${prefix}mutemember @user\n` +
            `> ${prefix}mutemember 6281234567890\n` +
            `> Reply a message + ${prefix}mutemember`,
        );
    }

    const targetNumber = jidToNumber(targetJid);

    // Refuse muting admins
    const isTargetAdmin = groupMetadata?.participants?.some(p => {
        const pNum = jidToNumber(p.id || p.jid || '');
        return pNum === targetNumber && p.admin;
    });
    if (isTargetAdmin) return reply(`❌ *FAILED*\n\n> Cannot mute a group admin.`);

    const list = getSetting(chatId, 'mutedMembers', []) || [];
    const already = list.some(jid => jidToNumber(jid) === targetNumber);
    if (already) {
        return sendMessageWithChannel(sock, chatId, {
            text: `❌ *FAILED*\n\n> @${targetNumber} is already muted`,
            mentions: [targetJid],
        });
    }

    list.push(targetJid);
    setSetting(chatId, 'mutedMembers', list);

    await react(sock, chatId, m.key, '🔇');
    return sendMessageWithChannel(sock, chatId, {
        text:
            `🔇 *MEMBER MUTED*\n\n` +
            `╭┈┈⬡「 📋 *DETAIL* 」\n` +
            `┃ 👤 ᴍᴇᴍʙᴇʀ : @${targetNumber}\n` +
            `┃ 🔇 sᴛᴀᴛᴜs : \`Muted\`\n` +
            `┃ 📊 ᴛᴏᴛᴀʟ  : \`${list.length}\` muted\n` +
            `╰┈┈⬡\n\n` +
            `> All messages from this member will be auto-deleted.\n` +
            `> Use \`${prefix}unmutemember\` to unmute.`,
        mentions: [targetJid],
    });
}

function isMutedMember(groupJid, senderJid) {
    const list = getSetting(groupJid, 'mutedMembers', []) || [];
    if (list.length === 0) return false;
    const senderNumber = jidToNumber(senderJid);
    return list.some(jid => jidToNumber(jid) === senderNumber);
}

// ══════════════════════════════════════════════════════════════════
// ─── COMMANDS: notifdemote / notifpromote ─────────────────────────
// ══════════════════════════════════════════════════════════════════
async function cmdNotifDemote(sock, m, args, context) {
    const { chatId, reply, prefix } = context;
    const opt = (args[0] || '').toLowerCase();
    if (!['on','off'].includes(opt)) {
        const status = getSetting(chatId, 'notifDemote', false) === true ? '✅ Active' : '❌ Inactive';
        return reply(
            `👤 *NOTIF DEMOTE*\n\n> Status: ${status}\n\n` +
            `*Usage:*\n\`${prefix}notifdemote on\`\n\`${prefix}notifdemote off\``,
        );
    }
    setSetting(chatId, 'notifDemote', opt === 'on');
    return reply(opt === 'on' ? `✅ *NOTIF DEMOTE ENABLED*` : `❌ *NOTIF DEMOTE DISABLED*`);
}

async function cmdNotifPromote(sock, m, args, context) {
    const { chatId, reply, prefix } = context;
    const opt = (args[0] || '').toLowerCase();
    if (!['on','off'].includes(opt)) {
        const status = getSetting(chatId, 'notifPromote', false) === true ? '✅ Active' : '❌ Inactive';
        return reply(
            `👑 *NOTIF PROMOTE*\n\n> Status: ${status}\n\n` +
            `*Usage:*\n\`${prefix}notifpromote on\`\n\`${prefix}notifpromote off\``,
        );
    }
    setSetting(chatId, 'notifPromote', opt === 'on');
    return reply(opt === 'on' ? `✅ *NOTIF PROMOTE ENABLED*` : `❌ *NOTIF PROMOTE DISABLED*`);
}

// ══════════════════════════════════════════════════════════════════
// ─── EVENT HOOK — messages.upsert ─────────────────────────────────
// Scans every group message for:
//   • antilinkch, antilinkgc, antilinkall
//   • antispam
//   • muted members (auto-delete their messages)
// ══════════════════════════════════════════════════════════════════
let _bound = false;
let _boundSock = null;

async function handleGroupMessage(sock, raw) {
    try {
        const chatJid = raw.key?.remoteJid || '';
        if (!chatJid.endsWith('@g.us')) return;
        if (raw.key?.fromMe) return;

        const sender = raw.key?.participant || '';
        if (!sender) return;

        const body = getMessageText(raw);
        const groupMeta = await sock.groupMetadata(chatJid).catch(() => null);
        if (!groupMeta) return;

        // Determine sender's admin status
        const senderNum = jidToNumber(sender);
        const senderP = (groupMeta.participants || []).find(p => jidToNumber(p.id || p.jid || '') === senderNum);
        const senderIsAdmin = ['admin', 'superadmin'].includes(senderP?.admin);

        // Bot admin status
        const botJid = (sock.user?.id || '').split(':')[0] + '@s.whatsapp.net';
        const botP = (groupMeta.participants || []).find(p => jidToNumber(p.id || p.jid || '') === jidToNumber(botJid));
        const botIsAdmin = ['admin', 'superadmin'].includes(botP?.admin);

        // ─── Muted member check (delete their messages) ──────────
        if (botIsAdmin && !senderIsAdmin && isMutedMember(chatJid, sender)) {
            try { await sock.sendMessage(chatJid, { delete: raw.key }); } catch { /* ignore */ }
            return;
        }

        // ─── Antilink checks (skip admins) ────────────────────────
        if (!senderIsAdmin && body) {
            const text = String(body);

            // antilinkch
            const aCh = getSetting(chatJid, 'antilinkch', false);
            if (aCh === true && botIsAdmin && CHANNEL_LINK_RE.test(text)) {
                await handleLinkViolation(sock, chatJid, raw, sender, 'channel');
                return;
            }

            // antilinkgc
            const aGc = getSetting(chatJid, 'antilinkgc', 'off');
            if (aGc === 'on' && botIsAdmin && WA_LINK_RE.test(text)) {
                await handleLinkViolation(sock, chatJid, raw, sender, 'wa');
                return;
            }

            // antilinkall
            const aAll = getSetting(chatJid, 'antilinkall', 'off');
            if (aAll === 'on' && botIsAdmin && GENERIC_LINK_RE.test(text)) {
                await handleLinkViolation(sock, chatJid, raw, sender, 'all');
                return;
            }
        }

        // ─── Antispam check ───────────────────────────────────────
        const aSpam = getSetting(chatJid, 'antispam', false);
        if (aSpam === true && !senderIsAdmin && body) {
            const isSpam = await checkSpam(chatJid, sender);
            if (isSpam) {
                await handleSpamAction(sock, chatJid, raw, sender, groupMeta, botIsAdmin);
            }
        }
    } catch (e) {
        console.error('[GROUP-TOOLS-EVENT]', e?.message);
    }
}

// ─── Antilink violation handler ───────────────────────────────────
async function handleLinkViolation(sock, chatJid, raw, sender, kind) {
    const modeKey = kind === 'wa'  ? 'antilinkgcMode'
                  : kind === 'all' ? 'antilinkallMode'
                  : null;
    const mode = modeKey ? getSetting(chatJid, modeKey, 'remove') : 'remove';

    // Always try to delete the message first
    try { await sock.sendMessage(chatJid, { delete: raw.key }); } catch { /* ignore */ }

    const userTag = jidToNumber(sender);

    if (mode === 'kick') {
        try {
            await sock.groupParticipantsUpdate(chatJid, [sender], 'remove');
            await sendMessageWithChannel(sock, chatJid, {
                text: `🚫 @${userTag} was kicked for sending a forbidden link.`,
                mentions: [sender],
            });
        } catch { /* ignore */ }
    } else {
        await sendMessageWithChannel(sock, chatJid, {
            text: `🚫 @${userTag} — links are not allowed here.`,
            mentions: [sender],
        });
    }
}

// ─── Antispam check ───────────────────────────────────────────────
async function checkSpam(chatJid, senderJid) {
    const chatKey = `${chatJid}_${senderJid}`;
    const now = Date.now();
    const delayThreshold = getSetting(chatJid, 'antispamDelay', 2000);

    const data = spamTracker.get(chatKey) || { count: 0, lastMessage: 0, warnings: 0 };
    const delta = now - (data.lastMessage || 0);

    if (delta < delayThreshold) data.count += 1;
    else if (delta > delayThreshold + 1000) data.count = 1;
    else data.count = Math.max(1, data.count - 1);

    data.lastMessage = now;
    spamTracker.set(chatKey, data);

    return data.count >= 5;
}

// ─── Antispam action handler ──────────────────────────────────────
async function handleSpamAction(sock, chatJid, raw, senderJid, groupMeta, botIsAdmin) {
    const action = getSetting(chatJid, 'antispamAction', 'warning');
    const chatKey = `${chatJid}_${senderJid}`;
    const userData = spamTracker.get(chatKey) || { count: 0, lastMessage: 0, warnings: 0 };
    const userTag = jidToNumber(senderJid);

    if (action === 'warning') {
        userData.warnings = (userData.warnings || 0) + 1;
        spamTracker.set(chatKey, userData);

        if (userData.warnings >= 3) {
            await sendMessageWithChannel(sock, chatJid, {
                text:
                    `⚠️ *MAX SPAM WARNINGS*\n\n` +
                    `> For: @${userTag}\n\n` +
                    `You received 3 warnings for spamming. Please stop or admins may take action.`,
                mentions: [senderJid],
            });
            userData.warnings = 0;
            userData.count = 0;
            spamTracker.set(chatKey, userData);
        } else {
            await sendMessageWithChannel(sock, chatJid, {
                text:
                    `⚠️ *SPAM DETECTED*\n\n` +
                    `> Warning ${userData.warnings} of 3\n\n` +
                    `Hi @${userTag}, please do not send rapid repeated messages.`,
                mentions: [senderJid],
            });
            userData.count = 0;
            spamTracker.set(chatKey, userData);
        }
        return;
    }

    if (action === 'kick') {
        if (!botIsAdmin) {
            await sendMessageWithChannel(sock, chatJid, {
                text:
                    `⚠️ *SPAM DETECTED*\n\n` +
                    `@${userTag} is spamming, but the bot is not admin so it cannot kick.`,
                mentions: [senderJid],
            });
            userData.count = 0;
            spamTracker.set(chatKey, userData);
            return;
        }
        await sendMessageWithChannel(sock, chatJid, {
            text: `🛑 @${userTag} was kicked for spamming.`,
            mentions: [senderJid],
        });
        try {
            await sock.groupParticipantsUpdate(chatJid, [senderJid], 'remove');
            spamTracker.delete(chatKey);
        } catch { /* ignore */ }
        return;
    }

    if (action === 'delete') {
        if (botIsAdmin) {
            try { await sock.sendMessage(chatJid, { delete: raw.key }); } catch { /* ignore */ }
        } else {
            userData.count = 0;
            spamTracker.set(chatKey, userData);
        }
    }
}

// ─── Bind sock to messages.upsert ─────────────────────────────────
async function onMessagesUpsert(payload) {
    try {
        const sock = _boundSock;
        if (!sock) return;
        const messages = Array.isArray(payload?.messages) ? payload.messages : [];
        for (const raw of messages) {
            if (!raw?.message || !raw?.key) continue;
            if (raw.key.fromMe) continue;

            const chatJid = raw.key.remoteJid || '';
            if (!chatJid.endsWith('@g.us')) continue;

            // Skip command messages (case.js handles them separately)
            const body = getMessageText(raw);
            const prefix = global.xprefix || '.';
            if (body && body.startsWith(prefix)) continue;

            await handleGroupMessage(sock, raw);
        }
    } catch (e) {
        console.error('[GROUP-TOOLS-EVENT]', e?.message);
    }
}

function bindSock(sock) {
    if (_bound || !sock || !sock.ev) return;
    _bound = true;
    _boundSock = sock;
    try {
        sock.ev.on('messages.upsert', onMessagesUpsert);
        console.log('[GROUP-TOOLS] event hook registered');
    } catch (e) {
        console.error('[GROUP-TOOLS] failed to bind:', e?.message);
        _bound = false;
    }
}

function tryBindFromGlobals() {
    const candidates = [global.sock, global.conn, global.Hanz, global.client];
    for (const c of candidates) {
        if (c && c.ev) { bindSock(c); return; }
    }
}

tryBindFromGlobals();
let _retryCount = 0;
const _retryTimer = setInterval(() => {
    if (_bound) return clearInterval(_retryTimer);
    if (++_retryCount >= 10) return clearInterval(_retryTimer);
    tryBindFromGlobals();
}, 3000);
if (_retryTimer.unref) _retryTimer.unref();

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'resetlinkgc',
    aliases:     [
        // reset link
        'resetlink', 'revokelink', 'newlink',
        // open time
        'opentime',
        // antilinks
        'antilinkch',
        'antilinkgc', 'algc', 'grouplinkguard',
        'antilinkall', 'alall', 'antialllink',
        'antispam', 'antispamgc',
        'delantilink', 'delalink', 'delblocklink', 'remantilink',
        // group name
        'setnamegc', 'setgroupname', 'setgcname', 'setnamegroup', 'setgroupname',
        // mute
        'mutemember', 'mutmember', 'silentmember', 'bisukanmember',
        // notifications
        'notifdemote', 'notifpromote',
    ],
    category:    'group',
    description: 'Group management tools (links, spam, mute, name, notifications)',
    usage:       'Various — see .resetlinkgc for the entry point',

    async handler(sock, m, args, context) {
        if (!_bound) bindSock(sock);

        const { chatId, reply, isGroup, isOwner, isAdmin, isBotAdmin, prefix } = context;

        if (!isGroup) {
            return reply(global.mess?.only?.group || 'This command only works in groups.');
        }
        if (!isAdmin && !isOwner) {
            return reply(global.mess?.only?.admin || 'Admin only.');
        }

        const calledAs = (context.command || 'resetlinkgc').toLowerCase();

        // ── Bot-admin-required commands ───────────────────────────
        const needsBotAdmin = new Set([
            'resetlinkgc', 'resetlink', 'revokelink', 'newlink',
            'opentime',
            'setnamegc', 'setgroupname', 'setgcname', 'setnamegroup', 'setgroupname',
            'mutemember', 'mutmember', 'silentmember', 'bisukanmember',
            'antilinkch',
            'antilinkgc', 'algc', 'grouplinkguard',
            'antilinkall', 'alall', 'antialllink',
            'antispam', 'antispamgc',
        ]);

        if (needsBotAdmin.has(calledAs) && !isBotAdmin) {
            return reply(global.mess?.only?.badmin || 'Bot must be admin to use this.');
        }

        try {
            // ── Dispatch ──────────────────────────────────────────
            if (['resetlinkgc', 'resetlink', 'revokelink', 'newlink'].includes(calledAs)) {
                return await cmdResetLink(sock, m, args, context);
            }
            if (calledAs === 'opentime') {
                return await cmdOpenTime(sock, m, args, context);
            }
            if (calledAs === 'antilinkch') {
                return await cmdAntiLinkCh(sock, m, args, context);
            }
            if (['antilinkgc', 'algc', 'grouplinkguard'].includes(calledAs)) {
                return await cmdAntiLinkGc(sock, m, args, context);
            }
            if (['antilinkall', 'alall', 'antialllink'].includes(calledAs)) {
                return await cmdAntiLinkAll(sock, m, args, context);
            }
            if (['antispam', 'antispamgc'].includes(calledAs)) {
                return await cmdAntiSpam(sock, m, args, context);
            }
            if (['delantilink', 'delalink', 'delblocklink', 'remantilink'].includes(calledAs)) {
                return await cmdDelAntiLink(sock, m, args, context);
            }
            if (['setnamegc', 'setgroupname', 'setgcname', 'setnamegroup', 'setgroupname'].includes(calledAs)) {
                return await cmdSetNameGc(sock, m, args, context);
            }
            if (['mutemember', 'mutmember', 'silentmember', 'bisukanmember'].includes(calledAs)) {
                return await cmdMuteMember(sock, m, args, context);
            }
            if (calledAs === 'notifdemote') {
                return await cmdNotifDemote(sock, m, args, context);
            }
            if (calledAs === 'notifpromote') {
                return await cmdNotifPromote(sock, m, args, context);
            }

            return reply(`❌ Unknown sub-command: \`${calledAs}\``);
        } catch (error) {
            console.error(`[GROUP-TOOLS:${calledAs}]`, error?.message || error);
            await react(sock, chatId, m.key, '❌');
            return reply(global.mess?.error?.fitur || 'Feature error.');
        }
    },

    // Exposed for advanced use
    _getSetting: getSetting,
    _setSetting: setSetting,
    isMutedMember,
    bindSock,
};