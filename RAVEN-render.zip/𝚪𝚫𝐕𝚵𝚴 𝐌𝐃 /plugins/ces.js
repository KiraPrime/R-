'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const {
    getSessionConfig,
    claimSession,
    updateSession,
    resetSessionConfig,
    isSessionOwner,
    normalizeJid,
} = require('../lib/session-config');

const SECRET_KEYS = new Set(['apikey', 'capikey']);

function mask(value) {
    const text = String(value || '');
    if (!text) return 'not set';
    if (text.length <= 8) return '••••••••';
    return `${text.slice(0, 4)}••••${text.slice(-4)}`;
}

function ownerOnly(context) {
    return context.isOwner || isSessionOwner(context.sessionId, context.sender);
}

function usage(prefix = '.') {
    return `⚙️ *PTERODACTYL SESSION CONFIGURATION*\n\n` +
        `This session is independent from other sessions.\n\n` +
        `*First-time use:*\n> ${prefix}ces\n\n` +
        `*Session owner commands:*\n` +
        `> ${prefix}ces status\n` +
        `> ${prefix}ces set domain https://panel.example.com\n` +
        `> ${prefix}ces set apikey PTLA...\n` +
        `> ${prefix}ces set capikey PTLC...\n` +
        `> ${prefix}ces set location 1\n` +
        `> ${prefix}ces set nodeegg 15\n` +
        `> ${prefix}ces set nodenestid 5\n` +
        `> ${prefix}ces set pyegg 16\n` +
        `> ${prefix}ces set pynestid 5\n` +
        `> ${prefix}ces setserver server1 https://panel.example.com|PTLA...\n\n` +
        `API keys are never displayed in plain text.`;
}

function status(context) {
    const cfg = getSessionConfig(context.sessionId);
    const p = cfg.pterodactyl;
    const servers = cfg.serverInfo?.pterodactyl || {};
    const configuredServers = Object.entries(servers)
        .filter(([, value]) => value?.domain && value?.apikey)
        .map(([key]) => key)
        .join(', ') || 'none';
    return `⚙️ *PTERODACTYL — SESSION*\n\n` +
        `👤 Session owner : @${normalizeJid(cfg.owner).split('@')[0] || 'not set'}\n` +
        `🌐 Domain : ${p.domain || 'not set'}\n` +
        `🔑 Application key : ${mask(p.apikey)}\n` +
        `🔐 Client key : ${mask(p.capikey)}\n` +
        `📍 Location : ${p.location || 'not set'}\n` +
        `🖥️ Configured serverinfo : ${configuredServers}`;
}

function parseValue(key, raw) {
    if (['location', 'nodeegg', 'nodenestid', 'pyegg', 'pynestid'].includes(key)) {
        if (!/^\d+$/.test(raw)) throw new Error('This value must be numeric.');
        return raw;
    }
    if (key === 'sshport') {
        if (!/^\d+$/.test(raw)) throw new Error('The SSH port must be numeric.');
        return Number(raw);
    }
    return raw;
}

function buildPatch(key, raw) {
    const value = parseValue(key, raw);
    const p = {};
    if (key === 'domain' || key === 'apikey' || key === 'capikey' || key === 'location') p[key] = value;
    else if (key === 'nodeegg') p.eggs = { node: { egg: value } };
    else if (key === 'nodenestid') p.eggs = { node: { nestid: value } };
    else if (key === 'pyegg') p.eggs = { python: { egg: value } };
    else if (key === 'pynestid') p.eggs = { python: { nestid: value } };
    else if (key === 'nodocker') p.docker = { node: value };
    else if (key === 'pydocker') p.docker = { python: value };
    else if (key === 'sshuser') p.sshUser = value;
    else if (key === 'sshport') p.sshPort = value;
    else throw new Error(`Unknown key: ${key}`);
    return p;
}

module.exports = {
    command: 'ces',
    aliases: ['sessionconfig', 'sessionowner'],
    category: 'owner',
    description: 'Claim and configure this bot session Pterodactyl settings',
    usage: '.ces [status|set <key> <value>]',

    async handler(sock, message, args, context) {
        const { reply, prefix, sessionId, sender, isOwner } = context;
        const sub = String(args[0] || '').toLowerCase();
        const sessionOwner = isSessionOwner(sessionId, sender);

        // .ces claims an unclaimed private session for the first user who runs it.
        if (!sub || sub === 'claim') {
            if (context.isGroup) return reply('❌ Use `.ces` in a private chat with this session.');
            const result = claimSession(sessionId, sender);
            if (!result.ok && result.reason === 'claimed' && !sessionOwner && !isOwner) {
                return reply('❌ This session already has an owner.');
            }
            if (result.ok && !sessionOwner) {
                return reply(`✅ You are now the owner of this bot session.\n\n${usage(prefix)}`);
            }
            return reply(`${status(context)}\n\n${usage(prefix)}`);
        }

        if (!ownerOnly(context)) return reply('❌ Only the owner of this session can use this command.');
        if (sub === 'status' || sub === 'config') return reply(status(context));
        if (sub === 'help') return reply(usage(prefix));

        if (sub === 'set') {
            const key = String(args[1] || '').toLowerCase();
            const raw = args.slice(2).join(' ').trim();
            if (!key || !raw) return reply(usage(prefix));
            try {
                const patch = buildPatch(key, raw);
                updateSession(sessionId, { pterodactyl: patch });
                return reply(`✅ *${key}* configuration saved for this session.\n\n${status(context)}`);
            } catch (error) {
                return reply(`❌ ${error.message}\n\n${usage(prefix)}`);
            }
        }

        if (sub === 'setserver') {
            const serverKey = String(args[1] || '').toLowerCase();
            const raw = args.slice(2).join(' ').trim();
            if (!/^server[1-5]$/.test(serverKey) || !raw.includes('|')) return reply(usage(prefix));
            const [domain, apikey] = raw.split('|', 2).map(value => value.trim());
            if (!domain || !apikey) return reply(usage(prefix));
            updateSession(sessionId, { serverInfo: { pterodactyl: { [serverKey]: { domain, apikey } } } });
            return reply(`✅ ${serverKey} saved for this session.\n\n${status(context)}`);
        }

        if (sub === 'reset') {
            resetSessionConfig(sessionId);
            return reply('✅ The Pterodactyl settings for this session have been reset.');
        }

        return reply(usage(prefix));
    },
};