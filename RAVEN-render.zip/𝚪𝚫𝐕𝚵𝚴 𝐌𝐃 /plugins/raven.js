/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const { File } = require('megajs');
const path = require('path');
const formatBytes = (bytes) => {
    if (bytes === 0)
        return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2)) } ${ sizes[i]}`;
};
const generateBar = (percentage) => {
    const totalBars = 10;
    const filledBars = Math.floor((percentage / 100) * totalBars);
    return '█'.repeat(filledBars) + '░'.repeat(totalBars - filledBars);
};
const MIME_TYPES = {
    '.mp4': 'video/mp4',
    '.pdf': 'application/pdf',
    '.zip': 'application/zip',
    '.apk': 'application/vnd.android.package-archive',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.mp3': 'audio/mpeg',
    '.mkv': 'video/x-matroska'
};
module.exports = {
    command: 'mega',
    aliases: ['megadl'],
    category: 'download',
    description: 'Download from 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 with real-time progress',
    usage: '.mega <mega-url>',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const text = args.join(' ').trim();
        if (!text) {
            return sendMessageWithChannel(sock, chatId, { text: `*Usage:* .mega https://mega.nz/file/xxxx#xxxx` }, { quoted: message });
        }
        try {
            const file = File.fromURL(text);
            await file.loadAttributes();
            if (file.size >= 500 * 1024 * 1024) {
                return sendMessageWithChannel(sock, chatId, { text: '❌ *Error:* File too large (Limit: 500MB)' }, { quoted: message });
            }
            const { key } = await sendMessageWithChannel(sock, chatId, {
                text: `🌩️ *𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 DOWNLOAD*\n\n▢ *File:* ${file.name}\n▢ *Size:* ${formatBytes(file.size)}\n\n*Progress:* 0% [░░░░░░░░░░]`
            }, { quoted: message });
            const stream = file.download();
            const chunks = [];
            let lastUpdate = Date.now();
            stream.on('progress', async (info) => {
                const { bytesLoaded, bytesTotal } = info;
                const percentage = Math.floor((bytesLoaded / bytesTotal) * 100);
                if (Date.now() - lastUpdate > 3000 || percentage === 100) {
                    const bar = generateBar(percentage);
                    await sendMessageWithChannel(sock, chatId, {
                        text: `🌩️ *𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 DOWNLOAD*\n\n▢ *File:* ${file.name}\n▢ *Size:* ${formatBytes(bytesTotal)}\n\n*Progress:* ${percentage}% [${bar}]`,
                        edit: key
                    });
                    lastUpdate = Date.now();
                }
            });
            stream.on('data', (chunk) => chunks.push(chunk));
            stream.on('end', async () => {
                const buffer = Buffer.concat(chunks);
                const ext = path.extname(file.name ?? '').toLowerCase();
                await sendMessageWithChannel(sock, chatId, {
                    document: buffer,
                    fileName: file.name,
                    mimetype: MIME_TYPES[ext] || 'application/octet-stream',
                    caption: `✅ *Download Complete*\n▢ *File:* ${file.name}\n▢ *Size:* ${formatBytes(file.size)}`
                }, { quoted: message });
            });
            stream.on('error', async (err) => {
                await sendMessageWithChannel(sock, chatId, { text: `❌ *Download Error:* ${err.message}` }, { quoted: message });
            });
        }
        catch (error) {
            await sendMessageWithChannel(sock, chatId, { text: `❌ *Error:* ${error.message}` }, { quoted: message });
        }
    }
};
