/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const words = ['javascript', 'bot', 'hangman', 'whatsapp', 'nodejs', 'python', 'programming', 'developer', 'computer', 'algorithm'];
const hangmanGames = {};
function guessLetter(sock, chatId, letter) {
    if (!hangmanGames[chatId]) {
        sendMessageWithChannel(sock, chatId, { text: '❌ *No game in progress*\n\nStart a new game with `.hangman`' });
        return;
    }
    const game = hangmanGames[chatId];
    const { word, guessedLetters, maskedWord, maxWrongGuesses } = game;
    if (guessedLetters.includes(letter)) {
        sendMessageWithChannel(sock, chatId, { text: `⚠️ *You already guessed "${letter}"*\n\nTry another letter.` });
        return;
    }
    guessedLetters.push(letter);
    if (word.includes(letter)) {
        for (let i = 0; i < word.length; i++) {
            if (word[i] === letter) {
                maskedWord[i] = letter;
            }
        }
        sendMessageWithChannel(sock, chatId, { text: `✅ *Good guess!*\n\n${maskedWord.join(' ')}` });
        if (!maskedWord.includes('_')) {
            sendMessageWithChannel(sock, chatId, { text: `🎉 *Congratulations!*\n\nYou guessed the word: *${word}*` });
            delete hangmanGames[chatId];
        }
    }
    else {
        game.wrongGuesses += 1;
        sendMessageWithChannel(sock, chatId, { text: `❌ *Wrong guess!*\n\nYou have *${maxWrongGuesses - game.wrongGuesses}* tries left.\n\n${maskedWord.join(' ')}` });
        if (game.wrongGuesses >= maxWrongGuesses) {
            sendMessageWithChannel(sock, chatId, { text: `💀 *Game over!*\n\nThe word was: *${word}*` });
            delete hangmanGames[chatId];
        }
    }
}
module.exports = {
    command: 'hangman',
    aliases: ['hang', 'hm'],
    category: 'games',
    description: 'Play hangman word guessing game',
    usage: '.hangman to start, then .guess <letter>',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const word = words[Math.floor(Math.random() * words.length)];
        const maskedWord = '_ '.repeat(word.length).trim();
        hangmanGames[chatId] = {
            word,
            maskedWord: maskedWord.split(' '),
            guessedLetters: [],
            wrongGuesses: 0,
            maxWrongGuesses: 6,
        };
        await sendMessageWithChannel(sock, chatId, {
            text: `🎮 *HANGMAN GAME STARTED!*\n\n` +
                `The word is: ${maskedWord}\n\n` +
                `*How to play:*\n` +
                `• Use \`.guess <letter>\` to guess\n` +
                `• You have 6 wrong guesses allowed\n` +
                `• Guess the word before running out of tries!\n\n` +
                `Good luck! 🍀`
        }, { quoted: message });
    },
    guessLetter
};
