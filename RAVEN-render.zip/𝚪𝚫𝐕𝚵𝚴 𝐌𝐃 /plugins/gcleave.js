/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: 'gcleave',
    aliases: ['leavegroup', 'groupleave', 'leavegc'],
    category: 'owner',
    description: 'Make the bot leave a group',
    usage: '.groupleave — leave current group\n.groupleave <jid> — leave specific group',
    ownerOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const channelInfo = context.channelInfo || {};
        const targetJid = args[0]?.includes('@g.us') ? args[0] : chatId;
        if (!targetJid.endsWith('@g.us')) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `❌ This command only works in groups.\n\nTo leave a specific group: \`.groupleave 1234567890-1234567890@g.us\``,
                ...channelInfo
            }, { quoted: message });
        }
        try {
            await sendMessageWithChannel(sock, targetJid, {
                text: `👋 *Bot is leaving the group.*\n\n_Goodbye everyone!_`,
                ...channelInfo
            });
            await new Promise(r => setTimeout(r, 500));
            await sock.groupLeave(targetJid);
            // If triggered from another chat, confirm there
            if (targetJid !== chatId) {
                await sendMessageWithChannel(sock, chatId, {
                    text: `✅ Left group: \`${targetJid}\``,
                    ...channelInfo
                }, { quoted: message });
            }
        }
        catch (e) {
            console.error('[GROUPLEAVE] Error:', e.message);
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Failed to leave group: ${e.message}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};
