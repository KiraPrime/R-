/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: 'stupid',
    aliases: ['stupidcard', 'dumb'],
    category: 'group',
    description: 'Generate a stupid card for a user',
    usage: '.stupid (reply to user, mention someone, or add text)',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const sender = message.key.participant || message.key.remoteJid;
        const quotedMsg = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const mentionedJid = message.message?.extendedTextMessage?.contextInfo?.mentionedJid;
        const who = quotedMsg
            ? quotedMsg.sender
            : mentionedJid && mentionedJid[0]
                ? mentionedJid[0]
                : sender;
        const text = args && args.length > 0 ? args.join(' ') : 'im+stupid';
        try {
            let avatarUrl;
            try {
                avatarUrl = await sock.profilePictureUrl(who, 'image');
            }
            catch (error) {
                console.error('Error fetching profile picture:', error);
                avatarUrl = 'https://telegra.ph/file/24fa902ead26340f3df2c.png'; // Default avatar
            }
            const apiUrl = `https://api.popcat.xyz/its-so-stupid?image=${encodeURIComponent(avatarUrl)}&text=${encodeURIComponent(text)}`;
            const response = await fetch(apiUrl);
            if (!response.ok)
                throw new Error(`API responded with status: ${response.status}`);
            const imageBuffer = Buffer.from(await response.arrayBuffer());
            await sendMessageWithChannel(sock, chatId, {
                image: imageBuffer,
                caption: `*@${who.split('@')[0]}*`,
                mentions: [who]
            }, { quoted: message });
        }
        catch (error) {
            console.error('Stupid Command Error:', error);
            await sendMessageWithChannel(sock, chatId, {
                text: '❌ Sorry, I couldn\'t generate the stupid card. Please try again later!'
            }, { quoted: message });
        }
    }
};
