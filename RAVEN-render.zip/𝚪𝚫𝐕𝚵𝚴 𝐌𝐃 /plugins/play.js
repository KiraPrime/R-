'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const yts   = require('yt-search');
const sharp = require('sharp');

let prepareWAMessageMedia;
try {
    ({ prepareWAMessageMedia } = require('@rexxhayanasi/elaina-baileys'));
} catch {
    try { ({ prepareWAMessageMedia } = require('@whiskeysockets/baileys')); } catch { prepareWAMessageMedia = null; }
}

// ══════════════════════════════════════════════════════════════════
// ─── YMCDN SCRAPER ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function extractVideoId(url) {
    if (!url) return null;
    let match = null;
    if (url.includes('youtube.com/shorts/') || url.includes('youtu.be/')) {
        match = /\/([a-zA-Z0-9\-_]{11})/.exec(url);
    } else if (url.includes('youtube.com')) {
        match = /v=([a-zA-Z0-9\-_]{11})/.exec(url);
    } else {
        match = /[a-zA-Z0-9\-_]{11}/.exec(url);
    }
    return match ? match[1] : null;
}

async function scrapeYtmp3(youtubeUrl, format = 'mp3') {
    const videoId = extractVideoId(youtubeUrl);
    if (!videoId) throw new Error('Invalid YouTube URL: could not extract video ID.');

    const lowerFormat = format.toLowerCase();
    if (lowerFormat !== 'mp3' && lowerFormat !== 'mp4') {
        throw new Error('Invalid format: must be "mp3" or "mp4".');
    }

    const headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.9',
        'Origin': 'https://id.ytmp3.mobi',
        'Referer': 'https://id.ytmp3.mobi/',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'cross-site',
    };

    // 1. INIT
    const initUrl = `https://a.ymcdn.org/api/v1/init?p=y&23=1llum1n471&_=${Math.random()}`;
    const initRes = await fetch(initUrl, { headers });
    if (!initRes.ok) throw new Error(`Init request failed (${initRes.status})`);

    const initJson = await initRes.json();
    if (initJson.error > 0) throw new Error(`Init API error: ${initJson.error}`);

    // 2. CONVERT
    let convertUrl = initJson.convertURL;
    let convertRequestUrl = `${convertUrl}&v=${videoId}&f=${lowerFormat}&_=${Math.random()}`;
    let convertJson;

    while (true) {
        const convertRes = await fetch(convertRequestUrl, { headers });
        if (!convertRes.ok) throw new Error(`Convert request failed (${convertRes.status})`);

        convertJson = await convertRes.json();
        if (convertJson.error > 0) throw new Error(`Convert API error: ${convertJson.error}`);

        if (convertJson.redirect > 0 && convertJson.redirectURL) {
            convertRequestUrl = `${convertJson.redirectURL}&v=${videoId}&f=${lowerFormat}&_=${Math.random()}`;
            continue;
        }
        break;
    }

    const progressUrl = convertJson.progressURL;
    const downloadUrl = convertJson.downloadURL;
    let title = convertJson.title || 'YouTube';

    if (!progressUrl) throw new Error('Missing progressURL.');
    if (!downloadUrl) throw new Error('Missing downloadURL.');

    // 3. POLL
    let progress = 0;
    let pollCount = 0;
    const maxPolls = 60;

    while (progress < 3 && pollCount < maxPolls) {
        await new Promise(r => setTimeout(r, 1000));
        pollCount++;

        const progressRes = await fetch(progressUrl, { headers });
        if (!progressRes.ok) throw new Error(`Progress request failed (${progressRes.status})`);

        const progressJson = await progressRes.json();
        if (progressJson.error > 0) throw new Error(`Progress API error: ${progressJson.error}`);

        progress = progressJson.progress;
        if (progressJson.title) title = progressJson.title;
    }

    if (progress < 3) throw new Error('Conversion timeout (60s).');

    return { status: 'success', videoId, title, format: lowerFormat, downloadUrl };
}

async function downloadBuffer(url) {
    const res = await fetch(url, {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
            'Referer': 'https://id.ytmp3.mobi/',
        },
    });
    if (!res.ok) throw new Error(`Download failed (${res.status})`);
    return Buffer.from(await res.arrayBuffer());
}

// ══════════════════════════════════════════════════════════════════
// ─── THUMBNAIL ────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function getThumb(url) {
    try {
        const res = await fetch(url);
        if (!res.ok) throw new Error('Thumbnail fetch failed');
        const raw = Buffer.from(await res.arrayBuffer());
        return await sharp(raw)
            .resize(1280, 720, { fit: 'cover', position: 'center' })
            .jpeg({ quality: 90 })
            .toBuffer();
    } catch (e) {
        console.error('[PLAY] Thumb Error:', e?.message);
        return Buffer.alloc(0);
    }
}

async function createHighQualityThumbnail(conn, thumb) {
    try {
        if (!thumb?.length || !prepareWAMessageMedia) return null;
        const { imageMessage } = await prepareWAMessageMedia(
            { image: thumb },
            { upload: conn.waUploadToServer, mediaTypeOverride: 'thumbnail-link' }
        );
        imageMessage.width  = 1280;
        imageMessage.height = 720;
        return imageMessage;
    } catch (e) {
        console.error('[PLAY] HQ Thumb Error:', e?.message);
        return null;
    }
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'play',
    aliases:     ['playaudio', 'song'],
    category:    'music',
    description: 'YouTube → high quality audio (ymcdn) with rich link preview — © 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
    usage:       '.play <song title | youtube link>',

    async handler(sock, message, args, context) {
        const { chatId, reply, prefix } = context;
        const text = (args.join(' ') || '').trim();

        if (!text) {
            return reply(`Example:\n\`${prefix}play chase atlantic\``);
        }

        await sock.sendMessage(chatId, { react: { text: '🎧', key: message.key } }).catch(() => {});

        try {
            let url = text;

            if (!/youtube\.com|youtu\.be/i.test(text)) {
                const search = await yts(text);
                if (!search?.videos?.length) throw 'Song not found';
                url = search.videos[0].url;
            }

            const detail = await yts(url);
            const vid    = detail?.videos?.[0];
            if (!vid) throw 'Video not found';

            const ytUrl   = vid.url || url;
            const thumb   = await getThumb(vid.thumbnail);
            const hqThumb = await createHighQualityThumbnail(sock, thumb);

            const invisible = '\u200B'.repeat(400);

            const caption = `
┈─ ◦ now playing ◦ ─┈

🎵 ${vid.title}

⏱️ ${vid.timestamp || '-'}
👁️ ${Number(vid.views || 0).toLocaleString('en-US')}
📆 ${vid.ago || '-'}

⏳ fetching audio...
`.trim();

            // 1. Envoi du link preview riche
            await sock.sendMessage(
                chatId,
                {
                    text: `${ytUrl}${invisible}\n\n${caption}`,
                    linkPreview: {
                        'matched-text': ytUrl,
                        matchedText:    ytUrl,
                        canonicalUrl:   ytUrl,
                        title:          vid.title,
                        description:    `🎧 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 • ${vid.timestamp || 'Audio'}`,
                        previewType:    0,
                        jpegThumbnail:  thumb,
                        highQualityThumbnail: hqThumb,
                        thumbnailUrl:   vid.thumbnail,
                        linkPreviewMetadata: {
                            linkMediaDuration:   0,
                            socialMediaPostType: 4,
                        },
                    },
                    favicon: { url: vid.thumbnail },
                },
                { quoted: message }
            );

            // 2. Récupération + envoi audio (à la fin)
            try {
                const res = await scrapeYtmp3(ytUrl, 'mp3');
                if (res.status === 'error') throw new Error(res.message);

                const audioBuffer = await downloadBuffer(res.downloadUrl);
                const safeTitle   = String(res.title || vid.title || 'audio')
                    .replace(/[\\/:*?"<>|]/g, '')
                    .trim()
                    .slice(0, 100);

await sock.sendMessage(
    chatId,
    {
        audio:    audioBuffer,
        mimetype: 'audio/mpeg',
        fileName: `${safeTitle}.mp3`,
        ptt:      false,
    }
);

                await sock.sendMessage(chatId, { react: { text: '✅', key: message.key } }).catch(() => {});
            } catch (e) {
                console.error('[PLAY] audio failed:', e);
                await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } }).catch(() => {});
                await reply('❌ Failed to fetch audio, try again later.');
            }
        } catch (e) {
            console.error('[PLAY]', e);
            await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } }).catch(() => {});
            return reply(`❌ ${typeof e === 'string' ? e : e?.message || 'Unknown error'}`);
        }
    },

    // Helpers exposés
    _scrapeYtmp3:    scrapeYtmp3,
    _downloadBuffer: downloadBuffer,
    _getThumb:       getThumb,
};