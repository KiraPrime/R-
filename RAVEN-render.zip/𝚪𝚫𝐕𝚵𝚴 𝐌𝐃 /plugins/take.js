/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const webp = require('node-webpmux');
const crypto = require('crypto');
module.exports = {
    command: 'take',
    aliases: ['steal', 'wm'],
    category: 'stickers',
    description: 'Change sticker pack name',
    usage: '.take <packname> (reply to sticker)',
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        try {
            const quotedMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            if (!quotedMessage?.stickerMessage) {
                await sendMessageWithChannel(sock, chatId, {
                    text: '❌ Reply to a sticker with .take <packname>',
                    ...channelInfo
                }, { quoted: message });
                return;
            }
            const packname = args.join(' ') || '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃';
            try {
                const stickerBuffer = await downloadMediaMessage({
                    key: message.message.extendedTextMessage.contextInfo.stanzaId,
                    message: quotedMessage,
                    // messageType: 'stickerMessage'
                }, 'buffer', {}, {
                    logger: console,
                    reuploadRequest: sock.updateMediaMessage
                });
                if (!stickerBuffer) {
                    await sendMessageWithChannel(sock, chatId, {
                        text: '❌ Failed to download sticker',
                        ...channelInfo
                    }, { quoted: message });
                    return;
                }
                const img = new webp.Image();
                await img.load(stickerBuffer);
                const json = {
                    'sticker-pack-id': crypto.randomBytes(32).toString('hex'),
                    'sticker-pack-name': packname,
                    'emojis': ['🤖']
                };
                const exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00]);
                const jsonBuffer = Buffer.from(JSON.stringify(json), 'utf8');
                const exif = Buffer.concat([exifAttr, jsonBuffer]);
                exif.writeUIntLE(jsonBuffer.length, 14, 4);
                img.exif = exif;
                const finalBuffer = await img.save(null);
                await sendMessageWithChannel(sock, chatId, {
                    sticker: finalBuffer,
                    ...channelInfo
                }, {
                    quoted: message
                });
            }
            catch (error) {
                console.error('Sticker processing error:', error);
                await sendMessageWithChannel(sock, chatId, {
                    text: '❌ Error processing sticker',
                    ...channelInfo
                }, { quoted: message });
            }
        }
        catch (error) {
            console.error('Error in take command:', error);
            await sendMessageWithChannel(sock, chatId, {
                text: '❌ Error processing command',
                ...channelInfo
            }, { quoted: message });
        }
    }
};
