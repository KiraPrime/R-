/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: 'unmute',
    aliases: ['unsilence'],
    category: 'admin',
    description: 'Unmute the group',
    usage: '.unmute',
    groupOnly: true,
    adminOnly: true,
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        try {
            await sock.groupSettingUpdate(chatId, 'not_announcement');
            await sendMessageWithChannel(sock, chatId, {
                text: 'The group has been unmuted.',
                ...channelInfo
            }, { quoted: message });
        }
        catch (error) {
            console.error('Error unmuting group:', error);
            await sendMessageWithChannel(sock, chatId, {
                text: 'Failed to unmute the group.',
                ...channelInfo
            }, { quoted: message });
        }
    }
};
