'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const ARISE_VIDEO_URL = 'https://files.catbox.moe/8aa61s.mp4';

// Image envoyée uniquement lorsqu'une catégorie est sélectionnée via le bouton du menu.
const CATEGORY_REPLY_IMAGES = [
    'https://g.top4top.io/p_3939u4lgq1.jpg',
    'https://f.top4top.io/p_3939b1lhd1.jpg',
    'https://h.top4top.io/p_3939v7o2b1.jpg',
    'https://j.top4top.io/p_3939faytr1.jpg',
    'https://i.top4top.io/p_39391nz8p1.jpg',
    'https://k.top4top.io/p_3939vyxpi1.jpg',
    'https://l.top4top.io/p_39393pj871.jpg',
    'https://a.top4top.io/p_3939py9811.jpg',
];

function getCategoryReplyImage() {
    return CATEGORY_REPLY_IMAGES[Math.floor(Math.random() * CATEGORY_REPLY_IMAGES.length)];
}

const CFG = {
    botName:   '𝗥𝗔𝗩𝗘𝗡 𝗠𝗗',
    ownerName: 'ᴋɪʀᴀ Dev 🇦🇱',
    footer:    '© RAVEN MD • ᴋɪʀᴀ Dev 🇦🇱',

    menuVideo: 'https://files.catbox.moe/51x75m.mp4',
    menuImage: 'menu-thumb.jpg',
    menuThumb:  'arise.gif',
    ownerMenuImage: 'https://d.top4top.io/p_3938harq80.jpg',
    menuAudio: 'https://www.image2url.com/r2/default/audio/1791350866934-95a0892a-5cab-47cd-914f-7448d94337d2.mp3',

    menuMode:  'text',
    menuStyle: 'attached',
    fastText:  false,

    ENABLE_BUTTONS: true,

    website: 'https://t.me/kira4hub',
    timezone: 'Africa/Libreville',

    defaultLevel: '1',
    defaultLimit: '10',

    forward: {
        enabled:         true,
        forwardingScore: 1,
        isForwarded:     true,
        newsletterJid:   '120363410293871779@newsletter',
        newsletterName:  '𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1,
    },

    menuButtonTitle: 'Select Category',
    categories: [
        { title: 'All Menu',      description: 'Show all commands',              id: 'allmenu'        },
        { title: 'Owner Menu',    description: 'Owner only features',            id: 'ownermenu'      },
        { title: 'Panel Menu',    description: 'Pterodactyl & sellers',          id: 'panelmenu'      },
        { title: 'Group Menu',    description: 'Group & moderation',             id: 'grupmenu'       },
        { title: 'Admin Menu',    description: 'Group admin tools',              id: 'adminmenu'      },
        { title: 'Protections',   description: 'Anti-link, anti-toxic, anti-bot',id: 'protectmenu'    },
        { title: 'Downloader',    description: 'YouTube, TikTok, Spotify',       id: 'downloadermenu' },
        { title: 'Tools Menu',    description: 'Utilities & helpers',            id: 'toolsmenu'      },
        { title: 'Sticker Menu',  description: 'Stickers, effects, media',       id: 'stickermenu'    },
        { title: 'Anime Menu',    description: 'Anime, waifu, images',           id: 'animemenu'      },
        { title: 'AI Menu',       description: 'GPT, Mistral, Flux…',            id: 'aimenu'         },
        { title: 'Music Menu',    description: 'YouTube music player',           id: 'musicmenu'      },
        { title: 'Fun Menu',      description: 'Games, husbu, soulmatch',        id: 'funmenu'        },
        { title: 'RPG Menu',      description: 'RPG & economy',                  id: 'rpgmenu'        },
        { title: 'Info Menu',     description: 'Search, stalk, info',            id: 'infomenu'       },
    ],

    orderTitle:  '𝚪𝚫𝐕𝚵𝚴',
    orderMsg:    'https://t.me/kira4hub',
    orderThumb:  'menu-thumb.jpg',
    itemCount:   99999999,
    surface:     99999999,

    channelUrl:  '',
    channelName: 'Channel',
};

// ══════════════════════════════════════════════════════════════════
// ─── IMPORTS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const os      = require('os');
const fs      = require('fs');
const path    = require('path');
const crypto  = require('crypto');
const { spawn }    = require('child_process');
const {
    generateWAMessageFromContent,
    proto,
    prepareWAMessageMedia,
    isJidGroup,
} = require('@whiskeysockets/baileys');

// ══════════════════════════════════════════════════════════════════
// ─── STORE ────────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const STORE_DIR  = path.join(__dirname, 'menu-data');
const STORE_PATH = path.join(STORE_DIR, 'store.json');
const MEDIA_CACHE_DIR = path.join(STORE_DIR, 'media-cache');

let _store = null;
let _saveTimer = null;

function _ensureDir() {
    try {
        if (!fs.existsSync(STORE_DIR)) fs.mkdirSync(STORE_DIR, { recursive: true });
        if (!fs.existsSync(MEDIA_CACHE_DIR)) fs.mkdirSync(MEDIA_CACHE_DIR, { recursive: true });
    }
    catch (e) { console.error('[MENU] mkdir failed:', e?.message); }
}

function loadStore() {
    _ensureDir();
    try {
        if (fs.existsSync(STORE_PATH)) {
            const raw = fs.readFileSync(STORE_PATH, 'utf8').trim();
            if (raw) {
                const parsed = JSON.parse(raw);
                _store = { enableButtons: parsed.enableButtons === true };
                return _store;
            }
        }
    } catch (e) { console.error('[MENU] store corrupted:', e?.message); }
    _store = { enableButtons: CFG.ENABLE_BUTTONS === true };
    writeStoreSync();
    return _store;
}

function writeStoreSync() {
    try {
        _ensureDir();
        const tmp = STORE_PATH + '.tmp';
        fs.writeFileSync(tmp, JSON.stringify(_store, null, 2), 'utf8');
        fs.renameSync(tmp, STORE_PATH);
    } catch (e) { console.error('[MENU] write failed:', e?.message); }
}

function scheduleSave() {
    if (_saveTimer) clearTimeout(_saveTimer);
    _saveTimer = setTimeout(() => { _saveTimer = null; writeStoreSync(); }, 500);
    if (_saveTimer.unref) _saveTimer.unref();
}

function getButtonsEnabled() {
    if (!_store) loadStore();
    return _store.enableButtons === true;
}

function setButtonsEnabled(value) {
    if (!_store) loadStore();
    _store.enableButtons = value === true;
    scheduleSave();
}

loadStore();
process.on('exit', () => { try { writeStoreSync(); } catch {} });

// ══════════════════════════════════════════════════════════════════
// ─── MEDIA ────────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function mediaPath(name) { return path.join(__dirname, '..', 'media', name); }

function loadMediaSync(src) {
    if (!src) return null;
    if (/^https?:\/\//i.test(src)) return { url: src };
    const f = mediaPath(src);
    if (!fs.existsSync(f)) { console.warn(`[MENU] Media absent: ${f}`); return null; }
    return fs.readFileSync(f);
}

async function loadMediaAsync(src) {
    if (!src) return null;
    if (/^https?:\/\//i.test(src)) {
        _ensureDir();
        const cacheKey = crypto.createHash('sha256').update(src).digest('hex');
        const cacheFile = path.join(MEDIA_CACHE_DIR, cacheKey + '.bin');
        try {
            if (fs.existsSync(cacheFile)) return fs.readFileSync(cacheFile);
        } catch (e) { console.warn(`[MENU] Cache read failed: ${e.message}`); }
        try {
            const res = await fetch(src, { signal: AbortSignal.timeout(30000) });
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            const data = Buffer.from(await res.arrayBuffer());
            try { fs.writeFileSync(cacheFile, data); } catch (e) {
                console.warn(`[MENU] Cache write failed: ${e.message}`);
            }
            return data;
        } catch (e) {
            console.warn(`[MENU] Download failed ${src}: ${e.message}`);
            return { url: src };
        }
    }
    return loadMediaSync(src);
}

function loadThumb(name) {
    if (!name) return undefined;
    if (!/\.(png|jpe?g|webp)$/i.test(name)) return undefined;
    const f = mediaPath(name);
    if (!fs.existsSync(f)) return undefined;
    const buf = fs.readFileSync(f);
    return buf.length <= 200 * 1024 ? buf : undefined;
}

let _imgCache   = null;
let _vidCache   = null;
let _ariseVidCache = null;
let _audioCache = null;

async function getMenuImage()  { if (_imgCache) return _imgCache; return (_imgCache = await loadMediaAsync(CFG.menuImage)); }
async function getMenuVideo()  { if (_vidCache) return _vidCache; return (_vidCache = await loadMediaAsync(CFG.menuVideo)); }
async function getAriseVideo() { if (_ariseVidCache) return _ariseVidCache; return (_ariseVidCache = await loadMediaAsync(ARISE_VIDEO_URL)); }
async function getRawAudio()   { if (_audioCache) return _audioCache; return (_audioCache = await loadMediaAsync(CFG.menuAudio)); }

// Précharge les médias sans bloquer le démarrage du bot. Les fichiers sont
// conservés dans plugins/menu-data/media-cache pour les prochains redémarrages.
setImmediate(() => {
    Promise.allSettled([getMenuVideo(), getAriseVideo()])
        .then(() => console.log('[MENU] Media cache ready.'))
        .catch(() => {});
});

// ══════════════════════════════════════════════════════════════════
// ─── GREETING ─────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function getGreeting() {
    let h;
    try {
        h = parseInt(new Intl.DateTimeFormat('en-GB', {
            hour: 'numeric', hour12: false, timeZone: CFG.timezone
        }).format(new Date()), 10) % 24;
    } catch { h = new Date().getHours(); }
    if (h >= 5  && h < 12) return 'good morning';
    if (h >= 12 && h < 18) return 'good afternoon';
    if (h >= 18 && h < 22) return 'good evening';
    return 'good night';
}

function shortUptime(sec) {
    const d = Math.floor(sec / 86400);
    const h = Math.floor((sec % 86400) / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = Math.floor(sec % 60);
    return [d && `${d}d`, (d||h) && `${h}h`, (d||h||m) && `${m}m`, `${s}s`].filter(Boolean).join(' ');
}
const fmtMB = b => `${(b/1024/1024).toFixed(0)} MB`;
const fmtGB = b => `${(b/1024/1024/1024).toFixed(1)} GB`;

// ══════════════════════════════════════════════════════════════════
// ─── COMMAND SECTIONS ─────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const COMMAND_SECTIONS = [];

function formatSection(section) {
    const emoji = section.emoji || '📡';
    let out = `╭─〔 *${section.name}* ${emoji} 〕─\n`;
    for (const cmd of section.cmds) out += `│ ❍ /${cmd}\n`;
    out += `╰────────────────────\n\n`;
    return out;
}

function getLiveCommandSections() {
    const order = [
        ['GENERAL', '🌐'], ['GROUP', '👥'], ['ADMIN', '🛡️'], ['OWNER', '👑'],
        ['PROTECTIONS', '🔒'], ['DOWNLOAD', '📥'], ['AI', '🤖'], ['TOOLS', '🔧'],
        ['UTILITY', '⚙️'], ['STICKERS', '🧩'], ['ANIME', '🌸'], ['IMAGES', '🖼️'],
        ['FUN', '🎉'], ['GAMES', '🎮'], ['RPG', '⚔️'], ['INFO', 'ℹ️'],
        ['SEARCH', '🔍'], ['STALKER', '🕵️'], ['MUSIC', '🎵'], ['PANEL', '🖥️'], ['QUOTES', '💬'],
    ];
    const groups = new Map(order.map(([name, emoji]) => [name, { name, emoji, cmds: [] }]));
    const fallback = groups.get('GENERAL');
    const normalize = {
        general:'GENERAL', menu:'GENERAL', maker:'TOOLS', internet:'TOOLS',
        group:'GROUP', admin:'ADMIN', owner:'OWNER', protection:'PROTECTIONS',
        protections:'PROTECTIONS', download:'DOWNLOAD', downloader:'DOWNLOAD',
        ai:'AI', tools:'TOOLS', utility:'UTILITY', sticker:'STICKERS', stickers:'STICKERS',
        anime:'ANIME', images:'IMAGES', fun:'FUN', game:'GAMES', games:'GAMES',
        rpg:'RPG', info:'INFO', search:'SEARCH', stalk:'STALKER', stalker:'STALKER',
        music:'MUSIC', panel:'PANEL', quotes:'QUOTES',
    };
    let plugins = [];
    try {
        const caseRef = require('../case.js');
        if (caseRef?.commands instanceof Map) plugins = [...caseRef.commands.values()];
    } catch {}
    if (!plugins.length) {
        try {
            const fs = require('fs');
            const path = require('path');
            for (const file of fs.readdirSync(__dirname).filter(f => f.endsWith('.js'))) {
                try {
                    const p = require(path.join(__dirname, file));
                    if (p?.command && typeof p.handler === 'function') plugins.push(p);
                } catch {}
            }
        } catch {}
    }
    const seen = new Set();
    for (const plugin of plugins) {
        const section = groups.get(normalize[String(plugin.category || 'general').toLowerCase()]) || fallback;
        const add = value => {
            const cmd = String(value || '').trim().toLowerCase();
            if (cmd && /^[a-z0-9][a-z0-9_-]*$/i.test(cmd) && !seen.has(cmd)) {
                seen.add(cmd);
                section.cmds.push(cmd);
            }
        };
        add(plugin.command);
        for (const alias of (Array.isArray(plugin.aliases) ? plugin.aliases : [])) add(alias);
    }
    return order.map(([name]) => groups.get(name)).filter(section => section.cmds.length);
}
function buildAllSections() { return getLiveCommandSections().map(formatSection).join(''); }

// ══════════════════════════════════════════════════════════════════
// ─── CATEGORY → SECTIONS ──────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const CATEGORY_MAP = {
    allmenu:        null,
    ownermenu:      ['OWNER'],
    panelmenu:      ['PANEL'],
    grupmenu:       ['GROUP'],
    adminmenu:      ['ADMIN','GROUP'],
    protectmenu:    ['PROTECTIONS','GROUP'],
    downloadermenu: ['DOWNLOAD'],
    toolsmenu:      ['TOOLS','UTILITY'],
    stickermenu:    ['STICKERS'],
    animemenu:      ['ANIME','IMAGES'],
    aimenu:         ['AI'],
    musicmenu:      ['MUSIC'],
    funmenu:        ['FUN','GAMES'],
    rpgmenu:        ['RPG'],
    infomenu:       ['INFO','SEARCH','STALKER'],
};

function buildCategoryContent(categoryId) {
    if (categoryId === 'allmenu' || !(categoryId in CATEGORY_MAP)) {
        return { content: buildAllSections(), total: totalCmds(null), title: 'ALL COMMANDS' };
    }
    const names = CATEGORY_MAP[categoryId];
    const sections = getLiveCommandSections().filter(s => names.includes(s.name));
    if (!sections.length) return { content: '> No commands in this category.', total: 0, title: '—' };
    return {
        content: sections.map(formatSection).join(''),
        total:   sections.reduce((n, s) => n + s.cmds.length, 0),
        title:   names.join(' + '),
    };
}

function totalCmds(names) {
    if (!names) return getLiveCommandSections().reduce((n, s) => n + s.cmds.length, 0);
    return getLiveCommandSections().filter(s => names.includes(s.name))
        .reduce((n, s) => n + s.cmds.length, 0);
}

// ══════════════════════════════════════════════════════════════════
// ─── HEADER ───────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function buildHeader({ tag, role, status, isPremium, isOwner, commandsMap }) {
    const limit    = isOwner || isPremium ? '∞' : CFG.defaultLimit;
    const mode     = String(global.botMode || 'PUBLIC').toUpperCase();
    const website  = CFG.website.replace(/^https?:\/\//i, '');
    const btnState = getButtonsEnabled() ? '✅ ON' : '❌ OFF';

    let text = `Hey 👋 @${tag}, ${getGreeting()}.\n\n`;
    text += `╭─〔 *USER INFO* 👤 〕─\n`;
    text += `│ ❍ ʀᴏʟᴇ    : ${role}\n`;
    text += `│ ❍ ꜱᴛᴀᴛᴜꜱ  : ${status}\n`;
    text += `│ ❍ ᴛʜᴇᴍᴇ   : SOLO LEVELING\n`;
    text += `│ ❍ ʙᴏᴛ     : ${CFG.botName} (${mode})\n`;
    text += `│ ❍ ʟᴇᴠᴇʟ   : ${CFG.defaultLevel}\n`;
    text += `│ ❍ ʟɪᴍɪᴛ   : ${limit}\n`;
    text += `│ ❍ ʙᴜᴛᴛᴏɴꜱ : ${btnState}\n`;
    text += `╰────────────────────\n\n`;

    text += `╭─〔 *SYSTEM STATS* 📊 〕─\n`;
    text += `│ ❍ ᴜᴘᴛɪᴍᴇ  : ${shortUptime(process.uptime())}\n`;
    text += `│ ❍ ʀᴀᴍ     : ${fmtMB(process.memoryUsage().rss)}\n`;
    text += `│ ❍ ᴛᴏᴛᴀʟ   : ${fmtGB(os.totalmem())}\n`;
    text += `│ ❍ ᴘʟᴜɢɪɴꜱ : ${commandsMap ? commandsMap.size : '—'}\n`;
    text += `│ ❍ ᴡᴇʙꜱɪᴛᴇ : ${website}\n`;
    text += `╰────────────────────\n\n`;

    text += `_*This bot was never meant to amuse you. It existed only to test you. And you are the only one I found worthy to command it.*_\n\n`;
    text += `\`Type .arise to display all commands.\``;
    return text;
}

// ══════════════════════════════════════════════════════════════════
// ─── FAKE ORDER ───────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function buildFakeWeb() {
    return {
        key: { participant: '0@s.whatsapp.net' },
        message: {
            orderMessage: {
                itemCount:  CFG.itemCount,
                surface:    CFG.surface,
                message:    CFG.orderMsg,
                orderTitle: CFG.orderTitle,
                thumbnail:  loadThumb(CFG.orderThumb),
                sellerJid:  '0@s.whatsapp.net',
            },
        },
    };
}

// ══════════════════════════════════════════════════════════════════
// ─── FORWARD CONTEXT ──────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function buildForwardContext() {
    if (!CFG.forward?.enabled) return null;
    return {
        forwardingScore: CFG.forward.forwardingScore ?? 1,
        isForwarded:     CFG.forward.isForwarded ?? true,
        forwardedNewsletterMessageInfo: {
            newsletterJid:   CFG.forward.newsletterJid,
            newsletterName:  CFG.forward.newsletterName,
            serverMessageId: CFG.forward.serverMessageId ?? -1,
        },
    };
}

// ══════════════════════════════════════════════════════════════════
// ─── BUTTONS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function buildCategoryButton() {
    return {
        name: 'single_select',
        buttonParamsJson: JSON.stringify({
            title: CFG.menuButtonTitle,
            sections: [{
                title:           CFG.menuButtonTitle,
                highlight_label: '',
                rows:            CFG.categories.map(c => ({
                    title:       c.title,
                    description: c.description || '',
                    id:          c.id,
                })),
            }],
        }),
    };
}

// ══════════════════════════════════════════════════════════════════
// ─── PHOTO CARD ───────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function buildPhotoCard(img) {
    const thumbUrl = /^https?:\/\//i.test(CFG.menuImage) ? CFG.menuImage
        : `https://u.pone.rs/aroggcod.jpg`;

    let thumbnail = null;
    if (Buffer.isBuffer(img)) {
        thumbnail = img;
        try {
            thumbnail = await require('sharp')(img)
                .resize(640, null, { withoutEnlargement: true })
                .jpeg({ quality: 70 })
                .toBuffer();
        } catch {}
    }

    return {
        title:                 CFG.botName,
        body:                  CFG.footer,
        mediaType:             1,
        thumbnailUrl:          thumbUrl,
        sourceUrl:             CFG.website,
        renderLargerThumbnail: true,
        showAdAttribution:     false,
        ...(thumbnail ? { thumbnail } : {}),
    };
}

// ══════════════════════════════════════════════════════════════════
// ─── INTERACTIVE HELPERS ──────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function buildInteractiveNodes(buttonType = 'mixed') {
    return [{
        tag: 'biz', attrs: {},
        content: [{
            tag: 'interactive',
            attrs: { type: 'native_flow', v: '1' },
            content: [{ tag: 'native_flow', attrs: { v: '9', name: buttonType } }],
        }],
    }];
}

function buildContextInfo(fakeWeb, extra = {}) {
    const base = {};
    if (fakeWeb) {
        try {
            base.stanzaId      = fakeWeb.key?.id;
            base.participant   = fakeWeb.key?.participant;
            base.quotedMessage = fakeWeb.message;
        } catch {}
    }
    const fwd = buildForwardContext();
    if (fwd) Object.assign(base, fwd);
    const merged = { ...base, ...extra };
    return Object.keys(merged).length ? merged : null;
}

function buildInteractiveMessage(jid, interactiveMsg) {
    return generateWAMessageFromContent(jid, proto.Message.fromObject({
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata:        {},
                    deviceListMetadataVersion: 2,
                },
                interactiveMessage: interactiveMsg,
            },
        },
    }), { userJid: jid });
}

async function relayInteractive(Hanz, jid, waMsg, buttonType = 'mixed') {
    const nodes = buildInteractiveNodes(buttonType);
    if (!isJidGroup(jid)) nodes.push({ tag: 'bot', attrs: { biz_bot: '1' } });
    return Hanz.relayMessage(jid, waMsg.message, {
        messageId:      waMsg.key.id,
        additionalNodes: nodes,
    });
}

// ══════════════════════════════════════════════════════════════════
// ─── DELIVER (logique Raven MD) ───────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function withTimeout(promise, ms, label) {
    let t;
    const timeout = new Promise((_, rej) => {
        t = setTimeout(() => rej(new Error(`${label} timeout ${ms/1000}s`)), ms);
    });
    return Promise.race([promise, timeout]).finally(() => clearTimeout(t));
}

async function deliver(Hanz, jid, { text, footer, buttons, userJid, video, fakeWeb }) {
    const img      = await getMenuImage();
    const mentions = [userJid];
    const hasVideo = !!video;
    const hasImg   = !!img;

    const hasButtons = Array.isArray(buttons) && buttons.length > 0;
    const caption    = `${text}\n\n${footer}`.trim();
    const quoted     = { quoted: fakeWeb };
    const fwd        = buildForwardContext();

    let adCard = null;
    if (hasImg) {
        try { adCard = await buildPhotoCard(img); }
        catch (e) { console.error('[MENU] photo card failed:', e?.message); }
    }

    // ── Cas A : pas de boutons (allmenu) ──────────────────────────
    if (!hasButtons) {
        if (hasVideo) {
            try {
                await withTimeout(
                    Hanz.sendMessage(jid, {
                        video,
                        gifPlayback: true,
                        caption,
                        contextInfo: {
                            mentionedJid: [userJid],
                            ...(adCard ? { externalAdReply: adCard } : {}),
                            ...(fwd || {}),
                        },
                    }, quoted),
                    90000, 'send menu GIF'
                );
                return;
            } catch (err) {
                console.error('[MENU] GIF failed:', err?.message || err);
            }
        }

        if (hasImg) {
            try {
                await withTimeout(
                    Hanz.sendMessage(jid, {
                        text: caption,
                        contextInfo: {
                            mentionedJid: [userJid],
                            externalAdReply: adCard,
                            ...(fwd || {}),
                        },
                    }, quoted),
                    60000, 'menu photo + ad'
                );
                return;
            } catch (err) {
                console.error('[MENU] photo+ad failed:', err?.message);
                try {
                    await Hanz.sendMessage(jid, {
                        image: img, caption, mentions,
                        contextInfo: fwd || undefined,
                    }, quoted);
                    return;
                } catch {}
            }
        }

        await Hanz.sendMessage(jid, {
            text: caption, mentions, contextInfo: fwd || undefined,
        }, quoted);
        return;
    }

    // ── Cas B : boutons (interactive) ─────────────────────────────
    const attached  = !!(hasVideo && img) && CFG.menuStyle !== 'stacked';
    let   photoSent = false;

    if (hasVideo && img && !attached) {
        try {
            await Hanz.sendMessage(jid, { image: img }, quoted);
            photoSent = true;
        } catch {}
    }

    const contextInfo = buildContextInfo(fakeWeb, { mentionedJid: [userJid] });
    if (attached && adCard) contextInfo.externalAdReply = adCard;

    if (CFG.menuMode !== 'simple') {
        try {
            if (hasVideo) {
                const media = await prepareWAMessageMedia(
                    Buffer.isBuffer(video)
                        ? { video, gifPlayback: true }
                        : { video: { url: video.url || video }, gifPlayback: true },
                    { upload: Hanz.waUploadToServer }
                );
                const msg = proto.Message.InteractiveMessage.fromObject({
                    body:   { text },
                    footer: { text: footer },
                    header: { hasMediaAttachment: true, ...media },
                    nativeFlowMessage: { buttons, messageParamsJson: '' },
                    ...(contextInfo ? { contextInfo } : {}),
                });
                await relayInteractive(Hanz, jid, buildInteractiveMessage(jid, msg), 'mixed');
            } else if (img) {
                const media = await prepareWAMessageMedia(
                    Buffer.isBuffer(img) ? { image: img } : { image: { url: img.url } },
                    { upload: Hanz.waUploadToServer }
                );
                const msg = proto.Message.InteractiveMessage.fromObject({
                    body:   { text },
                    footer: { text: footer },
                    header: { hasMediaAttachment: true, ...media },
                    nativeFlowMessage: { buttons, messageParamsJson: '' },
                    ...(contextInfo ? { contextInfo } : {}),
                });
                await relayInteractive(Hanz, jid, buildInteractiveMessage(jid, msg), 'mixed');
            }
            return;
        } catch (err) {
            console.error('[MENU] interactive failed:', err?.message);
        }
    }

    if (hasVideo && img && !photoSent) {
        try { await Hanz.sendMessage(jid, { image: img }, quoted); } catch {}
    }
    const content = hasVideo
        ? { video, gifPlayback: true, caption, mentions, contextInfo: fwd || undefined }
        : img
            ? { image: img, caption, mentions, contextInfo: fwd || undefined }
            : { text: caption, mentions, contextInfo: fwd || undefined };
    await Hanz.sendMessage(jid, content, { quoted: fakeWeb });
}

// ══════════════════════════════════════════════════════════════════
// ─── AUDIO VOICE NOTE ─────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function toOpusVoice(input) {
    return new Promise((resolve, reject) => {
        const proc = spawn('ffmpeg', [
            '-hide_banner', '-loglevel', 'error',
            '-i', 'pipe:0',
            '-vn', '-ac', '1', '-ar', '48000',
            '-c:a', 'libopus', '-b:a', '48k', '-application', 'voip',
            '-f', 'ogg', 'pipe:1',
        ], { stdio: ['pipe', 'pipe', 'pipe'] });

        const out = []; let err = '';
        proc.stdout.on('data', d => out.push(d));
        proc.stderr.on('data', d => { err += d.toString(); });
        proc.on('error', reject);
        proc.stdin.on('error', () => {});
        proc.on('close', code => {
            const buf = Buffer.concat(out);
            if (code === 0 && buf.length > 0) resolve(buf);
            else reject(new Error(`ffmpeg code ${code}: ${err.trim().slice(0, 200)}`));
        });
        proc.stdin.end(input);
    });
}

let _audioPrepared = null;

async function prepareAudio() {
    const src = CFG.menuAudio;
    if (!src) return null;
    if (_audioPrepared?.src === src) return _audioPrepared;

    const raw = await getRawAudio();
    if (!raw || !Buffer.isBuffer(raw)) return null;

    let ogg = null;
    try { ogg = await toOpusVoice(raw); }
    catch (e) { console.warn('[MENU-AUDIO] VN conversion failed:', e.message); }
    return (_audioPrepared = { ogg, raw, src });
}

async function sendMenuAudio(Hanz, jid) {
    if (!CFG.menuAudio) return;
    try {
        const a = await prepareAudio();
        if (!a) return;
        const fwd = buildForwardContext();

        if (a.ogg) {
            await Hanz.sendMessage(jid, {
                audio: a.ogg,
                mimetype: 'audio/ogg; codecs=opus',
                ptt: true,
                ...(fwd ? { contextInfo: fwd } : {}),
            });
        } else {
            await Hanz.sendMessage(jid, {
                audio: a.raw,
                mimetype: 'audio/mpeg',
                ptt: false,
                ...(fwd ? { contextInfo: fwd } : {}),
            });
        }
    } catch (e) { console.error('[MENU-AUDIO] failed:', e?.message || e); }
}

// ══════════════════════════════════════════════════════════════════
// ─── SEND A CATEGORY ──────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function sendCategory(Hanz, jid, categoryId, sender) {
    const { content, total, title } = buildCategoryContent(categoryId);

    const header =
        `╭─〔 *${title}* 📡 〕─\n` +
        `│ ❍ ᴛᴏᴛᴀʟ : ${total}\n` +
        `╰────────────────────\n\n`;

    const footer = `\n> _Type .Arise to unleash your Shadows_`;

    // Cette image est réservée au clic sur une catégorie du bouton interactif.
    // Les commandes texte et les réponses ordinaires restent textuelles.
    await Hanz.sendMessage(jid, {
        image: { url: getCategoryReplyImage() },
        caption: header + content + footer,
        mentions: sender ? [sender] : [],
    });
}

// ══════════════════════════════════════════════════════════════════
// ─── INTERACTIVE RESPONSE PARSER ──────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function extractSelectedId(message) {
    if (!message) return null;
    const msg = message.message || message;

    const ir =
        msg.interactiveResponseMessage ||
        msg.viewOnceMessage?.message?.interactiveResponseMessage ||
        msg.viewOnceMessageV2?.message?.interactiveResponseMessage ||
        msg.viewOnceMessageV2Extension?.message?.interactiveResponseMessage;

    if (ir) {
        const paramsJson =
            ir?.nativeFlowResponseMessage?.paramsJson ||
            ir?.nativeFlowResponseMessage?.params_json;
        if (paramsJson) {
            try {
                const parsed = typeof paramsJson === 'string' ? JSON.parse(paramsJson) : paramsJson;
                const id = parsed?.id || parsed?.selectedId || parsed?.selected_id;
                if (id) return id;
            } catch {}
        }
        if (ir?.buttonId) return ir.buttonId;
        if (ir?.selectedButtonId) return ir.selectedButtonId;
    }

    const lr = msg.listResponseMessage || msg.viewOnceMessage?.message?.listResponseMessage;
    if (lr) {
        const id = lr?.singleSelectReply?.selectedRowId;
        if (id) return id;
    }

    const br = msg.buttonsResponseMessage || msg.viewOnceMessage?.message?.buttonsResponseMessage;
    if (br) {
        const id = br?.selectedButtonId;
        if (id) return id;
    }

    return null;
}

// ══════════════════════════════════════════════════════════════════
// ─── MAIN EXPORT ──────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'menu',
    aliases:     ['help', 'commands', 'list', 'h', 'menubuttons', 'arise'],
    category:    'general',
    description: 'Main menu — stats + button categories / .arise for full commands',
    usage:       '.menu',

    async handler(sock, message, args, context) {
        const { chatId, sender, isOwner, isPremium, prefix, command } = context;
        const cmd = (command || 'menu').toLowerCase();

        if (cmd === 'menubuttons') {
            if (!isOwner) return context.reply(global.mess?.only?.owner || 'Owner only.');
            const action = (args[0] || '').toLowerCase();
            if (action !== 'on' && action !== 'off') {
                const state = getButtonsEnabled() ? '✅ ON' : '❌ OFF';
                return context.reply(
                    `🎛️ *MENU BUTTONS*\n\n> Status: *${state}*\n\n` +
                    `*Usage:*\n> \`${prefix}menubuttons on\`\n> \`${prefix}menubuttons off\``,
                );
            }
            setButtonsEnabled(action === 'on');
            return context.reply(
                action === 'on'
                    ? `✅ *CATEGORY BUTTONS ENABLED*\n\n> Type \`.menu\` to see the button.`
                    : `❌ *CATEGORY BUTTONS DISABLED*\n\n> The menu will be plain text.`,
            );
        }

        if (cmd === 'arise') {
            const total = getLiveCommandSections().reduce((n, s) => n + s.cmds.length, 0);
            const header =
                `╭─〔 *ALL COMMANDS* 📡 〕─\n` +
                `│ ❍ ᴛᴏᴛᴀʟ : ${total}\n` +
                `╰────────────────────\n\n`;

            await deliver(sock, chatId, {
                text:    header + buildAllSections(),
                footer:  `_*These commands were never meant to serve. They exist to test the one worthy to wield them.*_`,
                buttons: [],
                userJid: sender,
                video:   CFG.fastText ? null : await getAriseVideo(),
                fakeWeb: CFG.fastText ? null : buildFakeWeb(),
            });
            return;
        }

        const tag  = (sender || '').split('@')[0].split(':')[0];
        const role = isOwner ? 'Super Owner' : (isPremium ? 'Premium' : 'User');
        const stat = isOwner ? 'Owner'       : (isPremium ? 'Premium' : 'Free');

        let commandsMap = new Map();
        try {
            const caseRef = require('../case.js');
            if (caseRef?.commands instanceof Map) commandsMap = caseRef.commands;
        } catch {}

        const headerText = buildHeader({
            tag, role, status: stat, isPremium, isOwner, commandsMap,
        });

        const videoSource = CFG.fastText ? null : await getMenuVideo();

        const fakeWeb = CFG.fastText ? null : buildFakeWeb();

        const buttons = getButtonsEnabled()
            ? [buildCategoryButton()].filter(Boolean)
            : [];

        await deliver(sock, chatId, {
            text:     headerText,
            footer:   CFG.footer,
            buttons,
            userJid:  sender,
            video:    videoSource,
            fakeWeb,
        });

        // Aucun audio automatique après l'affichage du menu.
    },

    async handleInteractive(sock, message, context = {}) {
        try {
            const selectedId = extractSelectedId(message);
            if (!selectedId) return false;

            const validIds = new Set(CFG.categories.map(c => c.id));
            if (!validIds.has(selectedId)) return false;

            const jid    = context.chatId || message.key?.remoteJid;
            const sender = context.sender || message.key?.participant || jid;

            console.log(`[MENU] category selected: ${selectedId}`);
            await sendCategory(sock, jid, selectedId, sender);
            return true;
        } catch (e) {
            console.error('[MENU] handleInteractive error:', e?.message);
            return false;
        }
    },

    _getButtonsEnabled: getButtonsEnabled,
    _setButtonsEnabled: setButtonsEnabled,
    _extractSelectedId: extractSelectedId,
};