/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require('axios');
module.exports = {
    command: 'stickers',
    aliases: ['stickersearch', 'ssticker'],
    category: 'stickers',
    description: 'Search for stickers using Tenor',
    usage: '.stickers <search term>',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const text = args?.join(' ')?.trim();
        if (!text) {
            return await sendMessageWithChannel(sock, chatId, { text: '*Provide a search term.*\nExample: .stickers funny' }, { quoted: message });
        }
        try {
            await sendMessageWithChannel(sock, chatId, { text: 'Searching for stickers...' }, { quoted: message });
            const { data } = await axios.get(`https://g.tenor.com/v1/search?q=${encodeURIComponent(text)}&key=LIVDSRZULELA&limit=8`);
            if (!data?.results?.length) {
                return await sendMessageWithChannel(sock, chatId, { text: '❌ No stickers found.' }, { quoted: message });
            }
            const limit = Math.min(data.results.length, 5);
            for (let i = 0; i < limit; i++) {
                const media = data.results[i].media?.[0]?.mp4?.url;
                if (!media)
                    continue;
                await sendMessageWithChannel(sock, chatId, { video: { url: media }, caption: `Sticker ${i + 1}`, mimetype: 'video/mp4' }, { quoted: message });
            }
        }
        catch (error) {
            console.error('StickerSearch plugin error:', error);
            await sendMessageWithChannel(sock, chatId, { text: '❌ Failed to fetch stickers.' }, { quoted: message });
        }
    }
};
