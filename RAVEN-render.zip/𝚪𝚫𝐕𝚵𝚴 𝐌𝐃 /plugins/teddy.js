/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const teddyUsers = {};
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));
module.exports = {
    command: 'teddy',
    aliases: [],
    category: 'fun',
    description: 'Send an animated teddy with cute emojis',
    usage: '.teddy',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const sender = message.key.participant || message.key.remoteJid;
        if (teddyUsers[sender])
            return;
        teddyUsers[sender] = true;
        const teddyEmojis = [
            '❤', '💕', '😻', '🧡', '💛', '💚', '💙', '💜', '🖤', '❣',
            '💞', '💓', '💗', '💖', '💘', '💝', '💟', '♥', '💌', '🙂',
            '🤗', '😌', '😉', '🤗', '😊', '🎊', '🎉', '🎁', '🎈'
        ];
        try {
            const pingMsg = await sendMessageWithChannel(sock, chatId, { text: `(\\_/)\n( •.•)\n/>🤍` }, { quoted: message });
            for (let i = 0; i < teddyEmojis.length; i++) {
                await sleep(500);
                await sock.relayMessage(chatId, {
                    protocolMessage: {
                        key: pingMsg.key,
                        type: 14,
                        editedMessage: {
                            conversation: `(\\_/)\n( •.•)\n/>${teddyEmojis[i]}`
                        }
                    }
                }, {});
            }
        }
        catch (err) {
            console.error('Error in teddy command:', err);
            try {
                await sendMessageWithChannel(sock, chatId, { text: '❌ Something went wrong while sending teddy emojis.' }, { quoted: message });
            }
            catch { }
        }
        finally {
            delete teddyUsers[sender];
        }
    }
};
