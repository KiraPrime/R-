'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function numOf(jid) {
    if (!jid) return '';
    return String(jid).split(':')[0].split('@')[0].replace(/[^0-9]/g, '');
}

function getParticipantJid(p) {
    if (!p) return '';
    if (p.jid && !p.jid.endsWith('@lid')) return p.jid;
    if (p.phoneNumber && !p.phoneNumber.endsWith('@lid')) return p.phoneNumber;
    if (p.id && !p.id.endsWith('@lid')) return p.id;
    const raw = p.id || p.jid || p.lid || '';
    return raw.endsWith('@lid') ? raw.replace('@lid', '@s.whatsapp.net') : raw;
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch { /* ignore */ }
}

function delay(ms) {
    return new Promise(res => setTimeout(res, ms));
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'onlinecheck',
    aliases:     ['checkonline', 'online', 'whosonline', 'whoisonline'],
    category:    'group',
    description: 'Check which group members are currently online',
    usage:       '.onlinecheck',

    async handler(sock, m, args, context) {
        const { chatId, reply, isGroup, groupMetadata, prefix } = context;

        // ── Group only ────────────────────────────────────────────
        if (!isGroup) {
            return reply(global.mess?.only?.group || 'This command only works in groups.');
        }
        if (!groupMetadata || !Array.isArray(groupMetadata.participants)) {
            return reply(global.mess?.error?.fitur || 'Could not read group metadata.');
        }

        await react(sock, chatId, m.key, '🔍');

        try {
            const participants = groupMetadata.participants;

            if (participants.length === 0) {
                await react(sock, chatId, m.key, '❌');
                return reply(`❌ *FAILED*\n\n> Could not fetch group members.`);
            }

            await reply(
                `🔍 *SCANNING ONLINE MEMBERS...*\n\n` +
                `> Waiting for response from ${participants.length} member(s)\n` +
                `> Estimated: 5–10 seconds`,
            );

            // ── Presence collector ────────────────────────────────
            const presences = {};

            const presenceHandler = (update) => {
                if (update.id !== chatId || !update.presences) return;
                for (const [jid, presence] of Object.entries(update.presences)) {
                    const state = presence?.lastKnownPresence;
                    if (state === 'available' || state === 'composing' || state === 'recording') {
                        presences[jid] = state;
                    }
                }
            };

            sock.ev.on('presence.update', presenceHandler);

            // ── Subscribe in batches ──────────────────────────────
            const batchSize = 10;
            for (let i = 0; i < participants.length; i += batchSize) {
                const batch = participants.slice(i, i + batchSize);
                await Promise.all(
                    batch.map(p => {
                        const jid = getParticipantJid(p);
                        return jid ? sock.presenceSubscribe(jid).catch(() => {}) : null;
                    }),
                );
                await delay(500);
            }

            // ── Wait for responses ────────────────────────────────
            await delay(5000);

            // ── Cleanup ───────────────────────────────────────────
            try { sock.ev.off('presence.update', presenceHandler); } catch {}

            // ── Build response ────────────────────────────────────
            const onlineMembers = Object.keys(presences);
            const mentions = onlineMembers;

            let text = `📊 *ONLINE CHECK*\n\n`;
            text += `╭┈┈⬡「 📋 *GROUP INFO* 」\n`;
            text += `┃ 👥 Name: *${groupMetadata.subject || 'Unknown'}*\n`;
            text += `┃ 👤 Total: \`${participants.length}\` member(s)\n`;
            text += `┃ 🟢 Online: \`${onlineMembers.length}\` member(s)\n`;
            text += `╰┈┈⬡\n\n`;

            if (onlineMembers.length === 0) {
                text += `> _No members detected online_\n`;
                text += `> _Make sure they have WhatsApp open_`;
            } else {
                text += `╭┈┈⬡「 🟢 *ONLINE MEMBERS* 」\n`;

                let count = 0;
                for (const jid of onlineMembers) {
                    if (count >= 50) {
                        text += `┃ ... and ${onlineMembers.length - 50} more member(s)\n`;
                        break;
                    }

                    const number = numOf(jid);
                    const targetNum = numOf(jid);
                    const participant = participants.find(
                        p => numOf(getParticipantJid(p)) === targetNum,
                    );
                    const isAdmin = participant?.admin === 'admin' || participant?.admin === 'superadmin';
                    const adminBadge = isAdmin ? ' 👑' : '';

                    let statusIcon = '🟢';
                    if (presences[jid] === 'composing') statusIcon = '⌨️';
                    if (presences[jid] === 'recording') statusIcon = '🎤';

                    text += `┃ ${statusIcon} @${number}${adminBadge}\n`;
                    count++;
                }

                text += `╰┈┈⬡\n\n`;
                text += `> 🟢 Online | ⌨️ Typing | 🎤 Recording audio`;
            }

            await react(sock, chatId, m.key, '✅');
            await sendMessageWithChannel(sock, chatId, {
                image: { url: 'https://h.top4top.io/p_3938idl6l0.jpg' },
                caption: text,
                mentions,
            });

        } catch (error) {
            console.error('[CEKONLINE]', error?.message || error);
            await react(sock, chatId, m.key, '☢');
            return reply(global.mess?.error?.fitur || 'Failed to check online members.');
        }
    },
};