/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: 'itunes',
    aliases: ['song', 'music', 'track'],
    category: 'info',
    description: 'Get detailed information about a song from iTunes',
    usage: '.itunes <song name>',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const text = args.join(' ').trim();
        if (!text) {
            await sendMessageWithChannel(sock, chatId, {
                text: '*Please provide a song name.*\nExample: `.itunes Blinding Lights`',
                quoted: message
            });
            return;
        }
        try {
            const url = `https://api.popcat.xyz/itunes?q=${encodeURIComponent(text)}`;
            const res = await fetch(url);
            if (!res.ok)
                throw new Error(`API request failed with status ${res.status}`);
            const json = await res.json();
            const songInfo = `
🎵 *${json.name || 'N/A'}*
👤 *Artist:* ${json.artist || 'N/A'}
💿 *Album:* ${json.album || 'N/A'}
📅 *Release Date:* ${json.release_date || 'N/A'}
💰 *Price:* ${json.price || 'N/A'}
⏱️ *Length:* ${json.length || 'N/A'}
🎼 *Genre:* ${json.genre || 'N/A'}
🔗 *URL:* ${json.url || 'N/A'}
      `.trim();
            if (json.thumbnail) {
                await sendMessageWithChannel(sock, chatId, {
                    image: { url: json.thumbnail },
                    caption: songInfo,
                    quoted: message
                });
            }
            else {
                await sendMessageWithChannel(sock, chatId, { text: songInfo, quoted: message });
            }
        }
        catch (error) {
            console.error('iTunes Command Error:', error);
            await sendMessageWithChannel(sock, chatId, {
                text: '❌ An error occurred while fetching the song info. Please try again later.',
                quoted: message
            });
        }
    }
};
