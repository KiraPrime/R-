/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require('axios');
module.exports = {
    command: 'istock',
    aliases: ['istockdl', 'istockdownload'],
    category: 'download',
    description: 'Download image or video from iStock URL',
    usage: '.istock <iStock URL>',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const url = args?.[0]?.trim();
        if (!url) {
            return await sendMessageWithChannel(sock, chatId, { text: 'Please provide an iStock URL.\nExample: .istock https://www.istockphoto.com/video/...' }, { quoted: message });
        }
        try {
            const apiUrl = `https://discardapi.dpdns.org/api/dl/istock?apikey=guru&url=${encodeURIComponent(url)}`;
            const { data } = await axios.get(apiUrl, { timeout: 10000 });
            if (!data?.status || !data.result) {
                return await sendMessageWithChannel(sock, chatId, { text: '❌ Failed to fetch media from the provided iStock URL.' }, { quoted: message });
            }
            const item = data.result;
            if (item.video) {
                await sendMessageWithChannel(sock, chatId, { video: { url: item.video }, caption: '🎬 *iStock Video*' }, { quoted: message });
            }
            if (item.image) {
                await sendMessageWithChannel(sock, chatId, { image: { url: item.image }, caption: '🖼️ *iStock Image*' }, { quoted: message });
            }
        }
        catch (error) {
            console.error('iStock download plugin error:', error);
            if (error.code === 'ECONNABORTED') {
                await sendMessageWithChannel(sock, chatId, { text: '❌ Request timed out. The API may be slow or unreachable.' }, { quoted: message });
            }
            else {
                await sendMessageWithChannel(sock, chatId, { text: '❌ Failed to download media from iStock URL.' }, { quoted: message });
            }
        }
    }
};
