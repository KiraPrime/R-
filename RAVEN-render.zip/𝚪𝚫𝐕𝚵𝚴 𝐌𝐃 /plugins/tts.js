/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const { gSpeak } = require('gspeak');
const fs = require('fs');
const path = require('path');
module.exports = {
    command: 'tts',
    aliases: ['texttospeech', 'speak'],
    category: 'tools',
    description: 'Convert text to speech and send as an audio message.',
    usage: '.tts <text> [language code]',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        if (!args.length) {
            return sendMessageWithChannel(sock, chatId, { text: '*Please provide text for TTS.*\nExample: `.tts Hello world`\nWith language: `.tts Hola mundo es`' }, { quoted: message });
        }
        let language = 'en';
        if (args.length > 1 && /^[a-z]{2}$/.test(args[args.length - 1])) {
            language = args.pop();
        }
        const text = args.join(' ').trim();
        const filePath = path.join(process.cwd(), 'tmp', `tts-${Date.now()}.mp3`);
        const tempDir = path.dirname(filePath);
        if (!fs.existsSync(tempDir))
            fs.mkdirSync(tempDir, { recursive: true });
        try {
            await new Promise((resolve, reject) => {
                const tts = new gSpeak(text, language);
                tts.save(filePath, (err) => {
                    if (err)
                        reject(err);
                    else
                        resolve();
                });
            });
            await sendMessageWithChannel(sock, chatId, {
                audio: { url: filePath },
                mimetype: 'audio/mpeg',
                fileName: 'tts.mp3'
            }, { quoted: message });
        }
        catch (err) {
            console.error('TTS error:', err.message);
            await sendMessageWithChannel(sock, chatId, { text: `❌ Failed to generate TTS audio.\nReason: ${err.message}` }, { quoted: message });
        }
        finally {
            if (fs.existsSync(filePath))
                fs.unlinkSync(filePath);
        }
    }
};
