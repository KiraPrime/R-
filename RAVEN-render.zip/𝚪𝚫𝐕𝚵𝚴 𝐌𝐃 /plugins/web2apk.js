'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const axios     = require('axios');
const FormData  = require('form-data');

// ══════════════════════════════════════════════════════════════════
// ─── APPMaker SCRAPER ─────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const appmaker = {
    defaultHeaders: {
        'User-Agent':           'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
        'Accept':               'application/json, text/plain, */*',
        'Accept-Encoding':      'gzip, deflate, br, zstd',
        'sec-ch-ua-platform':   '"Android"',
        'sec-ch-ua':            '"Not;A=Brand";v="99", "Google Chrome";v="139", "Chromium";v="139"',
        'dnt':                  '1',
        'sec-ch-ua-mobile':     '?1',
        'origin':               'https://create.appmaker.xyz',
        'sec-fetch-site':       'same-site',
        'sec-fetch-mode':       'cors',
        'sec-fetch-dest':       'empty',
        'referer':              'https://create.appmaker.xyz/',
        'accept-language':      'id,en-US;q=0.9,en;q=0.8,ja;q=0.7',
        'priority':             'u=1, i',
    },

    createApp: async (url, email) => {
        const data = JSON.stringify({ url, email });
        const config = {
            method: 'POST',
            url:    'https://standalone-app-api.appmaker.xyz/webapp/build',
            headers: {
                ...appmaker.defaultHeaders,
                'Content-Type': 'application/json;charset=UTF-8',
            },
            data: data,
        };
        const response = await axios.request(config);
        return response.data;
    },

    uploadFileBuffer: async (buffer, filename, appId) => {
        const data = new FormData();
        data.append('file', buffer, { filename });
        data.append('id', appId);

        const config = {
            method: 'POST',
            url:    'https://standalone-app-api.appmaker.xyz/webapp/build/file-upload',
            headers: {
                ...appmaker.defaultHeaders,
                ...data.getHeaders(),
            },
            data: data,
        };
        const response = await axios.request(config);
        return response.data;
    },

    buildApp: async (appConfig) => {
        const data = JSON.stringify(appConfig);
        const config = {
            method: 'POST',
            url:    'https://standalone-app-api.appmaker.xyz/webapp/build/build',
            headers: {
                ...appmaker.defaultHeaders,
                'Content-Type': 'application/json;charset=UTF-8',
            },
            data: data,
        };
        const response = await axios.request(config);
        return response.data;
    },

    checkStatus: async (appId) => {
        const config = {
            method: 'GET',
            url:    `https://standalone-app-api.appmaker.xyz/webapp/build/status?appId=${appId}`,
            headers: { ...appmaker.defaultHeaders },
        };
        const response = await axios.request(config);
        return response.data;
    },

    getDownloadUrl: async (appId) => {
        const config = {
            method: 'GET',
            url:    `https://standalone-app-api.appmaker.xyz/webapp/complete/download?appId=${appId}`,
            headers: appmaker.defaultHeaders,
        };
        const response = await axios.request(config);
        return response.data;
    },

    create: async (url, email, appName, iconBuffer, splashBuffer, options = {}) => {
        const createResult = await appmaker.createApp(url, email);
        const appId = createResult.body.appId;

        const iconUpload   = await appmaker.uploadFileBuffer(iconBuffer, 'icon.jpeg', appId);
        const appIconUrl   = iconUpload.cloudStoragePublicUrl;

        const splashUpload = await appmaker.uploadFileBuffer(splashBuffer, 'splash.jpeg', appId);
        const splashIconUrl = splashUpload.cloudStoragePublicUrl;

        const appConfig = {
            appId:                appId,
            appIcon:              appIconUrl,
            appName:              appName,
            isPaymentInProgress:  false,
            enableShowToolBar:    options.enableShowToolBar !== undefined ? options.enableShowToolBar : true,
            toolbarColor:         options.toolbarColor     || '#03A9F4',
            toolbarTitleColor:    options.toolbarTitleColor || '#FFFFFF',
            splashIcon:           splashIconUrl,
            ...options,
        };

        await appmaker.buildApp(appConfig);

        let status;
        let attempts = 0;
        const maxAttempts = 30;

        do {
            await new Promise(resolve => setTimeout(resolve, 10000));
            status = await appmaker.checkStatus(appId);
            attempts++;

            if (status.body?.status === 'success') {
                break;
            } else if (status.body?.status === 'failed') {
                throw new Error('App build failed on Appmaker server');
            }
        } while (attempts < maxAttempts && status.body?.status !== 'success');

        if (attempts >= maxAttempts) {
            throw new Error('Build timeout — exceeded waiting limit');
        }

        const downloadInfo = await appmaker.getDownloadUrl(appId);

        return {
            appId:       appId,
            appName:     downloadInfo.body.appName,
            packageName: downloadInfo.body.package_name,
            downloadUrl: downloadInfo.body.buildFile,
            aabFile:     downloadInfo.body.aabFile,
            appIcon:     downloadInfo.body.appIcon,
        };
    },
};

// ══════════════════════════════════════════════════════════════════
// ─── IMAGE DETECTION HELPER ───────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function checkImageMedia(msg) {
    if (!msg) return false;
    if (msg.mtype === 'imageMessage') return true;

    const rawMsg   = msg.message || msg.msg || msg;
    const mimetype =
        msg.mimetype ||
        rawMsg?.mimetype ||
        rawMsg?.documentMessage?.mimetype ||
        rawMsg?.imageMessage?.mimetype ||
        '';
    return mimetype.startsWith('image/');
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'web2apk',
    aliases:     ['apkbuild', 'makeapk'],
    category:    'maker',
    description: 'Convert a website URL into an Android app (.apk) — © 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
    usage:       '.web2apk AppName | URL | Email (reply to an image for icon/splash)',

    async handler(sock, message, args, context) {
        const { chatId, reply, prefix, command } = context;

        const isDirectImage = checkImageMedia(message);
        const quoted        = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const isQuotedImage = quoted ? checkImageMedia({ message: quoted }) : false;
        const targetMsg     = isQuotedImage ? quoted : (isDirectImage ? message.message : null);

        const text = (args.join(' ') || '').trim();
        const pfx  = prefix || '.';

        if (!text) {
            await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } }).catch(() => {});
            return reply(
                `*Wrong format!*\n\n` +
                `Reply to an image (for Icon & Splash Screen) with caption:\n` +
                `\`${pfx}${command} AppName | URL | Email\`\n\n` +
                `*Example:*\n` +
                `\`${pfx}${command} KitsuLabs | https://www.kitsulabs.xyz | mymail@gmail.com\``
            );
        }

        const [appName, webUrl, userEmail] = text.split('|').map(s => s?.trim());

        if (!appName || !webUrl || !userEmail) {
            await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } }).catch(() => {});
            return reply(
                `*Incomplete format!*\n\n` +
                `Use pipe (|) separators:\n` +
                `\`${pfx}${command} AppName | URL | Email\``
            );
        }

        if (!webUrl.startsWith('http://') && !webUrl.startsWith('https://')) {
            await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } }).catch(() => {});
            return reply('❌ Website URL must start with `http://` or `https://`');
        }

        if (!targetMsg) {
            await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } }).catch(() => {});
            return reply('❌ Please attach/reply to an image to use as Icon & Splash Screen!');
        }

        await sock.sendMessage(chatId, { react: { text: '⏳', key: message.key } }).catch(() => {});
        await reply('⏳ *Building APK...*\n\n> This takes about 1-3 minutes. Please wait!');

        try {
            const { downloadMediaMessage } = require('@whiskeysockets/baileys');

            let imgBuffer;
            try {
                if (quoted) {
                    imgBuffer = await downloadMediaMessage(
                        { key: message.key, message: { imageMessage: quoted.imageMessage } },
                        'buffer',
                        {},
                        { reuploadRequest: sock.updateMediaMessage }
                    );
                } else {
                    imgBuffer = await downloadMediaMessage(message, 'buffer', {}, {
                        reuploadRequest: sock.updateMediaMessage,
                    });
                }
            } catch (e) {
                console.error('[WEB2APK] download failed:', e?.message);
            }

            if (!imgBuffer) {
                await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } }).catch(() => {});
                return reply('❌ Failed to download the icon image.');
            }

            const res = await appmaker.create(webUrl, userEmail, appName, imgBuffer, imgBuffer);

            await sock.sendMessage(chatId, { react: { text: '✅', key: message.key } }).catch(() => {});

            const caption =
                `🚀 *WEB2APK CONVERTER SUCCESS*\n\n` +
                `📱 *App name:* ${res.appName}\n` +
                `📦 *Package name:* \`${res.packageName}\`\n` +
                `🆔 *App ID:* \`${res.appId}\`\n\n` +
                `🔗 *APK download link:*\n${res.downloadUrl}`;

            return reply(caption);
        } catch (error) {
            console.error('[WEB2APK]', error);
            await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } }).catch(() => {});
            return reply(`❌ *FAILED TO BUILD APK*\n\n> ${error.message}`);
        }
    },

    // Expose helpers for future use
    _appmaker:       appmaker,
    _checkImageMedia: checkImageMedia,
};