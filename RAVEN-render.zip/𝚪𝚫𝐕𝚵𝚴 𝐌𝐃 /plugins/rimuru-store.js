'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const fs = require("fs");
const path = require("path");
const dir = path.join(__dirname, "rimuru-data");
const file = path.join(dir, "users.json");
let db;
function load(){ if(db) return db; try{db=JSON.parse(fs.readFileSync(file,"utf8"));}catch{db={};} return db; }
function save(){ fs.mkdirSync(dir,{recursive:true}); const t=file+".tmp"; fs.writeFileSync(t,JSON.stringify(db,null,2)); fs.renameSync(t,file); }
function id(j){return String(j||"").split(":")[0].split("@")[0].replace(/[^0-9]/g,"");}
function get(j,name){const d=load(), k=id(j); if(!d[k]) d[k]={id:k,name:name||"User",cash:0,exp:0,level:1,inventory:{},cooldowns:{}}; if(name)d[k].name=name; return d[k];}
function money(n){return Number(n||0).toLocaleString("en-US");}
function cooldown(ms){const s=Math.max(0,Math.ceil(ms/1000));return `${Math.floor(s/3600)}h ${Math.floor(s%3600/60)}m ${s%60}s`;}
function target(m,c){return c?.mentionedJid?.[0]||m?.mentionedJid?.[0]||c?.quoted?.sender||m?.quoted?.sender||null;}
module.exports={load,save,id,get,money,cooldown,target};
