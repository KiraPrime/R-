/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: 'getpp',
    aliases: ['dlpp', 'profilepic', 'getdp'],
    category: 'general',
    description: 'Get user profile picture',
    usage: '.getpp @user or reply or number',
    async handler(sock, message, args, _context) {
        const chatId = message.key.remoteJid;
        const isGroup = chatId.endsWith('@g.us');
        let target;
        let displayName = 'Unknown';
        let displayNumber = '';
        const quoted = message.message?.extendedTextMessage?.contextInfo;
        if (quoted?.mentionedJid?.[0]) {
            target = quoted.mentionedJid[0];
        }
        else if (quoted?.participant) {
            target = quoted.participant;
            if (quoted.pushName)
                displayName = quoted.pushName;
        }
        else if (args[0]) {
            const input = args[0].replace(/[^0-9]/g, '');
            if (input.length >= 10) {
                target = `${input }@s.whatsapp.net`;
                displayName = ''; // Will be resolved later, don't show Unknown
            }
            else {
                return await sendMessageWithChannel(sock, chatId, {
                    text: '❌ Invalid number. Use format: 923051234567 or +923051234567'
                }, { quoted: message });
            }
        }
        else {
            return await sendMessageWithChannel(sock, chatId, {
                text: '📸 *Get Profile Picture*\n\nUsage:\n• Reply to a message\n• Mention someone: `.getpp @user`\n• Provide a number: `.getpp 923001234567`'
            }, { quoted: message });
        }
        try {
            let realJid = target;
            if (target.endsWith('@lid') && isGroup) {
                const metadata = await sock.groupMetadata(chatId);
                const participant = metadata.participants.find((p) => p.lid === target || p.id === target);
                if (participant?.id) {
                    realJid = participant.id;
                }
            }
            const cleanNumber = realJid.replace(/@s\.whatsapp\.net|@lid/g, '').split(':')[0];
            // Only show number if it looks like a real phone number (10+ digits)
            displayNumber = cleanNumber.length >= 10 ? `+${cleanNumber}` : '';
            if (displayName === 'Unknown') {
                try {
                    const name = await sock.getName(realJid);
                    if (name && !name.startsWith('+'))
                        displayName = name;
                }
                catch (e) { }
            }
            let ppUrl = null;
            try {
                ppUrl = await sock.profilePictureUrl(realJid, 'image');
            }
            catch (e) {
                return await sendMessageWithChannel(sock, chatId, {
                    text: `❌ No profile picture found for *${displayName}* (${displayNumber})`
                }, { quoted: message });
            }
            if (ppUrl) {
                await sendMessageWithChannel(sock, chatId, {
                    image: { url: ppUrl },
                    caption: `📸 *Profile Picture*${displayName && displayName !== 'Unknown' ? `\n\n👤 *Name:* ${ displayName}` : ''}${displayNumber ? `\n📱 *Number:* ${ displayNumber}` : ''}`
                }, { quoted: message });
            }
        }
        catch (error) {
            console.error('GetPP Error:', error);
            await sendMessageWithChannel(sock, chatId, {
                text: '❌ Failed to fetch profile picture.'
            }, { quoted: message });
        }
    }
};
