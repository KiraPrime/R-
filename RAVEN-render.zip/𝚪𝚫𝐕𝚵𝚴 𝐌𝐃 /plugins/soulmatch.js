'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── DATA ─────────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const ELEMENTS = [
    'Fire 🔥', 'Water 💧', 'Earth 🌍', 'Wind 🌪️',
    'Lightning ⚡', 'Ice ❄️', 'Light ✨', 'Shadow 🌑',
];

const ZODIAC = [
    '♈ Aries', '♉ Taurus', '♊ Gemini', '♋ Cancer',
    '♌ Leo', '♍ Virgo', '♎ Libra', '♏ Scorpio',
    '♐ Sagittarius', '♑ Capricorn', '♒ Aquarius', '♓ Pisces',
];

const SOUL_TYPES = [
    'Brave Leader',
    'Wise Balancer',
    'Expressive Creator',
    'Solid Builder',
    'Free Adventurer',
    'Loyal Protector',
    'Mystic Thinker',
    'Mighty Conqueror',
    'Pure Humanitarian',
];

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function generateSoulData(name, seed) {
    const nameVal = Array.from(name.toLowerCase())
        .reduce((a, c) => a + c.charCodeAt(0), 0);
    return {
        element:  ELEMENTS[(nameVal + seed) % ELEMENTS.length],
        zodiac:   ZODIAC[(nameVal + seed * 2) % ZODIAC.length],
        soulType: SOUL_TYPES[(nameVal + seed * 3) % SOUL_TYPES.length],
    };
}

function getMatchDescription(score) {
    if (score >= 90) return '💫 True Destiny';
    if (score >= 80) return '✨ Perfect Harmony';
    if (score >= 70) return '🌟 Strong Connection';
    if (score >= 60) return '⭐ Good Potential';
    if (score >= 50) return '🌙 Needs Effort';
    return '🌑 Heavy Challenge';
}

function getReading(score) {
    if (score >= 80) {
        return 'Your souls share a rare and special connection. Fate has planned this meeting.';
    }
    if (score >= 60) {
        return 'There is strong chemistry between you two. Your differences create harmony.';
    }
    if (score >= 40) {
        return 'It will take time to understand each other. Each challenge will strengthen your bond.';
    }
    return 'Significant differences in soul energy. Needs a lot of adaptation and understanding.';
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch { /* ignore */ }
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'soulmatch',
    aliases:     ['soulmate', 'lovematch', 'lovescore', 'compatibility'],
    category:    'fun',
    description: 'Check soul compatibility between two names',
    usage:       '.soulmatch name1|name2',

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix } = context;

        const text = (args.join(' ') || '').trim();

        // ── Require "name1|name2" ─────────────────────────────────
        if (!text || !text.includes('|')) {
            return reply(
                `💫 *SOUL MATCH*\n\n` +
                `> Check the soul compatibility between two names!\n\n` +
                `*Format:*\n` +
                `> \`${prefix}soulmatch name1|name2\`\n\n` +
                `*Example:*\n` +
                `> \`${prefix}soulmatch Raiden|Mei\``,
            );
        }

        const [name1, name2] = text.split('|').map(n => n.trim());

        if (!name1 || !name2) {
            return reply(`❌ Provide two names: \`${prefix}soulmatch name1|name2\``);
        }

        await react(sock, chatId, m.key, '🕕');

        // ── Compute soul data + compatibility ─────────────────────
        const seed1 = Date.now() % 100;
        const seed2 = (Date.now() + 50) % 100;

        const soul1 = generateSoulData(name1, seed1);
        const soul2 = generateSoulData(name2, seed2);

        const combined = name1.toLowerCase() + name2.toLowerCase();
        const baseScore = Array.from(combined).reduce((a, c) => a + c.charCodeAt(0), 0);
        const compatibility = (baseScore % 51) + 50; // between 50 and 100

        // ── Build the response ────────────────────────────────────
        let txt = `╭═══❯ *💫 SOUL MATCH* ❮═══\n`;
        txt += `│\n`;
        txt += `│ 👤 *${name1}*\n`;
        txt += `│ ├ 🔮 Soul: ${soul1.soulType}\n`;
        txt += `│ ├ 🌟 Element: ${soul1.element}\n`;
        txt += `│ └ 🎯 Zodiac: ${soul1.zodiac}\n`;
        txt += `│\n`;
        txt += `│ 👤 *${name2}*\n`;
        txt += `│ ├ 🔮 Soul: ${soul2.soulType}\n`;
        txt += `│ ├ 🌟 Element: ${soul2.element}\n`;
        txt += `│ └ 🎯 Zodiac: ${soul2.zodiac}\n`;
        txt += `│\n`;
        txt += `│ 💕 *COMPATIBILITY*\n`;
        txt += `│ ├ 📊 Score: *${compatibility}%*\n`;
        txt += `│ └ 🎭 Status: ${getMatchDescription(compatibility)}\n`;
        txt += `│\n`;
        txt += `│ 🔮 *Reading:*\n`;
        txt += `│ ${getReading(compatibility)}\n`;
        txt += `│\n`;
        txt += `╰════════════════════`;

        await sendMessageWithChannel(sock, chatId, { text: txt });

        await react(sock, chatId, m.key, '✅');
    },
};