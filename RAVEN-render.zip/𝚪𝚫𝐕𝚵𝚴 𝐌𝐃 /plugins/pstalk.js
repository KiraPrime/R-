/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require('axios');
module.exports = {
    command: 'pinstalk',
    aliases: ['pstalk', 'pinprofile'],
    category: 'stalk',
    description: 'Lookup Pinterest user profile',
    usage: '.pinstalk <username>',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        if (!args.length) {
            return await sendMessageWithChannel(sock, chatId, {
                text: '*Please provide a Pinterest username.*\nExample: .pinstalk anti_establishment'
            }, { quoted: message });
        }
        const username = args[0];
        try {
            const { data } = await axios.get(`https://discardapi.dpdns.org/api/stalk/pinterest`, {
                params: { apikey: 'guru', username }
            });
            if (!data?.result) {
                return await sendMessageWithChannel(sock, chatId, { text: '❌ Pinterest user not found.' }, { quoted: message });
            }
            const result = data.result;
            const profileImage = result.image?.large || result.image?.original || null;
            const caption = `📌 *Pinterest Profile Info*\n\n` +
                `👤 Full Name: ${result.full_name || 'N/A'}\n` +
                `🆔 Username: ${result.username || 'N/A'}\n` +
                `📝 Bio: ${result.bio || 'N/A'}\n` +
                `📌 Boards: ${result.stats?.boards || 0}\n` +
                `👥 Followers: ${result.stats?.followers || 0}\n` +
                `➡ Following: ${result.stats?.following || 0}\n` +
                `❤️ Likes: ${result.stats?.likes || 0}\n` +
                `📌 Pins: ${result.stats?.pins || 0}\n` +
                `💾 Saves: ${result.stats?.saves || 0}\n` +
                `🔗 Profile URL: ${result.profile_url || 'N/A'}\n` +
                `🌐 Website: ${result.website || 'N/A'}`;
            if (profileImage) {
                await sendMessageWithChannel(sock, chatId, { image: { url: profileImage }, caption }, { quoted: message });
            }
            else {
                await sendMessageWithChannel(sock, chatId, { text: caption }, { quoted: message });
            }
        }
        catch (err) {
            console.error('Pinterest plugin error:', err);
            await sendMessageWithChannel(sock, chatId, { text: '❌ Failed to fetch Pinterest profile.' }, { quoted: message });
        }
    }
};
