/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require('axios');
const yts = require('yt-search');
const DL_API = 'https://api.qasimdev.dpdns.org/api/loaderto/download';
const API_KEY = 'xbps-install-Syu';
const wait = (ms) => new Promise(r => setTimeout(r, ms));
const downloadWithRetry = async (url, retries = 3) => {
    for (let i = 0; i < retries; i++) {
        try {
            const { data } = await axios.get(DL_API, {
                params: { apiKey: API_KEY, format: 'mp3', url },
                timeout: 120000
            });
            if (data?.data?.downloadUrl)
                return data.data;
            throw new Error('No download URL');
        }
        catch (err) {
            if (i === retries - 1)
                throw err;
            console.log(`Download attempt ${i + 1} failed, retrying in 5s...`);
            await wait(5000);
        }
    }
    throw new Error('All download attempts failed');
};
module.exports = {
    command: 'song',
    aliases: ['music', 'audio', 'mp3'],
    category: 'music',
    description: 'Download song from YouTube (MP3)',
    usage: '.song <song name | youtube link>',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const query = args.join(' ').trim();
        if (!query)
            return sendMessageWithChannel(sock, chatId, { text: '🎵 *Song Downloader*\n\nUsage:\n.song <song name | YouTube link>' }, { quoted: message });
        try {
            let video;
            if (query.includes('youtube.com') || query.includes('youtu.be')) {
                video = { url: query };
            }
            else {
                const { videos } = await yts(query);
                if (!videos?.length)
                    return sendMessageWithChannel(sock, chatId, { text: '❌ No results found.' }, { quoted: message });
                video = videos[0];
            }
            if (video.thumbnail) {
                await sendMessageWithChannel(sock, chatId, {
                    image: { url: video.thumbnail },
                    caption: `🎶 *${video.title || query}*\n⏱ ${video.timestamp || ''}\n\n⏳ Downloading... *(may take up to 30s)*`
                }, { quoted: message });
            }
            const audio = await downloadWithRetry(video.url);
            await sendMessageWithChannel(sock, chatId, {
                audio: { url: audio.downloadUrl },
                mimetype: 'audio/mpeg',
                fileName: `${audio.title || video.title || 'song'}.mp3`,
                ptt: false
            }, { quoted: message });
        }
        catch (err) {
            console.error('Song plugin error:', err.message);
            const reason = err.response?.status === 408
                ? 'Download timed out. Try again.'
                : err.message;
            await sendMessageWithChannel(sock, chatId, { text: `❌ Failed: ${reason}` }, { quoted: message });
        }
    }
};
