/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require('axios');
module.exports = {
    command: 'joke2',
    aliases: ['funny2', 'jokes2'],
    category: 'fun',
    description: 'Get a random general joke',
    usage: '.joke2',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            const res = await axios.get('https://raw.githubusercontent.com/GlobalTechInfo/Database/main/text/random_jokes.txt');
            if (!res.data) {
                return await sendMessageWithChannel(sock, chatId, { text: '❌ Failed to fetch joke.' }, { quoted: message });
            }
            const jokes = res.data.split('\n').filter((line) => line.trim() !== '');
            if (jokes.length === 0) {
                return await sendMessageWithChannel(sock, chatId, { text: '❌ No jokes available.' }, { quoted: message });
            }
            const randomJoke = jokes[Math.floor(Math.random() * jokes.length)];
            await sendMessageWithChannel(sock, chatId, { text: `😂 *Joke*\n\n${randomJoke}` }, { quoted: message });
        }
        catch (err) {
            console.error('Joke plugin error:', err);
            await sendMessageWithChannel(sock, chatId, { text: '❌ Error while fetching joke.' }, { quoted: message });
        }
    }
};
