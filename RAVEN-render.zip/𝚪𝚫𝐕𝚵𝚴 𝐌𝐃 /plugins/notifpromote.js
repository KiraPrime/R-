'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const fs   = require('fs');
const path = require('path');

// ══════════════════════════════════════════════════════════════════
// ─── INTERNAL STORE (self-sufficient, no DB needed) ───────────────
// ══════════════════════════════════════════════════════════════════
const DATA_DIR   = path.join(__dirname, 'notifpromote-data');
const STORE_PATH = path.join(DATA_DIR, 'store.json');

const DEFAULT_STORE = { groups: {} };

let _store = null;
let _saveTimer = null;

function ensureDir() {
    try {
        if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    } catch (e) { console.error('[NOTIFPROMOTE] mkdir failed:', e?.message); }
}

function loadStore() {
    ensureDir();
    try {
        if (fs.existsSync(STORE_PATH)) {
            const raw = fs.readFileSync(STORE_PATH, 'utf8').trim();
            if (raw) {
                const parsed = JSON.parse(raw);
                _store = { groups: { ...(parsed.groups || {}) } };
                return _store;
            }
        }
    } catch (e) {
        console.error('[NOTIFPROMOTE] store corrupted, rebuilding:', e?.message);
        try {
            const backup = STORE_PATH + '.corrupted.' + Date.now() + '.bak';
            if (fs.existsSync(STORE_PATH)) fs.copyFileSync(STORE_PATH, backup);
        } catch {}
    }
    _store = JSON.parse(JSON.stringify(DEFAULT_STORE));
    writeStoreSync();
    return _store;
}

function writeStoreSync() {
    try {
        ensureDir();
        const tmp = STORE_PATH + '.tmp';
        fs.writeFileSync(tmp, JSON.stringify(_store, null, 2), 'utf8');
        fs.renameSync(tmp, STORE_PATH);
    } catch (e) { console.error('[NOTIFPROMOTE] store write failed:', e?.message); }
}

function scheduleSave() {
    if (_saveTimer) clearTimeout(_saveTimer);
    _saveTimer = setTimeout(() => { _saveTimer = null; writeStoreSync(); }, 500);
    if (_saveTimer.unref) _saveTimer.unref();
}

function getSetting(jid, key, def = null) {
    if (!_store) loadStore();
    const g = _store.groups?.[jid];
    if (!g) return def;
    const v = g[key];
    return v === undefined ? def : v;
}

function setSetting(jid, key, value) {
    if (!_store) loadStore();
    if (!_store.groups[jid]) _store.groups[jid] = {};
    _store.groups[jid][key] = value;
    scheduleSave();
}

// initial load
loadStore();
process.on('exit',   () => { try { writeStoreSync(); } catch {} });
process.on('SIGINT', () => { try { writeStoreSync(); } catch {} process.exit(0); });

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function jidToNumber(jid) {
    if (!jid) return '';
    return String(jid).split(':')[0].split('@')[0].replace(/[^0-9]/g, '');
}

function getParticipantJid(p) {
    if (!p) return '';
    if (p.jid && !p.jid.endsWith('@lid')) return p.jid;
    if (p.phoneNumber && !p.phoneNumber.endsWith('@lid')) return p.phoneNumber;
    if (p.id && !p.id.endsWith('@lid')) return p.id;
    const raw = p.id || p.jid || p.lid || '';
    return raw.endsWith('@lid') ? raw.replace('@lid', '@s.whatsapp.net') : raw;
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {}
}

// ══════════════════════════════════════════════════════════════════
// ─── LISTENER: group-participants.update → notify on promote ──────
// ══════════════════════════════════════════════════════════════════
let _bound = false;
let _boundSock = null;

async function onGroupParticipantsUpdate(payload) {
    try {
        const sock = _boundSock;
        if (!sock) return;

        const { id: chatId, participants, action } = payload || {};
        if (!chatId || !Array.isArray(participants)) return;
        if (action !== 'promote') return;

        // Toggle off → skip
        if (getSetting(chatId, 'notifPromote', false) !== true) return;

        for (const rawId of participants) {
            const targetJid = typeof rawId === 'string'
                ? rawId
                : getParticipantJid(rawId);

            const targetNum = jidToNumber(targetJid);
            if (!targetNum) continue;

            const mention = targetNum + '@s.whatsapp.net';

            // Add context: group name
            let contextText = '';
            try {
                const meta = await sock.groupMetadata(chatId).catch(() => null);
                if (meta?.subject) contextText = `_in ${meta.subject}_`;
            } catch {}

            const text =
                `👑 *ᴘʀᴏᴍᴏᴛᴇ ᴅᴇᴛᴇᴄᴛᴇᴅ*\n\n` +
                `> @${targetNum} is now an admin\n` +
                (contextText ? `> ${contextText}\n` : '') +
                `\n🔺 *Action:* promoted to admin`;

            await sock.sendMessage(chatId, {
                text,
                mentions: [mention]
            }).catch(() => {});
        }
    } catch (e) {
        console.error('[NOTIFPROMOTE-EVENT]', e?.message);
    }
}

function bindSock(sock) {
    if (_bound || !sock || !sock.ev) return;
    _bound = true;
    _boundSock = sock;
    try {
        sock.ev.on('group-participants.update', onGroupParticipantsUpdate);
        console.log('[NOTIFPROMOTE] event hook registered');
    } catch (e) {
        console.error('[NOTIFPROMOTE] failed to bind:', e?.message);
        _bound = false;
    }
}

function tryBindFromGlobals() {
    const candidates = [global.sock, global.conn, global.Hanz, global.client];
    for (const c of candidates) {
        if (c && c.ev) { bindSock(c); return; }
    }
}

tryBindFromGlobals();

let _retryCount = 0;
const _retryTimer = setInterval(() => {
    if (_bound) return clearInterval(_retryTimer);
    if (++_retryCount >= 10) return clearInterval(_retryTimer);
    tryBindFromGlobals();
}, 3000);
if (_retryTimer.unref) _retryTimer.unref();

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT (ΓΔVEN MD format) ──────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'notifpromote',
    aliases:     ['npromote', 'notifpr'],
    category:    'group',
    description: 'Notify when someone is promoted to admin — © 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
    usage:       '.notifpromote on/off/status',

    async handler(sock, message, args, context) {
        // Lazy-bind sock au cas où
        if (!_bound) bindSock(sock);

        const { chatId, reply, prefix, isGroup, isAdmin, isOwner } = context;

        // ── Group only ───────────────────────────────────
        if (!isGroup) {
            return reply(`❌ This command only works in groups.`);
        }

        // ── Admin / Owner only ───────────────────────────
        if (!isAdmin && !isOwner) {
            return reply(`❌ Only group admins can use this feature.`);
        }

        const sub = (args[0] || '').toLowerCase();
        const current = getSetting(chatId, 'notifPromote', false);

        // ── Status / usage ───────────────────────────────
        if (!sub || sub === 'status') {
            const status = current === true ? '✅ Active' : '❌ Inactive';
            return reply(
                `👑 *ɴᴏᴛɪꜰ ᴘʀᴏᴍᴏᴛᴇ*\n\n` +
                `> Status: ${status}\n\n` +
                `*Usage:*\n` +
                `\`${prefix}notifpromote on\`  — Enable\n` +
                `\`${prefix}notifpromote off\` — Disable`
            );
        }

        // ── Enable ───────────────────────────────────────
        if (sub === 'on') {
            setSetting(chatId, 'notifPromote', true);
            await react(sock, chatId, message.key, '✅');
            return reply(`✅ *ɴᴏᴛɪꜰ ᴘʀᴏᴍᴏᴛᴇ ᴇɴᴀʙʟᴇᴅ*`);
        }

        // ── Disable ──────────────────────────────────────
        if (sub === 'off') {
            setSetting(chatId, 'notifPromote', false);
            await react(sock, chatId, message.key, '❌');
            return reply(`❌ *ɴᴏᴛɪꜰ ᴘʀᴏᴍᴏᴛᴇ ᴅɪꜱᴀʙʟᴇᴅ*`);
        }

        return reply(`❌ Use \`${prefix}notifpromote on\` or \`${prefix}notifpromote off\``);
    },
};