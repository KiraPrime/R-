/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require('axios');
module.exports = {
    command: 'sharechat',
    aliases: ['sharechatdl', 'sharechatvideo'],
    category: 'download',
    description: 'Download video from ShareChat',
    usage: '.sharechat <ShareChat URL>',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const url = args?.[0];
        if (!url) {
            return await sendMessageWithChannel(sock, chatId, { text: 'Please provide a ShareChat URL.\nExample: .sharechat https://sharechat.com/video/XDPQKxb?referrer=url' }, { quoted: message });
        }
        try {
            const apiUrl = `https://discardapi.dpdns.org/api/dl/sharechat?apikey=guru&url=${encodeURIComponent(url)}`;
            const { data } = await axios.get(apiUrl, { timeout: 10000 });
            if (!data?.status || !data.result?.length) {
                return await sendMessageWithChannel(sock, chatId, { text: '❌ No video found for this URL.' }, { quoted: message });
            }
            const videoUrl = data.result[0].video;
            const imageUrl = data.result[0].image;
            if (imageUrl) {
                await sendMessageWithChannel(sock, chatId, { image: { url: imageUrl }, caption: '🖼️ ShareChat Thumbnail' }, { quoted: message });
            }
            if (videoUrl) {
                await sendMessageWithChannel(sock, chatId, { video: { url: videoUrl }, caption: '🎬 ShareChat Video' }, { quoted: message });
            }
        }
        catch (error) {
            console.error('ShareChat plugin error:', error);
            if (error.code === 'ECONNABORTED') {
                await sendMessageWithChannel(sock, chatId, { text: '❌ Request timed out. The API may be slow or unreachable.' }, { quoted: message });
            }
            else {
                await sendMessageWithChannel(sock, chatId, { text: '❌ Failed to fetch ShareChat video.' }, { quoted: message });
            }
        }
    }
};
