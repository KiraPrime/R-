/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require('axios');
module.exports = {
    command: 'element',
    aliases: ['atom', 'periodictable'],
    category: 'search',
    description: 'Get information about a chemical element',
    usage: '.element <name or symbol>',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const query = args?.join(' ')?.trim();
        if (!query) {
            return await sendMessageWithChannel(sock, chatId, { text: '*Provide element name or symbol.*\nExample: .element H' }, { quoted: message });
        }
        try {
            const { data: json } = await axios.get(`https://api.popcat.xyz/periodic-table?element=${encodeURIComponent(query)}`);
            if (!json?.name) {
                return await sendMessageWithChannel(sock, chatId, { text: '❌ Element not found.' }, { quoted: message });
            }
            const text = `🧪 *Element Info*\n` +
                `• Name: ${json.name}\n` +
                `• Symbol: ${json.symbol}\n` +
                `• Atomic #: ${json.atomic_number}\n` +
                `• Atomic Mass: ${json.atomic_mass}\n` +
                `• Period: ${json.period}\n` +
                `• Phase: ${json.phase}\n` +
                `• Discovered By: ${json.discovered_by || 'Unknown'}\n\n` +
                `📘 Summary:\n${json.summary}`;
            await sendMessageWithChannel(sock, chatId, { image: { url: json.image }, caption: text }, { quoted: message });
        }
        catch (error) {
            console.error('Element plugin error:', error);
            await sendMessageWithChannel(sock, chatId, { text: '❌ Failed to fetch element info.' }, { quoted: message });
        }
    }
};
