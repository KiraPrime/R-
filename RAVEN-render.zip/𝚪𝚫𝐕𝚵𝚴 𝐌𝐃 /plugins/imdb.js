/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: 'imdb',
    aliases: ['movie', 'film'],
    category: 'info',
    description: 'Get detailed information about a movie or series from IMDB',
    usage: '.imdb <movie/series title>',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const text = args.join(' ').trim();
        if (!text) {
            await sendMessageWithChannel(sock, chatId, {
                text: '*Please provide a movie or series title.*\nExample: `.imdb Inception`',
                quoted: message
            });
            return;
        }
        try {
            const res = await fetch(`https://api.popcat.xyz/imdb?q=${encodeURIComponent(text)}`);
            if (!res.ok)
                throw new Error(`API request failed with status ${res.status}`);
            const json = await res.json();
            const ratings = (json.ratings || [])
                .map((r) => `⭐ *${r.source}:* ${r.value}`)
                .join('\n') || 'No ratings available';
            const movieInfo = `
🎬 *${json.title || 'N/A'}* (${json.year || 'N/A'})
🎭 *Genres:* ${json.genres || 'N/A'}
📺 *Type:* ${json.type || 'N/A'}
📝 *Plot:* ${json.plot || 'N/A'}
⭐ *IMDB Rating:* ${json.rating || 'N/A'} (${json.votes || 'N/A'} votes)
🏆 *Awards:* ${json.awards || 'N/A'}
🎬 *Director:* ${json.director || 'N/A'}
✍️ *Writer:* ${json.writer || 'N/A'}
👨‍👩‍👧‍👦 *Actors:* ${json.actors || 'N/A'}
⏱️ *Runtime:* ${json.runtime || 'N/A'}
📅 *Released:* ${json.released || 'N/A'}
🌐 *Country:* ${json.country || 'N/A'}
🗣️ *Languages:* ${json.languages || 'N/A'}
💰 *Box Office:* ${json.boxoffice || 'N/A'}
💽 *DVD Release:* ${json.dvd || 'N/A'}
🏢 *Production:* ${json.production || 'N/A'}
🔗 *Website:* ${json.website || 'N/A'}

*Ratings:*
${ratings}
      `.trim();
            if (json.poster) {
                await sendMessageWithChannel(sock, chatId, {
                    image: { url: json.poster },
                    caption: movieInfo,
                    quoted: message
                });
            }
            else {
                await sendMessageWithChannel(sock, chatId, { text: movieInfo, quoted: message });
            }
        }
        catch (error) {
            console.error('IMDB Command Error:', error);
            await sendMessageWithChannel(sock, chatId, {
                text: '❌ Failed to fetch movie information. Please try again later.',
                quoted: message
            });
        }
    }
};
