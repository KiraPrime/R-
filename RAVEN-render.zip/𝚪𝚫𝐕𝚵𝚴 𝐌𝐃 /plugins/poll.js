/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: 'poll',
    aliases: ['createpoll', 'newpoll'],
    category: 'group',
    description: 'Create a native WhatsApp poll in the group',
    usage: '.poll <Question> | <Option1> | <Option2> | ...',
    groupOnly: true,
    adminOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const channelInfo = context.channelInfo || {};
        const fullText = args.join(' ');
        const parts = fullText.split('|').map((p) => p.trim()).filter(Boolean);
        if (parts.length < 3) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `*📊 CREATE A POLL*\n\n` +
                    `*Usage:*\n\`.poll <Question> | <Option1> | <Option2> | ...\`\n\n` +
                    `*Example:*\n\`.poll Favourite color? | Red | Blue | Green | Yellow\`\n\n` +
                    `_Minimum 2 options. Maximum 12 options._`,
                ...channelInfo
            }, { quoted: message });
        }
        const question = parts[0];
        const options = parts.slice(1);
        if (options.length > 12) {
            return await sendMessageWithChannel(sock, chatId, {
                text: '❌ Maximum 12 options allowed.',
                ...channelInfo
            }, { quoted: message });
        }
        try {
            await sendMessageWithChannel(sock, chatId, {
                poll: {
                    name: question,
                    values: options,
                    selectableCount: 1
                }
            });
        }
        catch (e) {
            console.error('[POLL] Error sending poll:', e.message);
            await sendMessageWithChannel(sock, chatId, {
                text: '❌ Failed to create poll. Please try again.',
                ...channelInfo
            }, { quoted: message });
        }
    }
};
