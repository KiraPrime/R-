/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: 'channelid',
    aliases: ['newsletterid'],
    category: 'general',
    description: 'Get the internal JID of a WhatsApp Channel',
    usage: '.channelid <url>',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        let url = args[0] || "";
        const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        if (quoted) {
            url = quoted.conversation || quoted.extendedTextMessage?.text || url;
        }
        if (!url || !url.includes('whatsapp.com/channel/')) {
            return await sendMessageWithChannel(sock, chatId, {
                text: 'Please provide a valid WhatsApp Channel URL.\n\n*Example:* .channelid https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w'
            }, { quoted: message });
        }
        const code = url.split('/').pop();
        try {
            const metadata = await sock.newsletterMetadata("invite", code);
            const response = `
🆔 *JID:* ${metadata.id}
      `.trim();
            await sendMessageWithChannel(sock, chatId, { text: response }, { quoted: message });
        }
        catch (err) {
            console.error('Channel ID Error:', err);
            await sendMessageWithChannel(sock, chatId, {
                text: '❌ *Failed to resolve:* This channel might be private, deleted, or the link is invalid.'
            }, { quoted: message });
        }
    }
};
