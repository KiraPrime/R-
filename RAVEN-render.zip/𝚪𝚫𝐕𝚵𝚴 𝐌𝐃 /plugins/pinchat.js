/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: 'pinchat',
    aliases: ['pin', 'unpin', 'unpinchat'],
    category: 'owner',
    description: 'Pin or unpin the current chat',
    usage: '.pinchat pin | .pinchat unpin',
    ownerOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const channelInfo = context.channelInfo || {};
        const rawText = (context.rawText || '').toLowerCase();
        const shouldPin = !rawText.startsWith('.unpin');
        try {
            await sock.chatModify({ pin: shouldPin }, chatId);
            await sendMessageWithChannel(sock, chatId, {
                text: shouldPin ? `📌 *Chat pinned!*` : `📌 *Chat unpinned!*`,
                ...channelInfo
            }, { quoted: message });
        }
        catch (e) {
            console.error('[PINCHAT] Error:', e.message);
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Failed to ${shouldPin ? 'pin' : 'unpin'} chat: ${e.message}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};
