'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function numOf(jid) {
    if (!jid) return '';
    return String(jid).split(':')[0].split('@')[0].replace(/[^0-9]/g, '');
}

function pickRandom(arr) {
    if (!Array.isArray(arr) || arr.length === 0) return null;
    return arr[Math.floor(Math.random() * arr.length)];
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'randomtag',
    aliases:     ['rtag', 'tagrandom', 'mentionrandom'],
    category:    'group',
    description: 'Mention a random member of the group',
    usage:       '.randomtag',

    async handler(sock, m, args, context) {
        const { chatId, reply, isGroup, groupMetadata } = context;

        // ── Group only ────────────────────────────────────────────
        if (!isGroup) {
            return reply(global.mess?.only?.group || 'This command only works in groups.');
        }
        if (!groupMetadata || !Array.isArray(groupMetadata.participants)) {
            return reply(global.mess?.error?.fitur || 'Could not read group metadata.');
        }

        // ── Filter out the bot ────────────────────────────────────
        const botNum = numOf(sock.user?.id);

        const members = groupMetadata.participants
            .map(p => p.id || p.jid || p.phoneNumber || '')
            .filter(jid => jid && numOf(jid) !== botNum);

        if (members.length === 0) {
            return reply(`Hmm... it seems there is no member I can pick, darling.`);
        }

        const random = pickRandom(members);
        if (!random) {
            return reply(global.mess?.error?.fitur || 'Failed to pick a random member.');
        }

        const text =
            `🎲 *RANDOM SELECT*\n\n` +
            `Ara ara~\n\n` +
            `Today I randomly chose someone in this group...\n\n` +
            `✨ The chosen one is...\n\n` +
            `💗 @${numOf(random)}\n\n` +
            `Do not be surprised, darling~\n` +
            `It seems you are being watched by me 👀`;

        await sendMessageWithChannel(sock, chatId, {
            text,
            mentions: [random],
        });
    },
};