'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── MORSE DICTIONARY ─────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const MORSE_DICT = {
    'a': '•–',    'b': '–•••',  'c': '–•–•',  'd': '–••',   'e': '•',
    'f': '••–•',  'g': '––•',   'h': '••••',  'i': '••',    'j': '•–––',
    'k': '–•–',   'l': '•–••',  'm': '––',    'n': '–•',    'o': '–––',
    'p': '•––•',  'q': '––•–',  'r': '•–•',   's': '•••',   't': '–',
    'u': '••–',   'v': '•••–',  'w': '•––',   'x': '–••–',  'y': '–•––',
    'z': '––••',
    '1': '•––––', '2': '••–––', '3': '•••––', '4': '••••–',
    '5': '•••••', '6': '–••••', '7': '––•••', '8': '–––••',
    '9': '––––•', '0': '–––––',
    ' ': '/',
};

const REVERSE_MORSE_DICT = Object.fromEntries(
    Object.entries(MORSE_DICT).map(([key, value]) => [value, key]),
);

// ══════════════════════════════════════════════════════════════════
// ─── CONVERTERS ───────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function textToMorse(text) {
    return String(text)
        .toLowerCase()
        .split('')
        .map(char => MORSE_DICT[char] || char)
        .join(' ');
}

function morseToText(morse) {
    return String(morse)
        .split(/\/|\s/)
        .map(word => word.split(' ').map(char => REVERSE_MORSE_DICT[char] || char).join(''))
        .join(' ')
        .trim();
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'morse',
    aliases:     ['demorse', 'tomorse', 'unmorse'],
    category:    'tools',
    description: 'Encode or decode text ↔ Morse code',
    usage:       '.morse <text> | .demorse <morse>',

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix, command } = context;

        const cmd = (command || 'morse').toLowerCase();
        const isEncode = cmd === 'morse' || cmd === 'tomorse';

        // ── Resolve input ─────────────────────────────────────────
        const text = (args.join(' ') || '').trim();
        const quotedText = m?.quoted?.text || m?.quoted?.message?.conversation || m?.quoted?.message?.extendedTextMessage?.text || '';
        const inputText = text || quotedText;

        // ── No input ──────────────────────────────────────────────
        if (!inputText) {
            const example = isEncode
                ? 'hello world'
                : '•– / –••• / –•–• / –•• / •';
            return reply(
                `❌ Provide ${isEncode ? 'text' : 'Morse code'} to convert!\n\n` +
                `*Example:*\n\`${prefix}${cmd} ${example}\``,
            );
        }

        // ── Convert ───────────────────────────────────────────────
        try {
            const result = isEncode
                ? textToMorse(inputText)
                : morseToText(inputText);

            await sendMessageWithChannel(sock, chatId, { text: result });
        } catch (e) {
            console.error('[MORSE]', e?.message);
            return reply(`❌ Conversion error.`);
        }
    },
};