'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const fs   = require('fs');
const path = require('path');

// ══════════════════════════════════════════════════════════════════
// ─── INTERNAL STORE (self-sufficient, no DB needed) ───────────────
// ══════════════════════════════════════════════════════════════════
const DATA_DIR   = path.join(__dirname, 'notifdemote-data');
const STORE_PATH = path.join(DATA_DIR, 'store.json');

const DEFAULT_STORE = { groups: {} };

let _store = null;
let _saveTimer = null;

function ensureDir() {
    try {
        if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    } catch (e) { console.error('[NOTIFDEMOTE] mkdir failed:', e?.message); }
}

function loadStore() {
    ensureDir();
    try {
        if (fs.existsSync(STORE_PATH)) {
            const raw = fs.readFileSync(STORE_PATH, 'utf8').trim();
            if (raw) {
                const parsed = JSON.parse(raw);
                _store = { groups: { ...(parsed.groups || {}) } };
                return _store;
            }
        }
    } catch (e) {
        console.error('[NOTIFDEMOTE] store corrupted, rebuilding:', e?.message);
        try {
            const backup = STORE_PATH + '.corrupted.' + Date.now() + '.bak';
            if (fs.existsSync(STORE_PATH)) fs.copyFileSync(STORE_PATH, backup);
        } catch {}
    }
    _store = JSON.parse(JSON.stringify(DEFAULT_STORE));
    writeStoreSync();
    return _store;
}

function writeStoreSync() {
    try {
        ensureDir();
        const tmp = STORE_PATH + '.tmp';
        fs.writeFileSync(tmp, JSON.stringify(_store, null, 2), 'utf8');
        fs.renameSync(tmp, STORE_PATH);
    } catch (e) { console.error('[NOTIFDEMOTE] store write failed:', e?.message); }
}

function scheduleSave() {
    if (_saveTimer) clearTimeout(_saveTimer);
    _saveTimer = setTimeout(() => { _saveTimer = null; writeStoreSync(); }, 500);
    if (_saveTimer.unref) _saveTimer.unref();
}

function getSetting(jid, key, def = null) {
    if (!_store) loadStore();
    const g = _store.groups?.[jid];
    if (!g) return def;
    const v = g[key];
    return v === undefined ? def : v;
}

function setSetting(jid, key, value) {
    if (!_store) loadStore();
    if (!_store.groups[jid]) _store.groups[jid] = {};
    _store.groups[jid][key] = value;
    scheduleSave();
}

// initial load
loadStore();
process.on('exit',   () => { try { writeStoreSync(); } catch {} });
process.on('SIGINT', () => { try { writeStoreSync(); } catch {} process.exit(0); });

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function jidToNumber(jid) {
    if (!jid) return '';
    return String(jid).split(':')[0].split('@')[0].replace(/[^0-9]/g, '');
}

function getParticipantJid(p) {
    if (!p) return '';
    if (p.jid && !p.jid.endsWith('@lid')) return p.jid;
    if (p.phoneNumber && !p.phoneNumber.endsWith('@lid')) return p.phoneNumber;
    if (p.id && !p.id.endsWith('@lid')) return p.id;
    const raw = p.id || p.jid || p.lid || '';
    return raw.endsWith('@lid') ? raw.replace('@lid', '@s.whatsapp.net') : raw;
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {}
}

// ══════════════════════════════════════════════════════════════════
// ─── LISTENER: group-participants.update → notify on demote ───────
// ══════════════════════════════════════════════════════════════════
let _bound = false;
let _boundSock = null;

async function onGroupParticipantsUpdate(payload) {
    try {
        const sock = _boundSock;
        if (!sock) return;

        const { id: chatId, participants, action } = payload || {};
        if (!chatId || !Array.isArray(participants)) return;
        if (action !== 'demote') return;

        // Toggle off → skip
        if (getSetting(chatId, 'notifDemote', false) !== true) return;

        for (const rawId of participants) {
            const targetJid = typeof rawId === 'string'
                ? rawId
                : getParticipantJid(rawId);

            const targetNum = jidToNumber(targetJid);
            if (!targetNum) continue;

            const mention = targetNum + '@s.whatsapp.net';

            // Try to get actor (who demoted)
            let actorText = '';
            try {
                const meta = await sock.groupMetadata(chatId).catch(() => null);
                if (meta) {
                    const groupName = meta.subject || '';
                    actorText = groupName ? `_in ${groupName}_` : '';
                }
            } catch {}

            const text =
                `👤 *ᴅᴇᴍᴏᴛᴇ ᴅᴇᴛᴇᴄᴛᴇᴅ*\n\n` +
                `> @${targetNum} is no longer an admin\n` +
                (actorText ? `> ${actorText}\n` : '') +
                `\n🔻 *Action:* demoted from admin`;

            await sock.sendMessage(chatId, {
                text,
                mentions: [mention]
            }).catch(() => {});
        }
    } catch (e) {
        console.error('[NOTIFDEMOTE-EVENT]', e?.message);
    }
}

function bindSock(sock) {
    if (_bound || !sock || !sock.ev) return;
    _bound = true;
    _boundSock = sock;
    try {
        sock.ev.on('group-participants.update', onGroupParticipantsUpdate);
        console.log('[NOTIFDEMOTE] event hook registered');
    } catch (e) {
        console.error('[NOTIFDEMOTE] failed to bind:', e?.message);
        _bound = false;
    }
}

function tryBindFromGlobals() {
    const candidates = [global.sock, global.conn, global.Hanz, global.client];
    for (const c of candidates) {
        if (c && c.ev) { bindSock(c); return; }
    }
}

tryBindFromGlobals();

let _retryCount = 0;
const _retryTimer = setInterval(() => {
    if (_bound) return clearInterval(_retryTimer);
    if (++_retryCount >= 10) return clearInterval(_retryTimer);
    tryBindFromGlobals();
}, 3000);
if (_retryTimer.unref) _retryTimer.unref();

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT (ΓΔVEN MD format) ──────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'notifdemote',
    aliases:     ['ndemote', 'notifdm'],
    category:    'group',
    description: 'Notify when someone is demoted from admin — © 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
    usage:       '.notifdemote on/off/status',

    async handler(sock, message, args, context) {
        // Lazy-bind sock au cas où le listener n'aurait pas démarré
        if (!_bound) bindSock(sock);

        const { chatId, reply, prefix, isGroup, isAdmin, isOwner } = context;

        // ── Group only ───────────────────────────────────
        if (!isGroup) {
            return reply(`❌ This command only works in groups.`);
        }

        // ── Admin / Owner only ───────────────────────────
        if (!isAdmin && !isOwner) {
            return reply(`❌ Only group admins can use this feature.`);
        }

        const sub = (args[0] || '').toLowerCase();
        const current = getSetting(chatId, 'notifDemote', false);

        // ── Status / usage ───────────────────────────────
        if (!sub || sub === 'status') {
            const status = current === true ? '✅ Active' : '❌ Inactive';
            return reply(
                `👤 *ɴᴏᴛɪꜰ ᴅᴇᴍᴏᴛᴇ*\n\n` +
                `> Status: ${status}\n\n` +
                `*Usage:*\n` +
                `\`${prefix}notifdemote on\`  — Enable\n` +
                `\`${prefix}notifdemote off\` — Disable`
            );
        }

        // ── Enable ───────────────────────────────────────
        if (sub === 'on') {
            setSetting(chatId, 'notifDemote', true);
            await react(sock, chatId, message.key, '✅');
            return reply(`✅ *ɴᴏᴛɪꜰ ᴅᴇᴍᴏᴛᴇ ᴇɴᴀʙʟᴇᴅ*`);
        }

        // ── Disable ──────────────────────────────────────
        if (sub === 'off') {
            setSetting(chatId, 'notifDemote', false);
            await react(sock, chatId, message.key, '❌');
            return reply(`❌ *ɴᴏᴛɪꜰ ᴅᴇᴍᴏᴛᴇ ᴅɪꜱᴀʙʟᴇᴅ*`);
        }

        return reply(`❌ Use \`${prefix}notifdemote on\` or \`${prefix}notifdemote off\``);
    },
};