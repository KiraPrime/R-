'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const fs   = require('fs');
const path = require('path');

// ══════════════════════════════════════════════════════════════════
// ─── CFG ──────────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const CFG = {
    menuImage: 'https://d.top4top.io/p_3938sefm00.jpg',

    botName:  '𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
    footer:   '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
    website:  'https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w',

    // Fake orderMessage (les "99999999 articles")
    itemCount:  99999999,
    surface:    99999999,
    orderTitle: '𝚪𝚫𝐕𝚵𝚴',
    orderMsg:   'https://helper.web.id',
    orderThumb: 'https://videotourl.com/videos/1791350231951-18971143-4050-43b8-918f-785933869af1.mp4',

    // Forward newsletter
    forward: {
        enabled:         true,
        forwardingScore: 1,
        isForwarded:     true,
        newsletterJid:   '120363410293871779@newsletter',
        newsletterName:  '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1,
    },
};

// ══════════════════════════════════════════════════════════════════
// ─── INTERNAL STORE (self-sufficient) ─────────────────────────────
// ══════════════════════════════════════════════════════════════════
const DATA_DIR   = path.join(__dirname, 'autoreply-data');
const MEDIA_DIR  = path.join(DATA_DIR, 'media');
const STORE_PATH = path.join(DATA_DIR, 'store.json');

const DEFAULT_STORE = {
    groups:   {},
    settings: {
        autoreplyPrivate: false,
        globalCustomReplies: [],
        smartTriggers: false
    }
};

let _store = null;
let _saveTimer = null;

function ensureDirs() {
    try {
        if (!fs.existsSync(DATA_DIR))  fs.mkdirSync(DATA_DIR,  { recursive: true });
        if (!fs.existsSync(MEDIA_DIR)) fs.mkdirSync(MEDIA_DIR, { recursive: true });
    } catch (e) { console.error('[AUTOREPLY] mkdir failed:', e?.message); }
}

function loadStore() {
    ensureDirs();
    try {
        if (fs.existsSync(STORE_PATH)) {
            const raw = fs.readFileSync(STORE_PATH, 'utf8').trim();
            if (raw) {
                const parsed = JSON.parse(raw);
                _store = {
                    groups:   { ...(parsed.groups   || {}) },
                    settings: { ...DEFAULT_STORE.settings, ...(parsed.settings || {}) }
                };
                return _store;
            }
        }
    } catch (e) {
        console.error('[AUTOREPLY] store corrupted, rebuilding:', e?.message);
        try {
            const backup = STORE_PATH + '.corrupted.' + Date.now() + '.bak';
            if (fs.existsSync(STORE_PATH)) fs.copyFileSync(STORE_PATH, backup);
        } catch {}
    }
    _store = JSON.parse(JSON.stringify(DEFAULT_STORE));
    writeStoreSync();
    return _store;
}

function writeStoreSync() {
    try {
        ensureDirs();
        const tmp = STORE_PATH + '.tmp';
        fs.writeFileSync(tmp, JSON.stringify(_store, null, 2), 'utf8');
        fs.renameSync(tmp, STORE_PATH);
    } catch (e) { console.error('[AUTOREPLY] store write failed:', e?.message); }
}

function scheduleSave() {
    if (_saveTimer) clearTimeout(_saveTimer);
    _saveTimer = setTimeout(() => { _saveTimer = null; writeStoreSync(); }, 500);
    if (_saveTimer.unref) _saveTimer.unref();
}

function getGroup(jid)            { if (!_store) loadStore(); return _store.groups[jid] || null; }
function setGroup(jid, data)      { if (!_store) loadStore(); _store.groups[jid] = { ...(getGroup(jid) || {}), ...data }; scheduleSave(); return _store.groups[jid]; }
function getSetting(key, def=null){ if (!_store) loadStore(); const v = _store.settings?.[key]; return v === undefined ? def : v; }
function setSetting(key, val)     { if (!_store) loadStore(); _store.settings[key] = val; scheduleSave(); }

loadStore();
process.on('exit',   () => { try { writeStoreSync(); } catch {} });
process.on('SIGINT', () => { try { writeStoreSync(); } catch {} process.exit(0); });

// ══════════════════════════════════════════════════════════════════
// ─── RICH SEND HELPERS (from menu.js style) ───────────────────────
// ══════════════════════════════════════════════════════════════════

// Fake orderMessage with 99999999 articles
function buildFakeWeb() {
    return {
        key: { participant: '0@s.whatsapp.net' },
        message: {
            orderMessage: {
                itemCount:  CFG.itemCount,
                surface:    CFG.surface,
                message:    CFG.orderMsg,
                orderTitle: CFG.orderTitle,
                thumbnail:  undefined,
                sellerJid:  '0@s.whatsapp.net',
            },
        },
    };
}

// Forward newsletter context
function buildForwardContext() {
    if (!CFG.forward?.enabled) return null;
    return {
        forwardingScore: CFG.forward.forwardingScore ?? 1,
        isForwarded:     CFG.forward.isForwarded ?? true,
        forwardedNewsletterMessageInfo: {
            newsletterJid:   CFG.forward.newsletterJid,
            newsletterName:  CFG.forward.newsletterName,
            serverMessageId: CFG.forward.serverMessageId ?? -1,
        },
    };
}

// externalAdReply with the image as large thumbnail
function buildAdReply(pushname = 'User') {
    return {
        title:                 CFG.botName,
        body:                  pushname,
        mediaType:             1,
        thumbnailUrl:          CFG.menuImage,
        sourceUrl:             CFG.website,
        renderLargerThumbnail: true,
        showAdAttribution:     false,
    };
}

// ══════════════════════════════════════════════════════════════════
// ─── sendRich → image + caption + fakeWeb + adReply ───────────────
// ══════════════════════════════════════════════════════════════════
async function sendRich(sock, chatId, caption, opts = {}) {
    const {
        mentions = [],
        quoted   = undefined,
        pushname = 'User',
    } = opts;

    const fwd = buildForwardContext();
    const ad  = buildAdReply(pushname);
    const fakeWeb = buildFakeWeb();

    const contextInfo = {
        mentionedJid: [].concat(mentions).filter(Boolean),
        externalAdReply: ad,
        ...(fwd || {}),
    };

    try {
        // Try image + caption + adReply
        await sock.sendMessage(
            chatId,
            {
                image: { url: CFG.menuImage },
                caption,
                contextInfo,
            },
            { quoted: quoted || fakeWeb }
        );
        return true;
    } catch (e) {
        console.error('[AUTOREPLY] sendRich image failed:', e?.message);
    }

    try {
        // Fallback: text + adReply
        await sock.sendMessage(
            chatId,
            { text: caption, contextInfo },
            { quoted: quoted || fakeWeb }
        );
        return true;
    } catch (e) {
        console.error('[AUTOREPLY] sendRich text failed:', e?.message);
    }

    // Last resort: plain text
    try {
        await sock.sendMessage(chatId, { text: caption });
        return true;
    } catch {
        return false;
    }
}

// ══════════════════════════════════════════════════════════════════
// ─── DEFAULTS + PLACEHOLDERS ──────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const DEFAULT_TRIGGERS = [
    { trigger: '@mention',        reply: '👋 Hi! Someone called the bot?' },
    { trigger: 'assalamualaikum', reply: 'Waalaikumsalam my friend 🤝' },
    { trigger: 'bot / gaven',     reply: '🤖 Bot is active and ready!' }
];

function applyPlaceholders(text, ctx) {
    if (!text) return '';
    return String(text)
        .replace(/\{name\}/g,     ctx.name     || 'User')
        .replace(/\{tag\}/g,      ctx.tag      || '')
        .replace(/\{sender\}/g,   ctx.sender   || '')
        .replace(/\{botname\}/g,  ctx.botname  || CFG.botName)
        .replace(/\{time\}/g,     ctx.time     || '')
        .replace(/\{date\}/g,     ctx.date     || '');
}

function escapeRegExp(s = '') {
    return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function bodyContainsTrigger(body, trigger) {
    if (!body || !trigger) return false;
    const b = body.toLowerCase();
    const t = String(trigger).toLowerCase().trim();
    if (!t) return false;

    if (t === '@mention') return /@\d{6,}/.test(body);

    try {
        const re = new RegExp(`(^|\\s)${escapeRegExp(t)}(\\s|$|[!?.,;:])`, 'i');
        return re.test(b);
    } catch {
        return b.includes(t);
    }
}

// ══════════════════════════════════════════════════════════════════
// ─── LISTENER: messages.upsert → autoresponse ─────────────────────
// ══════════════════════════════════════════════════════════════════
let _bound = false;
let _boundSock = null;

async function onMessagesUpsert(payload) {
    try {
        const sock = _boundSock;
        if (!sock) return;

        const messages = Array.isArray(payload?.messages) ? payload.messages : [];
        for (const raw of messages) {
            if (!raw?.message || !raw?.key) continue;
            if (raw.key.fromMe) continue;

            const chatJid = raw.key.remoteJid || '';
            const sender  = raw.key.participant || chatJid;
            const isGroup = chatJid.endsWith('@g.us');

            const msg = raw.message;
            const body =
                msg.conversation ||
                msg.extendedTextMessage?.text ||
                msg.imageMessage?.caption ||
                msg.videoMessage?.caption ||
                '';
            if (!body) continue;

            const prefix = global.xprefix || '.';
            const prefixList = Array.isArray(global.prefa) ? global.prefa : [prefix];
            if (prefixList.some(p => p && body.startsWith(p))) continue;

            const botNum = String(sock.user?.id || '').split(':')[0].split('@')[0];
            if (botNum && sender.includes(botNum)) continue;

            const candidates = [];

            if (isGroup) {
                const group = getGroup(chatJid) || {};
                const groupOn = group.autoreply ?? getSetting('smartTriggers', false);
                if (groupOn) {
                    for (const r of (group.customReplies || [])) candidates.push({ ...r, scope: 'group' });
                }
            }

            for (const r of (getSetting('globalCustomReplies') || [])) candidates.push({ ...r, scope: 'global' });

            if (!isGroup) {
                const priv = getSetting('autoreplyPrivate', false);
                if (!priv) continue;
            }

            for (const r of DEFAULT_TRIGGERS) candidates.push({ ...r, scope: 'default' });

            const order = { group: 0, global: 1, default: 2 };
            candidates.sort((a, b) => (order[a.scope] ?? 99) - (order[b.scope] ?? 99));

            let match = null;
            for (const c of candidates) {
                if (bodyContainsTrigger(body, c.trigger)) { match = c; break; }
            }
            if (!match) continue;

            const name    = raw.pushName || 'User';
            const number  = String(sender).split('@')[0].split(':')[0];
            const tag     = `@${number}`;
            const botname = global.botName || CFG.botName;
            const now     = new Date();
            const time    = now.toLocaleTimeString('en-GB');
            const date    = now.toLocaleDateString('en-GB');

            const finalText = applyPlaceholders(match.reply || '', {
                name, tag, sender: number, botname, time, date
            });

            // If custom image exists → send it
            if (match.image && fs.existsSync(match.image)) {
                try {
                    await sock.sendMessage(chatJid, {
                        image: fs.readFileSync(match.image),
                        caption: finalText,
                        mentions: [sender],
                        contextInfo: {
                            mentionedJid: [sender],
                            externalAdReply: buildAdReply(name),
                            ...(buildForwardContext() || {}),
                        },
                    }, { quoted: raw });
                    break;
                } catch (e) {
                    console.error('[AUTOREPLY] custom image send failed:', e?.message);
                }
            }

            // Default: rich send (thumbnail image + caption + fakeWeb)
            if (finalText) {
                await sendRich(sock, chatJid, finalText, {
                    mentions: [sender],
                    quoted:   raw,
                    pushname: name,
                });
            }

            break;
        }
    } catch (e) {
        console.error('[AUTOREPLY-EVENT]', e?.message);
    }
}

function bindSock(sock) {
    if (_bound || !sock || !sock.ev) return;
    _bound = true;
    _boundSock = sock;
    try {
        sock.ev.on('messages.upsert', onMessagesUpsert);
        console.log('[AUTOREPLY] event hook registered');
    } catch (e) {
        console.error('[AUTOREPLY] failed to bind:', e?.message);
        _bound = false;
    }
}

function tryBindFromGlobals() {
    const candidates = [global.sock, global.conn, global.Hanz, global.client];
    for (const c of candidates) {
        if (c && c.ev) { bindSock(c); return; }
    }
}

tryBindFromGlobals();

let _retryCount = 0;
const _retryTimer = setInterval(() => {
    if (_bound) return clearInterval(_retryTimer);
    if (++_retryCount >= 10) return clearInterval(_retryTimer);
    tryBindFromGlobals();
}, 3000);
if (_retryTimer.unref) _retryTimer.unref();

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function react(sock, chatId, key, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key } }); } catch {}
}

async function downloadQuotedOrDirectImage(sock, message) {
    try {
        const quoted = message?.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const { downloadMediaMessage } = require('@whiskeysockets/baileys');
        if (quoted?.imageMessage) {
            return await downloadMediaMessage(
                { key: message.key, message: { imageMessage: quoted.imageMessage } },
                'buffer', {}, { reuploadRequest: sock.updateMediaMessage }
            );
        }
        if (message?.message?.imageMessage) {
            return await downloadMediaMessage(message, 'buffer', {}, {
                reuploadRequest: sock.updateMediaMessage
            });
        }
    } catch (e) {
        console.error('[AUTOREPLY] image download failed:', e?.message);
    }
    return null;
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'autoreply',
    aliases:     ['ar', 'autorespond', 'smartreply'],
    category:    'group',
    description: 'Manage per-group and global autoresponders — © 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
    usage:       '.autoreply <on|off|status|add|del|list|reset|private|global>',

    async handler(sock, message, args, context) {
        if (!_bound) bindSock(sock);

        const { chatId, sender, isGroup, isAdmin, isOwner } = context;
        const prefix  = context.prefix || '.';
        const action  = (args[0] || '').toLowerCase();
        const body    = message.body || '';
        const pushname = message.pushName || 'User';

        // Wrap reply → rich send
        const reply = async (text) => sendRich(sock, chatId, text, {
            mentions: sender ? [sender] : [],
            quoted:   message,
            pushname,
        });

        const priv = getSetting('autoreplyPrivate', false);

        // ═══════════════════════════════════════════════
        // ─── PRIVATE TOGGLE (owner) ─────────────────────
        // ═══════════════════════════════════════════════
        if (action === 'private') {
            if (!isOwner) return reply(`❌ Only the owner can configure private autoreply.`);
            const sub = (args[1] || '').toLowerCase();

            if (sub === 'on') {
                setSetting('autoreplyPrivate', true);
                await react(sock, chatId, message.key, '✅');
                return reply(`✅ *ᴀᴜᴛᴏʀᴇᴘʟʏ ᴘʀɪᴠᴀᴛᴇ ᴇɴᴀʙʟᴇᴅ*\n\n> Bot will auto-reply in DMs.`);
            }
            if (sub === 'off') {
                setSetting('autoreplyPrivate', false);
                await react(sock, chatId, message.key, '❌');
                return reply(`❌ *ᴀᴜᴛᴏʀᴇᴘʟʏ ᴘʀɪᴠᴀᴛᴇ ᴅɪꜱᴀʙʟᴇᴅ*\n\n> Bot will not auto-reply in DMs.`);
            }

            return reply(
                `📱 *AUTOREPLY PRIVATE*\n\n` +
                `Status: *${priv ? '✅ ENABLED' : '❌ DISABLED'}*\n\n` +
                `*Commands:*\n` +
                `• \`${prefix}autoreply private on\`  — Enable\n` +
                `• \`${prefix}autoreply private off\` — Disable`
            );
        }

        // ═══════════════════════════════════════════════
        // ─── GLOBAL TRIGGERS (owner) ────────────────────
        // ═══════════════════════════════════════════════
        if (action === 'global') {
            if (!isOwner) return reply(`❌ Only the owner can configure global autoreply.`);
            const sub = (args[1] || '').toLowerCase();
            const globalList = getSetting('globalCustomReplies') || [];

            if (sub === 'add') {
                const pipeIdx = body.indexOf('|');
                if (pipeIdx === -1) {
                    return reply(
                        `❌ *Invalid format*\n\n> Use: \`trigger|reply\`\n\n` +
                        `> Ex: \`${prefix}autoreply global add hello|Hi {name}!\``
                    );
                }
                const head = body.substring(0, pipeIdx);
                const trigger = head.substring(head.toLowerCase().lastIndexOf('global add ') + 'global add '.length).trim();
                const replyText = body.substring(pipeIdx + 1).trim();

                if (!trigger || !replyText) return reply(`❌ Trigger and reply cannot be empty!`);

                const idx = globalList.findIndex(r => r.trigger.toLowerCase() === trigger.toLowerCase());
                if (idx !== -1) globalList[idx].reply = replyText;
                else globalList.push({ trigger: trigger.toLowerCase(), reply: replyText });

                setSetting('globalCustomReplies', globalList);
                await react(sock, chatId, message.key, '✅');
                return reply(
                    `✅ *ɢʟᴏʙᴀʟ ᴀᴜᴛᴏʀᴇᴘʟʏ ᴀᴅᴅᴇᴅ*\n\n` +
                    `• Trigger: *${trigger}*\n` +
                    `• Total: *${globalList.length}* replies`
                );
            }

            if (sub === 'del' || sub === 'rm') {
                const trigger = args.slice(2).join(' ').toLowerCase().trim();
                if (!trigger) return reply(`❌ Provide a trigger to remove.`);
                const idx = globalList.findIndex(r => r.trigger === trigger);
                if (idx === -1) return reply(`❌ Trigger \`${trigger}\` not found.`);
                globalList.splice(idx, 1);
                setSetting('globalCustomReplies', globalList);
                await react(sock, chatId, message.key, '🗑️');
                return reply(`🗑️ *ɢʟᴏʙᴀʟ ᴀᴜᴛᴏʀᴇᴘʟʏ ʀᴇᴍᴏᴠᴇᴅ*\n\nTrigger *${trigger}* deleted.`);
            }

            if (globalList.length === 0) {
                return reply(
                    `📋 *GLOBAL AUTOREPLY*\n\n` +
                    `> No global triggers yet.\n\n` +
                    `Add one: \`${prefix}autoreply global add hello|Hi {name}!\``
                );
            }
            let t = `📋 *GLOBAL AUTOREPLY*\n\nTotal: *${globalList.length}*\n\n`;
            globalList.forEach((r, i) => {
                t += `${i + 1}. *${r.trigger}*\n   ↳ ${String(r.reply || '').substring(0, 40)}\n\n`;
            });
            return reply(t.trim());
        }

        // ═══════════════════════════════════════════════
        // ─── GROUP-ONLY ACTIONS ─────────────────────────
        // ═══════════════════════════════════════════════
        if (!isGroup) {
            return reply(
                `📱 *AUTOREPLY SYSTEM*\n\n` +
                `Private autoreply: *${priv ? '✅ ENABLED' : '❌ DISABLED'}*\n\n` +
                `*Commands:*\n` +
                `• \`${prefix}autoreply private on/off\`\n` +
                `• \`${prefix}autoreply global add/del/list\`\n\n` +
                `_Group settings must be used inside a group._`
            );
        }

        if (!isAdmin && !isOwner) {
            return reply(`❌ Only admins can configure group autoreply.`);
        }

        const groupData = getGroup(chatId) || {};
        const smartGlobal = getSetting('smartTriggers', false);

        // ─── STATUS (default) ───────────────────────────
        if (!action || action === 'status') {
            const groupStatus = groupData.autoreply;
            const effective = groupStatus ?? smartGlobal;
            const custom = groupData.customReplies || [];

            let t = `🤖 *GROUP AUTOREPLY SYSTEM*\n\n`;
            t += `Global: *${smartGlobal ? '✅ ON' : '❌ OFF'}*\n`;
            t += `This group: *${groupStatus === undefined ? 'DEFAULT' : (groupStatus ? '✅ ON' : '❌ OFF')}*\n`;
            t += `Private: *${priv ? '✅ ON' : '❌ OFF'}*\n`;
            t += `Effective here: *${effective ? '✅ ON' : '❌ OFF'}*\n`;
            t += `Custom replies: *${custom.length}*\n\n`;
            t += `*MANAGEMENT:*\n`;
            t += `• \`${prefix}autoreply on\`\n`;
            t += `• \`${prefix}autoreply off\`\n`;
            t += `• \`${prefix}autoreply add <trigger>|<reply>\`\n`;
            t += `• \`${prefix}autoreply del <trigger>\`\n`;
            t += `• \`${prefix}autoreply list\`\n`;
            t += `• \`${prefix}autoreply reset\`\n\n`;
            t += `*Placeholders:* {name} {tag} {sender} {botname} {time} {date}`;
            return reply(t);
        }

        // ─── ON / OFF ───────────────────────────────────
        if (action === 'on') {
            setGroup(chatId, { ...groupData, autoreply: true });
            await react(sock, chatId, message.key, '✅');
            return reply(`✅ *ᴀᴜᴛᴏʀᴇᴘʟʏ ᴇɴᴀʙʟᴇᴅ*\n\n> Bot will auto-reply in this group.`);
        }
        if (action === 'off') {
            setGroup(chatId, { ...groupData, autoreply: false });
            await react(sock, chatId, message.key, '❌');
            return reply(`❌ *ᴀᴜᴛᴏʀᴇᴘʟʏ ᴅɪꜱᴀʙʟᴇᴅ*\n\n> Bot will not auto-reply in this group.`);
        }

        // ─── ADD ────────────────────────────────────────
        if (action === 'add') {
            const pipeIdx = body.indexOf('|');
            if (pipeIdx === -1) {
                return reply(
                    `❌ *Invalid format*\n\nUse: \`trigger|reply\`\n\n` +
                    `Ex: \`${prefix}autoreply add hello|Hi {name}!\``
                );
            }
            const head = body.substring(0, pipeIdx);
            const trigger = head.substring(head.toLowerCase().lastIndexOf('add ') + 'add '.length).trim();
            const replyText = body.substring(pipeIdx + 1).trim();

            if (!trigger) return reply(`❌ Trigger cannot be empty.`);

            const imgBuffer = await downloadQuotedOrDirectImage(sock, message);
            let imagePath = null;
            if (imgBuffer) {
                ensureDirs();
                const filename = `ar_${chatId.replace(/[^0-9]/g, '')}_${Date.now()}.jpg`;
                imagePath = path.join(MEDIA_DIR, filename);
                try { fs.writeFileSync(imagePath, imgBuffer); } catch (e) {
                    console.error('[AUTOREPLY] image save failed:', e?.message);
                    imagePath = null;
                }
            }

            const custom = groupData.customReplies || [];
            const idx = custom.findIndex(r => r.trigger.toLowerCase() === trigger.toLowerCase());

            const entry = {
                trigger: trigger.toLowerCase(),
                reply: replyText || '',
                image: imagePath || (idx !== -1 ? custom[idx].image : null),
                createdAt: Date.now()
            };

            if (idx !== -1 && custom[idx].image && custom[idx].image !== imagePath) {
                try { if (fs.existsSync(custom[idx].image)) fs.unlinkSync(custom[idx].image); } catch {}
            }

            if (idx !== -1) custom[idx] = entry;
            else custom.push(entry);

            setGroup(chatId, { ...groupData, customReplies: custom });
            await react(sock, chatId, message.key, '✅');

            let msg = `✅ *ᴀᴜᴛᴏʀᴇᴘʟʏ ᴀᴅᴅᴇᴅ*\n\n`;
            msg += `• Trigger: *${trigger}*\n`;
            if (replyText) msg += `• Reply: ${replyText.substring(0, 50)}\n`;
            if (imagePath) msg += `• Image: ✅ saved\n`;
            msg += `\nTotal: *${custom.length}* replies in this group`;
            return reply(msg);
        }

        // ─── DEL ────────────────────────────────────────
        if (action === 'del' || action === 'rm' || action === 'remove') {
            const trigger = args.slice(1).join(' ').toLowerCase().trim();
            if (!trigger) return reply(`❌ Provide a trigger to remove.\n\n\`${prefix}autoreply del hello\``);

            const custom = groupData.customReplies || [];
            const idx = custom.findIndex(r => r.trigger === trigger);
            if (idx === -1) return reply(`❌ Trigger \`${trigger}\` not found.`);

            if (custom[idx].image) {
                try { if (fs.existsSync(custom[idx].image)) fs.unlinkSync(custom[idx].image); } catch {}
            }
            custom.splice(idx, 1);
            setGroup(chatId, { ...groupData, customReplies: custom });
            await react(sock, chatId, message.key, '🗑️');
            return reply(
                `🗑️ *ᴀᴜᴛᴏʀᴇᴘʟʏ ʀᴇᴍᴏᴠᴇᴅ*\n\n` +
                `Trigger *${trigger}* deleted.\n` +
                `Remaining: *${custom.length}*`
            );
        }

        // ─── LIST ───────────────────────────────────────
        if (action === 'list') {
            const custom = groupData.customReplies || [];
            let t = `📋 *GROUP AUTOREPLY LIST*\n\n`;
            t += `*DEFAULTS:*\n`;
            DEFAULT_TRIGGERS.forEach(r => { t += `• *${r.trigger}*\n  ↳ ${r.reply}\n`; });
            t += `\n`;
            if (custom.length > 0) {
                t += `*CUSTOM:*\n`;
                custom.forEach(r => {
                    t += `• *${r.trigger}*${r.image ? ' 🖼️' : ''}\n`;
                    if (r.reply) t += `  ↳ ${r.reply.substring(0, 35)}\n`;
                });
            } else {
                t += `*CUSTOM:*\n_No custom triggers yet._\n`;
            }
            return reply(t);
        }

        // ─── RESET ──────────────────────────────────────
        if (action === 'reset' || action === 'clear') {
            const custom = groupData.customReplies || [];
            for (const r of custom) {
                if (r.image) { try { if (fs.existsSync(r.image)) fs.unlinkSync(r.image); } catch {} }
            }
            setGroup(chatId, { ...groupData, customReplies: [] });
            await react(sock, chatId, message.key, '🗑️');
            return reply(`🗑️ *ᴀᴜᴛᴏʀᴇᴘʟʏ ʀᴇꜱᴇᴛ*\n\n> All custom replies in this group were removed.`);
        }

        return reply(`❌ *Invalid action*\n\n> Use: \`on\`, \`off\`, \`private on/off\`, \`add\`, \`del\`, \`list\`, \`reset\``);
    },
};