'use strict';

/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║  PINPACK — Pinterest → sticker pack (multi-API fallback)         ║
 * ║  APIs : siputzx (search) + azbry (download HD)                   ║
 * ╚══════════════════════════════════════════════════════════════════╝
 */

const axios = require('axios');
const fs    = require('fs');
const path  = require('path');

let _sharp = null;
try { _sharp = require('sharp'); } catch { _sharp = null; }

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36';

// ══════════════════════════════════════════════════════════════════
// ─── CONFIG ───────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const CFG = {
    botName:  global.botName   || '𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
    author:   global.author    || '𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
    packname: global.packname  || '𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
    footer:   global.footer    || '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
    prefix:   global.xprefix   || '.',
    link:     global.link      || 'https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w',
    mess:     global.mess      || {},
    maxStickers: 20,
};

// ══════════════════════════════════════════════════════════════════
// ─── HTTP HELPERS ─────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function fetchJson(url, timeout = 20000) {
    try {
        const res = await axios.get(url, { timeout, headers: { 'User-Agent': UA } });
        return res.data;
    } catch (e) {
        console.error('[PINPACK] fetchJson fail:', url, e?.message);
        return null;
    }
}

async function downloadBuffer(url, timeout = 30000) {
    const res = await axios.get(url, {
        responseType: 'arraybuffer',
        timeout,
        headers: { 'User-Agent': UA, Referer: 'https://www.pinterest.com/' },
    });
    return Buffer.from(res.data);
}

// ══════════════════════════════════════════════════════════════════
// ─── SEARCH — MULTI-API FALLBACK ──────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function searchPinterest(query) {
    const q = encodeURIComponent(query);

    const apis = [
        // ── API 1 : siputzx (structure : { data: [{ image_url }] })
        {
            url: `https://api.siputzx.my.id/api/s/pinterest?query=${q}`,
            parse: d => d?.data?.map(x => x.image_url).filter(Boolean),
        },
        // ── API 2 : vreden (structure : { result: [{ image_url }] })
        {
            url: `https://api.vreden.my.id/api/pinterest?query=${q}`,
            parse: d => d?.result?.map(x => x.image_url || x.url).filter(Boolean),
        },
        // ── API 3 : nexoracle (structure : { result: [{ url }] })
        {
            url: `https://api.nexoracle.com/search/pinterest?q=${q}`,
            parse: d => d?.result?.map(x => x.url || x.image).filter(Boolean),
        },
        // ── API 4 : itzpire
        {
            url: `https://itzpire.com/search/pinterest?query=${q}`,
            parse: d => d?.data?.map(x => x.image_url || x.url).filter(Boolean),
        },
    ];

    for (const api of apis) {
        try {
            const data = await fetchJson(api.url);
            if (!data) continue;
            const urls = api.parse(data);
            if (Array.isArray(urls) && urls.length > 0) {
                console.log(`[PINPACK] ✅ ${api.url.split('/')[2]} → ${urls.length} results`);
                return urls.slice(0, CFG.maxStickers);
            }
        } catch (e) {
            console.error(`[PINPACK] ❌ API fail:`, e?.message);
        }
    }

    return [];
}

// ══════════════════════════════════════════════════════════════════
// ─── EXIF ─────────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
let _webpmux = null;
async function getWebpmux() {
    if (_webpmux) return _webpmux;
    try {
        const mod = await import('node-webpmux');
        _webpmux = mod.default || mod;
    } catch {}
    return _webpmux;
}

function buildExif({ packname, author, emojis = ['❤'] }) {
    const json = {
        'sticker-pack-id': 'com.gaven.sticker',
        'sticker-pack-name': packname,
        'sticker-pack-publisher': author,
        'emojis': emojis,
        'is-avatar-sticker': 0,
        'android-app-store-link': '',
        'ios-app-store-link': '',
    };
    const exifAttr = Buffer.from([
        0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00,
        0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x16, 0x00, 0x00, 0x00,
    ]);
    const jsonBuffer = Buffer.from(JSON.stringify(json), 'utf8');
    const exif = Buffer.concat([exifAttr, jsonBuffer]);
    exif.writeUIntLE(jsonBuffer.length, 14, 4);
    return exif;
}

async function addExif(webpBuffer, opts) {
    const webpmux = await getWebpmux();
    if (!webpmux) return webpBuffer;
    try {
        const img = new webpmux.Image();
        await img.load(webpBuffer);
        img.exif = buildExif(opts);
        return await img.save(null);
    } catch {
        return webpBuffer;
    }
}

// ══════════════════════════════════════════════════════════════════
// ─── CONVERSION ───────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function toWebp(buffer) {
    if (!_sharp) throw new Error('sharp not installed');

    const img = _sharp(buffer);
    const meta = await img.metadata();
    const { width, height } = meta;

    // Size of the crop square (smallest side)
    const side = Math.min(width, height);

    // Crop position (centered by default)
    const left = Math.floor((width  - side) / 2);
    const top  = Math.floor((height - side) / 2);

    return _sharp(buffer)
        .extract({ left, top, width: side, height: side })  // ✂️ crop into a square
        .resize(512, 512, { fit: 'fill' })                  // 📐 scale up/down
        .webp({ quality: 85 })
        .toBuffer();
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN ───────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command: 'pinpack',
    aliases: ['ppack', 'pinterestpack'],
    category: 'sticker',
    description: 'Pinterest → sticker pack',
    usage: '.pinpack <query>',

    async handler(sock, m, args, context) {
        const chatId = context?.chatId || m.chat;
        const prefix = context?.prefix || CFG.prefix;
        const reply  = context?.reply  || ((t) =>
            sock.sendMessage(chatId, { text: t }, { quoted: m }));

        const query = (args?.join(' ') || '').trim();

        if (!query) {
            return reply(
                `── .✦ 𝗣𝗜𝗡 𝗣𝗔𝗖𝗞 ✦. ── 𝜗ৎ\n\n` +
                `> ${prefix}pinpack <query>\n\n` +
                `*${prefix}pinpack anime cat*`
            );
        }

        await sock.sendMessage(chatId, { react: { text: '🕕', key: m.key } }).catch(() => {});

        try {
            // 1. Multi-API search
            const urls = await searchPinterest(query);

            if (urls.length === 0) {
                await sock.sendMessage(chatId, { react: { text: '✘', key: m.key } }).catch(() => {});
                return reply(`── .✦ ──\n\n> No results for: *${query}*`);
            }

            await sock.sendMessage(chatId, {
                text: `── .✦ ──\n\n> Downloading *${urls.length}* images...`,
            }, { quoted: m });

            // 2. Convert to stickers
            const buffers = [];
            for (const url of urls) {
                try {
                    const buf  = await downloadBuffer(url);
                    const webp = await toWebp(buf);
                    buffers.push(webp);
                    await new Promise(r => setTimeout(r, 500));
                } catch { continue; }
            }

            if (buffers.length === 0) {
                await sock.sendMessage(chatId, { react: { text: '✘', key: m.key } }).catch(() => {});
                return reply(`> Failed to download the images.`);
            }

            const packname = `Pinterest: ${query}`;
            const author   = CFG.author;

            // 3. Send — native pack or individual stickers
            let sent = 0;
            if (typeof sock.sendStickerPack === 'function') {
                try {
                    await sock.sendStickerPack(chatId, buffers, m, {
                        name: packname, packname, publisher: author, author,
                        description: `Pinterest: ${query}`,
                        emojis: ['❤'],
                    });
                    sent = buffers.length;
                } catch (e) {
                    console.error('[PINPACK] pack fail:', e?.message);
                }
            }

            if (sent === 0) {
                for (const buf of buffers) {
                    try {
                        const exifBuf = await addExif(buf, { packname, author });
                        await sock.sendMessage(chatId,
                            { sticker: exifBuf }, { quoted: m });
                        sent++;
                        await new Promise(r => setTimeout(r, 400));
                    } catch { continue; }
                }
            }

            await sock.sendMessage(chatId, {
                react: { text: sent > 0 ? '✅' : '☢', key: m.key },
            }).catch(() => {});

            if (sent > 0) {
                await sock.sendMessage(chatId, {
                    text: `── .✦ ──\n\n> ✅ *${sent}* stickers sent\n> Pack: *${packname}*`,
                }, { quoted: m });
            } else {
                return reply(`> Failed to send the stickers.`);
            }
        } catch (error) {
            console.error('[PINPACK]', error?.message);
            await sock.sendMessage(chatId, { react: { text: '☢', key: m.key } }).catch(() => {});
            return reply(global.mess?.error?.fitur || 'Pinpack error.');
        }
    },
};