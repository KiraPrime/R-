/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: 'dado',
    aliases: ['dados', 'dice'],
    category: 'games',
    description: 'Roll a random dice sticker',
    usage: '.dado',
    async handler(sock, message, _args, _context) {
        const chatId = message.key.remoteJid;
        const diceLinks = [
            'https://tinyurl.com/gdd01',
            'https://tinyurl.com/gdd02',
            'https://tinyurl.com/gdd003',
            'https://tinyurl.com/gdd004',
            'https://tinyurl.com/gdd05',
            'https://tinyurl.com/gdd006'
        ];
        const randomDice = diceLinks[Math.floor(Math.random() * diceLinks.length)];
        try {
            await sendMessageWithChannel(sock, chatId, {
                sticker: { url: randomDice }
            }, { quoted: message });
        }
        catch (e) {
            console.error('Dice Plugin Error:', e);
            await sendMessageWithChannel(sock, chatId, {
                image: { url: randomDice },
                caption: '🎲 The dice rolled!'
            }, { quoted: message });
        }
    }
};
