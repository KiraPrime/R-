'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const fs   = require('fs');
const path = require('path');

// ══════════════════════════════════════════════════════════════════
// ─── FORWARD NEWSLETTER CONTEXT (mandatory on all plugins) ────────
// ══════════════════════════════════════════════════════════════════
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── STORE (auto-created) ─────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const DATA_DIR   = path.join(__dirname, 'cpanel-data');
const STORE_PATH = path.join(DATA_DIR, 'legacy_sellers.json');

function ensureDir() {
    try {
        if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    } catch (e) {
        console.error('[SELLER] mkdir failed:', e?.message);
    }
}

function getLegacyData() {
    ensureDir();
    if (fs.existsSync(STORE_PATH)) {
        try {
            const raw = fs.readFileSync(STORE_PATH, 'utf8').trim();
            if (raw) {
                const parsed = JSON.parse(raw);
                return {
                    sellers:     Array.isArray(parsed.sellers)     ? parsed.sellers     : [],
                    ownerPanels: Array.isArray(parsed.ownerPanels) ? parsed.ownerPanels : [],
                };
            }
        } catch (e) {
            console.error('[SELLER] store corrupted:', e?.message);
        }
    }
    return { sellers: [], ownerPanels: [] };
}

function saveLegacyData(data) {
    try {
        ensureDir();
        const tmp = STORE_PATH + '.tmp';
        fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8');
        fs.renameSync(tmp, STORE_PATH);
        return true;
    } catch (e) {
        console.error('[SELLER] save failed:', e?.message);
        return false;
    }
}

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function cleanJid(jid) {
    if (!jid) return null;
    let j = String(jid);
    if (j.endsWith('@lid')) j = j.replace('@lid', '@s.whatsapp.net');
    return j.includes('@') ? j : j + '@s.whatsapp.net';
}

function getNumber(jid) {
    const clean = cleanJid(jid);
    if (!clean) return null;
    const num = clean.split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
    return num || null;
}

function getMentions(m) {
    const ctx =
        m?.message?.extendedTextMessage?.contextInfo ||
        m?.message?.imageMessage?.contextInfo ||
        m?.message?.videoMessage?.contextInfo ||
        null;
    return ctx?.mentionedJid || [];
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch { /* ignore */ }
}

function hasAccess(senderJid, isOwner, legacyData) {
    if (isOwner) return true;
    const cleanSender = getNumber(senderJid);
    if (!cleanSender) return false;
    const ownerPanels = legacyData?.ownerPanels || [];
    return ownerPanels.includes(cleanSender);
}

/**
 * Resolve the target user's phone number from (in order):
 *   1. quoted message sender
 *   2. mention
 *   3. raw text (digits only)
 *   4. sender (self)
 */
function resolveTarget(m, args) {
    // Quoted
    if (m?.quoted?.sender) return getNumber(m.quoted.sender);
    // Mention
    const mentions = getMentions(m);
    if (mentions.length > 0) return getNumber(mentions[0]);
    // Raw text
    const raw = (args.join(' ') || '').trim();
    if (raw) {
        const digits = raw.replace(/[^0-9]/g, '');
        if (digits) return digits;
    }
    // Self
    return null; // don't default to self for safety
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'addseller',
    aliases:     [
        'addreseller',
        'delseller',
        'delreseller',
        'listseller',
        'listreseller',
    ],
    category:    'panel',
    description: 'Manage panel sellers / resellers',
    usage:       '.addseller @user | .delseller @user | .listseller',

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix, isOwner, sender } = context;

        const cmd = (context.command || 'addseller').toLowerCase();

        // ── Load store ────────────────────────────────────────────
        const legacyData = getLegacyData();

        // ── Access check (owner OR ownerPanel) ────────────────────
        if (!hasAccess(sender, isOwner, legacyData)) {
            return reply(
                `❌ *ACCESS DENIED*\n\n` +
                `> This feature is for the Owner or Panel Owners only.`,
            );
        }

        if (!legacyData.sellers) legacyData.sellers = [];

        const isAdd  = ['addseller', 'addreseller'].includes(cmd);
        const isDel  = ['delseller', 'delreseller'].includes(cmd);
        const isList = ['listseller', 'listreseller'].includes(cmd);

        // ── LIST ─────────────────────────────────────────────────
        if (isList) {
            if (legacyData.sellers.length === 0) {
                return reply(`📋 *SELLER / RESELLER LIST*\n\n> No seller registered yet.`);
            }

            let txt = `📋 *SELLER / RESELLER LIST*\n\n`;
            txt += `> Total: *${legacyData.sellers.length}* seller(s)\n\n`;
            legacyData.sellers.forEach((s, i) => {
                txt += `${i + 1}. \`${s}\`\n`;
            });
            txt += `\n> _Sellers can create servers (1GB–10GB v1/v2/v3)_`;
            return reply(txt);
        }

        // ── Resolve target ────────────────────────────────────────
        const targetUser = resolveTarget(m, args);

        if (!targetUser) {
            return reply(
                `⚠️ *USAGE*\n\n` +
                `> \`${prefix}${cmd} @user\`\n` +
                `> \`${prefix}${cmd} 628xxx\`\n` +
                `> Reply to a user message`,
            );
        }

        // ── ADD ───────────────────────────────────────────────────
        if (isAdd) {
            if (legacyData.sellers.includes(targetUser)) {
                return reply(`❌ \`${targetUser}\` is already a seller.`);
            }

            let roleChanged = '';
            const ownerIdx = (legacyData.ownerPanels || []).indexOf(targetUser);
            if (ownerIdx !== -1) {
                legacyData.ownerPanels.splice(ownerIdx, 1);
                roleChanged = `\n> ⚡ Auto-downgraded from Owner Panel to Seller`;
            }

            legacyData.sellers.push(targetUser);

            if (saveLegacyData(legacyData)) {
                await react(sock, chatId, m.key, '✅');
                return reply(
                    `✅ *SELLER ADDED*\n\n` +
                    `╭┈┈⬡「 📋 *DETAILS* 」\n` +
                    `┃ 📱 NUMBER : \`${targetUser}\`\n` +
                    `┃ 🏷️ STATUS : \`Seller/Reseller\`\n` +
                    `┃ 🔓 ACCESS : \`Create Server (1GB-10GB v1-v3)\`\n` +
                    `┃ 📊 TOTAL  : \`${legacyData.sellers.length}\` seller(s)\n` +
                    `╰┈┈⬡${roleChanged}`,
                );
            } else {
                return reply(`❌ Failed to save to database.`);
            }
        }

        // ── DEL ───────────────────────────────────────────────────
        if (isDel) {
            if (!legacyData.sellers.includes(targetUser)) {
                return reply(`❌ \`${targetUser}\` is not a seller.`);
            }

            legacyData.sellers = legacyData.sellers.filter(s => s !== targetUser);

            if (saveLegacyData(legacyData)) {
                await react(sock, chatId, m.key, '✅');
                return reply(
                    `✅ *SELLER REMOVED*\n\n` +
                    `> Number: \`${targetUser}\`\n` +
                    `> Total: *${legacyData.sellers.length}* seller(s)`,
                );
            } else {
                return reply(`❌ Failed to save to database.`);
            }
        }
    },
};