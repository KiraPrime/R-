/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: 'qmaker',
    aliases: ['qmkr', 'quozio'],
    category: 'tools',
    description: 'Create a quote image from text or replied message',
    usage: '.qmaker <text> or reply to a message',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        let text = args?.join(' ')?.trim();
        try {
            if (!text) {
                const quotedText = message?.message?.extendedTextMessage?.contextInfo?.quotedMessage?.conversation;
                if (!quotedText) {
                    return await sendMessageWithChannel(sock, chatId, { text: '*Provide text or reply to a message to create a quote.*' }, { quoted: message });
                }
                text = quotedText;
            }
            const author = message.pushName || message?.key?.participant || 'Anonymous';
            const createRes = await fetch('https://quozio.com/api/v1/quotes', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    author,
                    quote: text
                })
            });
            const quoteData = await createRes.json();
            if (!quoteData?.quoteId)
                throw new Error('Quote creation failed');
            const quoteId = quoteData.quoteId;
            const templatesRes = await fetch('https://quozio.com/api/v1/templates');
            const templatesData = await templatesRes.json();
            const templates = templatesData.data;
            if (!templates?.length)
                throw new Error('No templates found');
            const template = templates[Math.floor(Math.random() * templates.length)];
            const imageRes = await fetch(`https://quozio.com/api/v1/quotes/${quoteId}/imageUrls?templateId=${template.templateId}`);
            const imageData = await imageRes.json();
            if (!imageData?.medium)
                throw new Error('Image generation failed');
            await sendMessageWithChannel(sock, chatId, { image: { url: imageData.medium }, caption: `📝 Quote Created\n\nAuthor: ${author}\n\n${text}` }, { quoted: message });
        }
        catch (error) {
            console.error('Quote plugin error:', error);
            await sendMessageWithChannel(sock, chatId, { text: '❌ Failed to create quote. Try again later.' }, { quoted: message });
        }
    }
};
