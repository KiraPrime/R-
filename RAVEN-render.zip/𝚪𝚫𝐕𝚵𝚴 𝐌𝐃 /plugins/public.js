'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
function validateOwner(message, isOwner) {
    if (!isOwner) return false;
    if (message.key?.fromMe) return true;

    const senderNumber = (message.key?.participant || message.key?.remoteJid || '')
        .replace(/[^0-9]/g, '') || '';
    const ownerNumbers = global.owner || [];

    const isInOwnerList = ownerNumbers.some(owner => {
        const cleanOwner = String(owner).replace(/[^0-9]/g, '');
        return senderNumber.includes(cleanOwner) || cleanOwner.includes(senderNumber);
    });
    if (!isInOwnerList) return false;
    if (!senderNumber) return false;

    return true;
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'public',
    aliases:     ['publicmode', 'pub'],
    category:    'owner',
    description: 'Enable public mode (everyone can access) — © 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
    usage:       '.public',

    async handler(sock, message, args, context) {
        const { chatId, reply, isOwner, setSetting } = context;

        try {
            const isRealOwner = validateOwner(message, isOwner);
            if (!isRealOwner) {
                return reply('🚫 *ACCESS DENIED*\n\n> Only the owner can change the bot mode!');
            }

            const currentMode = global.botMode || 'PUBLIC';

            if (currentMode.toLowerCase() === 'public') {
                return reply('ℹ️ Bot is already in *public* mode.');
            }

            global.botMode = 'PUBLIC';
            sock.public = true;
            setSetting('bot', 'botMode', 'public');

            const responseText =
                `🌐 *PUBLIC MODE ENABLED*\n\n` +
                `> Bot will now respond to all users!\n\n` +
                `_Use .self to restrict access_`;

            await reply(responseText);
            console.log(`[Mode] Changed to PUBLIC by ${message.pushName} (${message.key?.participant || message.key?.remoteJid})`);
        } catch (error) {
            console.error('[PUBLIC ERROR]', error);
            await reply(`❌ An error occurred: ${error.message}`);
        }
    },

    // Expose helper for future use
    _validateOwner: validateOwner,
};