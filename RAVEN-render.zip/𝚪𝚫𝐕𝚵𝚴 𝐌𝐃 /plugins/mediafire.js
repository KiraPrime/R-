/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require('axios');
const cheerio = require('cheerio');
async function mediafireDl(url) {
    try {
        const { data } = await axios.get(url, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36'
            }
        });
        const $ = cheerio.load(data);
        const link = $('#downloadButton').attr('href');
        const name = $('div.dl-info > div.promo-text').text().trim() || $('.dl-btn-label').attr('title');
        const size = $('#downloadButton').text().replace(/Download|[()]|\s/g, '').trim() || 'Unknown';
        const ext = name.split('.').pop();
        return { name, size, link, ext };
    }
    catch (e) {
        return null;
    }
}
module.exports = {
    command: 'mediafire',
    aliases: ['mfire', 'mf'],
    category: 'download',
    description: 'Download files from MediaFire',
    usage: '.mediafire <url>',
    async handler(sock, message, args, context) {
        const { chatId } = context;
        const text = args.join(' ');
        if (!text)
            return await sendMessageWithChannel(sock, chatId, { text: "❌ Provide a MediaFire URL.\n\nExample:\n.mfire https://www.mediafire.com/file/5e54xv2cislhfgb/twoxzhn.zip/file" }, { quoted: message });
        try {
            const data = await mediafireDl(text);
            if (!data || !data.link) {
                return await sendMessageWithChannel(sock, chatId, { text: "❌ Failed to parse MediaFire page. Link might be private or broken." }, { quoted: message });
            }
            let caption = `≡ *MEDIAFIRE DOWNLOADER*\n\n`;
            caption += `▢ *File:* ${data.name}\n`;
            caption += `▢ *Size:* ${data.size}\n`;
            caption += `▢ *Extension:* ${data.ext}\n\n`;
            caption += `*Download In Progress... Please Wait ⌛*`;
            await sendMessageWithChannel(sock, chatId, { text: caption }, { quoted: message });
            const response = await axios({
                method: 'get',
                url: data.link,
                responseType: 'arraybuffer',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36',
                    'Referer': text
                }
            });
            const buffer = Buffer.from(response.data);
            if (buffer.length < 10000) {
                return await sendMessageWithChannel(sock, chatId, { text: "❌ Error: The downloaded file is corrupt or invalid." });
            }
            let mimeType = 'application/octet-stream';
            const mimes = {
                'zip': 'application/zip',
                'pdf': 'application/pdf',
                'apk': 'application/vnd.android.package-archive',
                'mp4': 'video/mp4',
                'mp3': 'audio/mpeg',
                'jpg': 'image/jpeg',
                'png': 'image/png'
            };
            if (mimes[data.ext.toLowerCase()])
                mimeType = mimes[data.ext.toLowerCase()];
            await sendMessageWithChannel(sock, chatId, {
                document: buffer,
                fileName: data.name,
                mimetype: mimeType,
                caption: `✅ *Download Complete:* ${data.name}`
            }, { quoted: message });
        }
        catch (err) {
            console.error('MF Download Error:', err);
            await sendMessageWithChannel(sock, chatId, { text: `❌ Error: ${ err.message}` }, { quoted: message });
        }
    }
};
