'use strict';

/*
  LOCK CHAT — Per-user password-protected chat lock (real DM lockdown)
  - .setpass <4 digits>   → set password (DM with bot only)
  - .resetpass / .mypass  → manage password (DM with bot only)
  - .lockchat <number>    → lock a DM partner (sends locked HTML + hides all messages)
  - .unlockchat <number> <pass> → unlock a DM partner
  Auto-creates: plugins/lockchat-data/pwd.json + locks.json
  Channel: https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
*/

const fs   = require('fs');
const path = require('path');
const { randomUUID } = require('node:crypto');

// ─── Forward context ──────────────────────────────────────────────
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ─── Store (auto-created) ─────────────────────────────────────────
const DATA_DIR   = path.join(__dirname, 'lockchat-data');
const PWD_PATH   = path.join(DATA_DIR, 'pwd.json');
const LOCKS_PATH = path.join(DATA_DIR, 'locks.json');

let _pwd   = null;
let _locks = null;
let _saveTimer = null;

function ensureDir() {
    try {
        if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    } catch (e) { console.error('[LOCKCHAT] mkdir failed:', e?.message); }
}

function loadJSON(p, fallback) {
    ensureDir();
    try {
        if (fs.existsSync(p)) {
            const raw = fs.readFileSync(p, 'utf8').trim();
            if (raw) return JSON.parse(raw);
        }
    } catch (e) {
        console.error('[LOCKCHAT] corrupted:', p, e?.message);
        try {
            const backup = p + '.corrupted.' + Date.now() + '.bak';
            if (fs.existsSync(p)) fs.copyFileSync(p, backup);
        } catch {}
    }
    return JSON.parse(JSON.stringify(fallback));
}

function writeJSON(p, data) {
    try {
        ensureDir();
        const tmp = p + '.tmp';
        fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8');
        fs.renameSync(tmp, p);
    } catch (e) { console.error('[LOCKCHAT] write failed:', e?.message); }
}

function loadStores() {
    _pwd   = loadJSON(PWD_PATH,   { users: {} });
    _locks = loadJSON(LOCKS_PATH, { locks: {} });
    if (!_pwd.users)   _pwd.users   = {};
    if (!_locks.locks) _locks.locks = {};
}

function saveStoresSync() {
    writeJSON(PWD_PATH,   _pwd);
    writeJSON(LOCKS_PATH, _locks);
}

function scheduleSave() {
    if (_saveTimer) clearTimeout(_saveTimer);
    _saveTimer = setTimeout(() => { _saveTimer = null; saveStoresSync(); }, 400);
    if (_saveTimer.unref) _saveTimer.unref();
}

function numOf(jid) {
    return String(jid || '').split(':')[0].split('@')[0].replace(/[^0-9]/g, '');
}

// Password
function getPass(jid) {
    const n = numOf(jid);
    return n ? (_pwd.users[n]?.pass || null) : null;
}
function setPass(jid, pass) {
    const n = numOf(jid);
    if (!n) return false;
    _pwd.users[n] = { pass, updatedAt: Date.now() };
    scheduleSave();
    return true;
}
function delPass(jid) {
    const n = numOf(jid);
    if (!n || !_pwd.users[n]) return false;
    delete _pwd.users[n];
    scheduleSave();
    return true;
}

// Locks
function setLock(ownerJid, partnerJid, pass) {
    const o = numOf(ownerJid);
    const p = numOf(partnerJid);
    if (!o || !p) return false;
    if (!_locks.locks[o]) _locks.locks[o] = {};
    _locks.locks[o][p] = { pass, lockedAt: Date.now() };
    scheduleSave();
    return true;
}
function getLock(ownerJid, partnerJid) {
    const o = numOf(ownerJid);
    const p = numOf(partnerJid);
    if (!o || !p) return null;
    return _locks.locks[o]?.[p] || null;
}
function removeLock(ownerJid, partnerJid) {
    const o = numOf(ownerJid);
    const p = numOf(partnerJid);
    if (!o || !p) return false;
    if (!_locks.locks[o]?.[p]) return false;
    delete _locks.locks[o][p];
    if (!Object.keys(_locks.locks[o]).length) delete _locks.locks[o];
    scheduleSave();
    return true;
}

// Check if a chat is locked in either direction
function isChatLocked(chatJid) {
    const partnerNum = numOf(chatJid);
    if (!partnerNum) return false;
    // Check any owner that has this partner locked
    for (const ownerNum of Object.keys(_locks.locks)) {
        if (_locks.locks[ownerNum]?.[partnerNum]) {
            return { ownerNum, pass: _locks.locks[ownerNum][partnerNum].pass };
        }
    }
    return false;
}

loadStores();
process.on('exit',   () => { try { saveStoresSync(); } catch {} });
process.on('SIGINT', () => { try { saveStoresSync(); } catch {} process.exit(0); });

// ─── Build locked HTML ────────────────────────────────────────────
function buildLockedHtml(pass) {
    const safePass = String(pass).replace(/[^0-9]/g, '').slice(0, 8);

    return `
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
  * { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
  html, body {
    margin: 0; padding: 0;
    background: radial-gradient(circle at top, #1a0d12 0%, #050407 100%);
    color: #fff;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
    min-height: 100vh;
    display: flex; align-items: center; justify-content: center;
    padding: 24px;
  }
  .wrap { width: 100%; max-width: 380px; text-align: center; }
  .lock {
    width: 90px; height: 90px; margin: 0 auto 20px;
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    background: linear-gradient(135deg, #4da6ff, #7b5cff);
    font-size: 42px;
    box-shadow: 0 12px 40px rgba(77, 166, 255, 0.5);
    animation: pulse 2s infinite;
  }
  @keyframes pulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.06); }
  }
  h1 { font-size: 22px; margin: 0 0 8px; font-weight: 800; }
  p { font-size: 13px; color: #8ea0c0; margin: 0 0 22px; }
  input {
    width: 100%; padding: 14px 16px;
    border-radius: 14px;
    border: 1px solid rgba(255, 255, 255, 0.14);
    background: rgba(255, 255, 255, 0.05);
    color: #fff; font-size: 15px; outline: none;
    text-align: center; letter-spacing: 6px;
    margin-bottom: 12px;
  }
  input:focus { border-color: #4da6ff; }
  button {
    width: 100%; padding: 14px;
    border-radius: 14px; border: 0;
    background: linear-gradient(135deg, #4da6ff, #7b5cff);
    color: #fff; font-size: 15px; font-weight: 800;
    cursor: pointer;
  }
  button:active { transform: scale(0.97); }
  .error { margin-top: 12px; font-size: 12px; color: #ff5c8a; min-height: 18px; font-weight: 600; }
  .success { margin-top: 12px; font-size: 13px; color: #7cff9f; font-weight: 700; }
  .footer { margin-top: 24px; font-size: 10px; color: #556080; }
</style>
</head>
<body>
  <div class="wrap">
    <div class="lock" id="lock">🔒</div>
    <h1 id="title">Chat Locked</h1>
    <p id="subtitle">Enter the password to unlock this chat.</p>
    <input id="pass" type="tel" inputmode="numeric" maxlength="8" placeholder="••••" autocomplete="off">
    <button id="btn">Unlock</button>
    <div id="msg"></div>
    <div class="footer">© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃</div>
  </div>
  <script>
    var CORRECT = '${safePass}';
    var passEl = document.getElementById('pass');
    var btnEl  = document.getElementById('btn');
    var msgEl  = document.getElementById('msg');
    var titleEl = document.getElementById('title');
    var subEl   = document.getElementById('subtitle');
    var lockEl  = document.getElementById('lock');
    function tryUnlock() {
      var val = (passEl.value || '').trim();
      if (val === CORRECT) {
        msgEl.className = 'success';
        msgEl.textContent = '✅ Unlocked!';
        titleEl.textContent = 'Access Granted';
        subEl.textContent = 'You may now view the chat.';
        lockEl.textContent = '🔓';
        lockEl.style.background = 'linear-gradient(135deg,#7cff9f,#4dffb8)';
        passEl.disabled = true;
        btnEl.disabled  = true;
        btnEl.textContent = 'Unlocked';
      } else {
        msgEl.className = 'error';
        msgEl.textContent = '❌ Incorrect password.';
        passEl.value = '';
      }
    }
    btnEl.addEventListener('click', tryUnlock);
    passEl.addEventListener('keydown', function(e) { if (e.key === 'Enter') tryUnlock(); });
    passEl.focus();
  </script>
</body>
</html>
`;
}

// ─── Send locked-chat rich response ───────────────────────────────
async function sendLockedChat(sock, targetJid, pass) {
    const responseId = randomUUID();
    const html       = buildLockedHtml(pass);

    await sock.relayMessage(
        targetJid,
        {
            messageContextInfo: {
                deviceListMetadata: {},
                deviceListMetadataVersion: 2,
                botMetadata: { messageDisclaimerText: '', botResponseId: responseId }
            },
            botForwardedMessage: {
                message: {
                    richResponseMessage: {
                        messageType: 1,
                        submessages: [{ messageType: 2, messageText: '🔒 Locked Chat' }],
                        unifiedResponse: {
                            data: Buffer.from(JSON.stringify({
                                response_id: responseId,
                                sections: [{
                                    view_model: {
                                        primitive: {
                                            __typename: 'GenAIaeacdsnwHtmlPrimitive',
                                            payload: html,
                                            trusted_sources: []
                                        },
                                        __typename: 'GenAISingleLayoutViewModel'
                                    }
                                }]
                            })).toString('base64')
                        },
                        contextInfo: {
                            forwardingScore: 1,
                            isForwarded: true,
                            forwardedAiBotMessageInfo: { botJid: '867051314767696@bot' },
                            forwardOrigin: 4
                        }
                    }
                }
            }
        },
        { messageId: responseId }
    );
}

// ─── Listener: delete all messages in locked DMs ──────────────────
let _bound     = false;
let _boundSock = null;

async function onMessagesUpsert(payload) {
    try {
        const sock = _boundSock;
        if (!sock) return;

        const messages = Array.isArray(payload?.messages) ? payload.messages : [];

        for (const raw of messages) {
            if (!raw?.key?.remoteJid) continue;

            const chatJid = raw.key.remoteJid;
            if (!chatJid.endsWith('@s.whatsapp.net')) continue;

            const lock = isChatLocked(chatJid);
            if (!lock) continue;

            // Skip the "unlock" command itself
            const body =
                raw.message?.conversation ||
                raw.message?.extendedTextMessage?.text ||
                '';
            const prefix = global.xprefix || '.';
            if (body.startsWith(`${prefix}unlockchat`)) continue;
            if (body.startsWith(`${prefix}lockchat`)) continue;

            // Delete the message
            try {
                await sock.sendMessage(chatJid, {
                    delete: {
                        remoteJid: chatJid,
                        fromMe: !!raw.key.fromMe,
                        id: raw.key.id,
                        participant: raw.key.participant
                    }
                });
            } catch (e) {
                console.error('[LOCKCHAT/DELETE]', e?.message);
            }
        }
    } catch (e) {
        console.error('[LOCKCHAT-EVENT]', e?.message);
    }
}

function bindSock(sock) {
    if (_bound || !sock || !sock.ev) return;
    _bound = true;
    _boundSock = sock;
    try {
        sock.ev.on('messages.upsert', onMessagesUpsert);
        console.log('[LOCKCHAT] ✅ event hook registered');
    } catch (e) {
        console.error('[LOCKCHAT] failed to bind:', e?.message);
        _bound = false;
    }
}

function tryBindFromGlobals() {
    const candidates = [global.sock, global.conn, global.Hanz, global.client];
    for (const c of candidates) {
        if (c && c.ev) { bindSock(c); return true; }
    }
    return false;
}

tryBindFromGlobals();

let _retryCount = 0;
const _retryTimer = setInterval(() => {
    if (_bound) return clearInterval(_retryTimer);
    if (++_retryCount >= 300) return clearInterval(_retryTimer);
    tryBindFromGlobals();
}, 1000);
if (_retryTimer.unref) _retryTimer.unref();

// ─── Plugin export ────────────────────────────────────────────────
module.exports = {
    command: 'setpass',
    aliases: [
        'resetpass', 'delpass', 'clearpass',
        'mypass', 'passstatus',
        'lockchat', 'lock',
        'unlockchat', 'unlock'
    ],
    category: 'general',
    description: 'Set password & lock DM chats',
    usage: '.setpass <4 digits> | .lockchat <number> | .unlockchat <number> <pass>',

    async handler(sock, message, args, context) {
        if (!_bound) bindSock(sock);

        const { chatId, reply, prefix, sender, command } = context;
        const cmd = (command || 'setpass').toLowerCase();

        const senderJid = sender || message.key?.participant || message.key?.remoteJid || '';
        const senderNum = numOf(senderJid);
        if (!senderNum) return reply('❌ Could not resolve your number.');

        const isDM = String(chatId).endsWith('@s.whatsapp.net');

        // ── .setpass <4 digits> ────────────────────────────
        if (cmd === 'setpass') {
            if (!isDM) return reply('❌ `.setpass` only works in DM with the bot.');
            const raw = (args.join(' ') || '').trim();
            if (!/^\d{4}$/.test(raw)) {
                return reply(
                    `🔐 *SET PASSWORD*\n\n` +
                    `> Provide exactly 4 digits.\n\n` +
                    `*Usage:* \`${prefix}setpass 1234\``
                );
            }
            setPass(senderJid, raw);
            return reply(
                `✅ *Password set!*\n\n` +
                `> Your password: \`${raw}\`\n\n` +
                `Now DM someone and type \`${prefix}lockchat <their_number>\` to lock the chat.`
            );
        }

        // ── .resetpass / .delpass / .clearpass ─────────────
        if (['resetpass', 'delpass', 'clearpass'].includes(cmd)) {
            if (!isDM) return reply('❌ Reset only works in DM with the bot.');
            const had = delPass(senderJid);
            return reply(had ? '✅ *Password removed.*' : 'ℹ️ You had no password set.');
        }

        // ── .mypass ────────────────────────────────────────
        if (['mypass', 'passstatus'].includes(cmd)) {
            const pass = getPass(senderJid);
            return reply(
                pass
                    ? `🔐 *Your password:* \`${pass}\`\n\n> Use \`${prefix}resetpass\` to remove it.`
                    : `ℹ️ *No password set.*\n\n> Use \`${prefix}setpass <4 digits>\` first.`
            );
        }

        // ── .lockchat <number> ─────────────────────────────
        if (cmd === 'lockchat' || cmd === 'lock') {
            const raw = (args.join(' ') || '').trim();
            if (!raw) {
                return reply(
                    `🔒 *LOCK CHAT*\n\n` +
                    `> Lock your DM chat with someone.\n\n` +
                    `*Usage:* \`${prefix}lockchat <number>\``
                );
            }
            const partnerNum = raw.replace(/[^0-9]/g, '');
            if (!partnerNum || partnerNum.length < 8) {
                return reply('❌ Invalid number.');
            }
            if (partnerNum === senderNum) {
                return reply('❌ You cannot lock yourself.');
            }

            const pass = getPass(senderJid);
            if (!pass) {
                return reply(
                    `❌ *No password set.*\n\n` +
                    `> Use \`${prefix}setpass <4 digits>\` in DM first.`
                );
            }

            const partnerJid = partnerNum + '@s.whatsapp.net';
            setLock(senderJid, partnerJid, pass);

            // Send the locked HTML to the partner
            try {
                await sendLockedChat(sock, partnerJid, pass);
            } catch (e) {
                console.error('[LOCKCHAT/SEND]', e?.message);
            }

            return reply(
                `🔒 *Chat locked with* \`${partnerNum}\`\n\n` +
                `> Any new message in this DM will be **auto-deleted**.\n` +
                `> To unlock: \`${prefix}unlockchat ${partnerNum} <password>\``
            );
        }

        // ── .unlockchat <number> <pass> ────────────────────
        if (cmd === 'unlockchat' || cmd === 'unlock') {
            const rawArgs = args.slice(0);
            if (rawArgs.length < 2) {
                return reply(
                    `🔓 *UNLOCK CHAT*\n\n` +
                    `*Usage:* \`${prefix}unlockchat <number> <password>\``
                );
            }
            const partnerNum = String(rawArgs[0]).replace(/[^0-9]/g, '');
            const providedPass = String(rawArgs[1]).trim();
            if (!partnerNum || partnerNum.length < 8) {
                return reply('❌ Invalid number.');
            }
            if (!/^\d{4}$/.test(providedPass)) {
                return reply('❌ Password must be 4 digits.');
            }

            const partnerJid = partnerNum + '@s.whatsapp.net';
            const lock = getLock(senderJid, partnerJid);
            if (!lock) {
                return reply(`ℹ️ No lock found with \`${partnerNum}\`.`);
            }
            if (lock.pass !== providedPass) {
                return reply('❌ *Wrong password.*');
            }

            removeLock(senderJid, partnerJid);
            return reply(
                `🔓 *Chat unlocked with* \`${partnerNum}\`\n\n` +
                `> Messages will no longer be auto-deleted.`
            );
        }
    },

    // Exposed helpers
    _getPass:  getPass,
    _setPass:  setPass,
    _delPass:  delPass,
    _setLock:  setLock,
    _getLock:  getLock,
    _removeLock: removeLock,
    _sendLockedChat: sendLockedChat,
};