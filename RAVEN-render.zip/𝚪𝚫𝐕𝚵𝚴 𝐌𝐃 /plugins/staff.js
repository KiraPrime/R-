/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: 'staff',
    aliases: ['admins', 'adminlist'],
    category: 'group',
    description: 'Display list of group admins',
    usage: '.staff',
    groupOnly: true,
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        try {
            const groupMetadata = await sock.groupMetadata(chatId);
            let pp;
            try {
                pp = await sock.profilePictureUrl(chatId, 'image');
            }
            catch {
                pp = 'https://i.imgur.com/2wzGhpF.jpeg';
            }
            const participants = groupMetadata.participants;
            const groupAdmins = participants.filter((p) => p.admin);
            const listAdmin = groupAdmins.map((v, i) => `${i + 1}. @${v.id.split('@')[0]}`).join('\n▢ ');
            const owner = groupMetadata.owner || groupAdmins.find((p) => p.admin === 'superadmin')?.id || `${chatId.split('-')[0] }@s.whatsapp.net`;
            const text = `
≡ *GROUP ADMINS* _${groupMetadata.subject}_

┌─⊷ *ADMINS*
▢ ${listAdmin}
└───────────
`.trim();
            await sendMessageWithChannel(sock, chatId, {
                image: { url: pp },
                caption: text,
                mentions: [...groupAdmins.map((v) => v.id), owner],
                ...channelInfo
            });
        }
        catch (error) {
            console.error('Error in staff command:', error);
            await sendMessageWithChannel(sock, chatId, {
                text: 'Failed to get admin list!',
                ...channelInfo
            }, { quoted: message });
        }
    }
};
