'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const S = require("./rimuru-store");
async function handler(sock,m,args,ctx={}){
 const me=S.get(ctx.sender||m.sender,ctx.pushname||m.pushName);
 const reply=(text,opts)=>ctx.reply?ctx.reply(text,opts):sock.sendMessage(ctx.chatId||m.key?.remoteJid,{text,...(opts||{})});
 const now=Date.now(),last=me.cooldowns.daily||0;if(now-last<86400000)return reply(`⏳ You already claimed your daily reward.\nTry again in *${S.cooldown(last+86400000-now)}*.`);const cash=500+Math.floor(Math.random()*1500),exp=100+Math.floor(Math.random()*300);me.cash+=cash;me.exp+=exp;me.cooldowns.daily=now;S.save();return reply(`🎁 *DAILY REWARD*\n\n💵 Cash: *+$${S.money(cash)}*\n✨ EXP: *+${S.money(exp)}*\n\nYour balance: *$${S.money(me.cash)}*`);
}
module.exports={command:"daily",aliases:['claim'],category:"rpg",description:'Claim a daily reward',handler};
