/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: 'excard',
    aliases: [],
    category: 'tools',
    description: 'Create a rich media card',
    usage: '.excard Title | Body | ImageURL',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const input = args.join(' ');
        if (!input.includes('|')) {
            return await sendMessageWithChannel(sock, chatId, {
                text: '*Usage:* .excard Title | Body | ImageURL\n\n*Example:* .excard Google | Search anything | https://google.com/logo.png'
            }, { quoted: message });
        }
        const [title, body, url] = input.split('|').map((t) => t.trim());
        const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const _hasQuotedImage = quoted?.imageMessage;
        await sendMessageWithChannel(sock, chatId, {
            text: body || " ",
            contextInfo: {
                externalAdReply: {
                    title,
                    body: 'Shared via 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
                    thumbnailUrl: url || 'https://i.ibb.co/3S6f0mS/default.jpg',
                    mediaType: 1,
                    renderLargerThumbnail: true,
                    sourceUrl: url || 'https://github.com'
                }
            }
        }, { quoted: message });
    }
};
