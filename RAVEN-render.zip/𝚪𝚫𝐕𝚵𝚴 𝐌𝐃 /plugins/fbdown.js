'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const axios = require('axios');

// ══════════════════════════════════════════════════════════════════
// ─── FORWARD NEWSLETTER CONTEXT ───────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── CONFIG ───────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const CFG = {
    apiBase: 'https://api.azbry.com/api/download/facebook',
    timeout: 45000,
};

// ══════════════════════════════════════════════════════════════════
// ─── SCRAPER (inlined from src/scraper/fbdown.js) ─────────────────
// ══════════════════════════════════════════════════════════════════
async function fbdown(url) {
    try {
        const res = await axios.get(
            `${CFG.apiBase}?url=${encodeURIComponent(url)}`,
            { timeout: CFG.timeout },
        );

        if (res.data?.status) return res.data;

        return { status: false, message: 'Failed to fetch data from API' };
    } catch (err) {
        return { status: false, message: err.message };
    }
}

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {}
}

function isFacebookUrl(url) {
    return /facebook\.com|fb\.watch|fb\.com/i.test(String(url || ''));
}

function pickBestVideo(medias = []) {
    if (!Array.isArray(medias) || medias.length === 0) return null;

    return (
        medias.find(m => m.quality === 'hd') ||
        medias.find(m => m.quality === 'sd') ||
        medias[0]
    );
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'fbdown',
    aliases:     ['facebookdl', 'facebook', 'fbdl'],
    category:    'download',
    description: 'Download a Facebook video',
    usage:       '.fbdown <url>',

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix } = context;

        const url = (args.join(' ') || '').trim();

        // ── No URL → help ─────────────────────────────────────────
        if (!url) {
            return reply(
                `⚠️ *USAGE*\n\n` +
                `> \`${prefix}fbdown <facebook_url>\`\n\n` +
                `*Example:*\n` +
                `> \`${prefix}fbdown https://www.facebook.com/watch?v=xxx\`\n` +
                `> \`${prefix}facebookdl https://fb.watch/xxx\``,
            );
        }

        if (!isFacebookUrl(url)) {
            return reply(`❌ Invalid URL. Please provide a Facebook link.`);
        }

        await react(sock, chatId, m.key, '🕕');

        try {
            const data = await fbdown(url);

            if (!data?.status || !data?.result?.medias || data.result.medias.length === 0) {
                await react(sock, chatId, m.key, '❌');
                return reply(
                    `❌ *FAILED TO FETCH VIDEO*\n\n` +
                    `> Try another link or make sure the post is public.\n\n` +
                    `_Note: only Facebook videos are supported, not photos._`,
                );
            }

            // ── Pick best quality ─────────────────────────────────
            const video = pickBestVideo(data.result.medias);

            if (!video?.url) {
                await react(sock, chatId, m.key, '❌');
                return reply(
                    `❌ *VIDEO NOT FOUND*\n\n` +
                    `_Note: only Facebook videos are supported, not photos._`,
                );
            }

            // ── Build caption ─────────────────────────────────────
            let caption = `🎥 *FACEBOOK DOWNLOADER*\n\n`;
            caption += `*Title*    : ${data.result.title || 'Facebook Video'}\n`;
            caption += `*Quality*  : ${video.quality ? video.quality.toUpperCase() : 'Normal'}\n`;
            if (video.formattedSize) {
                caption += `*Size*     : ${video.formattedSize}\n`;
            }
            caption += `\n_Note: photo posts are not supported._`;

            // ── Send ──────────────────────────────────────────────
            await sendMessageWithChannel(sock, chatId, {
                video:    { url: video.url },
                mimetype: 'video/mp4',
                caption,
            }, { quoted: m });

            await react(sock, chatId, m.key, '✅');

        } catch (err) {
            console.error('[FBDOWN]', err?.message || err);
            await react(sock, chatId, m.key, '❌');
            return reply(global.mess?.error?.fitur || 'Facebook download failed.');
        }
    },
};