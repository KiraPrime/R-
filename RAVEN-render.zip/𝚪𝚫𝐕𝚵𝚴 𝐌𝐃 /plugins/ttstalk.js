/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require('axios');
module.exports = {
    command: 'ttstalk',
    aliases: ['tikstalk', 'ttprofile'],
    category: 'stalk',
    description: 'Lookup TikTok user profile',
    usage: '.ttstalk <username>',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        if (!args.length) {
            return await sendMessageWithChannel(sock, chatId, {
                text: '*Please provide a TikTok username.*\nExample: .ttstalk truepakistanofficial'
            }, { quoted: message });
        }
        const username = args[0];
        try {
            const { data } = await axios.get('https://discardapi.dpdns.org/api/stalk/tiktok', {
                params: { apikey: 'guru', username }
            });
            if (!data?.result?.user) {
                return await sendMessageWithChannel(sock, chatId, { text: '❌ TikTok user not found.' }, { quoted: message });
            }
            const user = data.result.user;
            const stats = data.result.statsV2 || data.result.stats;
            const profileImage = user.avatarLarger || user.avatarMedium || user.avatarThumb;
            const verifiedMark = user.verified ? '✅ Verified' : '';
            const caption = `🎵 *TikTok Profile Info*\n\n` +
                `👤 Nickname: ${user.nickname || 'N/A'} ${verifiedMark}\n` +
                `🆔 Username: @${user.uniqueId || 'N/A'}\n` +
                `📝 Bio: ${user.signature || 'N/A'}\n` +
                `🔒 Private Account: ${user.privateAccount ? 'Yes' : 'No'}\n\n` +
                `👥 Followers: ${stats?.followerCount || 0}\n` +
                `➡ Following: ${stats?.followingCount || 0}\n` +
                `❤️ Likes: ${stats?.heartCount || 0}\n` +
                `🎥 Videos: ${stats?.videoCount || 0}\n\n` +
                `🔗 Profile URL: https://www.tiktok.com/@${user.uniqueId}`;
            if (profileImage) {
                await sendMessageWithChannel(sock, chatId, { image: { url: profileImage }, caption }, { quoted: message });
            }
            else {
                await sendMessageWithChannel(sock, chatId, { text: caption }, { quoted: message });
            }
        }
        catch (err) {
            console.error('TikTok plugin error:', err);
            await sendMessageWithChannel(sock, chatId, { text: '❌ Failed to fetch TikTok profile.' }, { quoted: message });
        }
    }
};
