'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const axios = require('axios');
const yts   = require('yt-search');
const ytdl  = require('../lib/ytdl.js');

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function formatViews(n) {
    if (!n) return '0';
    if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
    if (n >= 1e3) return (n / 1e3).toFixed(1) + 'K';
    return n.toString();
}

async function getVideoDownloadUrl(url) {
    try {
        const { data } = await axios.get(
            `https://my.izuka-api.xyz/api/downloader/ytmp4?url=${encodeURIComponent(url)}`,
            { timeout: 30000 }
        );
        if (data?.status && data?.result?.video_normal) {
            const videos = data.result.video_normal.filter(v => v.ext === 'mp4');
            if (videos.length > 0) {
                videos.sort((a, b) => parseInt(b.quality) - parseInt(a.quality));
                if (videos[0]?.url) return videos[0].url;
            }
        }
    } catch (e) {
        console.error('[YTMP4 Izuka API]', e.message);
    }

    const fallback = await ytdl(url, 'mp4').catch(() => null);
    if (fallback?.status && fallback?.dl) return fallback.dl;

    throw new Error(fallback?.mess || 'Failed to get video download URL');
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT (ΓΔVEN MD format) ──────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'playvideo',
    aliases:     ['playvid', 'ytmp4', 'video'],
    category:    'search',
    description: 'Search and play a YouTube video — © 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
    usage:       '.playvid <query>',

    async handler(sock, message, args, context) {
        const { chatId, reply, prefix } = context;
        const query = (args.join(' ') || '').trim();

        if (!query) {
            return reply(
                `Hello *${message.pushName || 'User'}* 👋\n\n` +
                `To search and play a YouTube video, use:\n` +
                `- \`${prefix}playvid <video title>\`\n\n` +
                `Example:\n` +
                `- \`${prefix}playvid windah basudara\``
            );
        }

        try { await sock.sendMessage(chatId, { react: { text: '🕕', key: message.key } }); } catch {}

        try {
            const search = await yts(query);
            if (!search.videos.length) throw new Error('Video not found');
            const video = search.videos[0];

            let info = `Hello *${message.pushName || 'User'}*, here is the video you were looking for:\n\n`;
            info += `📌 *Title:* ${video.title}\n`;
            info += `👤 *Channel:* ${video.author.name}\n`;
            info += `⏱️ *Duration:* ${video.duration.timestamp}\n`;
            info += `👀 *Views:* ${formatViews(video.views)}\n`;
            info += `📅 *Upload:* ${video.ago}\n\n`;
            info += `_⏳ Downloading the video, please wait..._`;

            // ── Preview (image + caption + externalAdReply) ──
            await sock.sendMessage(
                chatId,
                {
                    image: { url: video.thumbnail },
                    caption: `${video.url}\n${info}`,
                    contextInfo: {
                        externalAdReply: {
                            title: video.title,
                            body: 'YouTube Video',
                            thumbnailUrl: video.thumbnail,
                            sourceUrl: video.url,
                            mediaType: 1,
                            renderLargerThumbnail: true,
                        },
                    },
                },
                { quoted: message }
            );

            // ── Download URL + send video ────────────────────
            const downloadUrl = await getVideoDownloadUrl(video.url);

            await sock.sendMessage(
                chatId,
                {
                    video: { url: downloadUrl },
                    mimetype: 'video/mp4',
                    fileName: `${video.title}.mp4`,
                    caption: `🎬 *${video.title}*\n👤 ${video.author.name}`,
                },
                { quoted: message }
            );

            await sock.sendMessage(chatId, { react: { text: '✅', key: message.key } }).catch(() => {});
        } catch (err) {
            console.error('[PlayVid]', err);
            await sock.sendMessage(chatId, { react: { text: '✘', key: message.key } }).catch(() => {});
            reply(
                `Sorry *${message.pushName || 'User'}*, the play video feature is currently unavailable, or the video is too large. Please try again later!`
            );
        }
    },
};