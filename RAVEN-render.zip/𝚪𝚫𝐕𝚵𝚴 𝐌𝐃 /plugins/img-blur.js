/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const sharp = require('sharp');
module.exports = {
    command: 'blur',
    aliases: ['blurimg', 'blurpic'],
    category: 'tools',
    description: 'Apply a blur effect to an image',
    usage: '.blur (reply to an image or send image with caption)',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const quotedMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        try {
            let imageBuffer;
            if (quotedMessage?.imageMessage) {
                const quoted = { message: { imageMessage: quotedMessage.imageMessage } };
                imageBuffer = await downloadMediaMessage(quoted, 'buffer', {});
            }
            else if (message.message?.imageMessage) {
                imageBuffer = await downloadMediaMessage(message, 'buffer', {}, {});
            }
            else {
                await sendMessageWithChannel(sock, chatId, {
                    text: 'Please reply to an image or send an image with caption `.blur`'
                }, { quoted: message });
                return;
            }
            const resizedImage = await sharp(imageBuffer)
                .resize(800, 800, {
                fit: 'inside',
                withoutEnlargement: true
            })
                .jpeg({ quality: 80 })
                .toBuffer();
            const blurredImage = await sharp(resizedImage)
                .blur(10)
                .toBuffer();
            await sendMessageWithChannel(sock, chatId, {
                image: blurredImage,
                caption: '✨ *Image Blurred Successfully!*',
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363319098372999@newsletter',
                        newsletterName: '𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
                        serverMessageId: -1
                    }
                }
            }, { quoted: message });
        }
        catch (error) {
            console.error('Error in blur command:', error);
            await sendMessageWithChannel(sock, chatId, {
                text: '❌ Failed to blur image. Please try again later.'
            }, { quoted: message });
        }
    }
};
