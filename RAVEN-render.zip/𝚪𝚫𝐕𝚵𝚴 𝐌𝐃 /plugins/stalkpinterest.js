'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const axios = require('axios');

// ══════════════════════════════════════════════════════════════════
// ─── FORWARD NEWSLETTER CONTEXT ───────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── CONFIG ───────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const CFG = {
    apiBase: 'https://api.nexray.eu.cc/stalker/pinterest',
    timeout: 30000,
    ua:      'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
};

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {}
}

function buildCaption(r) {
    let caption = `📌 *PINTEREST STALK — PROFILE INFO* 📌\n\n`;
    caption += `Here are the results for *@${r.username}*:\n\n`;

    caption += `👤 *PROFILE*\n`;
    caption += `  - Full name   : *${r.full_name || '-'}*\n`;
    caption += `  - Username    : @${r.username}\n`;
    caption += `  - Bio         : ${r.bio || '-'}\n`;
    caption += `  - Account type: ${r.account_type || '-'}\n`;
    caption += `  - Created at  : ${r.created_at || '-'}\n\n`;

    caption += `📊 *STATS*\n`;
    caption += `  - Followers   : ${r.stats?.followers || 0}\n`;
    caption += `  - Following   : ${r.stats?.following || 0}\n`;
    caption += `  - Total pins  : ${r.stats?.pins || 0}\n`;
    caption += `  - Total boards: ${r.stats?.boards || 0}\n\n`;

    caption += `🔗 *PROFILE LINK*\n`;
    caption += `  - ${r.profile_url}\n\n`;

    caption += `Share this profile with your friends! 🚀`;
    return caption;
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'pintereststalk',
    aliases:     ['pinstalk2', 'pinterestinfo', 'pinstalker'],
    category:    'stalker',
    description: 'Look up a Pinterest profile by username',
    usage:       '.pintereststalk <username>',

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix } = context;

        const username = (args[0] || '').trim();

        if (!username) {
            return reply(
                `❌ *PINTEREST USERNAME MISSING*\n\n` +
                `> Provide a Pinterest username to stalk.\n\n` +
                `\`Example: ${prefix}pintereststalk dims\``,
            );
        }

        await react(sock, chatId, m.key, '🕕');

        try {
            const res = await axios.get(
                `${CFG.apiBase}?username=${encodeURIComponent(username)}`,
                {
                    timeout: CFG.timeout,
                    headers: { 'User-Agent': CFG.ua },
                },
            );

            const data = res.data;

            if (!data?.status || !data?.result) {
                await react(sock, chatId, m.key, '❌');
                return reply(
                    `⚠️ *LOOKUP FAILED*\n\n` +
                    `Username *${username}* was not found on Pinterest.\n` +
                    `Double-check the spelling and try again.`,
                );
            }

            const r = data.result;
            const caption = buildCaption(r);

            const imageUrl =
                r.image?.original ||
                r.image?.large    ||
                r.image?.medium   ||
                r.image?.small    ||
                null;

            if (imageUrl) {
                await sendMessageWithChannel(sock, chatId, {
                    image:   { url: imageUrl },
                    caption,
                }, { quoted: m });
            } else {
                await sendMessageWithChannel(sock, chatId, { text: caption }, { quoted: m });
            }

            await react(sock, chatId, m.key, '✅');

        } catch (error) {
            console.error('[PINTERESTSTALK]', error?.message || error);
            await react(sock, chatId, m.key, '☢');
            return reply(
                `😔 *SYSTEM ERROR*\n\n` +
                `Failed to fetch data from the Pinterest server. Please try again later.`,
            );
        }
    },
};