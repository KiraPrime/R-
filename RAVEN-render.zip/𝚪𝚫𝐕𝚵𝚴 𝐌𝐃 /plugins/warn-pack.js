'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const fs   = require('fs');
const path = require('path');

// ══════════════════════════════════════════════════════════════════
// ─── FORWARD NEWSLETTER CONTEXT ───────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── STORE (auto-created) ─────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const DATA_DIR   = path.join(__dirname, 'warn-data');
const STORE_PATH = path.join(DATA_DIR, 'store.json');

const DEFAULT_STORE = {
    groups: {
        // "<groupJid>": {
        //   maxWarnings: 3,
        //   warnings: {
        //     "<userJid>": [{ reason, by, time }]
        //   }
        // }
    },
};

let _store = null;
let _saveTimer = null;

function ensureDir() {
    try { if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true }); }
    catch (e) { console.error('[WARN] mkdir failed:', e?.message); }
}

function loadStore() {
    ensureDir();
    try {
        if (fs.existsSync(STORE_PATH)) {
            const raw = fs.readFileSync(STORE_PATH, 'utf8').trim();
            if (raw) {
                const parsed = JSON.parse(raw);
                _store = { groups: { ...(parsed.groups || {}) } };
                return _store;
            }
        }
    } catch (e) {
        console.error('[WARN] corrupted, rebuilding:', e?.message);
        try {
            const backup = STORE_PATH + '.corrupted.' + Date.now() + '.bak';
            if (fs.existsSync(STORE_PATH)) fs.copyFileSync(STORE_PATH, backup);
        } catch {}
    }
    _store = JSON.parse(JSON.stringify(DEFAULT_STORE));
    writeStoreSync();
    return _store;
}

function writeStoreSync() {
    try {
        ensureDir();
        const tmp = STORE_PATH + '.tmp';
        fs.writeFileSync(tmp, JSON.stringify(_store, null, 2), 'utf8');
        fs.renameSync(tmp, STORE_PATH);
    } catch (e) { console.error('[WARN] write failed:', e?.message); }
}

function scheduleSave() {
    if (_saveTimer) clearTimeout(_saveTimer);
    _saveTimer = setTimeout(() => { _saveTimer = null; writeStoreSync(); }, 500);
    if (_saveTimer.unref) _saveTimer.unref();
}

function getGroupData(chatId) {
    if (!_store) loadStore();
    if (!_store.groups[chatId]) {
        _store.groups[chatId] = { maxWarnings: 3, warnings: {} };
        scheduleSave();
    }
    return _store.groups[chatId];
}

loadStore();
process.on('exit', () => { try { writeStoreSync(); } catch {} });
process.on('SIGINT', () => { try { writeStoreSync(); } catch {} process.exit(0); });

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function numOf(jid) {
    if (!jid) return '';
    return String(jid).split(':')[0].split('@')[0].replace(/[^0-9]/g, '');
}

function getParticipantJid(p) {
    if (!p) return '';
    if (p.jid && !p.jid.endsWith('@lid')) return p.jid;
    if (p.phoneNumber && !p.phoneNumber.endsWith('@lid')) return p.phoneNumber;
    if (p.id && !p.id.endsWith('@lid')) return p.id;
    const raw = p.id || p.jid || p.lid || '';
    return raw.endsWith('@lid') ? raw.replace('@lid', '@s.whatsapp.net') : raw;
}

function getMentions(m) {
    const ctx =
        m?.message?.extendedTextMessage?.contextInfo ||
        m?.message?.imageMessage?.contextInfo ||
        m?.message?.videoMessage?.contextInfo ||
        null;
    return ctx?.mentionedJid || [];
}

function resolveTarget(m) {
    if (m?.quoted?.sender) return m.quoted.sender;
    const mentions = getMentions(m);
    if (mentions.length > 0) return mentions[0];
    return null;
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch { /* ignore */ }
}

function formatDate(ts) {
    try {
        return new Date(ts).toLocaleDateString('en-GB'); // DD/MM/YYYY
    } catch {
        return '-';
    }
}

// ══════════════════════════════════════════════════════════════════
// ─── COMMAND: warn ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function cmdWarn(sock, m, args, context) {
    const { chatId, reply, sender, groupMetadata, prefix } = context;
    const groupData = getGroupData(chatId);
    const maxWarns  = groupData.maxWarnings || 3;
    const warnings  = groupData.warnings || {};

    // ── Help / no target ──────────────────────────────────────
    const sub = (args[0] || '').toLowerCase();
    const hasTarget = m.quoted || getMentions(m).length > 0;

    if (!hasTarget && sub !== 'max') {
        return reply(
            `⚠️ *GROUP WARNING SYSTEM*\n\n` +
            `Violation management system for group members.\n` +
            `Warning limit: *${maxWarns}* (auto-kick)\n\n` +
            `*USAGE:*\n` +
            `• \`${prefix}warn @user <reason>\` — give a warning\n` +
            `• \`${prefix}warn max <number>\` — change warning limit\n` +
            `• \`${prefix}listwarn\` — list warned members\n` +
            `• \`${prefix}resetwarn @user\` — clear a user's warnings\n\n` +
            `*HOW IT WORKS:*\n` +
            `1. First violation: \`${prefix}warn @user Spam\`\n` +
            `2. Bot records "Spam" as warning #1\n` +
            `3. Second violation: \`${prefix}warn @user Toxic language\`\n` +
            `4. When warnings reach *${maxWarns}*, bot auto-kicks the member.\n` +
            `5. Full history: \`${prefix}listwarn @user\``,
        );
    }

    // ── Set max warnings ──────────────────────────────────────
    if (sub === 'max') {
        const newMax = parseInt(args[1], 10);
        if (isNaN(newMax) || newMax < 1 || newMax > 20) {
            return reply(`❌ *FAILED*\n\nLimit must be a number between 1 and 20.\nExample: \`${prefix}warn max 5\``);
        }
        groupData.maxWarnings = newMax;
        scheduleSave();
        return reply(`✅ *WARNING LIMIT UPDATED*\n\nMax warnings for this group is now *${newMax}*.`);
    }

    // ── Resolve target ────────────────────────────────────────
    const targetUser = resolveTarget(m);
    if (!targetUser) {
        return reply(
            `⚠️ *USAGE*\n\n` +
            `> Reply to a message + \`${prefix}warn reason\`\n` +
            `> Or: \`${prefix}warn @user reason\``,
        );
    }

    // ── Refuse to warn admins ─────────────────────────────────
    try {
        const targetNum = numOf(targetUser);
        const participant = (groupMetadata?.participants || []).find(
            p => numOf(getParticipantJid(p)) === targetNum,
        );
        if (participant?.admin) {
            return reply(`❌ Cannot warn a group admin.`);
        }
    } catch {}

    // ── Refuse to warn the bot ────────────────────────────────
    const botJid = (sock.user?.id || '').split(':')[0] + '@s.whatsapp.net';
    if (numOf(targetUser) === numOf(botJid)) {
        return reply(`❌ Do not warn me, I'm just a bot.`);
    }

    // ── Extract reason ────────────────────────────────────────
    let reason = '';
    if (m.quoted) {
        // Reason is the raw text (minus the command word)
        const raw = (args.join(' ') || '').trim();
        reason = raw.replace(/^\s*(warn|warning|strike)\s*/i, '').trim();
    } else {
        // Mention case: strip @user from text
        const raw = (args.join(' ') || '').trim();
        reason = raw.replace(/@\d+/g, '').replace(/^\s*(warn|warning|strike)\s*/i, '').trim();
    }
    if (!reason) reason = 'No reason provided';

    // ── Apply warning ─────────────────────────────────────────
    const userWarnings = warnings[targetUser] || [];
    userWarnings.push({ reason, by: sender, time: Date.now() });
    warnings[targetUser] = userWarnings;
    groupData.warnings = warnings;
    scheduleSave();

    const warnCount  = userWarnings.length;
    const targetName = numOf(targetUser);

    // ── Auto-kick if reached max ──────────────────────────────
    if (warnCount >= maxWarns) {
        try {
            await sock.groupParticipantsUpdate(chatId, [targetUser], 'remove');
            await react(sock, chatId, m.key, '🚨');

            await sendMessageWithChannel(sock, chatId, {
                text:
                    `🚨 *MAX WARNINGS REACHED*\n\n` +
                    `@${targetName} was kicked for reaching the warning limit!\n\n` +
                    `*Details:*\n` +
                    `> Warnings: *${warnCount}/${maxWarns}*\n` +
                    `> Last reason: *${reason}*`,
                mentions: [targetUser],
            });

            delete warnings[targetUser];
            groupData.warnings = warnings;
            scheduleSave();
        } catch (e) {
            console.error('[WARN:kick]', e?.message);
            return reply(global.mess?.error?.fitur || 'Could not kick the member (bot admin?).');
        }
        return;
    }

    // ── Normal warning ────────────────────────────────────────
    await react(sock, chatId, m.key, '⚠️');
    await sendMessageWithChannel(sock, chatId, {
        text:
            `⚠️ *WARNING GIVEN*\n\n` +
            `@${targetName} received strike SP${warnCount}!\n\n` +
            `*Details:*\n` +
            `> Warning: *${warnCount}/${maxWarns}*\n` +
            `> Reason: *${reason}*\n\n` +
            `_${maxWarns - warnCount} more warning(s) = AUTO KICK_`,
        mentions: [targetUser],
    });
}

// ══════════════════════════════════════════════════════════════════
// ─── COMMAND: listwarn ────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function cmdListWarn(sock, m, args, context) {
    const { chatId, reply, prefix } = context;
    const groupData = getGroupData(chatId);
    const maxWarns  = groupData.maxWarnings || 3;
    const warnings  = groupData.warnings || {};

    const targetUser = resolveTarget(m);

    // ── Show one user ─────────────────────────────────────────
    if (targetUser) {
        const userWarnings = warnings[targetUser] || [];
        const targetName   = numOf(targetUser);

        if (userWarnings.length === 0) {
            return reply(`✅ @${targetName} has no warnings.`);
        }

        let txt = `⚠️ *WARNINGS @${targetName}*\n\n`;
        txt += `> Total: *${userWarnings.length}/${maxWarns}*\n\n`;

        userWarnings.forEach((w, i) => {
            const date = formatDate(w.time);
            txt += `*${i + 1}.* ${w.reason}\n`;
            txt += `   └ _${date}_\n`;
        });

        return sendMessageWithChannel(sock, chatId, {
            text: txt,
            mentions: [targetUser],
        });
    }

    // ── Show all users ────────────────────────────────────────
    const usersWithWarnings = Object.keys(warnings).filter(u => warnings[u]?.length > 0);

    if (usersWithWarnings.length === 0) {
        return reply(`✅ No members with warnings in this group.`);
    }

    let txt = `⚠️ *WARNINGS LIST*\n\n`;
    usersWithWarnings.forEach((user, i) => {
        const count = warnings[user].length;
        const name  = numOf(user);
        txt += `*${i + 1}.* @${name} — *${count}/${maxWarns}* warning(s)\n`;
    });
    txt += `\n> Type \`${prefix}listwarn @user\` for details`;

    return sendMessageWithChannel(sock, chatId, {
        text: txt,
        mentions: usersWithWarnings,
    });
}

// ══════════════════════════════════════════════════════════════════
// ─── COMMAND: resetwarn ───────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function cmdResetWarn(sock, m, args, context) {
    const { chatId, reply, prefix } = context;
    const groupData = getGroupData(chatId);
    const maxWarns  = groupData.maxWarnings || 3;
    const warnings  = groupData.warnings || {};

    const targetUser = resolveTarget(m);

    if (!targetUser) {
        return reply(
            `⚠️ *USAGE*\n\n` +
            `> Reply to a message + \`${prefix}resetwarn\`\n` +
            `> Or: \`${prefix}resetwarn @user\``,
        );
    }

    const targetName = numOf(targetUser);

    if (!warnings[targetUser] || warnings[targetUser].length === 0) {
        return sendMessageWithChannel(sock, chatId, {
            text: `✅ @${targetName} has no warnings.`,
            mentions: [targetUser],
        });
    }

    const prevCount = warnings[targetUser].length;
    delete warnings[targetUser];
    groupData.warnings = warnings;
    scheduleSave();

    await react(sock, chatId, m.key, '✅');
    return sendMessageWithChannel(sock, chatId, {
        text:
            `✅ *WARNINGS RESET*\n` +
            `Warnings for @${targetName} cleared!\n` +
            `Before: *${prevCount}/${maxWarns}*\n` +
            `Now: *0/${maxWarns}*`,
        mentions: [targetUser],
    });
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'warn',
    aliases:     [
        'warning', 'strike',                                  // warn
        'listwarn', 'warnings', 'checkwarn', 'warnlist',       // listwarn
        'resetwarn', 'clearwarn', 'delwarn',                   // resetwarn
    ],
    category:    'group',
    description: 'Group warning system (SP1, SP2, SP3) with auto-kick',
    usage:       '.warn @user <reason> | .listwarn | .resetwarn @user',

    async handler(sock, m, args, context) {
        const { chatId, reply, isGroup, isOwner, isAdmin, isBotAdmin, groupMetadata } = context;

        // ── Guards ────────────────────────────────────────────────
        if (!isGroup) {
            return reply(global.mess?.only?.group || 'This command only works in groups.');
        }
        if (!isAdmin && !isOwner) {
            return reply(global.mess?.only?.admin || 'Admin only.');
        }

        const cmd = (context.command || 'warn').toLowerCase();

        const LIST_WARN_CMDS  = ['listwarn', 'warnings', 'checkwarn', 'warnlist'];
        const RESET_WARN_CMDS = ['resetwarn', 'clearwarn', 'delwarn'];
        const WARN_CMDS       = ['warn', 'warning', 'strike'];

        try {
            if (LIST_WARN_CMDS.includes(cmd)) {
                return cmdListWarn(sock, m, args, context);
            }
            if (RESET_WARN_CMDS.includes(cmd)) {
                return cmdResetWarn(sock, m, args, context);
            }
            if (WARN_CMDS.includes(cmd)) {
                // warn doesn't need bot to be admin (only auto-kick does, handled internally)
                return cmdWarn(sock, m, args, context);
            }

            return reply(`❌ Unknown warn command: \`${cmd}\``);
        } catch (err) {
            console.error(`[WARN-PACK:${cmd}]`, err?.message || err);
            await react(sock, chatId, m.key, '❌');
            return reply(global.mess?.error?.fitur || 'Warn error. Please try again.');
        }
    },
};