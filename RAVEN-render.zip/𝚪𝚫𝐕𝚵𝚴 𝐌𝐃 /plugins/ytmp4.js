'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const axios   = require('axios');
const scraper = require('../lib/ytdl.js');

// ══════════════════════════════════════════════════════════════════
// ─── FORWARD NEWSLETTER CONTEXT ───────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {}
}

function isYouTubeUrl(url) {
    return /youtube\.com|youtu\.be/i.test(String(url || ''));
}

// ══════════════════════════════════════════════════════════════════
// ─── DOWNLOADER — Izuka API + local scraper ───────────────────────
// ══════════════════════════════════════════════════════════════════
async function getVideoDownloadUrl(url) {
    // ── 1. Primary: Izuka API ─────────────────────────────────
    try {
        const { data } = await axios.get(
            `https://my.izuka-api.xyz/api/downloader/ytmp4?url=${encodeURIComponent(url)}`,
            { timeout: 30000 },
        );

        if (data?.status && data?.result?.video_normal) {
            const videos = data.result.video_normal.filter(v => v.ext === 'mp4');
            if (videos.length > 0) {
                videos.sort((a, b) => parseInt(b.quality) - parseInt(a.quality));
                if (videos[0]?.url) return videos[0].url;
            }
        }
    } catch (e) {
        console.error('[YTMP4] Izuka API error:', e.message);
    }

    // ── 2. Fallback: local ytdl scraper (ytmp3.mobi) ──────────
    try {
        const fallback = await scraper.ytdl(url, 'mp4');
        if (fallback?.status && fallback?.dl) return fallback.dl;
    } catch (e) {
        console.error('[YTMP4] local ytdl fallback error:', e.message);
    }

    throw new Error('Could not retrieve YouTube video URL.');
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'ytmp4',
    aliases:     ['ytvideo', 'ytv'],
    category:    'download',
    description: 'Download a YouTube video in MP4',
    usage:       '.ytmp4 <url>',

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix } = context;

        const url = (args.join(' ') || '').trim();

        if (!url) {
            return reply(
                `⚠️ *USAGE*\n\n` +
                `> \`${prefix}ytmp4 <youtube_url>\`\n\n` +
                `> Example: \`${prefix}ytmp4 https://youtube.com/watch?v=xxx\``,
            );
        }

        if (!isYouTubeUrl(url)) {
            return reply(`❌ URL must be a YouTube link.`);
        }

        await react(sock, chatId, m.key, '🕕');

        try {
            const downloadUrl = await getVideoDownloadUrl(url);

            await sendMessageWithChannel(sock, chatId, {
                video:    { url: downloadUrl },
                mimetype: 'video/mp4',
            }, { quoted: m });

            await react(sock, chatId, m.key, '✅');
        } catch (err) {
            console.error('[YTMP4]', err?.message || err);
            await react(sock, chatId, m.key, '❌');
            return reply(`❌ Failed to download video.`);
        }
    },
};