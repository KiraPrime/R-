/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: 'clear',
    aliases: ['clr', 'clean'],
    category: 'owner',
    description: 'Clear bot messages from chat',
    usage: '.clear',
    ownerOnly: true,
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        try {
            const sent = await sendMessageWithChannel(sock, chatId, {
                text: 'Clearing bot messages...',
                ...channelInfo
            });
            await new Promise(resolve => setTimeout(resolve, 1000));
            await sendMessageWithChannel(sock, chatId, { delete: sent.key });
        }
        catch (error) {
            console.error('Error clearing messages:', error);
            await sendMessageWithChannel(sock, chatId, {
                text: 'An error occurred while clearing messages.',
                ...channelInfo
            }, { quoted: message });
        }
    }
};
