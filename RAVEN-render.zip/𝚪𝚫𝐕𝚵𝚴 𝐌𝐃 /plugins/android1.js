/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const pkg = require('api-qasim');
const QasimAny = pkg;
const axios = require('axios');
module.exports = {
    command: 'apkdl',
    aliases: ['apk', 'an1apk', 'appdl', 'app'],
    category: 'download',
    description: 'Search APKs and download by reply',
    usage: '.apkdl <apk_name>',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const query = args.join(' ').trim();
        try {
            if (!query) {
                return await sendMessageWithChannel(sock, chatId, { text: '*Please provide an APK name.*\nExample: .apkdl Telegram' }, { quoted: message });
            }
            await sendMessageWithChannel(sock, chatId, { text: '🔎 Searching for APKs...' }, { quoted: message });
            const res = await QasimAny.apksearch(query);
            if (!res?.data || !Array.isArray(res.data) || res.data.length === 0) {
                return await sendMessageWithChannel(sock, chatId, { text: '❌ No APKs found.' }, { quoted: message });
            }
            const results = res.data;
            const first = results[0];
            let caption = `📱 *APK Search Results for:* *${query}*\n\n`;
            caption += `↩️ *Reply with a number to download*\n\n`;
            results.forEach((item, i) => {
                caption +=
                    `*${i + 1}.* ${item.judul}\n` +
                        `👨‍💻 Developer: ${item.dev}\n` +
                        `⭐ Rating: ${item.rating}\n` +
                        `🔗 ${item.link}\n\n`;
            });
            const sentMsg = await sendMessageWithChannel(sock, chatId, { image: { url: first.thumb }, caption }, { quoted: message });
            const timeout = setTimeout(async () => {
                sock.ev.off('messages.upsert', listener);
                await sendMessageWithChannel(sock, chatId, { text: '⏱ APK selection expired. Please search again.' }, { quoted: sentMsg });
            }, 5 * 60 * 1000);
            const listener = async ({ messages }) => {
                const m = messages[0];
                if (!m?.message || m.key.remoteJid !== chatId)
                    return;
                const ctx = m.message?.extendedTextMessage?.contextInfo;
                if (!ctx?.stanzaId || ctx.stanzaId !== sentMsg.key.id)
                    return;
                const replyText = m.message.conversation ||
                    m.message.extendedTextMessage?.text ||
                    '';
                const choice = parseInt(replyText.trim(), 10);
                if (isNaN(choice) || choice < 1 || choice > results.length) {
                    return await sendMessageWithChannel(sock, chatId, { text: `❌ Invalid choice. Pick 1-${results.length}.` }, { quoted: m });
                }
                clearTimeout(timeout);
                sock.ev.off('messages.upsert', listener);
                const selected = results[choice - 1];
                await sendMessageWithChannel(sock, chatId, { text: `⬇️ Downloading *${selected.judul}*...\n⏱ Please wait...` }, { quoted: m });
                const apiUrl = `https://discardapi.dpdns.org/api/apk/dl/android1?apikey=guru&url=${ 
                    encodeURIComponent(selected.link)}`;
                const dlRes = await axios.get(apiUrl);
                const apk = dlRes.data?.result;
                if (!apk?.url) {
                    return await sendMessageWithChannel(sock, chatId, { text: '❌ Failed to get APK download link.' }, { quoted: m });
                }
                const safeName = apk.name.replace(/[^\w.-]/g, '_');
                const apkCaption = `📦 *APK Downloaded*\n\n` +
                    `📛 Name: ${apk.name}\n` +
                    `⭐ Rating: ${apk.rating}\n` +
                    `📦 Size: ${apk.size}\n` +
                    `📱 Android: ${apk.requirement}\n` +
                    `🧒 Age: ${apk.rated}\n` +
                    `📅 Published: ${apk.published}\n\n` +
                    `📝 Description:\n${apk.description}`;
                await sendMessageWithChannel(sock, chatId, { document: { url: apk.url }, fileName: `${safeName}.apk`, mimetype: 'application/vnd.android.package-archive', caption: apkCaption }, { quoted: m });
            };
            sock.ev.on('messages.upsert', listener);
        }
        catch (err) {
            console.error('❌ Android Plugin Error:', err);
            await sendMessageWithChannel(sock, chatId, { text: '❌ Failed to process APK request.' }, { quoted: message });
        }
    }
};
