/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
module.exports = {
    command: 'viewonce',
    aliases: ['viewmedia', 'vv'],
    category: 'general',
    description: 'Re-send a view-once image or video.',
    usage: '.viewonce (reply to a view-once media)',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            const quotedImage = quoted?.imageMessage;
            const quotedVideo = quoted?.videoMessage;
            if (quotedImage && quotedImage.viewOnce) {
                const stream = await downloadContentFromMessage(quotedImage, 'image');
                let buffer = Buffer.from([]);
                for await (const chunk of stream)
                    buffer = Buffer.concat([buffer, chunk]);
                await sendMessageWithChannel(sock, chatId, {
                    image: buffer,
                    fileName: 'media.jpg',
                    caption: quotedImage.caption || ''
                }, { quoted: message });
            }
            else if (quotedVideo && quotedVideo.viewOnce) {
                const stream = await downloadContentFromMessage(quotedVideo, 'video');
                let buffer = Buffer.from([]);
                for await (const chunk of stream)
                    buffer = Buffer.concat([buffer, chunk]);
                await sendMessageWithChannel(sock, chatId, {
                    video: buffer,
                    fileName: 'media.mp4',
                    caption: quotedVideo.caption || ''
                }, { quoted: message });
            }
            else {
                await sendMessageWithChannel(sock, chatId, {
                    text: '*Please reply to a view-once image or video.*'
                }, { quoted: message });
            }
        }
        catch (error) {
            console.error('Error in viewonceCommand:', error);
            await sendMessageWithChannel(sock, chatId, {
                text: '❌ Failed to retrieve the view-once media. Please try again later.'
            }, { quoted: message });
        }
    }
};
