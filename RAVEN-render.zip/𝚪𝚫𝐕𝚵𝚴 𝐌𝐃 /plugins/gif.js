/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require('axios');
module.exports = {
    command: 'gif',
    aliases: ['giphy', 'searchgif'],
    category: 'stickers',
    description: 'Get a GIF based on a search term',
    usage: '.gif <search term>',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const config = context.config;
        const query = args.join(' ');
        if (!query) {
            await sendMessageWithChannel(sock, chatId, { text: 'Please provide a search term for the GIF.' }, { quoted: message });
            return;
        }
        try {
            const response = await axios.get('https://api.giphy.com/v1/gifs/search', {
                params: {
                    api_key: config.giphyApiKey,
                    q: query,
                    limit: 1,
                    rating: 'g'
                }
            });
            const gifData = response.data.data[0];
            if (!gifData) {
                await sendMessageWithChannel(sock, chatId, { text: 'No GIFs found for your search term.' }, { quoted: message });
                return;
            }
            const mp4Url = gifData.images.original_mp4?.mp4;
            if (mp4Url) {
                await sendMessageWithChannel(sock, chatId, { video: { url: mp4Url }, caption: `Here is your GIF for "${query}"` }, { quoted: message });
            }
            else {
                const gifUrl = gifData.images.original?.url;
                await sendMessageWithChannel(sock, chatId, { document: { url: gifUrl }, mimetype: 'image/gif', caption: `Here is your GIF for "${query}"` }, { quoted: message });
            }
        }
        catch (error) {
            console.error('Error in gif command:', error);
            await sendMessageWithChannel(sock, chatId, { text: '❌ Failed to fetch GIF. Please try again later.' }, { quoted: message });
        }
    }
};
