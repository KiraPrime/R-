'use strict';

/*
  PANEL — Unified Pterodactyl manager for Raven MD
  Original dev: Kira Dev
  Channel: https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
*/

const fs     = require('fs');
const path   = require('path');
const crypto = require('crypto');
const axios  = require('axios');
const { Client } = require('ssh2');

// ─── Session config ──────────────────────────────────────────────
let sessionLib = null;
try { sessionLib = require('../lib/session-config'); }
catch (e) { console.warn('[PANEL] session-config.js not found:', e?.message); }

const {
    getSessionConfig         = () => ({ pterodactyl: {}, serverInfo: {} }),
    claimSession             = () => ({ ok: false, reason: 'lib missing' }),
    updateSession            = () => { throw new Error('session-config missing'); },
    resetSessionConfig       = () => {},
    isSessionOwner           = () => false,
    normalizeJid             = (j) => String(j || '').split('@')[0],
} = sessionLib || {};

const getCurrentSessionConfig = sessionLib?.getCurrentSessionConfig || getSessionConfig;

// ─── Roles wrapper ───────────────────────────────────────────────
let rolesLib = null;
try { rolesLib = require('../lib/cpanel-roles-wrapper.js'); }
catch (e) { console.warn('[PANEL] cpanel-roles-wrapper.js not found:', e?.message); }

const {
    addRole              = () => ({ success: false, error: 'roles lib missing' }),
    removeRole           = () => ({ success: false, error: 'roles lib missing' }),
    listByRole           = () => [],
    canManageRole        = () => false,
    getUserRole          = () => null,
    hasAccessToServer    = () => false,
    hasFullAccess        = () => false,
    getAccessibleServers = () => [],
} = rolesLib || {};

// ─── Time helper ─────────────────────────────────────────────────
let timeHelper = null;
try { timeHelper = require('../lib/time.js'); } catch { timeHelper = null; }

// ─── Forward context ─────────────────────────────────────────────
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1,
    },
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: { ...(content.contextInfo || {}), ...forwardInfo },
    }, options);
}

// ─── Panel thumbnail ─────────────────────────────────────────────
const PANEL_THUMB = 'https://k.top4top.io/p_3937el98m0.jpg';
const PANEL_SITE  = 'https://t.me/kira4hub';

function buildFakeOrderQuoted() {
    return {
        key: { participant: '0@s.whatsapp.net' },
        message: {
            orderMessage: {
                itemCount:  99999999,
                surface:    99999999,
                message:    PANEL_SITE,
                orderTitle: '𝚪𝚫𝐕𝚵𝚴',
                sellerJid:  '0@s.whatsapp.net',
            },
        },
    };
}

async function sendWithPanelThumb(sock, jid, text, quotedMsg = null) {
    const ctx = {
        ...forwardInfo,
        externalAdReply: {
            title:                 '𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 • PANEL',
            body:                  'Powered by Raven 2.0',
            mediaType:             1,
            thumbnailUrl:          PANEL_THUMB,
            sourceUrl:             PANEL_SITE,
            renderLargerThumbnail: true,
            showAdAttribution:     false,
        },
    };
    try {
        return await sock.sendMessage(jid, { text, contextInfo: ctx }, { quoted: quotedMsg || buildFakeOrderQuoted() });
    } catch {
        try { return sock.sendMessage(jid, { text }, { quoted: quotedMsg || buildFakeOrderQuoted() }); }
        catch { return sock.sendMessage(jid, { text }); }
    }
}

// ─── Data dirs ───────────────────────────────────────────────────
const DATA_DIR    = path.join(__dirname, 'panel-data');
const JEDA_FILE   = path.join(DATA_DIR, 'panel-jeda.json');
const LEGACY_FILE = path.join(DATA_DIR, 'legacy_sellers.json');

function ensureDir() {
    try { if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true }); }
    catch (e) { console.error('[PANEL] mkdir failed:', e?.message); }
}
function loadJson(file, def) {
    ensureDir();
    try {
        if (fs.existsSync(file)) {
            const raw = fs.readFileSync(file, 'utf8').trim();
            if (raw) return JSON.parse(raw);
        }
    } catch {}
    return JSON.parse(JSON.stringify(def));
}
function saveJson(file, data) {
    try {
        ensureDir();
        const tmp = file + '.tmp';
        fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8');
        fs.renameSync(tmp, file);
        return true;
    } catch (e) { console.error('[PANEL] save failed:', e?.message); return false; }
}

function getLegacy() { return loadJson(LEGACY_FILE, { sellers: [], ownerPanels: [] }); }
function saveLegacy(d) { return saveJson(LEGACY_FILE, d); }

// ─── RAM specs ───────────────────────────────────────────────────
const RAM_SPECS = {
    '1':  { ram: 1024,  cpu: 70,  disk: 1024  },
    '2':  { ram: 2048,  cpu: 80,  disk: 2048  },
    '3':  { ram: 3072,  cpu: 90,  disk: 2048  },
    '4':  { ram: 4096,  cpu: 100, disk: 4096  },
    '5':  { ram: 5120,  cpu: 110, disk: 5120  },
    '6':  { ram: 6144,  cpu: 120, disk: 6144  },
    '7':  { ram: 7168,  cpu: 130, disk: 7168  },
    '8':  { ram: 8192,  cpu: 140, disk: 8192  },
    '9':  { ram: 9216,  cpu: 150, disk: 9216  },
    '10': { ram: 10240, cpu: 160, disk: 10240 },
    'unli': { ram: 0,   cpu: 0,   disk: 0     },
};

// ─── Helpers ─────────────────────────────────────────────────────
function cleanNumber(jid) {
    if (!jid) return null;
    return String(jid).split(':')[0].split('@')[0].replace(/[^0-9]/g, '') || null;
}
function cleanJid(jid) {
    if (!jid) return null;
    let j = String(jid);
    if (j.endsWith('@lid')) j = j.replace('@lid', '@s.whatsapp.net');
    return j.includes('@') ? j : j + '@s.whatsapp.net';
}
function capitalize(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1).toLowerCase() : ''; }
function fmtBytes(mb) {
    const n = Number(mb);
    if (!n || Number.isNaN(n)) return 'Unlimited';
    if (n >= 1000) return `${(n / 1000).toFixed(1)} GB`;
    return `${n} MB`;
}
function parseCmd(cmd) {
    const m = String(cmd || '').toLowerCase().match(/^(\d+|unli)(js|py)?$/);
    if (!m) return null;
    return { ram: m[1], lang: (m[2] || 'js') === 'py' ? 'python' : 'node' };
}
function resolveTarget(m, rawArg) {
    if (m?.quoted?.sender) return cleanJid(m.quoted.sender);
    const ctx = m?.message?.extendedTextMessage?.contextInfo || m?.message?.imageMessage?.contextInfo || null;
    const mentions = ctx?.mentionedJid || [];
    if (mentions.length) return cleanJid(mentions[0]);
    if (rawArg) {
        const num = String(rawArg).replace(/[^0-9]/g, '');
        if (num.length >= 8) return num + '@s.whatsapp.net';
    }
    return null;
}

// ─── SSH helpers ─────────────────────────────────────────────────
function execSSH(conn, cmd) {
    return new Promise((res, rej) => {
        conn.exec(cmd, { pty: true }, (err, stream) => {
            if (err) return rej(err);
            let out = '';
            stream.on('close', code => (code === 0 || code === null) ? res(out) : rej(new Error(`exit ${code}`)));
            stream.on('data', d => out += d.toString());
            stream.stderr.on('data', d => out += d.toString());
        });
    });
}
function execSSHInteractive(conn, cmd, inputs) {
    return new Promise((res, rej) => {
        conn.exec(cmd, { pty: true }, (err, stream) => {
            if (err) return rej(err);
            let buf = '', step = 0;
            stream.on('close', () => res(buf));
            stream.on('data', d => {
                buf += d.toString();
                const n = inputs[step];
                if (n && buf.includes(n.trigger)) {
                    stream.write(n.value + '\n');
                    step++; buf = '';
                }
            });
            stream.stderr.on('data', d => buf += d.toString());
        });
    });
}

async function runThemeInstall(sock, chatId, msgKey, context, opts) {
    const { title, steps, themeName } = opts;
    const { prefix, reply, command, args } = context;
    const text = (args.join(' ') || '').trim();

    if (!text) {
        return reply(
            `╭┈┈⬡「 🎨 *INSTALL ${title.toUpperCase()}* 」\n` +
            `┃ Usage: \`${prefix}${command} <ip>|<password>\`\n` +
            `╰┈┈⬡\n\n` +
            `> \`Example: ${prefix}${command} 192.168.1.1|secretpass\``
        );
    }

    const parts  = text.split('|');
    if (parts.length < 2) return reply(`❌ Wrong format! Use: \`ip|password\``);

    const ipvps  = parts[0].trim();
    const passwd = parts[1].trim();
    const extra  = parts.slice(2);

    const conn = new Client();
    await reply('🕕 Connecting...').catch(() => {});

    return new Promise((resolve) => {
        conn.on('ready', async () => {
            try {
                for (let i = 0; i < steps.length; i++) {
                    const step = steps[i];
                    await reply(`🕕 *[${i + 1}/${steps.length}] ${step.title}...*\n\n> ${step.desc}`);
                    if (step.interactive) {
                        const inputs = step.getInputs ? step.getInputs(extra) : [];
                        await execSSHInteractive(conn, step.cmd, inputs);
                    } else {
                        await execSSH(conn, step.cmd);
                    }
                }
                await reply(
                    `╭┈┈⬡「 ✅ *${title.toUpperCase()}* 」\n` +
                    `┃ Status: *Installed*\n` +
                    `┃ IP: ${ipvps}\n` +
                    `╰┈┈⬡\n\n` +
                    `> _${themeName} installed successfully!_`
                );
            } catch (err) {
                console.error(`[PANEL:${command}]`, err?.message);
                await reply('❌ Install error.');
            } finally {
                try { conn.end(); } catch {}
                resolve();
            }
        });
        conn.on('error', async (err) => {
            console.error('[PANEL SSH]', err?.message);
            await reply(`❌ *CONNECTION FAILED*\n\n> Invalid IP or password.`);
            resolve();
        });
        conn.connect({ host: ipvps, port: 22, username: 'root', password: passwd, readyTimeout: 30000 });
    });
}

const THEME_STEPS = {
    stellar: [
        { title: '1/3 Install dependencies', desc: 'Installing Node.js, Yarn, Composer...',
          cmd: 'apt-get update -y && apt-get install -y curl git && curl -fsSL https://deb.nodesource.com/setup_18.x | bash - && apt-get install -y nodejs && npm i -g yarn && apt-get install -y composer' },
        { title: '2/3 Install theme', desc: 'Downloading & installing Stellar theme...',
          cmd: 'bash <(curl -s https://raw.githubusercontent.com/AnonGhostID/flavor/main/flavor.sh)' },
        { title: '3/3 Build assets', desc: 'Compiling panel assets...',
          cmd: 'cd /var/www/pterodactyl && composer install --no-dev --optimize-autoloader && yarn install && export NODE_OPTIONS=--openssl-legacy-provider && yarn build:production && php artisan view:clear && php artisan config:clear' },
    ],
    nebula: [
        { title: '1/3 Prepare environment', desc: 'Installing Node.js 22, Yarn...',
          cmd: `apt-get update -qq && apt-get install -y curl wget unzip git zip gnupg ca-certificates -qq && mkdir -p /etc/apt/keyrings && curl -fsSL https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key | gpg --dearmor -yes -o /etc/apt/keyrings/nodesource.gpg && echo "deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_22.x nodistro main" | tee /etc/apt/sources.list.d/nodesource.list && apt-get update -qq && apt-get install -y nodejs -qq && npm i -g yarn && cd /var/www/pterodactyl && yarn install` },
        { title: '2/3 Install Blueprint', desc: 'Downloading & configuring Blueprint...',
          cmd: `cd /var/www/pterodactyl && wget "$(curl -s https://api.github.com/repos/BlueprintFramework/framework/releases/latest | grep 'browser_download_url' | grep 'release.zip' | cut -d '"' -f 4)" -O release.zip && unzip -o release.zip && rm release.zip && touch .blueprintrc && echo 'WEBUSER="www-data";\\nOWNERSHIP="www-data:www-data";\\nUSERSHELL="/bin/bash";' > .blueprintrc && chmod +x blueprint.sh && bash blueprint.sh` },
        { title: '3/3 Install Nebula', desc: 'Installing Nebula theme...',
          cmd: `cd /var/www/pterodactyl && wget -q -O nebula.blueprint "https://github.com/FikXzModzDeveloper/Nebula-Theme-pterodactyl/raw/main/nebula.blueprint" && (command -v blueprint &> /dev/null && printf "\\n\\n" | blueprint -install nebula || printf "\\n\\n" | bash blueprint.sh -install nebula)` },
    ],
    enigma: [
        { title: '1/3 Install dependencies', desc: 'Installing Node.js, Yarn, Composer...',
          cmd: 'apt-get update -y && apt-get install -y curl git && curl -fsSL https://deb.nodesource.com/setup_18.x | bash - && apt-get install -y nodejs && npm i -g yarn && apt-get install -y composer' },
        { title: '2/3 Install theme', desc: 'Installing Enigma theme (interactive)...',
          cmd: 'bash <(curl -s https://raw.githubusercontent.com/veryLinh/Theme-Autoinstaller/main/install.sh)',
          interactive: true,
          getInputs: (extra) => [
            { trigger: 'AKSES TOKEN',      value: 'skyzodev' },
            { trigger: 'Masukkan pilihan', value: '1' },
            { trigger: 'Masukkan pilihan', value: '3' },
            { trigger: 'WhatsApp',         value: extra[0] || '-' },
            { trigger: 'group',            value: extra[1] || '-' },
            { trigger: 'channel',          value: extra[2] || '-' },
          ] },
        { title: '3/3 Build assets', desc: 'Compiling panel assets...',
          cmd: 'cd /var/www/pterodactyl && composer install --no-dev --optimize-autoloader && yarn install && export NODE_OPTIONS=--openssl-legacy-provider && yarn build:production && php artisan view:clear && php artisan config:clear' },
    ],
    billing: [
        { title: '1/3 Install dependencies', desc: 'Installing Node.js, Yarn, Composer...',
          cmd: 'apt-get update -y && apt-get install -y curl git && curl -fsSL https://deb.nodesource.com/setup_18.x | bash - && apt-get install -y nodejs && npm i -g yarn && apt-get install -y composer' },
        { title: '2/3 Install theme', desc: 'Installing Billing theme (interactive)...',
          cmd: 'bash <(curl -s https://raw.githubusercontent.com/veryLinh/Theme-Autoinstaller/main/install.sh)',
          interactive: true,
          getInputs: () => [
            { trigger: 'AKSES TOKEN',      value: 'skyzodev' },
            { trigger: 'Masukkan pilihan', value: '1' },
            { trigger: 'Masukkan pilihan', value: '2' },
          ] },
        { title: '3/3 Build assets', desc: 'Compiling panel assets...',
          cmd: 'cd /var/www/pterodactyl && composer install --no-dev --optimize-autoloader && yarn install && export NODE_OPTIONS=--openssl-legacy-provider && yarn build:production && php artisan view:clear && php artisan config:clear' },
    ],
    untheme: [
        { title: '1/1 Uninstall theme', desc: 'Running theme uninstaller...',
          cmd: 'bash <(curl -s https://raw.githubusercontent.com/veryLinh/Theme-Autoinstaller/main/install.sh)',
          interactive: true,
          getInputs: () => [
            { value: 'skyzodev\n' },
            { value: '2\n' },
            { value: 'y\n' },
            { value: 'x\n' },
          ] },
    ],
};

// ══════════════════════════════════════════════════════════════════
// ─── SET / CONFIG / SESSION HELPERS (from .ces) ─────────────────
// ══════════════════════════════════════════════════════════════════

function mask(value) {
    const text = String(value || '');
    if (!text) return 'not set';
    if (text.length <= 8) return '••••••••';
    return `${text.slice(0, 4)}••••${text.slice(-4)}`;
}

function parseValue(key, raw) {
    if (['location', 'nodeegg', 'nodenestid', 'pyegg', 'pynestid'].includes(key)) {
        if (!/^\d+$/.test(raw)) throw new Error('This value must be numeric.');
        return raw;
    }
    if (key === 'sshport') {
        if (!/^\d+$/.test(raw)) throw new Error('The SSH port must be numeric.');
        return Number(raw);
    }
    return raw;
}

function buildPatch(key, raw) {
    const value = parseValue(key, raw);
    const p = {};
    if (['domain', 'apikey', 'capikey', 'location'].includes(key)) p[key] = value;
    else if (key === 'nodeegg')    p.eggs   = { node:   { egg: value } };
    else if (key === 'nodenestid') p.eggs   = { node:   { nestid: value } };
    else if (key === 'pyegg')      p.eggs   = { python: { egg: value } };
    else if (key === 'pynestid')   p.eggs   = { python: { nestid: value } };
    else if (key === 'nodocker')   p.docker = { node:   value };
    else if (key === 'pydocker')   p.docker = { python: value };
    else if (key === 'sshuser')    p.sshUser = value;
    else if (key === 'sshport')    p.sshPort = value;
    else throw new Error(`Unknown key: ${key}`);
    return p;
}

function buildStatusText(sessionId) {
    const cfg = getSessionConfig(sessionId);
    const p = cfg.pterodactyl || {};
    const servers = cfg.serverInfo?.pterodactyl || {};
    const configuredServers = Object.entries(servers)
        .filter(([, v]) => v?.domain && v?.apikey)
        .map(([k]) => k)
        .join(', ') || 'none';

    return `⚙️ *PTERODACTYL — SESSION*\n\n` +
        `👤 Owner  : @${normalizeJid(cfg.owner).split('@')[0] || 'not set'}\n` +
        `🌐 Domain : ${p.domain || 'not set'}\n` +
        `🔑 App key: ${mask(p.apikey)}\n` +
        `🔐 Client : ${mask(p.capikey)}\n` +
        `📍 Loc.   : ${p.location || 'not set'}\n` +
        `🥚 Node   : ${p.eggs?.node?.egg || 'not set'}\n` +
        `🐍 Py egg : ${p.eggs?.python?.egg || 'not set'}\n` +
        `🖥️ Servers: ${configuredServers}`;
}

function sessionUsage(prefix = '.') {
    return `⚙️ *PANEL SESSION CONFIG*\n\n` +
        `This session is independent from other sessions.\n\n` +
        `*First-time use:*\n> \`${prefix}claim\`\n\n` +
        `*Owner commands:*\n` +
        `> \`${prefix}set domain https://panel.example.com\`\n` +
        `> \`${prefix}set apikey PTLA...\`\n` +
        `> \`${prefix}set capikey PTLC...\`\n` +
        `> \`${prefix}set location 1\`\n` +
        `> \`${prefix}set nodeegg 15\`\n` +
        `> \`${prefix}set nodenestid 5\`\n` +
        `> \`${prefix}set pyegg 16\`\n` +
        `> \`${prefix}set pynestid 5\`\n` +
        `> \`${prefix}status\`\n` +
        `> \`${prefix}reset\`\n\n` +
        `API keys are never displayed in plain text.`;
}

// ══════════════════════════════════════════════════════════════════
// ─── COMMAND HANDLERS ────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════

// ─── Claim session (ex-.ces claim) ──────────────────────────────
async function cmdClaim(sock, m, args, context) {
    const { reply, prefix, sessionId, sender, isOwner, isGroup } = context;
    if (isGroup) return reply('❌ Use this in a private chat with this session.');

    const sessionOwner = isSessionOwner(sessionId, sender);
    const result = claimSession(sessionId, sender);

    if (!result.ok && result.reason === 'claimed' && !sessionOwner && !isOwner) {
        return reply('❌ This session already has an owner.');
    }
    if (result.ok && !sessionOwner) {
        return reply(`✅ You are now the owner of this bot session.\n\n${sessionUsage(prefix)}`);
    }
    return reply(`${buildStatusText(sessionId)}\n\n${sessionUsage(prefix)}`);
}

// ─── Session status ─────────────────────────────────────────────
async function cmdStatus(sock, m, args, context) {
    const { reply, sessionId } = context;
    return reply(buildStatusText(sessionId));
}

// ─── Set config key (ex-.ces set) ───────────────────────────────
async function cmdSet(sock, m, args, context) {
    const { reply, prefix, isOwner, sessionId, sender } = context;
    if (!isOwner && !isSessionOwner(sessionId, sender)) {
        return reply('❌ Only the owner of this session can use this command.');
    }

    const key = String(args[0] || '').toLowerCase();
    const raw = args.slice(1).join(' ').trim();

    const validKeys = ['domain', 'apikey', 'capikey', 'location', 'nodeegg', 'nodenestid', 'pyegg', 'pynestid', 'nodocker', 'pydocker', 'sshuser', 'sshport'];
    if (!key || !validKeys.includes(key)) return reply(sessionUsage(prefix));
    if (!raw) return reply(sessionUsage(prefix));

    try {
        const patch = buildPatch(key, raw);
        updateSession(sessionId, { pterodactyl: patch });
        return reply(`✅ *${key}* saved.\n\n${buildStatusText(sessionId)}`);
    } catch (e) {
        return reply(`❌ ${e.message}\n\n${sessionUsage(prefix)}`);
    }
}

// ─── Reset session ──────────────────────────────────────────────
async function cmdReset(sock, m, args, context) {
    const { reply, isOwner, sessionId, sender } = context;
    if (!isOwner && !isSessionOwner(sessionId, sender)) {
        return reply('❌ Only the owner of this session can reset.');
    }
    resetSessionConfig(sessionId);
    return reply('✅ Session config reset.');
}

// ─── Create server ──────────────────────────────────────────────
async function cmdCreate(sock, m, args, context) {
    const { reply, prefix, isOwner, sender, command, sessionId } = context;
    const parsed = parseCmd(command);
    if (!parsed) return reply('❌ Invalid command.');

    const { ram, lang } = parsed;
    if (!hasAccessToServer(sender, isOwner) && !isOwner) {
        return reply(`❌ *ACCESS DENIED*\n\n> Your role: *${getUserRole(sender) || 'none'}*`);
    }

    const cfg = getSessionConfig(sessionId).pterodactyl || {};
    if (!cfg.domain || !cfg.apikey) {
        return reply('⚠️ *Panel not configured.*\n\n> Use `.set domain <url>` and `.set apikey <key>` first.');
    }

    const argStr = (args.join(' ') || '').trim();
    let username = null, targetUser = null;
    if (argStr.includes(',')) {
        const p = argStr.split(',');
        username = (p[0] || '').trim().toLowerCase();
        const n = (p[1] || '').trim().replace(/[^0-9]/g, '');
        if (n) targetUser = n + '@s.whatsapp.net';
    } else if (argStr) username = argStr.trim().toLowerCase();

    if (!username) return reply(`⚠️ Usage: \`${prefix}${command} username\` or \`${prefix}${command} username,241xxxx\``);
    if (!/^[a-z0-9_]{3,16}$/.test(username)) return reply('❌ Username must be 3-16 chars a-z0-9_.');
    if (!targetUser) targetUser = resolveTarget(m, argStr) || cleanJid(sender);

    const specs = RAM_SPECS[ram];
    if (!specs) return reply('❌ Package not found.');

    const langLabel = lang === 'python' ? 'Python' : 'Node.js';
    const ramTxt    = specs.ram === 0 ? 'Unlimited' : `${specs.ram / 1024} GB`;

    await reply(`🕕 Creating ${langLabel} ${ramTxt} server for \`${targetUser.split('@')[0]}\`...`);

    try {
        const password = username + crypto.randomBytes(3).toString('hex');
        const email    = `${username}@raven.md`;
        const name     = capitalize(username) + ' Server';

        const uRes = await axios.post(`${cfg.domain}/api/application/users`, {
            email, username, first_name: name, last_name: 'Panel',
            language: 'en', password,
        }, {
            headers: { Authorization: `Bearer ${cfg.apikey}`, 'Content-Type': 'application/json', Accept: 'Application/vnd.pterodactyl.v1+json' },
            timeout: 30000,
        });
        const user = uRes.data.attributes;

        const eggs = cfg.eggs || {};
        const eggConfig = lang === 'python' ? eggs.python : eggs.node;
        if (!eggConfig?.egg || !eggConfig?.nestid) return reply(`⚠️ Egg for ${langLabel} not configured.`);

        const eggRes = await axios.get(
            `${cfg.domain}/api/application/nests/${eggConfig.nestid}/eggs/${eggConfig.egg}?include=variables`,
            { headers: { Authorization: `Bearer ${cfg.apikey}`, Accept: 'Application/vnd.pterodactyl.v1+json' }, timeout: 30000 }
        );
        const eggData = eggRes.data.attributes;
        const startup = eggData.startup;
        const variables = eggData?.relationships?.variables?.data || [];
        const environment = {};
        for (const v of variables) {
            const a = v.attributes || {};
            if (!a.env_variable) continue;
            let value = a.default_value ?? '';
            if (!value) {
                if (lang === 'python') {
                    if (a.env_variable === 'MAIN_FILE') value = 'main.py';
                    if (a.env_variable === 'CMD_RUN')   value = 'python main.py';
                    if (a.env_variable === 'INST')      value = 'pip';
                } else {
                    if (a.env_variable === 'MAIN_FILE') value = 'index.js';
                    if (a.env_variable === 'CMD_RUN')   value = 'npm start';
                    if (a.env_variable === 'INST')      value = 'npm';
                }
                if (a.env_variable === 'USER_UPLOAD' || a.env_variable === 'AUTO_UPDATE') value = '0';
            }
            environment[a.env_variable] = String(value);
        }

        const sRes = await axios.post(`${cfg.domain}/api/application/servers`, {
            name,
            description: `Created ${new Date().toISOString()} [${langLabel}]`,
            user: user.id,
            egg: parseInt(eggConfig.egg),
            docker_image: (cfg.docker?.[lang === 'python' ? 'python' : 'node']) || 'ghcr.io/parkervcp/yolks:nodejs_18',
            startup,
            environment,
            limits: { memory: specs.ram, swap: 0, disk: specs.disk, io: 500, cpu: specs.cpu },
            feature_limits: { databases: 5, backups: 5, allocations: 5 },
            deploy: { locations: [parseInt(cfg.location || 1)], dedicated_ip: false, port_range: [] },
        }, {
            headers: { Authorization: `Bearer ${cfg.apikey}`, 'Content-Type': 'application/json', Accept: 'Application/vnd.pterodactyl.v1+json' },
            timeout: 30000,
        });
        const server = sRes.data.attributes;

        let txt = `✅ *PANEL CREATED*\n\n`;
        txt += `🖥️ Type    : *${langLabel}*\n`;
        txt += `👤 User    : *${user.username}*\n`;
        txt += `🔐 Pass    : *${password}*\n`;
        txt += `💾 RAM     : *${ramTxt}*\n`;
        txt += `🆔 Server  : *${server.id}*\n`;
        txt += `🌐 Panel   : ${cfg.domain}\n\n`;
        txt += `⚠️ Save this info!`;

        await sendWithPanelThumb(sock, targetUser, txt);
        if (targetUser !== sender) return reply(`✅ ${langLabel} ${ramTxt} created for \`${targetUser.split('@')[0]}\``);
    } catch (err) {
        const rawMsg = err?.response?.data?.errors?.[0]?.detail || err?.response?.data?.message || err?.message || 'Unknown error';
        return reply(`❌ Failed: ${rawMsg}`);
    }
}

// ─── Create admin ───────────────────────────────────────────────
async function cmdCreateAdmin(sock, m, args, context) {
    const { reply, prefix, isOwner, sender, command, sessionId } = context;
    if (!hasFullAccess(sender, isOwner) && !isOwner) return reply('❌ Access denied.');

    const cfg = getSessionConfig(sessionId).pterodactyl || {};
    if (!cfg.domain || !cfg.apikey) return reply('⚠️ Panel not configured.');

    const argStr = (args.join(' ') || '').trim();
    let username = null, targetUser = null;
    if (argStr.includes(',')) {
        const p = argStr.split(',');
        username = (p[0] || '').trim().toLowerCase();
        const n = (p[1] || '').trim().replace(/[^0-9]/g, '');
        if (n) targetUser = n + '@s.whatsapp.net';
    } else if (argStr) username = argStr.trim().toLowerCase();

    if (!username) return reply(`⚠️ Usage: \`${prefix}${command} username\``);
    if (!/^[a-z0-9_]{3,16}$/.test(username)) return reply('❌ Invalid username.');
    if (!targetUser) targetUser = resolveTarget(m, argStr) || cleanJid(sender);

    const email    = `${username}@gmail.com`;
    const name     = capitalize(username) + ' Admin';
    const password = username + crypto.randomBytes(3).toString('hex');

    await reply('🛠️ Creating admin...');

    try {
        const uRes = await axios.post(`${cfg.domain}/api/application/users`, {
            email, username, first_name: name, last_name: 'Admin',
            root_admin: true, language: 'en', password,
        }, {
            headers: { Authorization: `Bearer ${cfg.apikey}`, 'Content-Type': 'application/json', Accept: 'Application/vnd.pterodactyl.v1+json' },
            timeout: 30000,
        });
        const user = uRes.data.attributes;

        let txt = `✅ *ADMIN CREATED*\n\n`;
        txt += `🆔 ID    : *${user.id}*\n`;
        txt += `👤 User  : *${user.username}*\n`;
        txt += `🔐 Pass  : *${password}*\n`;
        txt += `👑 Admin : *Root*\n`;
        txt += `🌐 Panel : ${cfg.domain}`;

        await sendWithPanelThumb(sock, targetUser, txt);
        if (targetUser !== sender) return reply('✅ Admin created.');
    } catch (err) {
        const msg = err?.response?.data?.errors?.[0]?.detail || err?.message;
        return reply(`❌ Failed: ${msg}`);
    }
}

// ─── List servers ───────────────────────────────────────────────
async function cmdListServers(sock, m, args, context) {
    const { reply, isOwner, sender, sessionId } = context;
    if (!hasFullAccess(sender, isOwner) && !isOwner) return reply('❌ Access denied.');

    const cfg = getSessionConfig(sessionId).pterodactyl || {};
    if (!cfg.domain || !cfg.apikey) return reply('⚠️ Panel not configured.');

    try {
        let all = [], page = 1, total = 1;
        while (page <= total) {
            const res = await axios.get(
                `${cfg.domain}/api/application/servers?page=${page}&per_page=50`,
                { headers: { Authorization: `Bearer ${cfg.apikey}`, Accept: 'Application/vnd.pterodactyl.v1+json' }, timeout: 30000 }
            );
            all = all.concat(res.data.data || []);
            const meta = res.data.meta?.pagination;
            if (meta) total = meta.total_pages || 1;
            page++;
        }
        if (!all.length) return reply('📋 No servers.');

        let txt = `📋 *SERVER LIST*\n\n> Total: *${all.length}*\n\n`;
        all.slice(0, 20).forEach(s => {
            const a = s.attributes;
            txt += `- *${a.name}*\n   ├ ID: \`${a.id}\`\n   ├ RAM: ${fmtBytes(a.limits?.memory)}\n   └ CPU: ${a.limits?.cpu === 0 ? 'Unlimited' : a.limits?.cpu + '%'}\n`;
        });
        if (all.length > 20) txt += `\n...and ${all.length - 20} more`;
        return reply(txt);
    } catch { return reply('❌ Failed.'); }
}

// ─── List users ─────────────────────────────────────────────────
async function cmdListUsers(sock, m, args, context) {
    const { reply, isOwner, sender, sessionId } = context;
    if (!hasFullAccess(sender, isOwner) && !isOwner) return reply('❌ Access denied.');

    const cfg = getSessionConfig(sessionId).pterodactyl || {};
    if (!cfg.domain || !cfg.apikey) return reply('⚠️ Panel not configured.');

    try {
        const res = await axios.get(
            `${cfg.domain}/api/application/users?per_page=100`,
            { headers: { Authorization: `Bearer ${cfg.apikey}`, Accept: 'Application/vnd.pterodactyl.v1+json' }, timeout: 30000 }
        );
        const users = res.data.data || [];
        if (!users.length) return reply('📋 No users.');

        let txt = `📋 *USER LIST*\n\n> Total: *${users.length}*\n\n`;
        users.slice(0, 20).forEach((u, i) => {
            const a = u.attributes;
            txt += `${i + 1}. *${a.username}*${a.root_admin ? ' 👑' : ''}\n   ├ ID: \`${a.id}\`\n   └ Email: \`${a.email}\`\n`;
        });
        if (users.length > 20) txt += `\n...and ${users.length - 20} more`;
        return reply(txt);
    } catch { return reply('❌ Failed.'); }
}

// ─── List admins ────────────────────────────────────────────────
async function cmdListAdmins(sock, m, args, context) {
    const { reply, isOwner, sender, sessionId } = context;
    if (!hasFullAccess(sender, isOwner) && !isOwner) return reply('❌ Access denied.');

    const cfg = getSessionConfig(sessionId).pterodactyl || {};
    if (!cfg.domain || !cfg.apikey) return reply('⚠️ Panel not configured.');

    try {
        const res = await axios.get(
            `${cfg.domain}/api/application/users`,
            { headers: { Authorization: `Bearer ${cfg.apikey}`, Accept: 'Application/vnd.pterodactyl.v1+json' }, timeout: 30000 }
        );
        const admins = (res.data.data || []).filter(u => u.attributes.root_admin);
        if (!admins.length) return reply('📋 No admins.');

        let txt = `📋 *ADMIN LIST*\n\n> Total: *${admins.length}*\n\n`;
        admins.forEach((u, i) => {
            const a = u.attributes;
            txt += `${i + 1}. *${a.username}*\n   └ ID: \`${a.id}\` | \`${a.email}\`\n`;
        });
        return reply(txt);
    } catch { return reply('❌ Failed.'); }
}

// ─── Server info ────────────────────────────────────────────────
async function cmdServerInfo(sock, m, args, context) {
    const { reply, isOwner, sender, prefix, command, sessionId } = context;
    if (!hasFullAccess(sender, isOwner) && !isOwner) return reply('❌ Access denied.');

    const cfg = getSessionConfig(sessionId).pterodactyl || {};
    if (!cfg.domain || !cfg.apikey) return reply('⚠️ Panel not configured.');

    const id = (args[0] || '').trim();
    if (!id || isNaN(Number(id))) return reply(`⚠️ Usage: \`${prefix}${command} <serverid>\``);

    try {
        const res = await axios.get(
            `${cfg.domain}/api/application/servers/${id}`,
            { headers: { Authorization: `Bearer ${cfg.apikey}`, Accept: 'Application/vnd.pterodactyl.v1+json' }, timeout: 30000 }
        );
        const s = res.data.attributes;
        const lim = s.limits || {};
        const feat = s.feature_limits || {};

        let txt = `📊 *SERVER INFO*\n\n`;
        txt += `🆔 ID    : *${s.id}*\n`;
        txt += `📛 Name  : *${s.name}*\n`;
        txt += `👤 User  : *${s.user}*\n`;
        txt += `📊 State : *${s.suspended ? '⛔ Suspended' : '✅ Active'}*\n\n`;
        txt += `💾 RAM   : *${fmtBytes(lim.memory)}*\n`;
        txt += `⚡ CPU   : *${lim.cpu === 0 ? 'Unlimited' : lim.cpu + '%'}*\n`;
        txt += `📦 Disk  : *${fmtBytes(lim.disk)}*\n`;
        txt += `🗄️ DBs   : *${feat.databases}*\n`;
        txt += `💾 Backs : *${feat.backups}*\n`;
        txt += `🔌 Alloc : *${feat.allocations}*`;
        return reply(txt);
    } catch { return reply('❌ Failed.'); }
}

// ─── Delete server ──────────────────────────────────────────────
async function cmdDelServer(sock, m, args, context) {
    const { reply, isOwner, sender, prefix, command, sessionId } = context;
    if (!hasFullAccess(sender, isOwner) && !isOwner) return reply('❌ Access denied.');

    const cfg = getSessionConfig(sessionId).pterodactyl || {};
    if (!cfg.domain || !cfg.apikey) return reply('⚠️ Panel not configured.');

    const id = (args[0] || '').trim();
    if (!id || isNaN(Number(id))) return reply(`⚠️ Usage: \`${prefix}${command} <serverid>\``);

    try {
        await axios.delete(
            `${cfg.domain}/api/application/servers/${id}`,
            { headers: { Authorization: `Bearer ${cfg.apikey}` }, timeout: 30000 }
        );
        return reply(`✅ Server \`${id}\` deleted.`);
    } catch { return reply('❌ Failed.'); }
}

// ─── Delete admin ───────────────────────────────────────────────
async function cmdDelAdmin(sock, m, args, context) {
    const { reply, isOwner, sender, prefix, command, sessionId } = context;
    if (!hasFullAccess(sender, isOwner) && !isOwner) return reply('❌ Access denied.');

    const cfg = getSessionConfig(sessionId).pterodactyl || {};
    if (!cfg.domain || !cfg.apikey) return reply('⚠️ Panel not configured.');

    const id = (args[0] || '').trim();
    if (!id || isNaN(Number(id))) return reply(`⚠️ Usage: \`${prefix}${command} <userid>\``);

    try {
        await axios.delete(
            `${cfg.domain}/api/application/users/${id}`,
            { headers: { Authorization: `Bearer ${cfg.apikey}` }, timeout: 30000 }
        );
        return reply(`✅ Admin \`${id}\` deleted.`);
    } catch { return reply('❌ Failed.'); }
}

// ─── Role manager ───────────────────────────────────────────────
async function cmdRole(sock, m, args, context) {
    const { reply, prefix, isOwner, sender, command } = context;
    const match = String(command || '').toLowerCase().match(/^(add|del|list)(own|ceo|res)$/);
    if (!match) return reply('❌ Invalid role command.');

    const action = match[1];
    const short  = match[2];
    const role   = short === 'own' ? 'owner' : short === 'res' ? 'reseller' : 'ceo';
    const roleLabel = capitalize(role);

    if (action === 'list') {
        const list = listByRole(role);
        if (!list.length) return reply(`📋 No *${role}* registered.`);
        let txt = `📋 *${roleLabel.toUpperCase()} LIST*\n\n> Total: *${list.length}*\n\n`;
        list.forEach((num, i) => { txt += `${i + 1}. \`${num}\`\n`; });
        return reply(txt);
    }

    if (!canManageRole(sender, role, isOwner) && !isOwner) {
        return reply(`❌ *ACCESS DENIED*\n\n> Cannot manage *${roleLabel}*`);
    }

    const targetUser = resolveTarget(m, (args.join(' ') || '').trim());
    if (!targetUser) return reply(`⚠️ Usage: \`${prefix}${command} @user\``);
    const targetNum = cleanNumber(targetUser);

    if (action === 'add') {
        const result = addRole(targetNum, role);
        if (!result.success) return reply(`❌ *FAILED*\n\n> ${result.error}`);
        return reply(`✅ *${roleLabel.toUpperCase()} ADDED*\n\n> Number: \`${targetNum}\`\n> Total: \`${listByRole(role).length}\``);
    }
    if (action === 'del') {
        const result = removeRole(targetNum, role);
        if (!result.success) return reply(`❌ *FAILED*\n\n> ${result.error}`);
        return reply(`✅ *${roleLabel.toUpperCase()} REMOVED*\n\n> Remaining: *${listByRole(role).length}*`);
    }
}

// ─── Sellers ────────────────────────────────────────────────────
async function cmdSeller(sock, m, args, context) {
    const { reply, prefix, isOwner, sender, command } = context;
    const cmd = (command || '').toLowerCase();

    const legacy = getLegacy();
    const senderNum = cleanNumber(sender);
    if (!isOwner && !legacy.ownerPanels.includes(senderNum)) {
        return reply('❌ Access denied (owner/panel owner only).');
    }

    const isAdd  = ['addsell', 'addres'].includes(cmd);
    const isDel  = ['delsell', 'delres'].includes(cmd);
    const isList = ['listsell', 'listres'].includes(cmd);

    if (isList) {
        if (!legacy.sellers.length) return reply('📋 No sellers registered.');
        let txt = `📋 *SELLER LIST*\n\n> Total: *${legacy.sellers.length}*\n\n`;
        legacy.sellers.forEach((s, i) => { txt += `${i + 1}. \`${s}\`\n`; });
        return reply(txt);
    }

    const target = resolveTarget(m, (args.join(' ') || '').trim());
    if (!target) return reply(`⚠️ Usage: \`${prefix}${command} @user\``);
    const targetNum = cleanNumber(target);

    if (isAdd) {
        if (legacy.sellers.includes(targetNum)) return reply('❌ Already a seller.');
        let note = '';
        const idx = legacy.ownerPanels.indexOf(targetNum);
        if (idx !== -1) { legacy.ownerPanels.splice(idx, 1); note = '\n> ⚡ Downgraded from Owner Panel'; }
        legacy.sellers.push(targetNum);
        if (saveLegacy(legacy)) {
            return reply(`✅ *SELLER ADDED*\n\n> Number: \`${targetNum}\`\n> Total: *${legacy.sellers.length}*${note}`);
        }
        return reply('❌ Save failed.');
    }

    if (isDel) {
        if (!legacy.sellers.includes(targetNum)) return reply('❌ Not a seller.');
        legacy.sellers = legacy.sellers.filter(s => s !== targetNum);
        if (saveLegacy(legacy)) {
            return reply(`✅ *SELLER REMOVED*\n\n> Total: *${legacy.sellers.length}*`);
        }
        return reply('❌ Save failed.');
    }
}

// ─── Menu ───────────────────────────────────────────────────────
async function cmdMenu(sock, m, args, context) {
    const { prefix, isOwner, sender, sessionId } = context;
    const cfg = getSessionConfig(sessionId).pterodactyl || {};
    const status = (cfg.domain && cfg.apikey) ? '✅ Configured' : '❌ Not configured';
    const userRoles = getAccessibleServers(sender);
    const userRoleTxt = userRoles.length ? userRoles.map(r => `${r.server}:${r.role}`).join(', ') : 'none';

    let txt = `🖥️ *PANEL MENU*\n\n`;
    txt += `> Panel : ${status}\n`;
    txt += `> Roles : *${isOwner ? 'Bot Owner' : userRoleTxt}*\n\n`;

    txt += `╭─「 ⚙️ SESSION 」\n`;
    txt += `┃ \`${prefix}claim\` → claim this session\n`;
    txt += `┃ \`${prefix}set <key> <value>\`\n`;
    txt += `┃ \`${prefix}status\`\n`;
    txt += `┃ \`${prefix}reset\`\n`;
    txt += `╰───────────\n\n`;

    txt += `╭─「 📦 CREATE 」\n`;
    txt += `┃ \`${prefix}1js\` \`${prefix}2js\` ... \`${prefix}10js\` \`${prefix}unli\`\n`;
    txt += `┃ \`${prefix}1py\` \`${prefix}2py\` ... \`${prefix}10py\` \`${prefix}unlipy\`\n`;
    txt += `╰───────────\n\n`;

    txt += `╭─「 👑 ROLES 」\n`;
    txt += `┃ \`${prefix}addown\` | \`${prefix}delown\` | \`${prefix}listown\`\n`;
    txt += `┃ \`${prefix}addceo\` | \`${prefix}delceo\` | \`${prefix}listceo\`\n`;
    txt += `┃ \`${prefix}addres\` | \`${prefix}delres\` | \`${prefix}listres\`\n`;
    txt += `╰───────────\n\n`;

    txt += `╭─「 🏪 SELLERS 」\n`;
    txt += `┃ \`${prefix}addsell\` | \`${prefix}delsell\` | \`${prefix}listsell\`\n`;
    txt += `╰───────────\n\n`;

    txt += `╭─「 🔐 ADMIN 」\n`;
    txt += `┃ \`${prefix}admin\` | \`${prefix}deladmin\` | \`${prefix}admins\`\n`;
    txt += `╰───────────\n\n`;

    txt += `╭─「 🖥️ SERVERS 」\n`;
    txt += `┃ \`${prefix}servers\` | \`${prefix}delsrv\` | \`${prefix}sinfo\`\n`;
    txt += `╰───────────\n\n`;

    txt += `╭─「 👤 USERS 」\n`;
    txt += `┃ \`${prefix}users\`\n`;
    txt += `╰───────────\n\n`;

    txt += `╭─「 🎨 THEMES (owner) 」\n`;
    txt += `┃ \`${prefix}stellar <ip>|<pw>\`\n`;
    txt += `┃ \`${prefix}nebula <ip>|<pw>\`\n`;
    txt += `┃ \`${prefix}enigma <ip>|<pw>|<wa>|<gc>|<ch>\`\n`;
    txt += `┃ \`${prefix}billing <ip>|<pw>\`\n`;
    txt += `┃ \`${prefix}untheme <ip>|<pw>\`\n`;
    txt += `╰───────────`;

    return sendWithPanelThumb(sock, context.chatId, txt, m);
}

// ══════════════════════════════════════════════════════════════════
// ─── COMMAND LIST ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const ALL_COMMANDS = (() => {
    const list = ['panel'];
    for (const n of ['1','2','3','4','5','6','7','8','9','10','unli']) {
        list.push(`${n}js`, `${n}py`);
    }
    list.push(
        'claim', 'set', 'status', 'reset',
        'admin', 'deladmin', 'admins', 'users',
        'servers', 'sinfo', 'delsrv',
        'addown', 'delown', 'listown',
        'addceo', 'delceo', 'listceo',
        'addres', 'delres', 'listres',
        'addsell', 'delsell', 'listsell',
        'stellar', 'nebula', 'enigma', 'billing', 'untheme',
    );
    return [...new Set(list)];
})();

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ───────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'panel',
    aliases:     ALL_COMMANDS.filter(c => c !== 'panel'),
    category:    'panel',
    description: 'Unified Pterodactyl manager',
    usage:       '.panel (see menu)',

    async handler(sock, m, args, context) {
        const cmd = (context.command || '').toLowerCase();

        // Themes
        const themeMap = { stellar: 'stellar', nebula: 'nebula', enigma: 'enigma', billing: 'billing', untheme: 'untheme' };
        if (themeMap[cmd]) {
            if (!context.isOwner) return context.reply('❌ Owner only.');
            const themeKey = themeMap[cmd];
            const titles = { stellar: 'INSTALL STELLAR THEME', nebula: 'INSTALL NEBULA THEME', enigma: 'INSTALL ENIGMA THEME', billing: 'INSTALL BILLING THEME', untheme: 'UNINSTALL THEME' };
            const names  = { stellar: 'Stellar', nebula: 'Nebula', enigma: 'Enigma', billing: 'Billing', untheme: 'Theme' };
            return runThemeInstall(sock, context.chatId, m.key, context, {
                title: titles[themeKey], themeName: names[themeKey], steps: THEME_STEPS[themeKey],
            });
        }

        // Menu
        if (cmd === 'panel') return cmdMenu(sock, m, args, context);

        // Session
        if (cmd === 'claim')  return cmdClaim(sock, m, args, context);
        if (cmd === 'status') return cmdStatus(sock, m, args, context);
        if (cmd === 'set')    return cmdSet(sock, m, args, context);
        if (cmd === 'reset')  return cmdReset(sock, m, args, context);

        // Create
        if (parseCmd(cmd)) return cmdCreate(sock, m, args, context);

        // Roles
        if (/^(add|del|list)(own|ceo|res)$/i.test(cmd)) return cmdRole(sock, m, args, context);

        // Sellers
        if (['addsell', 'delsell', 'listsell'].includes(cmd)) return cmdSeller(sock, m, args, context);

        // Accounts
        if (cmd === 'admin')    return cmdCreateAdmin(sock, m, args, context);
        if (cmd === 'deladmin') return cmdDelAdmin(sock, m, args, context);
        if (cmd === 'admins')   return cmdListAdmins(sock, m, args, context);
        if (cmd === 'users')    return cmdListUsers(sock, m, args, context);

        // Servers
        if (cmd === 'servers') return cmdListServers(sock, m, args, context);
        if (cmd === 'sinfo')   return cmdServerInfo(sock, m, args, context);
        if (cmd === 'delsrv')  return cmdDelServer(sock, m, args, context);

        return context.reply(`❌ Unknown panel command: \`${cmd}\``);
    },
};