/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const isAdmin = require('../lib/isAdmin.js');
module.exports = {
    command: 'clearchat',
    aliases: ['deletechat'],
    category: 'owner',
    description: 'Clear/delete the current chat',
    usage: '.clearchat',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const channelInfo = context.channelInfo || {};
        const isGroup = chatId.endsWith('@g.us');
        const senderId = context.senderId || message.key.participant || message.key.remoteJid;
        const senderIsOwnerOrSudo = context.senderIsOwnerOrSudo || false;
        if (isGroup && !senderIsOwnerOrSudo) {
            // Fetch admin status directly — context.isSenderAdmin unreliable without adminOnly flag
            const { isSenderAdmin } = await isAdmin(sock, chatId, senderId);
            if (!isSenderAdmin) {
                return await sendMessageWithChannel(sock, chatId, {
                    text: '❌ Only group admins or bot owner can clear this chat.',
                    ...channelInfo
                }, { quoted: message });
            }
        }
        if (!isGroup && !senderIsOwnerOrSudo && !message.key.fromMe) {
            return await sendMessageWithChannel(sock, chatId, {
                text: '❌ Only the bot owner can clear DM chats.',
                ...channelInfo
            }, { quoted: message });
        }
        try {
            await sock.chatModify({
                delete: true,
                lastMessages: [
                    {
                        key: message.key,
                        messageTimestamp: message.messageTimestamp
                    }
                ]
            }, chatId);
            await sendMessageWithChannel(sock, chatId, {
                text: `🗑️ *Chat cleared successfully!*`,
                ...channelInfo
            }, { quoted: message });
        }
        catch (e) {
            console.error('[CLEARCHAT] Error:', e.message);
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Failed to clear chat: ${e.message}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};
