/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: 'hack',
    aliases: ['fakehack', 'prankhack'],
    category: 'fun',
    description: 'Simulate a hack sequence (fun prank)',
    usage: '.hack <target>',
    /**
     * @param {object} sock - Baileys sock
     * @param {object} message - the original message object
     * @param {Array} args - command arguments
     * @param {object} context - additional context
     */
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const target = args?.[0] || 'target';
        try {
            await sendMessageWithChannel(sock, chatId, { text: '*💻 Initializing hack sequence...*' }, { quoted: message });
            await delay(1500);
            await sendMessageWithChannel(sock, chatId, { text: '*🔌 Establishing secure connection to the server...*' }, { quoted: message });
            await delay(1500);
            await sendMessageWithChannel(sock, chatId, { text: '*🛡 Bypassing firewalls and security protocols...*' }, { quoted: message });
            await displayProgressBar(sock, message, 'Bypassing firewalls', 4, chatId);
            await sendMessageWithChannel(sock, chatId, { text: '*🔐 Gaining access to encrypted database...*' }, { quoted: message });
            await delay(2000);
            await sendMessageWithChannel(sock, chatId, { text: '*🔑 Cracking encryption keys...*' }, { quoted: message });
            await displayProgressBar(sock, message, 'Cracking encryption', 6, chatId);
            await sendMessageWithChannel(sock, chatId, { text: '*📥 Downloading sensitive data from server...*' }, { quoted: message });
            await displayProgressBar(sock, message, 'Downloading files', 5, chatId);
            await sendMessageWithChannel(sock, chatId, { text: '*🔒 Planting a backdoor for future access...*' }, { quoted: message });
            await delay(2500);
            await sendMessageWithChannel(sock, chatId, { text: `*💥 Hack complete! 🎯 Target "${target}" successfully compromised.*` }, { quoted: message });
            await delay(1000);
            await sendMessageWithChannel(sock, chatId, { text: '*🤖 Mission accomplished. Logging off...*' }, { quoted: message });
        }
        catch (error) {
            console.error('Error in hack sequence:', error);
            await sendMessageWithChannel(sock, chatId, { text: '*⚠️ An error occurred during the hack sequence. Please try again later.*' }, { quoted: message });
        }
    }
};
/**
 * Helper function: delay for a number of milliseconds
 */
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));
/**
 * Display progress bar in chat
 */
async function displayProgressBar(sock, message, taskName, steps, chatId) {
    const progressBarLength = 20;
    for (let i = 1; i <= steps; i++) {
        const progress = Math.round((i / steps) * progressBarLength);
        const bar = '█'.repeat(progress) + '░'.repeat(progressBarLength - progress);
        await sendMessageWithChannel(sock, chatId, { text: `*${taskName}:* [${bar}]` }, { quoted: message });
        await delay(1000);
    }
}
