'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const fs = require('fs');
const path = require('path');

// ══════════════════════════════════════════════════════════════════
// ─── FORWARD NEWSLETTER CONTEXT (mandatory on all plugins) ────────
// ══════════════════════════════════════════════════════════════════
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── INTERNAL STORE ───────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const DATA_DIR   = path.join(__dirname, 'antibot-data');
const STORE_PATH = path.join(DATA_DIR, 'store.json');

const DEFAULT_STORE = { groups: {} };

let _store = null;
let _saveTimer = null;

function ensureDir() {
    try {
        if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    } catch (e) { console.error('[ANTIBOT] mkdir failed:', e?.message); }
}

function loadStore() {
    ensureDir();
    try {
        if (fs.existsSync(STORE_PATH)) {
            const raw = fs.readFileSync(STORE_PATH, 'utf8').trim();
            if (raw) {
                const parsed = JSON.parse(raw);
                _store = { groups: { ...(parsed.groups || {}) } };
                return _store;
            }
        }
    } catch (e) {
        console.error('[ANTIBOT] store corrupted, rebuilding:', e?.message);
        try {
            const backup = STORE_PATH + '.corrupted.' + Date.now() + '.bak';
            if (fs.existsSync(STORE_PATH)) fs.copyFileSync(STORE_PATH, backup);
        } catch { /* ignore */ }
    }
    _store = JSON.parse(JSON.stringify(DEFAULT_STORE));
    writeStoreSync();
    return _store;
}

function writeStoreSync() {
    try {
        ensureDir();
        const tmp = STORE_PATH + '.tmp';
        fs.writeFileSync(tmp, JSON.stringify(_store, null, 2), 'utf8');
        fs.renameSync(tmp, STORE_PATH);
    } catch (e) { console.error('[ANTIBOT] store write failed:', e?.message); }
}

function scheduleSave() {
    if (_saveTimer) clearTimeout(_saveTimer);
    _saveTimer = setTimeout(() => { _saveTimer = null; writeStoreSync(); }, 500);
    if (_saveTimer.unref) _saveTimer.unref();
}

function getSetting(jid, key, def = null) {
    if (!_store) loadStore();
    const g = _store.groups?.[jid];
    if (!g) return def;
    const v = g[key];
    return v === undefined ? def : v;
}

function setSetting(jid, key, value) {
    if (!_store) loadStore();
    if (!_store.groups[jid]) _store.groups[jid] = {};
    _store.groups[jid][key] = value;
    scheduleSave();
}

loadStore();
process.on('exit', () => { try { writeStoreSync(); } catch {} });
process.on('SIGINT', () => { try { writeStoreSync(); } catch {} process.exit(0); });

// ══════════════════════════════════════════════════════════════════
// ─── CONFIG ───────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const CFG = {
    antibotMsg: '🤖 *AntiBot* — @%user% was detected as a bot and kicked.',
};

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function jidToNumber(jid) {
    if (!jid) return '';
    return String(jid).split(':')[0].split('@')[0].replace(/[^0-9]/g, '');
}

function getParticipantJid(p) {
    if (!p) return '';
    if (p.jid && !p.jid.endsWith('@lid')) return p.jid;
    if (p.phoneNumber && !p.phoneNumber.endsWith('@lid')) return p.phoneNumber;
    if (p.id && !p.id.endsWith('@lid')) return p.id;
    const raw = p.id || p.jid || p.lid || '';
    return raw.endsWith('@lid') ? raw.replace('@lid', '@s.whatsapp.net') : raw;
}

function findParticipantByNumber(participants, targetJid) {
    if (!Array.isArray(participants) || !targetJid) return null;
    const targetNum = jidToNumber(targetJid);
    if (!targetNum) return null;
    for (const p of participants) {
        const pNum = jidToNumber(p.id || p.jid || p.phoneNumber || p.lid || '');
        if (pNum && pNum === targetNum) return p;
    }
    return null;
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch { /* ignore */ }
}

// ══════════════════════════════════════════════════════════════════
// ─── BOT DETECTION HEURISTICS ─────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function extractMessageId(m) {
    return String(m?.key?.id || m?.id || '').trim();
}

function extractSenderDevice(m) {
    const participant = String(m?.key?.participant || '');
    const match = participant.match(/:(\d+)@/);
    if (!match) return null;
    const value = Number.parseInt(match[1], 10);
    return Number.isNaN(value) ? null : value;
}

function isUnknownPushName(pushName) {
    const value = String(pushName || '').trim().toLowerCase();
    return !value || ['unknown', 'undefined', 'null'].includes(value);
}

function analyzeBotMessage(m) {
    const messageId = extractMessageId(m);
    if (!messageId) {
        return { isBot: false, score: 0, reasons: [], confidence: 'low' };
    }

    if (messageId.startsWith('WAMID.') || messageId.startsWith('false_') || messageId.startsWith('true_')) {
        return { isBot: false, score: 0, reasons: [], confidence: 'low' };
    }

    let score = 0;
    const reasons = [];
    const idUpper = messageId.toUpperCase();

    if (idUpper.startsWith('BAE5')) { score += 5; reasons.push('id-BAE5'); }
    else if (idUpper.startsWith('3EB0') && idUpper.length === 22) { score += 4; reasons.push('id-3EB0'); }
    else if (idUpper.startsWith('B24E')) { score += 5; reasons.push('id-B24E'); }
    else if (idUpper.startsWith('94DD')) { score += 5; reasons.push('id-94DD'); }
    else if (idUpper.startsWith('B1E')) { score += 5; reasons.push('id-B1E'); }
    else if (/^[A-F0-9]{28,40}$/i.test(messageId)) { score += 2; reasons.push('id-upper-hex'); }
    else if (messageId.length === 16) { score += 3; reasons.push('id-length-16'); }
    else if (messageId.length < 20 && !messageId.includes('-')) { score += 2; reasons.push('id-length-suspicious'); }

    if (/[a-z]/.test(messageId) && !messageId.startsWith('3EB0') && !messageId.includes('-')) {
        score += 4; reasons.push('id-lowercase-signature');
    }

    const len = messageId.length;
    if (len !== 16 && len !== 20 && len !== 22 && len !== 32 && !messageId.includes('-')) {
        score += 3; reasons.push('id-length-unusual');
    }

    if (m?.isBaileys === true) { score += 5; reasons.push('flag-isBaileys'); }

    const msg = m?.message || {};
    const actualMsg = msg.ephemeralMessage?.message
        || msg.viewOnceMessage?.message
        || msg.viewOnceMessageV2?.message
        || msg;

    const textMsg = m?.text
        || actualMsg?.conversation
        || actualMsg?.extendedTextMessage?.text
        || '';

    const contextInfo = actualMsg?.extendedTextMessage?.contextInfo
        || actualMsg?.imageMessage?.contextInfo
        || actualMsg?.videoMessage?.contextInfo
        || {};

    if (contextInfo.externalAdReply) { score += 6; reasons.push('custom-ad-reply'); }

    if (contextInfo.isForwarded && contextInfo.forwardingScore > 100) {
        score += 3; reasons.push('fake-forward-score');
    }

    if (/[\u200B-\u200D\uFEFF]/.test(textMsg)) { score += 3; reasons.push('invisible-characters'); }

    const botMessageTypes = [
        'buttonsMessage', 'templateMessage', 'listMessage',
        'interactiveMessage', 'buttonsResponseMessage',
        'templateButtonReplyMessage', 'listResponseMessage',
        'interactiveResponseMessage',
    ];
    for (const type of botMessageTypes) {
        if (actualMsg[type]) { score += 6; reasons.push(`message-type-${type}`); break; }
    }

    if (msg.deviceSentMessage) {
        score += 1; reasons.push('message-deviceSent');
        if (msg.deviceSentMessage?.message) { score += 1; reasons.push('message-deviceWrapper'); }
    }

    const senderDevice = extractSenderDevice(m);
    if (Number.isInteger(senderDevice) && senderDevice > 20) {
        score += 2; reasons.push('participant-highDevice');
    }

    const lowerPushName = String(m?.pushName || '').toLowerCase();
    if (isUnknownPushName(m?.pushName)) { score += 1; reasons.push('pushname-unknown'); }
    else if (/(bot|system|admin|owner|host|panel)/i.test(lowerPushName)) {
        score += 2; reasons.push('pushname-suspicious');
    }

    const confidence = score >= 6 ? 'high' : score >= 4 ? 'medium' : 'low';
    return { isBot: score >= 5, score, reasons, confidence, messageId, senderDevice };
}

function isBotMessage(m) {
    const result = analyzeBotMessage(m);
    return {
        isBot: result.isBot,
        reason: result.reasons[0] || null,
        score: result.score,
        reasons: result.reasons,
        confidence: result.confidence,
    };
}

// ══════════════════════════════════════════════════════════════════
// ─── DETECT + KICK ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function detectBot(m, sock) {
    try {
        if (!m.isGroup) return false;

        const groupData = getSetting(m.chat, 'antibot', false);
        if (groupData !== true) return false;

        const result = isBotMessage(m);
        if (!result.isBot) return false;

        const botJid = m.sender;
        if (!botJid) return false;

        const groupMeta = m.groupMetadata;
        if (!groupMeta) return false;

        const myNumber = sock.user?.id?.split(':')[0] || sock.user?.id?.split('@')[0];
        const myJid = myNumber + '@s.whatsapp.net';
        if (botJid === myJid) return false;

        const botParticipant = findParticipantByNumber(groupMeta.participants, myJid);
        if (!botParticipant?.admin) return false;

        const targetParticipant = findParticipantByNumber(groupMeta.participants, botJid);
        if (targetParticipant?.admin) return false;

        const targetJidToKick = targetParticipant
            ? getParticipantJid(targetParticipant)
            : botJid;

        // Delete the offending message
        try {
            await sock.sendMessage(m.chat, { delete: m.key });
        } catch {
            try {
                await sock.sendMessage(m.chat, {
                    delete: {
                        remoteJid: m.chat,
                        fromMe: false,
                        id: m.key?.id || m.id,
                        participant: m.sender,
                    },
                });
            } catch { /* ignore */ }
        }

        // Kick
        await sock.groupParticipantsUpdate(m.chat, [targetJidToKick], 'remove');

        // Notify
        const userTag = botJid.split('@')[0];
        const notifyText = CFG.antibotMsg.replace(/%user%/g, userTag);
        await sendMessageWithChannel(sock, m.chat, {
            text: notifyText,
            mentions: [botJid],
        });

        return true;
    } catch (err) {
        console.error('[ANTIBOT] detectBot failed:', err?.message || err);
        return false;
    }
}

// ══════════════════════════════════════════════════════════════════
// ─── EVENT HOOK (self-registering on messages.upsert) ─────────────
// ══════════════════════════════════════════════════════════════════
let _bound = false;
let _boundSock = null;

async function onMessagesUpsert(payload) {
    try {
        const sock = _boundSock;
        if (!sock) return;

        const messages = Array.isArray(payload?.messages) ? payload.messages : [];
        for (const raw of messages) {
            if (!raw?.message || !raw?.key) continue;
            if (raw.key.fromMe) continue;

            // Skip command messages — the command handler will process them
            const chatJid = raw.key.remoteJid || '';
            if (!chatJid.endsWith('@g.us')) continue;

            const body =
                raw.message?.conversation ||
                raw.message?.extendedTextMessage?.text ||
                raw.message?.imageMessage?.caption ||
                raw.message?.videoMessage?.caption ||
                '';
            const prefix = global.xprefix || '.';
            if (body && body.startsWith(prefix)) continue;

            // Hydrate a message-like object
            const mLike = {
                key: raw.key,
                id: raw.key.id,
                message: raw.message,
                chat: chatJid,
                sender: raw.key.participant || raw.key.remoteJid,
                pushName: raw.pushName,
                isGroup: chatJid.endsWith('@g.us'),
                isBaileys: raw.key?.id?.length === 20 && /^[A-Z0-9]+$/.test(raw.key.id) ? true : false,
            };

            // Fetch group metadata (cached by Baileys)
            mLike.groupMetadata = await sock.groupMetadata(chatJid).catch(() => null);
            if (!mLike.groupMetadata) continue;

            await detectBot(mLike, sock);
        }
    } catch (e) {
        console.error('[ANTIBOT-EVENT]', e?.message);
    }
}

function bindSock(sock) {
    if (_bound || !sock || !sock.ev) return;
    _bound = true;
    _boundSock = sock;
    try {
        sock.ev.on('messages.upsert', onMessagesUpsert);
        console.log('[ANTIBOT] event hook registered');
    } catch (e) {
        console.error('[ANTIBOT] failed to bind:', e?.message);
        _bound = false;
    }
}

function tryBindFromGlobals() {
    const candidates = [global.sock, global.conn, global.Hanz, global.client];
    for (const c of candidates) {
        if (c && c.ev) { bindSock(c); return; }
    }
}

tryBindFromGlobals();

let _retryCount = 0;
const _retryTimer = setInterval(() => {
    if (_bound) return clearInterval(_retryTimer);
    if (++_retryCount >= 10) return clearInterval(_retryTimer);
    tryBindFromGlobals();
}, 3000);
if (_retryTimer.unref) _retryTimer.unref();

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'antibot',
    aliases:     ['botdetect'],
    category:    'group',
    description: 'Detect and kick WhatsApp bots (Baileys) from the group',
    usage:       '.antibot <on|off|status>',

    async handler(sock, m, args, context) {
        // Lazy-bind on first command invocation
        if (!_bound) bindSock(sock);

        const { chatId, reply, isGroup, isOwner, isAdmin, isBotAdmin, prefix } = context;

        if (!isGroup) return reply(global.mess?.only?.group || 'This command only works in groups.');
        if (!isAdmin && !isOwner) return reply(global.mess?.only?.admin || 'Admin only.');

        const sub = (args[0] || '').toLowerCase();
        const current = getSetting(chatId, 'antibot', false);

        if (!sub || sub === 'status') {
            return reply(
                `🤖 *AntiBot*\n\n` +
                `> Status: ${current ? '✅ Active' : '❌ Inactive'}\n\n` +
                `> Detection: *Smart Heuristic*\n\n` +
                `> \`${prefix}antibot on/off\``,
            );
        }

        if (sub === 'on') {
            setSetting(chatId, 'antibot', true);
            await react(sock, chatId, m.key, '✅');
            return reply(`✅ *AntiBot enabled*`);
        }

        if (sub === 'off') {
            setSetting(chatId, 'antibot', false);
            await react(sock, chatId, m.key, '❌');
            return reply(`❌ *AntiBot disabled*`);
        }

        return reply(`❌ Use \`${prefix}antibot on\` or \`${prefix}antibot off\``);
    },

    // Exposed for advanced use
    detectBot,
    isBotMessage,
};