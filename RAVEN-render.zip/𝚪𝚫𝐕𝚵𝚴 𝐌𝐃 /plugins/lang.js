'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const { SUPPORTED_LANGUAGES, normalizeLanguage, getLanguage, message } = require('../i18n');

module.exports = {
  command: 'lang',
  aliases: ['language', 'lng'],
  category: 'general',
  description: 'Change the bot language (English or French)',
  usage: '.lang [en|fr]',
  async handler(sock, m, args, context) {
    const chatId = context.chatId || m.chat || m.key?.remoteJid;
    const requested = String(args?.[0] || '').trim().toLowerCase();
    if (!requested) return context.reply(message(getLanguage(chatId, context.getSetting), 'languageCurrent', getLanguage(chatId, context.getSetting)));
    if (!SUPPORTED_LANGUAGES.includes(normalizeLanguage(requested)) || !['en', 'fr'].includes(requested.split(/[-_]/)[0])) {
      return context.reply(message(getLanguage(chatId, context.getSetting), 'languageInvalid'));
    }
    context.setSetting(chatId, 'language', requested);
    return context.reply(message(requested, 'languageChanged', requested));
  }
};
