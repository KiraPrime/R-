'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const axios = require('axios');

// ══════════════════════════════════════════════════════════════════
// ─── FORWARD NEWSLETTER CONTEXT ───────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── CONFIG ───────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const BASE              = 'https://www.dclookup.id';
const SITEKEY           = '6Lc0ZystAAAAAKESQ1HMsCQujyLgDvSu6FW1CHfP';
const ACTION            = 'lookup';
const RECAPTCHA_BASE    = 'https://www.google.com/recaptcha/';
const UA                = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36';

const gc = axios.create({
    timeout: 20000,
    headers: {
        'user-agent': UA,
        'accept-language': 'id-ID',
        'sec-ch-ua': '"Chromium";v="127", "Not)A;Brand";v="99", "Microsoft Edge Simulate";v="127", "Lemur";v="127"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Android"',
    },
    validateStatus: () => true,
});

// ══════════════════════════════════════════════════════════════════
// ─── reCAPTCHA v3 BYPASS ──────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function buildCo(url) {
    const { origin, protocol } = new URL(url);
    const port = protocol === 'https:' ? '443' : '80';
    return Buffer.from(`${origin}:${port}`).toString('base64').replace(/=/g, '');
}

function randomCb() {
    let s = '';
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    for (let i = 0; i < 12; i++) s += chars[Math.floor(Math.random() * chars.length)];
    return s;
}

let _cachedV = null;
async function fetchLatestVersion() {
    if (_cachedV) return _cachedV;
    const res = await gc.get(`${RECAPTCHA_BASE}api.js`, {
        headers: { referer: 'https://www.google.com/' },
    });
    const m = String(res.data).match(/releases\/([\w-]+)\//);
    if (!m) throw new Error('Failed to grab collector version (v) from api.js');
    _cachedV = m[1];
    return _cachedV;
}

function extractRresp(body) {
    const cleaned = String(body).replace(/^\)\]\}'\s*/, '');
    try {
        const arr = JSON.parse(cleaned);
        if (Array.isArray(arr) && arr[0] === 'rresp' && typeof arr[1] === 'string') return arr[1];
    } catch (_) {}
    const m = cleaned.match(/"rresp","([^"]+)"/);
    return m ? m[1] : null;
}

async function solveRecaptchaV3({ sitekey, url, action, hl = 'id', retries = 2 } = {}) {
    if (!sitekey) throw new Error('sitekey is required');

    const base = `${RECAPTCHA_BASE}api2/`;
    const params = {
        ar: '1',
        k: sitekey,
        co: buildCo(url),
        hl,
        v: await fetchLatestVersion(),
        size: 'invisible',
        'anchor-ms': '20000',
        'execute-ms': '30000',
        cb: randomCb(),
    };

    let lastErr;
    for (let attempt = 1; attempt <= retries + 1; attempt++) {
        try {
            const anchorQs = new URLSearchParams(params).toString();
            const anchorRes = await gc.get(`${base}anchor?${anchorQs}`, {
                headers: { referer: new URL(url).origin + '/', 'sec-fetch-dest': 'iframe' },
            });
            if (anchorRes.status !== 200) throw new Error(`anchor HTTP ${anchorRes.status}`);

            const cMatch = String(anchorRes.data).match(/id="recaptcha-token"\s+value="([^"]+)"/);
            if (!cMatch) throw new Error('recaptcha-token not found in anchor response');

            const postData = new URLSearchParams({
                v: params.v,
                reason: 'q',
                c: cMatch[1],
                k: params.k,
                co: params.co,
                ...(action ? { sa: action } : {}),
            }).toString();

            const reloadRes = await gc.post(`${base}reload?k=${params.k}`, postData, {
                headers: {
                    'content-type': 'application/x-www-form-urlencoded',
                    origin: 'https://www.google.com',
                    referer: `${base}anchor?${anchorQs}`,
                    accept: '*/*',
                    'sec-fetch-site': 'same-origin',
                    'sec-fetch-mode': 'cors',
                    'sec-fetch-dest': 'empty',
                },
            });
            if (reloadRes.status !== 200) throw new Error(`reload HTTP ${reloadRes.status}`);

            const token = extractRresp(reloadRes.data);
            if (!token) throw new Error('rresp/token not found in reload response');

            return { token, version: params.v };
        } catch (err) {
            lastErr = err;
            if (attempt <= retries) params.cb = randomCb();
        }
    }
    throw lastErr;
}

// ══════════════════════════════════════════════════════════════════
// ─── DISCORD LOOKUP ───────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function lookupUser(discordId, recaptchaToken) {
    const res = await axios.post(
        `${BASE}/api/user/lookup`,
        new URLSearchParams({ id: discordId }).toString(),
        {
            timeout: 20000,
            headers: {
                'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                accept: 'application/json, text/javascript, */*; q=0.01',
                'x-requested-with': 'XMLHttpRequest',
                'x-recaptcha-token': recaptchaToken,
                'user-agent': UA,
                origin: BASE,
                referer: `${BASE}/`,
            },
            validateStatus: () => true,
        }
    );

    if (typeof res.data !== 'object') {
        throw new Error(`Response is not JSON (HTTP ${res.status})`);
    }
    return res.data;
}

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {}
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'stalkdc',
    aliases:     ['dcstalk', 'dclookup', 'discordstalk'],
    category:    'stalker',
    description: 'Look up a Discord profile by ID',
    usage:       '.stalkdc <discord_id>',

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix } = context;

        const rawInput = (args.join(' ') || '').trim();

        if (!rawInput) {
            return reply(
                `👾 *DISCORD STALKER* 👾\n\n` +
                `Look up a Discord profile from its ID.\n\n` +
                `*USAGE:*\n` +
                `> \`${prefix}stalkdc <Discord ID>\`\n` +
                `> Example: \`${prefix}stalkdc 1280009524941426700\`\n\n` +
                `_Make sure you provide a numeric ID (not a username)._`,
            );
        }

        const discordId = rawInput.replace(/[^0-9]/g, '');

        if (!discordId) {
            return reply(`❌ *INVALID ID*\n\n> The Discord ID must contain digits only.`);
        }

        try {
            await react(sock, chatId, m.key, '🕕');

            const { token } = await solveRecaptchaV3({ sitekey: SITEKEY, url: BASE, action: ACTION });
            const resp = await lookupUser(discordId, token);

            if (!resp.success) {
                await react(sock, chatId, m.key, '❌');
                return reply(
                    `❌ *ACCOUNT NOT FOUND*\n\n` +
                    `No account matches the ID *${discordId}*. The ID may be incorrect or the account was deleted.\n\n` +
                    `_Error: ${resp.message || '-'}_`,
                );
            }

            const d      = resp.data || {};
            const isBot  = d.is_bot ? 'Yes (Bot)' : 'No (User)';
            const badges = (d.badges || []).map(b => b.name).join(', ') || '-';

            let caption = `👾 *DISCORD STALKER* 👾\n\n`;
            caption += `Here is the profile info for that Discord account:\n\n`;
            caption += `👤 *Username*     : ${d.username}\n`;
            caption += `🏷️ *Global name*  : ${d.global_name || '-'}\n`;
            caption += `🆔 *User ID*      : ${d.id}\n`;
            caption += `🤖 *Is bot*       : ${isBot}\n`;
            caption += `🗓️ *Created at*   : ${d.creation_date || '-'}\n`;
            caption += `🏅 *Badges*       : ${badges}\n`;

            if (d.clan) {
                caption += `🛡️ *Clan*         : ${d.clan.tag} (${d.clan.name})\n`;
            }

            caption += `\n_Powered by dclookup.id_`;

            const avaUrl = d.avatar_url || d.default_avatar_url || d.avatar;

            if (avaUrl) {
                await sendMessageWithChannel(sock, chatId, {
                    image:   { url: avaUrl },
                    caption,
                }, { quoted: m });
            } else {
                await sendMessageWithChannel(sock, chatId, { text: caption }, { quoted: m });
            }

            await react(sock, chatId, m.key, '✅');

        } catch (e) {
            console.error('[STALKDC]', e?.message || e);
            await react(sock, chatId, m.key, '❌');
            return reply(
                `❌ *LOOKUP FAILED*\n\n` +
                `The system failed to bypass the reCAPTCHA or reach the API. Please try again later.\n\n` +
                `_Error: ${e.message}_`,
            );
        }
    },
};