'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const fs     = require('fs');
const path   = require('path');
const {
    generateWAMessageFromContent,
    proto,
} = require('@whiskeysockets/baileys');

// ══════════════════════════════════════════════════════════════════
// ─── CONFIG ───────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const CFG = {
    botName:    global.botName  || '𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
    footer:     global.footer   || '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
    channelUrl: global.link     || 'https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w',

    thumbnailUrl: 'https://b.top4top.io/p_3941wrada0.png',
    adLink:       'https://t.me/kira4hub',
    adTitle:      'Join us on Telegram',

    orderTitle:  '𝚪𝚫𝐕𝚵𝚴',
    orderMsg:    'https://t.me/kira4hub',
    itemCount:   99999999,
    surface:     99999999,

    defaultWelcome: '╭─〔 👋 *WELCOME* 〕─\n│ ❍ ᴜꜱᴇʀ  : {user}\n│ ❍ ɢʀᴏᴜᴘ : {group}\n│ ❍ ᴍᴇᴍʙᴇʀꜱ: {count}\n╰───────────────────\n',
    defaultGoodbye: '╭─〔 👋 *GOODBYE* 〕─\n│ ❍ ᴜꜱᴇʀ  : {user}\n│ ❍ ɢʀᴏᴜᴘ : {group}\n╰───────────────────\n',

    forward: {
        enabled:         true,
        forwardingScore: 1,
        isForwarded:     true,
        newsletterJid:   '120363410293871779@newsletter',
        newsletterName:  '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1,
    },
};

// ══════════════════════════════════════════════════════════════════
// ─── FORWARD HELPERS ──────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const forwardInfo = {
    forwardingScore: CFG.forward.forwardingScore,
    isForwarded:     CFG.forward.isForwarded,
    forwardedNewsletterMessageInfo: {
        newsletterJid:   CFG.forward.newsletterJid,
        newsletterName:  CFG.forward.newsletterName,
        serverMessageId: CFG.forward.serverMessageId,
    },
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo,
        },
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── FAKE ORDER (99999999 articles) ───────────────────────────────
// ══════════════════════════════════════════════════════════════════
function buildFakeWeb() {
    return {
        key: { participant: '0@s.whatsapp.net' },
        message: {
            orderMessage: {
                itemCount:         CFG.itemCount,
                surface:           CFG.surface,
                message:           CFG.orderMsg,
                orderTitle:        CFG.orderTitle,
                thumbnail:         Buffer.alloc(0),
                sellerJid:         '0@s.whatsapp.net',
                token:             '',
                currency:          '',
                totalAmount1000:   0,
                totalCurrencyCode: '',
            },
        },
    };
}

// ══════════════════════════════════════════════════════════════════
// ─── MIME HELPER ──────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function _guessMime(filename) {
    const ext = path.extname(filename).toLowerCase();
    const map = {
        '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
        '.png': 'image/png',  '.webp': 'image/webp',
        '.gif': 'image/gif',  '.bmp':  'image/bmp',
        '.svg': 'image/svg+xml',
        '.mp4': 'video/mp4',  '.3gp':  'video/3gpp',
        '.mov': 'video/quicktime',
    };
    return map[ext] || 'application/octet-stream';
}

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

// ══════════════════════════════════════════════════════════════════
// ─── UPLOADERS ────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════

// ─── 1. Catbox (axios) ────────────────────────────────────────────
async function uploadToCatbox(buffer, filename) {
    const axios = require('axios');
    let FormData;
    try { FormData = require('form-data'); } catch { FormData = global.FormData; }

    const form = new FormData();
    form.append('reqtype', 'fileupload');
    form.append('fileToUpload', buffer, {
        filename,
        contentType: _guessMime(filename),
    });

    const res = await axios.post('https://catbox.moe/user/api.php', form, {
        headers: {
            ...(form.getHeaders ? form.getHeaders() : {}),
            'User-Agent': UA,
            'Accept':     '*/*',
            'Origin':     'https://catbox.moe',
            'Referer':    'https://catbox.moe/',
        },
        maxBodyLength:    Infinity,
        maxContentLength: Infinity,
        timeout:          60000,
    });

    const url = String(res.data || '').trim();
    if (!url.startsWith('http')) {
        throw new Error(`Catbox invalid response: ${url.slice(0, 100)}`);
    }
    return { host: 'Catbox', url, expires: 'Permanent' };
}

// ─── 2. Pone.rs (fallback) ────────────────────────────────────────
async function uploadToPone(buffer, filename) {
    const axios = require('axios');
    let FormData;
    try { FormData = require('form-data'); } catch { FormData = global.FormData; }

    const form = new FormData();
    form.append('files[]', buffer, {
        filename,
        contentType: _guessMime(filename),
    });

    const res = await axios.post('https://pone.rs/upload.php', form, {
        headers: {
            ...(form.getHeaders ? form.getHeaders() : {}),
            'User-Agent': UA,
            'Accept':     '*/*',
            'Origin':     'https://pone.rs',
            'Referer':    'https://pone.rs/',
        },
        maxBodyLength:    Infinity,
        maxContentLength: Infinity,
        timeout:          60000,
    });

    const data = res.data;
    const url  = data?.files?.[0]?.url?.replaceAll('\\/', '/') || null;
    if (!data?.success || !url) throw new Error('Pone: invalid response');
    return { host: 'Pone', url, expires: 'Permanent' };
}

// ─── 3. Qu.ax (fallback) ──────────────────────────────────────────
async function uploadToQuax(buffer, filename) {
    const axios = require('axios');
    let FormData;
    try { FormData = require('form-data'); } catch { FormData = global.FormData; }

    const form = new FormData();
    form.append('file', buffer, {
        filename,
        contentType: _guessMime(filename),
    });

    const res = await axios.post('https://qu.ax/upload.php', form, {
        headers: {
            ...(form.getHeaders ? form.getHeaders() : {}),
            'User-Agent': UA,
        },
        maxBodyLength:    Infinity,
        maxContentLength: Infinity,
        timeout:          60000,
    });

    const data = res.data;
    if (!data?.success || !data?.files?.[0]?.url) throw new Error('Qu.ax: invalid response');
    return { host: 'Qu.ax', url: data.files[0].url, expires: 'Permanent' };
}

// ══════════════════════════════════════════════════════════════════
// ─── MULTI-HOST UPLOAD (fallback chain) ───────────────────────────
// ══════════════════════════════════════════════════════════════════
const UPLOAD_CHAIN = [
    { name: 'Catbox', fn: uploadToCatbox },
    { name: 'Pone',   fn: uploadToPone   },
    { name: 'Qu.ax',  fn: uploadToQuax   },
];

async function uploadMedia(buffer, filename) {
    const errors = [];

    for (const host of UPLOAD_CHAIN) {
        try {
            const result = await host.fn(buffer, filename);
            console.log(`[WG] Upload OK → ${host.name}: ${result.url}`);
            return result;
        } catch (e) {
            console.error(`[WG] Upload failed on ${host.name}:`, e?.message);
            errors.push(`${host.name}: ${e.message}`);
        }
    }

    throw new Error('All hosts failed:\n' + errors.join('\n'));
}

// ══════════════════════════════════════════════════════════════════
// ─── STORE (per-owner isolation) ──────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const DATA_DIR   = path.join(__dirname, 'welcome-goodbye-data');
const STORE_PATH = path.join(DATA_DIR, 'group-data.json');

const DEFAULT_STORE = { groups: {} };

let _store     = null;
let _saveTimer = null;

function ensureDir() {
    try {
        if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    } catch (e) { console.error('[WG] mkdir failed:', e?.message); }
}

function loadStore() {
    ensureDir();
    try {
        if (fs.existsSync(STORE_PATH)) {
            const raw = fs.readFileSync(STORE_PATH, 'utf8').trim();
            if (raw) {
                const parsed = JSON.parse(raw);
                _store = { groups: { ...(parsed.groups || {}) } };
                return _store;
            }
        }
    } catch (e) {
        console.error('[WG] store corrupted, rebuilding:', e?.message);
        try {
            const backup = STORE_PATH + '.corrupted.' + Date.now() + '.bak';
            if (fs.existsSync(STORE_PATH)) fs.copyFileSync(STORE_PATH, backup);
        } catch {}
    }
    _store = JSON.parse(JSON.stringify(DEFAULT_STORE));
    writeStoreSync();
    return _store;
}

function writeStoreSync() {
    try {
        ensureDir();
        const tmp = STORE_PATH + '.tmp';
        fs.writeFileSync(tmp, JSON.stringify(_store, null, 2), 'utf8');
        fs.renameSync(tmp, STORE_PATH);
    } catch (e) { console.error('[WG] store write failed:', e?.message); }
}

function scheduleSave() {
    if (_saveTimer) clearTimeout(_saveTimer);
    _saveTimer = setTimeout(() => { _saveTimer = null; writeStoreSync(); }, 400);
    if (_saveTimer.unref) _saveTimer.unref();
}

function getOwnerNumber(sock) {
    const ownerList = global.owner || [];
    if (Array.isArray(ownerList) && ownerList.length) {
        const first = String(ownerList[0]).split(':')[0].split('@')[0].replace(/[^0-9]/g, '');
        if (first) return first;
    }

    if (global.ownernumber) {
        const n = String(global.ownernumber).replace(/[^0-9]/g, '');
        if (n) return n;
    }

    try {
        const raw = sock?.user?.id || '';
        const n   = String(raw).split(':')[0].split('@')[0].replace(/[^0-9]/g, '');
        if (n) return n;
    } catch {}

    return 'unknown';
}

function makeKey(sock, chatId) {
    const owner = getOwnerNumber(sock);
    return `${chatId}::${owner}`;
}

function getGroup(sock, chatId) {
    if (!_store) loadStore();
    const key = makeKey(sock, chatId);
    return _store.groups[key] || null;
}

function setGroup(sock, chatId, data) {
    if (!_store) loadStore();
    const key = makeKey(sock, chatId);
    _store.groups[key] = { ...(getGroup(sock, chatId) || {}), chatId, ...data };
    scheduleSave();
    return _store.groups[key];
}

loadStore();
process.on('exit',   () => { try { writeStoreSync(); } catch {} });
process.on('SIGINT', () => { try { writeStoreSync(); } catch {} process.exit(0); });

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function jidToNumber(jid) {
    if (!jid) return '';
    return String(jid).split(':')[0].split('@')[0].replace(/[^0-9]/g, '');
}

function getParticipantJid(p) {
    if (!p) return '';
    if (p.jid && !p.jid.endsWith('@lid')) return p.jid;
    if (p.phoneNumber && !p.phoneNumber.endsWith('@lid')) return p.phoneNumber;
    if (p.id && !p.id.endsWith('@lid')) return p.id;
    const raw = p.id || p.jid || p.lid || '';
    return raw.endsWith('@lid') ? raw.replace('@lid', '@s.whatsapp.net') : raw;
}

function applyPlaceholders(template, ctx) {
    if (!template) return '';
    return String(template)
        .replace(/\{user\}/g,        ctx.user        || '')
        .replace(/\{group\}/g,       ctx.group       || '')
        .replace(/\{description\}/g, (ctx.description && String(ctx.description).trim()) ? ctx.description : CFG.footer)
        .replace(/\{count\}/g,       ctx.count       || '')
        .replace(/\{botname\}/g,     CFG.botName)
        .replace(/\{time\}/g,        new Date().toLocaleTimeString('en-GB'))
        .replace(/\{date\}/g,        new Date().toLocaleDateString('en-GB'));
}

async function react(sock, chatId, key, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key } }); } catch {}
}

function buildAdReply() {
    return {
        title:                 CFG.adTitle,
        body:                  CFG.adLink,
        mediaType:             1,
        thumbnailUrl:          CFG.thumbnailUrl,
        sourceUrl:             CFG.adLink,
        renderLargerThumbnail: true,
        showAdAttribution:     false,
    };
}

function buildFinalMessage(template, caption, placeholders) {
    const base = applyPlaceholders(template || '', placeholders);

    if (!caption) return base;

    const parts = base.split(/\n\n(?=[^\n]*>)/);
    if (parts.length === 2) {
        return `${parts[0]}\n\n${caption}\n\n${parts[1]}`;
    }
    const lines = base.split('\n');
    const lastLineIdx = lines.findIndex(l => l.trim().startsWith('>'));
    if (lastLineIdx !== -1) {
        lines.splice(lastLineIdx, 0, '', caption, '');
        return lines.join('\n');
    }
    return `${base}\n\n${caption}`;
}

// ══════════════════════════════════════════════════════════════════
// ─── INTERACTIVE SEND (fakeWeb + adReply + image header) ──────────
// ══════════════════════════════════════════════════════════════════
function buildForwardContext() {
    if (!CFG.forward?.enabled) return null;
    return {
        forwardingScore: CFG.forward.forwardingScore ?? 1,
        isForwarded:     CFG.forward.isForwarded ?? true,
        forwardedNewsletterMessageInfo: {
            newsletterJid:   CFG.forward.newsletterJid,
            newsletterName:  CFG.forward.newsletterName,
            serverMessageId: CFG.forward.serverMessageId ?? -1,
        },
    };
}

function buildContextInfo(fakeWeb, extra = {}) {
    const base = {};
    if (fakeWeb) {
        try {
            base.stanzaId      = fakeWeb.key?.id;
            base.participant   = fakeWeb.key?.participant;
            base.quotedMessage = fakeWeb.message;
        } catch {}
    }
    const fwd = buildForwardContext();
    if (fwd) Object.assign(base, fwd);
    const merged = { ...base, ...extra };
    return Object.keys(merged).length ? merged : null;
}

async function sendRichWelcome(sock, chatId, message, { text, mediaUrl, mediaType, mention }) {
    const fakeWeb = buildFakeWeb();
    const quoted  = { quoted: fakeWeb };
    const fwd     = buildForwardContext();
    const adCard  = buildAdReply();

    const mentions = mention ? [mention] : [];

    // ── No media → text + ad + fakeWeb ────────────────
    if (!mediaUrl) {
        try {
            await sock.sendMessage(chatId, {
                text,
                mentions,
                contextInfo: {
                    mentionedJid: mentions,
                    externalAdReply: adCard,
                    ...(fwd || {}),
                },
            }, quoted);
            return;
        } catch (e) {
            console.error('[WG] text+ad failed:', e?.message);
            await sendMessageWithChannel(sock, chatId, { text, mentions }).catch(() => {});
            return;
        }
    }

    // ── With media → InteractiveMessage with media header ──
    try {
        const mediaPayload = mediaType === 'video'
            ? { video: { url: mediaUrl }, gifPlayback: true }
            : { image: { url: mediaUrl } };

        const { prepareWAMessageMedia } = require('@whiskeysockets/baileys');
        const media = await prepareWAMessageMedia(
            mediaPayload,
            { upload: sock.waUploadToServer }
        );

        const contextInfo = buildContextInfo(fakeWeb, {
            mentionedJid: mentions,
            externalAdReply: adCard,
        });

        const msg = proto.Message.InteractiveMessage.fromObject({
            body:   { text },
            footer: { text: CFG.footer },
            header: { hasMediaAttachment: true, ...media },
            nativeFlowMessage: { buttons: [], messageParamsJson: '' },
            ...(contextInfo ? { contextInfo } : {}),
        });

        const waMsg = generateWAMessageFromContent(chatId, proto.Message.fromObject({
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata:        {},
                        deviceListMetadataVersion: 2,
                    },
                    interactiveMessage: msg,
                },
            },
        }), { userJid: chatId });

        const isGroup = chatId.endsWith('@g.us');
        const nodes = [{
            tag: 'biz', attrs: {},
            content: [{
                tag: 'interactive',
                attrs: { type: 'native_flow', v: '1' },
                content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }],
            }],
        }];
        if (!isGroup) nodes.push({ tag: 'bot', attrs: { biz_bot: '1' } });

        await sock.relayMessage(chatId, waMsg.message, {
            messageId:      waMsg.key.id,
            additionalNodes: nodes,
        });
        return;
    } catch (e) {
        console.error('[WG] interactive send failed:', e?.message);
    }

    // ── Fallback: simple media send ───────────────────
    try {
        if (mediaType === 'video') {
            await sock.sendMessage(chatId, {
                video: { url: mediaUrl },
                caption: text,
                mentions,
                contextInfo: { externalAdReply: adCard, ...(fwd || {}) },
            }, quoted);
        } else {
            await sock.sendMessage(chatId, {
                image: { url: mediaUrl },
                caption: text,
                mentions,
                contextInfo: { externalAdReply: adCard, ...(fwd || {}) },
            }, quoted);
        }
    } catch (e) {
        console.error('[WG] fallback send failed:', e?.message);
        await sendMessageWithChannel(sock, chatId, { text, mentions }).catch(() => {});
    }
}

// ══════════════════════════════════════════════════════════════════
// ─── LISTENER: group-participants.update → welcome / goodbye ──────
// ══════════════════════════════════════════════════════════════════
let _bound     = false;
let _boundSock = null;

async function onGroupParticipantsUpdate(payload) {
    try {
        const sock = _boundSock;
        if (!sock) return;

        const { id: chatId, participants, action } = payload || {};
        if (!chatId || !chatId.endsWith('@g.us') || !Array.isArray(participants)) return;

        const isAdd    = action === 'add';
        const isRemove = action === 'remove';
        if (!isAdd && !isRemove) return;

        const group  = getGroup(sock, chatId) || {};
        const cfgKey = isAdd ? 'welcome' : 'goodbye';
        const cfg    = group[cfgKey];
        // Aucun réglage global/fallback : seul le groupe ayant explicitement
        // activé cette fonction reçoit les notifications.
        if (!cfg || cfg.enabled !== true) return;

        let meta = null;
        try { meta = await sock.groupMetadata(chatId); } catch {}
        const groupName   = meta?.subject || 'Group';
        const groupDesc   = (meta?.desc && String(meta.desc).trim()) ? meta.desc : CFG.footer;
        const memberCount = meta?.participants?.length || 0;

        for (const rawId of participants) {
            const targetJid = typeof rawId === 'string' ? rawId : getParticipantJid(rawId);
            const targetNum = jidToNumber(targetJid);
            if (!targetNum) continue;

            const mention = targetNum + '@s.whatsapp.net';

            let displayName = targetNum;
            try {
                const p = meta?.participants?.find(x => jidToNumber(x.id || x.jid) === targetNum);
                if (p?.name) displayName = p.name;
                else if (p?.notify) displayName = p.notify;
            } catch {}

            const placeholders = {
                user:        `@${displayName}`,
                group:       groupName,
                description: groupDesc,
                count:       String(memberCount),
            };

            const template  = cfg.message || (isAdd ? CFG.defaultWelcome : CFG.defaultGoodbye);
            const finalText = buildFinalMessage(template, cfg.caption || '', placeholders);

            await sendRichWelcome(sock, chatId, null, {
                text:      finalText,
                mediaUrl:  cfg.mediaUrl,
                mediaType: cfg.mediaType,
                mention,
            });
        }
    } catch (e) {
        console.error('[WG-EVENT]', e?.message);
    }
}

function bindSock(sock) {
    if (_bound || !sock || !sock.ev) return;
    _bound = true;
    _boundSock = sock;
    try {
        sock.ev.on('group-participants.update', onGroupParticipantsUpdate);
        console.log(`[WG] event hook registered (owner: ${getOwnerNumber(sock)})`);
    } catch (e) {
        console.error('[WG] failed to bind:', e?.message);
        _bound = false;
    }
}

function tryBindFromGlobals() {
    const candidates = [global.sock, global.conn, global.Hanz, global.client];
    for (const c of candidates) {
        if (c && c.ev) { bindSock(c); return; }
    }
}

tryBindFromGlobals();

let _retryCount = 0;
const _retryTimer = setInterval(() => {
    if (_bound) return clearInterval(_retryTimer);
    if (++_retryCount >= 10) return clearInterval(_retryTimer);
    tryBindFromGlobals();
}, 3000);
if (_retryTimer.unref) _retryTimer.unref();

// ══════════════════════════════════════════════════════════════════
// ─── MEDIA DOWNLOAD HELPERS ───────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function downloadQuotedOrDirect(sock, message) {
    try {
        const { downloadMediaMessage } = require('@whiskeysockets/baileys');
        const ctx    = message.message?.extendedTextMessage?.contextInfo;
        const quoted = ctx?.quotedMessage;

        if (quoted) {
            const type = quoted.imageMessage
                ? 'imageMessage'
                : quoted.videoMessage
                    ? 'videoMessage'
                    : null;
            if (!type) return null;
            return await downloadMediaMessage(
                { key: message.key, message: { [type]: quoted[type] } },
                'buffer', {}, { reuploadRequest: sock.updateMediaMessage }
            );
        }

        const type = message.message?.imageMessage
            ? 'imageMessage'
            : message.message?.videoMessage
                ? 'videoMessage'
                : null;
        if (!type) return null;

        return await downloadMediaMessage(message, 'buffer', {}, {
            reuploadRequest: sock.updateMediaMessage,
        });
    } catch (e) {
        console.error('[WG] media download failed:', e?.message);
        return null;
    }
}

function getMediaType(message) {
    const ctx    = message.message?.extendedTextMessage?.contextInfo;
    const quoted = ctx?.quotedMessage;
    if (quoted?.imageMessage) return 'image';
    if (quoted?.videoMessage) return 'video';
    if (message.message?.imageMessage) return 'image';
    if (message.message?.videoMessage) return 'video';
    return null;
}

function getQuotedMediaCaption(message) {
    const ctx    = message.message?.extendedTextMessage?.contextInfo;
    const quoted = ctx?.quotedMessage;
    if (!quoted) return '';

    if (quoted.imageMessage?.caption) return quoted.imageMessage.caption;
    if (quoted.videoMessage?.caption) return quoted.videoMessage.caption;
    return '';
}

// ══════════════════════════════════════════════════════════════════
// ─── COMMAND LOGIC ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function runCmd(sock, message, args, context, kind) {
    const { chatId, reply, prefix, isGroup, isAdmin, isOwner } = context;

    if (!isGroup) return reply(`❌ This command only works in groups.`);
    if (!isAdmin && !isOwner) return reply(`❌ Only group admins can use this.`);

    const sub  = (args[0] || '').toLowerCase();
    const rest = args.slice(1).join(' ').trim();

    const group   = getGroup(sock, chatId) || {};
    const current = group[kind] || { enabled: false, message: null, mediaUrl: null, mediaType: null, caption: null };
    const emoji   = kind === 'welcome' ? '👋' : '🫡';

    // ── STATUS / HELP ────────────────────────────────
    if (!sub || sub === 'status') {
        const status = current.enabled ? '✅ Enabled' : '❌ Disabled';
        return reply(
            `${emoji} *${kind.toUpperCase()} SYSTEM*\n\n` +
            `> Status: ${status}\n` +
            `> Message: ${current.message ? 'custom' : 'default'}\n` +
            `> Media: ${current.mediaUrl ? current.mediaType : 'none'}\n` +
            `> Media caption: ${current.caption ? 'yes' : 'no'}\n\n` +
            `*Usage:*\n` +
            `> \`${prefix}${kind} on\`\n` +
            `> \`${prefix}${kind} off\`\n` +
            `> \`${prefix}${kind} set <message>\` _(reply photo/video optional)_\n` +
            `> \`${prefix}${kind} clear\` _(remove media + caption)_\n\n` +
            `*Placeholders:* {user} {group} {description} {count}`
        );
    }

    // ── ON ───────────────────────────────────────────
    if (sub === 'on') {
        setGroup(sock, chatId, { [kind]: { ...current, enabled: true } });
        await react(sock, chatId, message.key, '✅');
        return reply(`✅ *${kind} enabled* for this group.`);
    }

    // ── OFF ──────────────────────────────────────────
    if (sub === 'off') {
        setGroup(sock, chatId, { [kind]: { ...current, enabled: false } });
        await react(sock, chatId, message.key, '❌');
        return reply(`❌ *${kind} disabled* for this group.`);
    }

    // ── CLEAR MEDIA + CAPTION ────────────────────────
    if (sub === 'clear') {
        setGroup(sock, chatId, {
            [kind]: { ...current, mediaUrl: null, mediaType: null, caption: null },
        });
        await react(sock, chatId, message.key, '🗑️');
        return reply(`🗑️ *${kind} media cleared.*`);
    }

    // ── SET ──────────────────────────────────────────
    if (sub === 'set') {
        const mediaType    = getMediaType(message);
        const mediaCaption = getQuotedMediaCaption(message);

        let mediaUrl  = current.mediaUrl  || null;
        let finalType = current.mediaType || null;
        let caption   = current.caption   || null;

        if (mediaType) {
            const buffer = await downloadQuotedOrDirect(sock, message);
            if (buffer) {
                try {
                    await react(sock, chatId, message.key, '📤');
                    const ext    = mediaType === 'video' ? 'mp4' : 'jpg';
                    const fname  = `${kind}_${Date.now()}.${ext}`;
                    const result = await uploadMedia(buffer, fname);
                    mediaUrl  = result.url;
                    finalType = mediaType;
                } catch (e) {
                    console.error('[WG] media upload failed:', e?.message);
                    return reply(`❌ Media upload failed:\n${e.message}`);
                }
            }
            caption = mediaCaption || null;
        }

        const newMessage = rest || current.message || null;

        if (!newMessage && !mediaUrl) {
            return reply(
                `❌ Provide a message or reply to a photo/video.\n\n` +
                `Ex: \`${prefix}${kind} set Welcome {user} to {group}!\``
            );
        }

        setGroup(sock, chatId, {
            [kind]: {
                ...current,
                enabled:   true,
                message:   newMessage,
                mediaUrl:  mediaUrl,
                mediaType: mediaUrl ? finalType : null,
                caption:   mediaUrl ? caption : null,
            },
        });

        await react(sock, chatId, message.key, '✅');
        // ⚠️ No URL shown in the reply
        return reply(
            `✅ *${kind} updated*\n\n` +
            `> Message: ${newMessage ? 'custom' : 'default'}\n` +
            `> Media: ${mediaUrl ? finalType : 'none'}\n` +
            `> Caption: ${caption ? 'yes' : 'no'}\n` +
            `> Status: ✅ Enabled`
        );
    }

    return reply(
        `❌ Invalid option.\n\n> Use \`${prefix}${kind} on\`, \`${prefix}${kind} off\`, \`${prefix}${kind} set <msg>\`, \`${prefix}${kind} clear\``
    );
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const GOODBYE_ALIASES = ['goodbye', 'gb', 'bye', 'setgoodbye', 'endmsg', 'farewell'];

module.exports = {
    command: 'welcome',
    aliases: ['wc', 'wel', 'setwelcome', 'startmsg', ...GOODBYE_ALIASES],
    category:    'group',
    description: 'Welcome / Goodbye per-group, per-owner system (Catbox → Pone → Qu.ax)',
    usage:       '.welcome <on|off|set|status|clear> | .goodbye <on|off|set|status|clear>',

    async handler(sock, message, args, context) {
        if (!_bound) bindSock(sock);

        const cmd  = (context?.command || 'welcome').toLowerCase();
        const kind = GOODBYE_ALIASES.includes(cmd) ? 'goodbye' : 'welcome';

        return runCmd(sock, message, args, context, kind);
    },

    _getGroup:        getGroup,
    _setGroup:        setGroup,
    _getOwnerNumber:  getOwnerNumber,
    _uploadToCatbox:  uploadToCatbox,
    _uploadToPone:    uploadToPone,
    _uploadToQuax:    uploadToQuax,
    _uploadMedia:     uploadMedia,
};