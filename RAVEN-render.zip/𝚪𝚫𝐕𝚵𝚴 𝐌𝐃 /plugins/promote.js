'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function numOf(jid) {
    if (!jid) return '';
    return String(jid).split(':')[0].split('@')[0].replace(/[^0-9]/g, '');
}

function getParticipantJid(p) {
    if (!p) return '';
    if (p.jid && !p.jid.endsWith('@lid')) return p.jid;
    if (p.phoneNumber && !p.phoneNumber.endsWith('@lid')) return p.phoneNumber;
    if (p.id && !p.id.endsWith('@lid')) return p.id;
    const raw = p.id || p.jid || p.lid || '';
    return raw.endsWith('@lid') ? raw.replace('@lid', '@s.whatsapp.net') : raw;
}

function getMentions(m) {
    const ctx =
        m?.message?.extendedTextMessage?.contextInfo ||
        m?.message?.imageMessage?.contextInfo ||
        m?.message?.videoMessage?.contextInfo ||
        null;
    return ctx?.mentionedJid || [];
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch { /* ignore */ }
}

function delay(ms) {
    return new Promise(res => setTimeout(res, ms));
}

// ══════════════════════════════════════════════════════════════════
// ─── COMMAND: totag ───────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function cmdToTag(sock, m, args, context) {
    const { chatId, reply, prefix, groupMetadata } = context;

    // ── Require quoted message ────────────────────────────────
    if (!m?.quoted) {
        return reply(
            `📢 *TOTAG*\n\n` +
            `> Reply to the message you want to forward to all members\n\n` +
            `> Example: Reply + \`${prefix}totag\``,
        );
    }

    await react(sock, chatId, m.key, '📢');

    try {
        const participants = groupMetadata?.participants || [];

        if (participants.length === 0) {
            await react(sock, chatId, m.key, '❌');
            return reply(`❌ Could not read group members.`);
        }

        // ── Exclude bot itself ────────────────────────────────
        const botNum = numOf(sock.user?.id);
        const users = participants
            .map(p => getParticipantJid(p))
            .filter(jid => jid && numOf(jid) !== botNum);

        // ── Forward the quoted message with mentions ─────────
        await sock.sendMessage(chatId, {
            forward: m.quoted,
            mentions: users,
        });

        await react(sock, chatId, m.key, '✅');

    } catch (err) {
        console.error('[TOTAG]', err?.message || err);
        await react(sock, chatId, m.key, '☢');
        return reply(global.mess?.error?.fitur || 'Failed to tag all members.');
    }
}

// ══════════════════════════════════════════════════════════════════
// ─── COMMAND: spamtag ─────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function cmdSpamTag(sock, m, args, context) {
    const { chatId, reply, prefix, isOwner, isPremium } = context;

    // ── Require a target mention ──────────────────────────────
    const mentions = getMentions(m);
    const target = mentions[0];

    if (!target) {
        return reply(`❌ Tag someone first. Example: \`${prefix}spamtag @user\``);
    }

    // ── Determine spam limit ──────────────────────────────────
    // owner  : 10
    // premium: 5
    // normal : 3
    const limit = isOwner ? 10 : isPremium ? 5 : 3;

    const targetNum = numOf(target);

    // ── Spam send ─────────────────────────────────────────────
    try {
        for (let i = 0; i < limit; i++) {
            await delay(700);
            await sendMessageWithChannel(sock, chatId, {
                text: `@${targetNum}`,
                mentions: [target],
            });
        }

        await sendMessageWithChannel(sock, chatId, {
            text: `✅ Spam tag done (${limit}x)`,
        });
    } catch (e) {
        console.error('[SPAMTAG]', e?.message);
        return reply(`❌ Error\nLogs: ${e.message}`);
    }
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'totag',
    aliases:     ['tagall2', 'mentionall', 'spamtag'],
    category:    'group',
    description: 'Tag/forward to all members or spam-mention one',
    usage:       '.totag (reply) | .spamtag @user',

    async handler(sock, m, args, context) {
        const { chatId, reply, isGroup, isOwner, isAdmin, isBotAdmin } = context;

        // ── Guards ────────────────────────────────────────────────
        if (!isGroup) {
            return reply(global.mess?.only?.group || 'This command only works in groups.');
        }
        if (!isAdmin && !isOwner) {
            return reply(global.mess?.only?.admin || 'Admin only.');
        }

        const cmd = (context.command || 'totag').toLowerCase();

        try {
            if (cmd === 'spamtag') {
                return cmdSpamTag(sock, m, args, context);
            }
            // totag, tagall2, mentionall
            return cmdToTag(sock, m, args, context);
        } catch (err) {
            console.error(`[TAG-PACK:${cmd}]`, err?.message || err);
            await react(sock, chatId, m.key, '❌');
            return reply(global.mess?.error?.fitur || 'Tag error. Please try again.');
        }
    },
};