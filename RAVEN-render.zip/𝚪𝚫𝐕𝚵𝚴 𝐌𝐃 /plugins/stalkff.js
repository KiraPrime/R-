'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const axios = require('axios');

// ══════════════════════════════════════════════════════════════════
// ─── FORWARD NEWSLETTER CONTEXT ───────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── CONFIG ───────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const CFG = {
    apiBase: 'https://api.nexray.eu.cc/stalker/freefire',
    timeout: 30000,
    ua:      'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
};

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {}
}

function isValidUrl(url) {
    return typeof url === 'string' && /^https?:\/\//i.test(url);
}

function buildCaption(r) {
    let caption = `🔥 *FREE FIRE STALK — PROFILE INFO* 🔥\n\n`;
    caption += `Results for UID *${r.uid || '-'}*:\n\n`;

    caption += `👤 *BASIC INFO*\n`;
    caption += `  - Name         : *${r.name || '-'}*\n`;
    caption += `  - Level        : ${r.level || '-'} (EXP: ${r.exp || '-'})\n`;
    caption += `  - Region       : ${r.region || '-'}\n`;
    caption += `  - Likes        : ${r.likes || '-'} ❤️\n`;
    caption += `  - Credit Score : ${r.credit_score || '-'}\n`;
    caption += `  - Bio          : ${r.signature || '-'}\n\n`;

    caption += `🏆 *RANKING & ACTIVITY*\n`;
    caption += `  - BR Rank Point : ${r.br_rank_point || '-'} (Max: ${r.br_max_rank || '-'})\n`;
    caption += `  - CS Rank Point : ${r.cs_rank_point || '-'} (Max: ${r.cs_max_rank || '-'})\n`;
    caption += `  - Season ID     : ${r.season_id || '-'}\n`;
    caption += `  - Created at    : ${r.created_at || '-'}\n`;
    caption += `  - Last login    : ${r.last_login || '-'}\n\n`;

    caption += `🛡️ *GUILD INFO*\n`;
    caption += `  - Guild name : ${r.guild_name && r.guild_name !== 'None' ? r.guild_name : 'No guild'}\n`;
    if (r.guild_name && r.guild_name !== 'None') {
        caption += `  - Guild level  : ${r.guild_level || '-'}\n`;
        caption += `  - Members      : ${r.guild_member || '-'}/${r.guild_capacity || '-'}\n`;
        caption += `  - Guild leader : ${r.guild_leader_name || '-'} (UID: ${r.guild_leader_uid || '-'})\n`;
    }
    caption += `\n`;

    caption += `🐾 *PET INFO*\n`;
    caption += `  - Pet level : ${r.pet_level || '-'}\n`;
    caption += `  - Pet EXP   : ${r.pet_exp || '-'}\n\n`;

    caption += `🔧 *MISC*\n`;
    caption += `  - Language     : ${r.language ? String(r.language).replace('Language_', '') : '-'}\n`;
    caption += `  - Favorite mode: ${r.mode_prefer ? String(r.mode_prefer).replace('ModePrefer_', '') : '-'}\n\n`;

    caption += `Share this profile with your friends! 🚀`;
    return caption;
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'ffstalk',
    aliases:     ['freefirestalk', 'ffstalker', 'firestalk'],
    category:    'stalker',
    description: 'Look up a Free Fire player profile by UID',
    usage:       '.ffstalk <uid>',

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix } = context;

        const uid = (args[0] || '').trim();

        if (!uid) {
            return reply(
                `❌ *FREE FIRE UID MISSING*\n\n` +
                `> Provide the Free Fire UID to stalk.\n\n` +
                `\`Example: ${prefix}ffstalk 470699855\``,
            );
        }

        await react(sock, chatId, m.key, '🕕');

        try {
            const res = await axios.get(
                `${CFG.apiBase}?uid=${encodeURIComponent(uid)}`,
                {
                    timeout: CFG.timeout,
                    headers: { 'User-Agent': CFG.ua },
                },
            );

            const data = res.data;

            if (!data?.status || !data?.result) {
                await react(sock, chatId, m.key, '❌');
                return reply(
                    `⚠️ *LOOKUP FAILED*\n\n` +
                    `UID *${uid}* was not found, or the API is currently unavailable.\n` +
                    `Double-check the UID and try again.`,
                );
            }

            const r = data.result;
            const caption = buildCaption(r);

            if (isValidUrl(r.banner_image)) {
                await sendMessageWithChannel(sock, chatId, {
                    image:   { url: r.banner_image },
                    caption,
                }, { quoted: m });
            } else {
                await sendMessageWithChannel(sock, chatId, { text: caption }, { quoted: m });
            }

            await react(sock, chatId, m.key, '✅');

        } catch (error) {
            console.error('[FFSTALK]', error?.message || error);
            await react(sock, chatId, m.key, '☢');
            return reply(
                `😔 *SYSTEM ERROR*\n\n` +
                `Failed to fetch data from the Free Fire server. Please try again later.`,
            );
        }
    },
};