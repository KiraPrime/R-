'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const S = require("./rimuru-store");
async function handler(sock,m,args,ctx={}){
 const me=S.get(ctx.sender||m.sender,ctx.pushname||m.pushName);
 const reply=(text,opts)=>ctx.reply?ctx.reply(text,opts):sock.sendMessage(ctx.chatId||m.key?.remoteJid,{text,...(opts||{})});
 const to=S.target(m,ctx),amount=parseInt(args.find(x=>/^\d+$/.test(x))||"0");if(!to||amount<=0)return reply("Usage: *.transfer @user <amount>*");if(me.cash<amount)return reply("❌ Insufficient cash.");const other=S.get(to);me.cash-=amount;other.cash+=amount;S.save();return reply(`✅ Transferred *$${S.money(amount)}* to *@${S.id(to)}*.`,{mentions:[to]});
}
module.exports={command:"transfer",aliases:['pay'],category:"rpg",description:'Transfer cash to another user',handler};
