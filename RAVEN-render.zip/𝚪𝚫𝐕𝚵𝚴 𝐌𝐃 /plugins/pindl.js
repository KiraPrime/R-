'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const fs    = require('fs');
const path  = require('path');
const axios = require('axios');
const { spawn } = require('child_process');

// ══════════════════════════════════════════════════════════════════
// ─── FORWARD NEWSLETTER CONTEXT ───────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚫𝚪𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── CONFIG ───────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const CFG = {
    apiBase: 'https://api.azbry.com/api/download/pinterest',
    timeout: 30000,
    ua:      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    referer: 'https://www.pinterest.com/',
};

// ══════════════════════════════════════════════════════════════════
// ─── FFMPEG QUEUE (inlined from rimuru-ffmpeg.js) ─────────────────
// ══════════════════════════════════════════════════════════════════
const _ffmpegQueue = [];
let _ffmpegBusy = false;

function queueFFmpeg(cmd, timeoutMs = 120000) {
    return new Promise((resolve, reject) => {
        const task = { cmd, timeoutMs, resolve, reject };
        _ffmpegQueue.push(task);
        _runQueue();
    });
}

function _runQueue() {
    if (_ffmpegBusy) return;
    const task = _ffmpegQueue.shift();
    if (!task) return;

    _ffmpegBusy = true;
    const proc = spawn(task.cmd, { shell: true, stdio: ['ignore', 'pipe', 'pipe'] });

    let stderr = '';
    proc.stderr.on('data', d => { stderr += d.toString(); });

    const timer = setTimeout(() => {
        try { proc.kill('SIGKILL'); } catch {}
        task.reject(new Error(`FFmpeg timeout after ${task.timeoutMs / 1000}s`));
        _ffmpegBusy = false;
        _runQueue();
    }, task.timeoutMs);

    proc.on('error', err => {
        clearTimeout(timer);
        task.reject(err);
        _ffmpegBusy = false;
        _runQueue();
    });

    proc.on('close', code => {
        clearTimeout(timer);
        if (code === 0) task.resolve();
        else task.reject(new Error(`FFmpeg exit code ${code}: ${stderr.trim().slice(-200)}`));
        _ffmpegBusy = false;
        _runQueue();
    });
}

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {}
}

function ensureTempDir() {
    const tempDir = path.join(process.cwd(), 'temp');
    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
    return tempDir;
}

function cleanFiles(...files) {
    for (const f of files) {
        try { if (f && fs.existsSync(f)) fs.unlinkSync(f); } catch {}
    }
}

async function downloadBuffer(url) {
    const res = await axios.get(url, {
        responseType: 'arraybuffer',
        timeout: 60000,
        headers: {
            'User-Agent': CFG.ua,
            'Referer':    CFG.referer,
        },
    });
    return Buffer.from(res.data);
}

// ══════════════════════════════════════════════════════════════════
// ─── HLS VIDEO DOWNLOADER ─────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function downloadHlsVideo(masterUrl, tempDir) {
    const timestamp = Date.now();
    const videoTemp  = path.join(tempDir, `${timestamp}_v.mp4`);
    const audioTemp  = path.join(tempDir, `${timestamp}_a.mp4`);
    const outputFile = path.join(tempDir, `${timestamp}_final.mp4`);

    try {
        const resHls = await axios.get(masterUrl, {
            headers: { 'User-Agent': CFG.ua, 'Referer': CFG.referer },
        });
        const text  = String(resHls.data);
        const lines = text.split('\n').map(l => l.trim()).filter(Boolean);

        const baseUrl = masterUrl.substring(0, masterUrl.lastIndexOf('/') + 1);
        let videoStreamUrl = null;
        let audioStreamUrl = null;
        let lastBandwidth  = 0;

        for (let i = 0; i < lines.length; i++) {
            if (lines[i].startsWith('#EXT-X-STREAM-INF')) {
                const bwMatch = lines[i].match(/BANDWIDTH=(\d+)/);
                const bw = bwMatch ? parseInt(bwMatch[1]) : 0;
                if (bw > lastBandwidth) {
                    lastBandwidth = bw;
                    const u = lines[i + 1];
                    videoStreamUrl = u?.startsWith('http') ? u : baseUrl + u;
                }
            }
            if (lines[i].startsWith('#EXT-X-MEDIA') && lines[i].includes('TYPE=AUDIO')) {
                const mUrl = lines[i].match(/URI="([^"]+)"/);
                if (mUrl) audioStreamUrl = mUrl[1].startsWith('http') ? mUrl[1] : baseUrl + mUrl[1];
            }
        }

        const hdr = `-user_agent "${CFG.ua}" -headers "Referer: ${CFG.referer}"`;

        if (!videoStreamUrl) {
            await queueFFmpeg(`ffmpeg -y ${hdr} -i "${masterUrl}" -c copy "${outputFile}"`);
        } else {
            await queueFFmpeg(`ffmpeg -y ${hdr} -i "${videoStreamUrl}" -c copy "${videoTemp}"`);
            if (audioStreamUrl) {
                await queueFFmpeg(`ffmpeg -y ${hdr} -i "${audioStreamUrl}" -c copy "${audioTemp}"`);
                await queueFFmpeg(`ffmpeg -y -i "${videoTemp}" -i "${audioTemp}" -c copy "${outputFile}"`);
            } else {
                fs.renameSync(videoTemp, outputFile);
            }
        }

        const buffer = fs.readFileSync(outputFile);
        return buffer;
    } finally {
        cleanFiles(videoTemp, audioTemp, outputFile);
    }
}

// ══════════════════════════════════════════════════════════════════
// ─── GIF → MP4 ────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function gifToMp4(gifUrl, tempDir) {
    const id = Date.now();
    const gifPath = path.join(tempDir, `pin-${id}.gif`);
    const mp4Path = path.join(tempDir, `pin-${id}.mp4`);

    try {
        const raw = await downloadBuffer(gifUrl);
        if (!raw) throw new Error('Failed to download GIF');
        fs.writeFileSync(gifPath, raw);

        await queueFFmpeg(
            `ffmpeg -y -ignore_loop 0 -i "${gifPath}" -t 30 ` +
            `-vf "scale=trunc(iw/2)*2:trunc(ih/2)*2" ` +
            `-c:v libx264 -pix_fmt yuv420p -movflags faststart -preset ultrafast -an "${mp4Path}"`,
        );

        if (!fs.existsSync(mp4Path)) throw new Error('Failed to convert GIF');
        return fs.readFileSync(mp4Path);
    } finally {
        cleanFiles(gifPath, mp4Path);
    }
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'pindl',
    aliases:     ['pinterestdl', 'pindownload', 'pinterest'],
    category:    'download',
    description: 'Download image / video from Pinterest',
    usage:       '.pindl <url>',

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix } = context;

        const url = (args.join(' ') || '').trim();

        if (!url) {
            return reply(
                `📌 *PINTEREST DOWNLOAD*\n\n` +
                `> Download image / video from Pinterest\n\n` +
                `*Examples:*\n` +
                `> \`${prefix}pindl https://pin.it/xxx\`\n` +
                `> \`${prefix}pindl https://pinterest.com/pin/xxx\``,
            );
        }

        if (!url.includes('pinterest') && !url.includes('pin.it')) {
            return reply(`❌ Invalid URL. Please provide a Pinterest link.`);
        }

        await react(sock, chatId, m.key, '🕕');

        try {
            const res = await axios.get(
                `${CFG.apiBase}?url=${encodeURIComponent(url)}`,
                { timeout: CFG.timeout },
            );

            if (!res.data?.status || !res.data?.result) {
                throw new Error('Failed to fetch data from Pinterest API.');
            }

            const data = res.data.result;
            const mediaList = [];

            // ── Build media list ──────────────────────────────────
            if (data.type === 'video') {
                const vidUrl = data.videos?.[0]?.url || data.download;
                if (vidUrl) mediaList.push({ type: 'video', url: vidUrl });
            }

            if (data.images && data.images.length > 0) {
                const orig = data.images.find(img => img.name === 'orig')
                          || data.images[data.images.length - 1];
                if (orig?.url) mediaList.push({ type: 'image', url: orig.url });
            } else if (data.type === 'image' && data.download) {
                mediaList.push({ type: 'image', url: data.download });
            }

            if (mediaList.length === 0) {
                throw new Error('No media found.');
            }

            // ── Process each media ────────────────────────────────
            const tempDir = ensureTempDir();

            for (const media of mediaList) {
                if (media.type === 'video') {
                    let buffer = null;

                    // Try HLS download
                    try {
                        let masterUrl = media.url;
                        if (masterUrl.includes('.mp4')) {
                            masterUrl = masterUrl
                                .replace(/720p|480p|360p|240p/g, 'hls')
                                .replace('.mp4', '.m3u8');
                        }
                        buffer = await downloadHlsVideo(masterUrl, tempDir);
                    } catch (err) {
                        console.error('[PINDL] HLS failed, fallback:', err.message);
                        try {
                            buffer = await downloadBuffer(media.url);
                        } catch (fallbackErr) {
                            console.error('[PINDL] fallback failed:', fallbackErr.message);
                        }
                    }

                    if (buffer) {
                        await sendMessageWithChannel(sock, chatId, {
                            video: buffer,
                            mimetype: 'video/mp4',
                        }, { quoted: m });
                    }
                } else if (media.type === 'image') {
                    // GIF → MP4
                    if (media.url.includes('gif')) {
                        try {
                            const mp4Buffer = await gifToMp4(media.url, tempDir);
                            await sendMessageWithChannel(sock, chatId, {
                                video: buffer ? undefined : mp4Buffer,
                                gifPlayback: true,
                                mimetype: 'video/mp4',
                            }, { quoted: m });
                        } catch (gifErr) {
                            console.error('[PINDL] GIF convert failed:', gifErr.message);
                            // Fallback : send as image
                            await sendMessageWithChannel(sock, chatId, {
                                image: { url: media.url },
                            }, { quoted: m });
                        }
                    } else {
                        await sendMessageWithChannel(sock, chatId, {
                            image: { url: media.url },
                        }, { quoted: m });
                    }
                }
            }

            await react(sock, chatId, m.key, '✅');

        } catch (error) {
            console.error('[PINDL]', error?.message || error);
            await react(sock, chatId, m.key, '☢');
            return reply(global.mess?.error?.fitur || 'Pinterest download failed.');
        }
    },
};