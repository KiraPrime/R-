/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

/*****************************************************************************
 *                                                                           *
 *                     Developed By Qasim Ali                                *
 *                                                                           *
 *  🌐  GitHub   : https://github.com/GlobalTechInfo                         *
 *  ▶️  YouTube  : https://youtube.com/@GlobalTechInfo                       *
 *  💬  WhatsApp : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w     *
 *                                                                           *
 *    © 2026 GlobalTechInfo. All rights reserved.                            *
 *                                                                           *
 *    Description: This file is part of the 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 Project.                 *
 *                 Unauthorized copying or distribution is prohibited.       *
 *                                                                           *
 *****************************************************************************/
const axios = require('axios');
module.exports = {
    command: 'alamy',
    aliases: ['alamydl', 'alamydownload'],
    category: 'download',
    description: 'Download image or video from Alamy URL',
    usage: '.alamy <Alamy URL>',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const url = args?.[0]?.trim();
        if (!url) {
            return await sendMessageWithChannel(sock, chatId, { text: '❌ Please provide an Alamy URL.\nExample: .alamy https://www.alamy.com/video/beautiful-lake...' }, { quoted: message });
        }
        try {
            const apiUrl = `https://discardapi.dpdns.org/api/dl/alamy?apikey=guru&url=${encodeURIComponent(url)}`;
            const { data } = await axios.get(apiUrl, { timeout: 10000 });
            if (!data?.status || !data.result?.length) {
                return await sendMessageWithChannel(sock, chatId, { text: '❌ Failed to fetch media from the provided Alamy URL.' }, { quoted: message });
            }
            const isValidUrl = (u) => u && u.startsWith('http');
            let sent = false;
            for (const item of data.result) {
                if (isValidUrl(item.video)) {
                    await sendMessageWithChannel(sock, chatId, { video: { url: item.video }, caption: '🎬 *Alamy Video*' }, { quoted: message });
                    sent = true;
                }
                if (isValidUrl(item.image)) {
                    await sendMessageWithChannel(sock, chatId, { image: { url: item.image }, caption: '🖼️ *Alamy Image*' }, { quoted: message });
                    sent = true;
                }
            }
            if (!sent) {
                await sendMessageWithChannel(sock, chatId, { text: '❌ No valid media found in the Alamy URL.' }, { quoted: message });
            }
        }
        catch (error) {
            console.error('Alamy download plugin error:', error);
            if (error.code === 'ECONNABORTED') {
                await sendMessageWithChannel(sock, chatId, { text: '❌ Request timed out. The API may be slow or unreachable.' }, { quoted: message });
            }
            else {
                await sendMessageWithChannel(sock, chatId, { text: '❌ Failed to download media from Alamy URL.' }, { quoted: message });
            }
        }
    }
};
/*****************************************************************************
 *                                                                           *
 *                     Developed By Qasim Ali                                *
 *                                                                           *
 *  🌐  GitHub   : https://github.com/GlobalTechInfo                         *
 *  ▶️  YouTube  : https://youtube.com/@GlobalTechInfo                       *
 *  💬  WhatsApp : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w     *
 *                                                                           *
 *    © 2026 GlobalTechInfo. All rights reserved.                            *
 *                                                                           *
 *    Description: This file is part of the 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 Project.                 *
 *                 Unauthorized copying or distribution is prohibited.       *
 *                                                                           *
 *****************************************************************************/
