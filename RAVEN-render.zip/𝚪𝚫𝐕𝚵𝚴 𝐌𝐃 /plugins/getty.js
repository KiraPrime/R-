/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require('axios');
module.exports = {
    command: 'getty',
    aliases: ['gettyvideo', 'gettydl'],
    category: 'download',
    description: 'Download video or image from Getty Images',
    usage: '.getty <Getty URL>',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const url = args?.[0];
        if (!url) {
            return await sendMessageWithChannel(sock, chatId, { text: 'Please provide a Getty URL.\nExample: .getty https://www.gettyimages.com/detail/video/482277170' }, { quoted: message });
        }
        try {
            const apiUrl = `https://discardapi.dpdns.org/api/dl/getty?apikey=guru&url=${encodeURIComponent(url)}`;
            const { data } = await axios.get(apiUrl, { timeout: 10000 });
            if (!data?.status || !data.result?.length) {
                return await sendMessageWithChannel(sock, chatId, { text: '❌ No video found for this URL.' }, { quoted: message });
            }
            const videoUrl = data.result[0].video;
            const imageUrl = data.result[0].image;
            if (imageUrl) {
                await sendMessageWithChannel(sock, chatId, { image: { url: imageUrl }, caption: '🖼️ Getty Thumbnail' }, { quoted: message });
            }
            if (videoUrl) {
                await sendMessageWithChannel(sock, chatId, { video: { url: videoUrl }, caption: '🎬 Getty Video' }, { quoted: message });
            }
        }
        catch (error) {
            console.error('Getty plugin error:', error);
            if (error.code === 'ECONNABORTED') {
                await sendMessageWithChannel(sock, chatId, { text: '❌ Request timed out. The API may be slow or unreachable.' }, { quoted: message });
            }
            else {
                await sendMessageWithChannel(sock, chatId, { text: '❌ Failed to fetch Getty video.' }, { quoted: message });
            }
        }
    }
};
