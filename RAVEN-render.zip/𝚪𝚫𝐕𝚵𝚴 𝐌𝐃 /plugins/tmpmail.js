'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const axios = require('axios');
const fs    = require('fs');
const path  = require('path');

// ══════════════════════════════════════════════════════════════════
// ─── INTERNAL STORE (self-sufficient) ─────────────────────────────
// ══════════════════════════════════════════════════════════════════
const DATA_DIR   = path.join(__dirname, 'tempmail-data');
const STORE_PATH = path.join(DATA_DIR, 'store.json');

let _store     = null;
let _saveTimer = null;

function ensureDir() {
    try {
        if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    } catch (e) { console.error('[TEMPMAIL] mkdir failed:', e?.message); }
}

function loadStore() {
    ensureDir();
    try {
        if (fs.existsSync(STORE_PATH)) {
            const raw = fs.readFileSync(STORE_PATH, 'utf8').trim();
            if (raw) {
                const parsed = JSON.parse(raw);
                _store = { users: { ...(parsed.users || {}) } };
                return _store;
            }
        }
    } catch (e) {
        console.error('[TEMPMAIL] store corrupted, rebuilding:', e?.message);
        try {
            const backup = STORE_PATH + '.corrupted.' + Date.now() + '.bak';
            if (fs.existsSync(STORE_PATH)) fs.copyFileSync(STORE_PATH, backup);
        } catch {}
    }
    _store = { users: {} };
    writeStoreSync();
    return _store;
}

function writeStoreSync() {
    try {
        ensureDir();
        const tmp = STORE_PATH + '.tmp';
        fs.writeFileSync(tmp, JSON.stringify(_store, null, 2), 'utf8');
        fs.renameSync(tmp, STORE_PATH);
    } catch (e) { console.error('[TEMPMAIL] store write failed:', e?.message); }
}

function scheduleSave() {
    if (_saveTimer) clearTimeout(_saveTimer);
    _saveTimer = setTimeout(() => { _saveTimer = null; writeStoreSync(); }, 500);
    if (_saveTimer.unref) _saveTimer.unref();
}

function getUser(jid) {
    if (!_store) loadStore();
    return _store.users[jid] || null;
}

function setUser(jid, data) {
    if (!_store) loadStore();
    _store.users[jid] = { ...(getUser(jid) || {}), ...data };
    scheduleSave();
    return _store.users[jid];
}

loadStore();
process.on('exit',   () => { try { writeStoreSync(); } catch {} });
process.on('SIGINT', () => { try { writeStoreSync(); } catch {} process.exit(0); });

// ══════════════════════════════════════════════════════════════════
// ─── TEMPMAIL API ─────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function generateCORS(length = 15) {
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result  = '';
    for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
}

function buildHeaders() {
    return {
        'Content-Type':        'application/json',
        'Application-Name':    'web',
        'Application-Version': '4.0.0',
        'X-CORS-Header':       generateCORS(),
        'User-Agent':          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
        Referer:               'https://temp-mail.io/',
    };
}

async function TempMailCreate() {
    try {
        const response = await axios.post(
            'https://api.internal.temp-mail.io/api/v3/email/new',
            { min_name_length: 10, max_name_length: 12 },
            { headers: buildHeaders() }
        );
        return { status: true, email: response.data.email };
    } catch (e) {
        return { status: false, error: e.message };
    }
}

async function TempMailInbox(email) {
    try {
        const response = await axios.get(
            `https://api.internal.temp-mail.io/api/v3/email/${email}/messages`,
            { headers: buildHeaders() }
        );
        const messages = response.data || [];
        return { status: true, email, count: messages.length, messages };
    } catch (e) {
        return { status: false, error: e.message };
    }
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'tempmail',
    aliases:     ['tmpmail', 'tempm'],
    category:    'tools',
    description: 'Create a temporary email & check inbox — © 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
    usage:       '.tempmail <create|inbox>',

    async handler(sock, message, args, context) {
        const { chatId, reply, sender, prefix } = context;
        const option = (args[0] || '').toLowerCase().trim();

        // ─── No args → help menu ─────────────────────────
        if (!option) {
            const saved = getUser(sender)?.tempmail;
            return reply(
                `📧 *Temp Mail*\n\n` +
                `Create a temporary email that can receive messages — perfect for signing up without exposing your real address.\n\n` +
                `*USAGE:*\n` +
                `> *${prefix}tempmail create* — Create a new email\n` +
                `> *${prefix}tempmail inbox* — Check your inbox\n\n` +
                (saved
                    ? `> Active email: *${saved}*\n`
                    : `> No email yet — use *${prefix}tempmail create* first\n`) +
                `\n_This email is temporary and can disappear at any time_`
            );
        }

        // ─── CREATE ──────────────────────────────────────
        if (option === 'create') {
            await sock.sendMessage(chatId, { react: { text: '🕕', key: message.key } }).catch(() => {});

            const result = await TempMailCreate();
            if (!result.status) {
                await sock.sendMessage(chatId, { react: { text: '☢', key: message.key } }).catch(() => {});
                return reply(`❌ *Failed to create email*\n\n> ${result.error}`);
            }

            setUser(sender, { tempmail: result.email });

            await sock.sendMessage(chatId, { react: { text: '✅', key: message.key } }).catch(() => {});
            return reply(
                `📧 *Temporary Email Created!*\n\n` +
                `> 📬 Email: *${result.email}*\n\n` +
                `You can now use this email to sign up for anything.\n` +
                `Check incoming messages with *${prefix}tempmail inbox*\n\n` +
                `_This email is temporary — do not use it for important things_`
            );
        }

        // ─── INBOX ───────────────────────────────────────
        if (option === 'inbox') {
            const saved = getUser(sender)?.tempmail;
            if (!saved) {
                await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } }).catch(() => {});
                return reply(
                    `❌ *No Email Yet*\n\n` +
                    `You haven't created a temporary email.\n` +
                    `Use *${prefix}tempmail create* first.`
                );
            }

            await sock.sendMessage(chatId, { react: { text: '🕕', key: message.key } }).catch(() => {});

            const result = await TempMailInbox(saved);
            if (!result.status) {
                await sock.sendMessage(chatId, { react: { text: '☢', key: message.key } }).catch(() => {});
                return reply(`❌ *Failed to check inbox*\n\n> ${result.error}`);
            }

            if (result.count === 0) {
                await sock.sendMessage(chatId, { react: { text: '📭', key: message.key } }).catch(() => {});
                return reply(
                    `📭 *Inbox Empty*\n\n` +
                    `> Email: *${saved}*\n\n` +
                    `No incoming messages yet. Try again later.`
                );
            }

            let txt = `📬 *Inbox — ${result.count} message(s)*\n\n`;
            txt += `> Email: *${saved}*\n\n`;

            for (const msg of result.messages) {
                txt += `*━━━━━━━━━━━━━━━━━━━━*\n`;
                txt += `> 📧 From: *${msg.from}*\n`;
                txt += `> 📌 Subject: *${msg.subject}*\n`;
                txt += `> 🕐 ${msg.created_at}\n`;
                txt += `> 📝 ${msg.body_text?.substring(0, 500) || '(no content)'}\n\n`;
            }

            await sock.sendMessage(chatId, { react: { text: '✅', key: message.key } }).catch(() => {});
            return reply(txt.trim());
        }

        // ─── Unknown option ──────────────────────────────
        return reply(
            `❌ *Invalid option*\n\n> Use *${prefix}tempmail create* or *${prefix}tempmail inbox*`
        );
    },

    // Expose helpers for future use
    _TempMailCreate: TempMailCreate,
    _TempMailInbox:  TempMailInbox,
};