'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const axios = require('axios');

// ══════════════════════════════════════════════════════════════════
// ─── FORWARD NEWSLETTER CONTEXT (mandatory on all plugins) ────────
// ══════════════════════════════════════════════════════════════════
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── CONFIG ───────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const CFG = {
    apiBase:         'https://firefly.maiku.my.id/api/stalk-tiktok',
    // Priority: global.apiKeys?.firefly > this value
    fireflyApiKey:   'OurinNextGen',
    timeout:         30000,
};

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch { /* ignore */ }
}

function shortNum(num) {
    if (!num) return '0';
    num = parseInt(num, 10);
    if (Number.isNaN(num)) return '0';
    if (num >= 1_000_000_000) return (num / 1_000_000_000).toFixed(1).replace('.0', '') + 'B';
    if (num >= 1_000_000)     return (num / 1_000_000).toFixed(1).replace('.0', '') + 'M';
    if (num >= 1_000)         return (num / 1_000).toFixed(1).replace('.0', '') + 'K';
    return String(num);
}

function getFireflyKey() {
    return global.apiKeys?.firefly || CFG.fireflyApiKey;
}

function buildCaption(d) {
    const s = d.stats || {};
    return (
        `🎵 *TIKTOK STALK*\n\n` +
        `👤 *Username:* @${d.username}\n` +
        `📛 *Name:* ${d.nickname || '-'}\n` +
        `✅ *Verified:* ${d.verified ? 'Yes' : 'No'}\n` +
        `🔒 *Private:* ${d.private ? 'Yes' : 'No'}\n\n` +
        `👥 *Followers:* ${shortNum(s.followers)}\n` +
        `👤 *Following:* ${shortNum(s.following)}\n` +
        `❤️ *Likes:* ${shortNum(s.hearts)}\n` +
        `🎬 *Videos:* ${shortNum(s.videos)}\n\n` +
        `📝 *Bio:*\n${d.signature || '-'}\n\n` +
        `🔗 https://tiktok.com/@${d.username}`
    );
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'tiktokstalk',
    aliases:     ['ttstalk', 'tiktoklookup', 'ttlookup', 'tiktokprofile'],
    category:    'stalker',
    description: 'Look up a TikTok account by username',
    usage:       '.tiktokstalk <username>',

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix } = context;

        // ── Parse username ────────────────────────────────────────
        const username = (args[0] || '').replace('@', '').trim();

        if (!username) {
            return reply(
                `🎵 *TIKTOK STALK*\n\n` +
                `> Provide a TikTok username\n\n` +
                `\`Example: ${prefix}tiktokstalk mrbeast\``,
            );
        }

        await react(sock, chatId, m.key, '🔍');

        try {
            const res = await axios.get(
                `${CFG.apiBase}?apikey=${encodeURIComponent(getFireflyKey())}&username=${encodeURIComponent(username)}`,
                { timeout: CFG.timeout },
            );

            if (!res.data?.status || !res.data?.data) {
                await react(sock, chatId, m.key, '❌');
                return reply(`❌ Username *@${username}* not found`);
            }

            const d = res.data.data;
            const caption = buildCaption(d);

            await react(sock, chatId, m.key, '✅');

            // ── Send with avatar (if available) ───────────────────
            if (d.avatar) {
                await sendMessageWithChannel(sock, chatId, {
                    image: { url: d.avatar },
                    caption,
                });
            } else {
                await sendMessageWithChannel(sock, chatId, { text: caption });
            }

        } catch (error) {
            console.error('[TIKTOKSTALK]', error?.message || error);
            await react(sock, chatId, m.key, '☢');
            return reply(global.mess?.error?.fitur || 'TikTok stalk error. Please try again.');
        }
    },
};