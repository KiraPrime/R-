'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch { /* ignore */ }
}

function normalizeDomain(raw) {
    return String(raw || '')
        .replace(/^(https?:\/\/)?(www\.)?/i, '')
        .split('/')[0]
        .trim();
}

function isValidDomain(domain) {
    return /^[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9]?(\.[a-zA-Z]{2,})+$/.test(domain);
}

async function safeFetchText(url) {
    try {
        const res = await fetch(url, { signal: AbortSignal.timeout(15000) });
        if (!res.ok) return null;
        const text = await res.text();
        return text || null;
    } catch {
        return null;
    }
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'lookup',
    aliases:     ['dnslookup', 'dns', 'whois', 'domaininfo'],
    category:    'tools',
    description: 'DNS + WHOIS lookup for a domain',
    usage:       '.lookup <domain>',

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix } = context;

        // ── Parse domain ──────────────────────────────────────────
        const raw = (args[0] || '').trim();

        if (!raw) {
            return reply(
                `⚠️ *USAGE*\n\n` +
                `> \`${prefix}lookup <domain>\`\n\n` +
                `*Example:*\n` +
                `> \`${prefix}lookup google.com\``,
            );
        }

        const domain = normalizeDomain(raw);

        if (!isValidDomain(domain)) {
            return reply(`❌ *INVALID FORMAT*\n\n> Example: \`google.com\``);
        }

        // ── Notify ────────────────────────────────────────────────
        await react(sock, chatId, m.key, '🕕');
        await reply(`🕕 *Fetching info for domain...*`);

        try {
            // ── Fetch DNS + WHOIS in parallel ─────────────────────
            const [dnsData, whoisData] = await Promise.all([
                safeFetchText(`https://api.hackertarget.com/dnslookup/?q=${encodeURIComponent(domain)}`),
                safeFetchText(`https://api.hackertarget.com/whois/?q=${encodeURIComponent(domain)}`),
            ]);

            if (!dnsData && !whoisData) {
                await react(sock, chatId, m.key, '❌');
                return reply(`❌ *FAILED*\n\n> Cannot process this domain.`);
            }

            // ── Build response ────────────────────────────────────
            let text = `🔍 *DNS LOOKUP*\n\n`;
            text += `> Domain: \`${domain}\`\n\n`;

            // DNS records
            if (dnsData && !dnsData.includes('error')) {
                const lines = dnsData.split('\n').filter(l => l.trim());
                const records = {};

                for (const line of lines) {
                    const parts = line.split(/\s+/);
                    if (parts.length >= 2) {
                        const type = parts[parts.length - 2] || 'OTHER';
                        const value = parts[parts.length - 1];
                        if (!records[type]) records[type] = [];
                        records[type].push(value);
                    }
                }

                text += `╭┈┈⬡「 📋 *DNS RECORDS* 」\n`;
                if (records['A'])    text += `┃ 🅰️ A: ${records['A'].slice(0, 3).join(', ')}\n`;
                if (records['AAAA']) text += `┃ 🔢 AAAA: ${records['AAAA'].slice(0, 2).join(', ')}\n`;
                if (records['MX'])   text += `┃ 📧 MX: ${records['MX'].slice(0, 2).join(', ')}\n`;
                if (records['NS'])   text += `┃ 🌐 NS: ${records['NS'].slice(0, 3).join(', ')}\n`;
                if (records['TXT'])  text += `┃ 📝 TXT: ${records['TXT'].length} records\n`;
                text += `╰┈┈┈┈┈┈┈┈⬡\n\n`;
            }

            // WHOIS
            if (whoisData && !whoisData.includes('error') && whoisData.length < 2000) {
                const registrar = whoisData.match(/Registrar:\s*(.+)/i)?.[1] || '-';
                const created   = whoisData.match(/Creation Date:\s*(.+)/i)?.[1] || '-';
                const expires   = whoisData.match(/Expir.*Date:\s*(.+)/i)?.[1] || '-';
                const nameservers =
                    whoisData
                        .match(/Name Server:\s*(.+)/gi)
                        ?.slice(0, 2)
                        .map(ns => ns.split(':')[1]?.trim()) || [];

                text += `╭┈┈⬡「 📄 *WHOIS* 」\n`;
                text += `┃ 🏢 Registrar: ${registrar.slice(0, 35)}\n`;
                text += `┃ 📅 Created: ${created.slice(0, 20)}\n`;
                text += `┃ ⏰ Expires: ${expires.slice(0, 20)}\n`;
                if (nameservers.length > 0) {
                    text += `┃ 🌐 NS: ${nameservers.join(', ')}\n`;
                }
                text += `╰┈┈┈┈┈┈┈┈⬡`;
            }

            await react(sock, chatId, m.key, '✅');
            await sendMessageWithChannel(sock, chatId, { text });

        } catch (err) {
            console.error('[LOOKUP]', err?.message || err);
            await react(sock, chatId, m.key, '☢');
            return reply(global.mess?.error?.fitur || 'Lookup error. Please try again.');
        }
    },
};