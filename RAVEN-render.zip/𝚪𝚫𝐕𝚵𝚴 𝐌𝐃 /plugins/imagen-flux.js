/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require('axios');
const IMAGE_APIS = [
    (p) => `https://stable.stacktoy.workers.dev/?apikey=Suhail&prompt=${encodeURIComponent(p)}`,
    (p) => `https://dalle.stacktoy.workers.dev/?apikey=Suhail&prompt=${encodeURIComponent(p)}`,
    (p) => `https://flux.gtech-apiz.workers.dev/?apikey=Suhail&text=${encodeURIComponent(p)}`
];
const generateImage = async (prompt) => {
    for (const apiUrl of IMAGE_APIS) {
        try {
            const { data } = await axios.get(apiUrl(prompt), {
                responseType: 'arraybuffer',
                timeout: 30000
            });
            const buf = Buffer.from(data);
            if (buf[0] === 0x89 || buf[0] === 0xFF)
                return buf;
        }
        catch {
            continue;
        }
    }
    throw new Error('All image generation APIs failed');
};
const enhancePrompt = (prompt) => {
    const enhancers = [
        'high quality', 'detailed', 'masterpiece', 'best quality',
        'ultra realistic', '4k', 'highly detailed', 'cinematic lighting'
    ];
    const selected = enhancers
        .sort(() => Math.random() - 0.5)
        .slice(0, Math.floor(Math.random() * 2) + 3);
    return `${prompt}, ${selected.join(', ')}`;
};
module.exports = {
    command: 'flux',
    aliases: ['aiimage', 'imagen', 'draw', 'genimage'],
    category: 'ai',
    description: 'Generate an AI image based on your prompt',
    usage: '.flux <prompt>',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const imagePrompt = args.join(' ').trim();
        if (!imagePrompt) {
            return sendMessageWithChannel(sock, chatId, { text: '🎨 *AI Image Generator*\n\nUsage: `.flux <prompt>`\nExample: `.flux a beautiful sunset over mountains`' }, { quoted: message });
        }
        await sendMessageWithChannel(sock, chatId, { react: { text: '🎨', key: message.key } });
        await sendMessageWithChannel(sock, chatId, { text: '🎨 Generating your image... Please wait.' }, { quoted: message });
        try {
            const enhanced = enhancePrompt(imagePrompt);
            const imageBuffer = await generateImage(enhanced);
            await sendMessageWithChannel(sock, chatId, {
                image: imageBuffer,
                caption: `🎨 *Generated Image*\n📝 Prompt: _${imagePrompt}_`
            }, { quoted: message });
        }
        catch (error) {
            console.error('Imagine error:', error.message);
            await sendMessageWithChannel(sock, chatId, { text: '❌ Failed to generate image. Please try again later.' }, { quoted: message });
        }
    }
};
