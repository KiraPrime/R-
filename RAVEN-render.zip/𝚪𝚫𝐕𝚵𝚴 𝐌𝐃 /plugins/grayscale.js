/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');
const path = require('path');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
module.exports = {
    command: 'grayscale',
    aliases: ['gray', 'grey'],
    category: 'tools',
    description: 'Convert an image to grayscale',
    usage: 'Reply to an image with .grayscale',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            if (!quoted?.imageMessage) {
                return await sendMessageWithChannel(sock, chatId, { text: '🖤 *Grayscale Image*\n\nReply to an image to convert it to grayscale\n\nUsage:\n.grayscale' }, { quoted: message });
            }
            await sendMessageWithChannel(sock, chatId, { react: { text: '🔄', key: message.key } });
            const stream = await downloadContentFromMessage(quoted.imageMessage, 'image');
            let buffer = Buffer.from([]);
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }
            const tempFile = path.join(process.cwd(), `grayscale_${Date.now()}.jpg`);
            fs.writeFileSync(tempFile, buffer);
            const form = new FormData();
            form.append('apikey', 'guru');
            form.append('file', fs.createReadStream(tempFile));
            const res = await axios.post('https://discardapi.dpdns.org/api/image/grayscale', form, { headers: form.getHeaders(), responseType: 'arraybuffer', timeout: 60000 });
            fs.unlinkSync(tempFile);
            if (!res?.data)
                throw new Error('Grayscale conversion failed');
            const grayFile = path.join(process.cwd(), `grayscale_result_${Date.now()}.jpg`);
            fs.writeFileSync(grayFile, res.data);
            await sendMessageWithChannel(sock, chatId, {
                image: { url: grayFile },
                caption: `🖤 *Grayscale Image*\n\nProcessed by: 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃`
            }, { quoted: message });
            fs.unlinkSync(grayFile);
        }
        catch (err) {
            console.error('Grayscale Plugin Error:', err);
            await sendMessageWithChannel(sock, chatId, { text: '❌ Failed to convert image to grayscale. Make sure the image is clear and try again.' }, { quoted: message });
        }
    }
};
