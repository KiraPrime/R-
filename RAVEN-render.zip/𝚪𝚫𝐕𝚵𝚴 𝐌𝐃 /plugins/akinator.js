'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
let cheerio = null;
try { cheerio = require('cheerio'); } catch {}

// ══════════════════════════════════════════════════════════════════
// ─── CONFIG ───────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const CFG = {
    botName:  global.botName   || '𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
    author:   global.author    || '𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
    footer:   global.footer    || '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
    prefix:   global.xprefix   || '.',
    link:     global.link      || 'https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w',
    mess:     global.mess      || {},
};

const BASE = 'https://id.akinator.com';

const THEMES = {
    1: ['Character', 1],
    2: ['Animal', 14],
    3: ['Object', 2],
};

const CHOICES = [
    ['1', 'Yes', 0],
    ['2', 'No', 1],
    ['3', "Don't know", 2],
    ['4', 'Probably', 3],
    ['5', 'Probably not', 4],
];

// ══════════════════════════════════════════════════════════════════
// ─── FORWARD CONTEXT ──────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1,
    },
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: { ...(content.contextInfo || {}), ...forwardInfo },
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── GLOBAL SESSION ───────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
if (!global.akinatorSessions) global.akinatorSessions = {};

// ══════════════════════════════════════════════════════════════════
// ─── GOT SCRAPING & COOKIE ────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
let scrape;
async function akinator() {
    if (!scrape) scrape = (await import('got-scraping')).gotScraping;
    return scrape;
}

function cookieString(jar) {
    if (!jar) return '';
    return Object.entries(jar)
        .map(([key, value]) => `${key}=${value}`)
        .join('; ');
}

function saveCookies(jar, res) {
    if (!jar || !res || !res.headers['set-cookie']) return;
    for (const cookie of res.headers['set-cookie']) {
        const [kv] = cookie.split(';');
        const index = kv.indexOf('=');
        if (index > 0) {
            const key   = kv.slice(0, index).trim();
            const value = kv.slice(index + 1).trim();
            jar[key] = value;
        }
    }
}

// ══════════════════════════════════════════════════════════════════
// ─── REQUEST & PARSER ─────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function post(game, path, form) {
    const g = await akinator();
    const headers = {
        'content-type':     'application/x-www-form-urlencoded; charset=UTF-8',
        'x-requested-with': 'XMLHttpRequest',
        'origin':           BASE,
        'referer':          BASE + '/game',
    };

    if (game.cookies && Object.keys(game.cookies).length > 0) {
        headers.cookie = cookieString(game.cookies);
    }

    const res = await g({
        url: BASE + path,
        method: 'POST',
        form,
        headers,
        throwHttpErrors: false,
    });

    saveCookies(game.cookies, res);
    return res;
}

function parseJSON(body) {
    try {
        return JSON.parse(body);
    } catch {
        throw new Error('Akinator response is not JSON.');
    }
}

// ══════════════════════════════════════════════════════════════════
// ─── AKINATOR GAME LOGIC ──────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function start(game) {
    if (!cheerio) throw new Error('cheerio not installed');
    const g = await akinator();
    const home = await g({ url: BASE + '/', throwHttpErrors: false });
    saveCookies(game.cookies, home);

    const res = await post(game, '/game', { sid: String(game.sid), cm: 'false' });
    const body = res.body;
    const $ = cheerio.load(body);

    const session =
        body.match(/session:\s*'([^']+)'/)?.[1] ||
        body.match(/name="session"[^>]*value="([^"]+)"/)?.[1];
    const identifiant =
        body.match(/localStorage\.setItem\('identifiant',\s*'([^']+)'\)/)?.[1] ||
        body.match(/name="identifiant"[^>]*value="([^"]+)"/)?.[1] || '';
    const question = $('#question-label').text().trim();

    if (!session || !question) throw new Error('Failed to fetch data from Akinator.');

    game.session   = session;
    game.identifiant = identifiant;
    game.question  = question;
    game.step = parseInt(body.match(/localStorage\.setItem\('step',\s*'(\d+)'\)/)?.[1] || '1');
    game.num = 1;
    game.progression = 0;
    game.stepLastProposition = '';
}

function handle(game, data) {
    if (data.completion === 'KO') throw new Error('Session expired.');
    if (data.completion === 'SOUNDLIKE') return { lost: true };

    if (data.id_proposition) {
        game.step = parseInt(data.step ?? game.step);
        game.stepLastProposition = String(game.step);
        return {
            guess: {
                id: data.id_proposition,
                id_base: data.id_base_proposition,
                name: data.name_proposition,
                description: data.description_proposition,
                photo: data.photo,
            },
        };
    }

    if (data.question) game.question = data.question;
    if (data.step !== undefined) game.step = parseInt(data.step);
    if (data.progression !== undefined) game.progression = parseFloat(data.progression);

    return {};
}

async function answer(game, id) {
    const res = await post(game, '/answer', {
        step:  String(game.step),
        progression: String(game.progression),
        sid: String(game.sid),
        cm: 'false',
        answer: String(id),
        step_last_proposition: game.stepLastProposition,
        session: game.session,
    });
    const result = handle(game, parseJSON(res.body));
    if (!result.guess && !result.lost) game.num++;
    return result;
}

async function back(game) {
    const res = await post(game, '/cancel_answer', {
        step:  String(game.step),
        progression: String(game.progression),
        sid: String(game.sid),
        cm: 'false',
        session: game.session,
    });
    handle(game, parseJSON(res.body));
    game.num = Math.max(1, game.num - 1);
}

async function exclude(game) {
    const res = await post(game, '/exclude', {
        step: String(game.step),
        sid: String(game.sid),
        cm: 'false',
        progression: String(game.progression),
        session: game.session,
        forward_answer: '1',
    });
    const result = handle(game, parseJSON(res.body));
    if (!result.guess && !result.lost) game.num++;
    return result;
}

async function confirm(game, guess) {
    try {
        await post(game, '/choice', {
            sid: String(game.sid),
            pid: String(guess.id),
            identifiant: game.identifiant,
            charac_name: guess.name,
            charac_desc: guess.description,
            session: game.session,
            step: String(game.step),
        });
    } catch {}
}

// ══════════════════════════════════════════════════════════════════
// ─── UI: MESSAGE VIEWS ────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function sendTheme(sock, chatId, m) {
    return sendMessageWithChannel(sock, chatId, {
        text:
            `╭─「 🎭 AKINATOR 」\n` +
            `│\n` +
            `│ Choose a theme:\n` +
            `│ 1. Character\n` +
            `│ 2. Animal\n` +
            `│ 3. Object\n` +
            `│\n` +
            `│ Reply with *1*, *2*, or *3*\n` +
            `│ Type *.akinator stop* to cancel.\n` +
            `╰──────────────`,
    }, { quoted: m });
}

async function sendQuestion(sock, chatId, m, game) {
    game.state = 'question';
    return sendMessageWithChannel(sock, chatId, {
        text:
            `╭─「 🧠 AKINATOR 」\n` +
            `│\n` +
            `│ 🎭 Theme: *${game.theme}*\n` +
            `│ 📊 Progress: *${Math.round(game.progression)}%*\n` +
            `│ ❓ Question: *${game.num}*\n` +
            `│\n` +
            `│ ${game.question}\n` +
            `│\n` +
            `│ 1. Yes\n` +
            `│ 2. No\n` +
            `│ 3. Don't know\n` +
            `│ 4. Probably\n` +
            `│ 5. Probably not\n` +
            `│\n` +
            `│ 0. Go back\n` +
            `╰──────────────`,
    }, { quoted: m });
}

async function handleResult(sock, chatId, m, game, result) {
    if (result.lost) {
        delete global.akinatorSessions[m.sender];
        return sendMessageWithChannel(sock, chatId, {
            text: `😵 Akinator gave up! I can't guess your answer.`,
        }, { quoted: m });
    }

    if (result.guess) {
        game.guess = result.guess;
        game.state = 'confirm';

        const teks =
            `╭─「 🎯 AKINATOR'S GUESS 」\n` +
            `│\n` +
            `│ 👤 *${result.guess.name}*\n` +
            `│ 📝 ${result.guess.description || '-'}\n` +
            `│\n` +
            `│ Is this correct?\n` +
            `│ Reply *1* (Yes) or *2* (No)\n` +
            `╰──────────────`;

        if (result.guess.photo) {
            return sendMessageWithChannel(sock, chatId,
                { image: { url: result.guess.photo }, caption: teks },
                { quoted: m });
        }
        return sendMessageWithChannel(sock, chatId, { text: teks }, { quoted: m });
    }
    return sendQuestion(sock, chatId, m, game);
}

// ══════════════════════════════════════════════════════════════════
// ─── BEFORE HOOK (INTERCEPTOR) ────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function before(sock, m, context) {
    if (m.isBaileys || m.fromMe || !m.text) return false;

    const chatId = context?.chatId || m.chat;
    const id = m.sender;
    const input = m.text.trim().toLowerCase();
    let game = global.akinatorSessions[id];

    if (!game) return false;

    // ── STATE: THEME ──────────────────────────────────────────────
    if (game.state === 'theme') {
        if (!THEMES[input]) return false;

        game.sid = THEMES[input][1];
        game.theme = THEMES[input][0];

        try {
            await sendMessageWithChannel(sock, chatId, {
                text: `⏳ Starting Akinator...\n🎭 Theme: *${game.theme}*`,
            }, { quoted: m });
            await start(game);
            game.state = 'question';
            await sendQuestion(sock, chatId, m, game);
        } catch (e) {
            delete global.akinatorSessions[id];
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Failed to start Akinator: ${e.message}`,
            }, { quoted: m });
        }
        return true;
    }

    // ── STATE: QUESTION ───────────────────────────────────────────
    if (game.state === 'question') {
        if (input === '0') {
            if (game.num <= 1) {
                await sendMessageWithChannel(sock, chatId, {
                    text: `⚠️ No previous question to go back to.`,
                }, { quoted: m });
                return true;
            }
            try {
                await back(game);
                await sendQuestion(sock, chatId, m, game);
            } catch (e) {
                await sendMessageWithChannel(sock, chatId, {
                    text: `❌ Failed to go back: ${e.message}`,
                }, { quoted: m });
            }
            return true;
        }

        const pick = CHOICES.find(choice => choice[0] === input);
        if (!pick) return false;

        try {
            const result = await answer(game, pick[2]);
            await handleResult(sock, chatId, m, game, result);
        } catch (e) {
            delete global.akinatorSessions[id];
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ An error occurred: ${e.message}`,
            }, { quoted: m });
        }
        return true;
    }

    // ── STATE: CONFIRM ────────────────────────────────────────────
    if (game.state === 'confirm') {
        if (!['1', '2', 'y', 'n', 'yes', 'no'].includes(input)) return false;

        const yes = ['1', 'y', 'yes'].includes(input);

        if (yes) {
            await confirm(game, game.guess);
            const result = game.guess;
            const totalNum = game.num;
            delete global.akinatorSessions[id];

            const teks =
                `╭─「 🎯 AKINATOR RESULT 」\n` +
                `│\n` +
                `│ 👤 *${result.name}*\n` +
                `│ 📝 ${result.description || '-'}\n` +
                `│\n` +
                `│ ❓ Total questions: ${totalNum}\n` +
                `╰──────────────`;

            if (result.photo) {
                await sendMessageWithChannel(sock, chatId,
                    { image: { url: result.photo }, caption: teks },
                    { quoted: m });
            } else {
                await sendMessageWithChannel(sock, chatId, { text: teks }, { quoted: m });
            }
            return true;
        }

        try {
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Not that?\n🧠 Okay, Akinator keeps searching...`,
            }, { quoted: m });
            const result = await exclude(game);
            await handleResult(sock, chatId, m, game, result);
        } catch (e) {
            delete global.akinatorSessions[id];
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Failed to continue: ${e.message}`,
            }, { quoted: m });
        }
        return true;
    }

    return false;
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command: 'akinator',
    aliases: ['aki'],
    category: 'game',
    description: 'Akinator game via id.akinator.com — guess your character!',
    usage: '.akinator',
    limit: true,

    // Interceptor: auto-read replies 1-5
    before,

    async handler(sock, m, args, context) {
        const chatId = context?.chatId || m.chat;
        const id = m.sender;
        const input = String(args?.join(' ') || '').trim().toLowerCase();

        if (input === 'stop') {
            if (global.akinatorSessions[id]) {
                delete global.akinatorSessions[id];
                return sendMessageWithChannel(sock, chatId, {
                    text: `✅ Akinator game stopped.`,
                }, { quoted: m });
            }
            return sendMessageWithChannel(sock, chatId, {
                text: `ℹ️ No active Akinator game.`,
            }, { quoted: m });
        }

        const defaultSession = {
            sid: 1, session: '', identifiant: '', step: 1, num: 1,
            progression: 0, stepLastProposition: '', question: '',
            theme: '', cookies: {}, state: 'theme', guess: null,
        };

        // ── Start with theme directly ─────────────────────────────
        if (THEMES[input]) {
            global.akinatorSessions[id] = {
                ...defaultSession,
                sid: THEMES[input][1],
                theme: THEMES[input][0],
            };

            const game = global.akinatorSessions[id];
            try {
                await sendMessageWithChannel(sock, chatId, {
                    text: `⏳ Starting Akinator...\n🎭 Theme: *${game.theme}*`,
                }, { quoted: m });
                await start(game);
                game.state = 'question';
                return sendQuestion(sock, chatId, m, game);
            } catch (e) {
                delete global.akinatorSessions[id];
                return sendMessageWithChannel(sock, chatId, {
                    text: `❌ Failed to start Akinator:\n${e.message}`,
                }, { quoted: m });
            }
        }

        // ── Already active ────────────────────────────────────────
        if (global.akinatorSessions[id]) {
            return sendMessageWithChannel(sock, chatId, {
                text: `⚠️ Finish your current game first, or type *.akinator stop* to cancel.`,
            }, { quoted: m });
        }

        // ── New session → ask theme ───────────────────────────────
        global.akinatorSessions[id] = { ...defaultSession };
        return sendTheme(sock, chatId, m);
    },
};