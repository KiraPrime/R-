/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: 'brainfuck',
    aliases: ['bfcode', 'obfuscate'],
    category: 'tools',
    description: 'Convert text into Brainfuck code',
    usage: '.brainfuck <text> OR reply to a message',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            let text = args?.join(' ') || "";
            const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            if (quoted) {
                text = quoted.conversation ||
                    quoted.extendedTextMessage?.text ||
                    quoted.imageMessage?.caption ||
                    quoted.videoMessage?.caption ||
                    text;
            }
            text = text.replace(/^\.\w+\s*/, '').trim();
            if (!text) {
                return await sendMessageWithChannel(sock, chatId, { text: '*Please provide text or reply to a message to obfuscate!*' }, { quoted: message });
            }
            let bfCode = "";
            let lastAscii = 0;
            for (let i = 0; i < text.length; i++) {
                const ascii = text.charCodeAt(i);
                const diff = ascii - lastAscii;
                if (diff > 0) {
                    bfCode += "+".repeat(diff);
                }
                else if (diff < 0) {
                    bfCode += "-".repeat(Math.abs(diff));
                }
                bfCode += ".";
                lastAscii = ascii;
            }
            const response = `*❄️ Brainfuck Obfuscated Text:*\n\n${bfCode}`;
            await sendMessageWithChannel(sock, chatId, { text: response }, { quoted: message });
        }
        catch (err) {
            console.error('BF Encoding Error:', err);
            await sendMessageWithChannel(sock, chatId, { text: '❌ Error generating code.' }, { quoted: message });
        }
    }
};
