/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: 'tagnotadmin',
    aliases: ['tagmembers', 'tagnon'],
    category: 'admin',
    description: 'Tag all non-admin members in the group',
    usage: '.tagnotadmin',
    groupOnly: true,
    adminOnly: true,
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        try {
            const groupMetadata = await sock.groupMetadata(chatId);
            const participants = groupMetadata.participants || [];
            const nonAdmins = participants.filter((p) => !p.admin).map((p) => p.id);
            if (nonAdmins.length === 0) {
                await sendMessageWithChannel(sock, chatId, {
                    text: 'No non-admin members to tag.',
                    ...channelInfo
                }, { quoted: message });
                return;
            }
            let text = '🔊 *Hello Everyone:*\n\n';
            nonAdmins.forEach((jid) => {
                text += `@${jid.split('@')[0]}\n`;
            });
            await sendMessageWithChannel(sock, chatId, {
                text,
                mentions: nonAdmins,
                ...channelInfo
            }, { quoted: message });
        }
        catch (error) {
            console.error('Error in tagnotadmin command:', error);
            await sendMessageWithChannel(sock, chatId, {
                text: 'Failed to tag non-admin members.',
                ...channelInfo
            }, { quoted: message });
        }
    }
};
