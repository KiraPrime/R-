'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const axios = require('axios');
const {
    VALID_SERVERS,
    hasFullAccess,
    getUserRole,
} = require('../lib/cpanel-roles.js');

// ══════════════════════════════════════════════════════════════════
// ─── FORWARD NEWSLETTER CONTEXT (mandatory on all plugins) ────────
// ══════════════════════════════════════════════════════════════════
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── CONFIG ───────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const { getSessionConfig } = require('../lib/session-config');

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function parseServerVersion(cmd) {
    const match = String(cmd || '').match(/v([1-5])$/i);
    if (!match) return { server: 'v1', serverKey: 's1' };
    return { server: 'v' + match[1], serverKey: 's' + match[1] };
}

function getServerConfig(pteroConfig, serverKey) {
    const map = {
        s1: pteroConfig.server1,
        s2: pteroConfig.server2,
        s3: pteroConfig.server3,
        s4: pteroConfig.server4,
        s5: pteroConfig.server5,
    };
    return map[serverKey] || null;
}

function validateServerConfig(serverConfig) {
    const missing = [];
    if (!serverConfig?.domain) missing.push('domain');
    if (!serverConfig?.apikey) missing.push('apikey (PTLA)');
    return missing;
}

function getAvailableServers(pteroConfig) {
    const available = [];
    for (let i = 1; i <= 5; i++) {
        const cfg = pteroConfig[`server${i}`];
        if (cfg?.domain && cfg?.apikey) available.push(`v${i}`);
    }
    return available;
}

function formatBytes(bytes) {
    if (bytes === 0 || bytes === null || bytes === undefined) return 'Unlimited';
    const mb = Number(bytes);
    if (Number.isNaN(mb)) return '—';
    if (mb >= 1000) return `${(mb / 1000).toFixed(1)} GB`;
    return `${mb} MB`;
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch { /* ignore */ }
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const allCommands = VALID_SERVERS.map(v => `serverinfo${v}`);
const allAliases  = VALID_SERVERS.map(v => `sinfo${v}`);

module.exports = {
    command:     allCommands[0],       // 'serverinfov1' — primary
    aliases:     [
        ...allCommands.slice(1),       // serverinfov2 … serverinfov5
        ...allAliases,                 // sinfov1 … sinfov5
    ],
    category:    'panel',
    description: 'Show Pterodactyl server info (v1–v5)',
    usage:       '.serverinfovN <serverid>',

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix, isOwner, sender, sessionId } = context;

        const sessionCfg = getSessionConfig(sessionId).serverInfo;
        const pteroConfig = sessionCfg.pterodactyl;

        // ── Detect which server variant was invoked ──────────────
        const cmdName = (context.command || 'serverinfov1').toLowerCase();
        const { server: serverVersion, serverKey } = parseServerVersion(cmdName);
        const serverLabel = serverVersion.toUpperCase();

        // ── Access check ─────────────────────────────────────────
        if (!hasFullAccess(sender, serverVersion, isOwner)) {
            const userRole = getUserRole(sender, serverVersion);
            return reply(
                `❌ *ACCESS DENIED*\n\n` +
                `> You don't have access to *${serverLabel}*\n` +
                `> Your role: *${userRole || 'none'}*`,
            );
        }

        // ── Parse server ID ──────────────────────────────────────
        const serverId = (args[0] || '').trim();

        const serverConfig  = getServerConfig(pteroConfig, serverKey);
        const missingConfig = validateServerConfig(serverConfig);

        if (missingConfig.length > 0) {
            const available = getAvailableServers(pteroConfig);
            let txt = `⚠️ *SERVER ${serverLabel} NOT CONFIGURED*\n\n`;
            if (available.length > 0) {
                txt += `> Available servers: *${available.join(', ')}*`;
            } else {
                txt += `> No servers are configured yet.`;
            }
            return reply(txt);
        }

        if (!serverId || isNaN(Number(serverId))) {
            return reply(
                `⚠️ *USAGE*\n\n` +
                `> \`${prefix}${cmdName} <serverid>\`\n\n` +
                `> List IDs with \`${prefix}listserver${serverVersion}\``,
            );
        }

        // ── Fetch server info from Pterodactyl ───────────────────
        await react(sock, chatId, m.key, '🕕');

        try {
            const serverRes = await axios.get(
                `${serverConfig.domain}/api/application/servers/${serverId}`,
                {
                    timeout: sessionCfg.timeout,
                    headers: {
                        'Authorization': `Bearer ${serverConfig.apikey}`,
                        'Content-Type': 'application/json',
                        'Accept': 'Application/vnd.pterodactyl.v1+json',
                    },
                },
            );

            const s        = serverRes.data.attributes;
            const limits   = s.limits || {};
            const features = s.feature_limits || {};

            let txt = `📊 *SERVER INFO [${serverLabel}]*\n\n`;
            txt += `╭─「 📋 *DETAILS* 」\n`;
            txt += `┃ 🆔 \`ID\`      : *${s.id}*\n`;
            txt += `┃ 📛 \`NAME\`    : *${s.name}*\n`;
            txt += `┃ 👤 \`OWNER\`   : *${s.user}*\n`;
            txt += `┃ 📝 \`DESC\`    : *${s.description || '-'}*\n`;
            txt += `┃ 📊 \`STATUS\`  : *${s.suspended ? '⛔ Suspended' : '✅ Active'}*\n`;
            txt += `╰───────────────\n\n`;
            txt += `╭─「 🧠 *SPECS* 」\n`;
            txt += `┃ 💾 \`RAM\`     : *${formatBytes(limits.memory)}*\n`;
            txt += `┃ ⚡ \`CPU\`     : *${limits.cpu === 0 ? 'Unlimited' : limits.cpu + '%'}*\n`;
            txt += `┃ 📦 \`DISK\`    : *${formatBytes(limits.disk)}*\n`;
            txt += `┃ 🔄 \`SWAP\`    : *${limits.swap} MB*\n`;
            txt += `╰───────────────\n\n`;
            txt += `╭─「 📦 *FEATURE LIMITS* 」\n`;
            txt += `┃ 🗄️ \`DATABASES\`  : *${features.databases}*\n`;
            txt += `┃ 💾 \`BACKUPS\`    : *${features.backups}*\n`;
            txt += `┃ 🔌 \`ALLOCATIONS\`: *${features.allocations}*\n`;
            txt += `╰───────────────`;

            await react(sock, chatId, m.key, '✅');
            return reply(txt);

        } catch (err) {
            console.error('[SERVERINFO]', err?.message || err);
            await react(sock, chatId, m.key, '☢');
            return reply(global.mess?.error?.fitur || 'Could not fetch server info.');
        }
    },
};