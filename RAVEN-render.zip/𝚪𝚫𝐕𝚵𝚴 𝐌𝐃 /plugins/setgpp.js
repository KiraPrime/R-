/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const fs = require('fs');
const path = require('path');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
module.exports = {
    command: 'setgpp',
    aliases: ['setgpic', 'grouppp', 'setgrouppic'],
    category: 'admin',
    description: 'Change group profile picture',
    usage: '.setgpp (reply to image)',
    groupOnly: true,
    adminOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const imageMessage = quoted?.imageMessage || quoted?.stickerMessage;
        if (!imageMessage) {
            await sendMessageWithChannel(sock, chatId, {
                text: '❌ *Please reply to an image or sticker*\n\nUsage: Reply to an image with `.setgpp`'
            }, { quoted: message });
            return;
        }
        try {
            const tmpDir = path.join(process.cwd(), 'tmp');
            if (!fs.existsSync(tmpDir)) {
                fs.mkdirSync(tmpDir, { recursive: true });
            }
            const stream = await downloadContentFromMessage(imageMessage, 'image');
            let buffer = Buffer.from([]);
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }
            const imgPath = path.join(tmpDir, `gpp_${Date.now()}.jpg`);
            fs.writeFileSync(imgPath, buffer);
            await sock.updateProfilePicture(chatId, { url: imgPath });
            try {
                fs.unlinkSync(imgPath);
            }
            catch (e) { }
            await sendMessageWithChannel(sock, chatId, {
                text: '✅ *Group profile picture updated successfully!*'
            }, { quoted: message });
        }
        catch (error) {
            console.error('Error updating group photo:', error);
            await sendMessageWithChannel(sock, chatId, {
                text: '❌ *Failed to update group profile picture*\n\nMake sure the bot is an admin and the image is valid.'
            }, { quoted: message });
        }
    }
};
