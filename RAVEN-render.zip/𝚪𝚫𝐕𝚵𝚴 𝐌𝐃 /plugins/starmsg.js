/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: 'star',
    aliases: ['starmsg', 'unstar', 'unstarmsg'],
    category: 'owner',
    description: 'Star or unstar a replied message',
    usage: '.star — reply to a message | .unstar — reply to a message',
    ownerOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const channelInfo = context.channelInfo || {};
        const rawText = (context.rawText || '').toLowerCase();
        const shouldStar = !rawText.startsWith('.unstar');
        // contextInfo can be nested in any message type
        const msg = message.message;
        const contextInfo = msg?.extendedTextMessage?.contextInfo ||
            msg?.imageMessage?.contextInfo ||
            msg?.videoMessage?.contextInfo ||
            msg?.audioMessage?.contextInfo ||
            msg?.documentMessage?.contextInfo ||
            msg?.stickerMessage?.contextInfo ||
            msg?.buttonsResponseMessage?.contextInfo ||
            null;
        if (!contextInfo?.stanzaId) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `*⭐ STAR MESSAGE*\n\n_Reply to any message with:_\n• \`.star\` — to star it\n• \`.unstar\` — to unstar it`,
                ...channelInfo
            }, { quoted: message });
        }
        const targetId = contextInfo.stanzaId;
        // Determine fromMe: compare phone numbers only (strip :xx@suffix)
        const botNum = (sock.user?.id || '').split(':')[0].split('@')[0];
        const participantNum = (contextInfo.participant || '').split(':')[0].split('@')[0];
        const fromMe = participantNum ? participantNum === botNum : message.key.fromMe;
        try {
            await sock.chatModify({
                star: {
                    messages: [{ id: targetId, fromMe }],
                    star: shouldStar
                }
            }, chatId);
            await sendMessageWithChannel(sock, chatId, {
                text: shouldStar ? `⭐ *Message starred!*` : `✴️ *Message unstarred!*`,
                ...channelInfo
            }, { quoted: message });
        }
        catch (e) {
            console.error('[STARMSG] Error:', e.message);
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Failed to ${shouldStar ? 'star' : 'unstar'} message: ${e.message}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};
