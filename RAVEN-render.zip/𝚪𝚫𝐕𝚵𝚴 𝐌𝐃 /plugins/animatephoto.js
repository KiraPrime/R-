'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const axios   = require('axios');
const FormData = require('form-data');

// ══════════════════════════════════════════════════════════════════
// ─── FORWARD NEWSLETTER CONTEXT ───────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── CONFIG ───────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const CFG = {
    // Neoxr API key — get it from https://api.neoxr.eu
    neoxrApiKey: 'Milik-Bot-zerotwoMD',
    apiBase:     'https://api.neoxr.eu/api/img2vid',
    uploadUrl:   'https://tmpfiles.org/api/v1/upload',
    timeout:     120000, // 2 min (video generation can be slow)
};

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {}
}

function getNeoxrKey() {
    return global.apiKeys?.neoxr || CFG.neoxrApiKey;
}

/**
 * Extract the quoted image message from the current context.
 */
function getQuotedImage(m) {
    const quoted = m?.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    if (!quoted) return null;

    // Case 1: direct image
    if (quoted.imageMessage) {
        return { type: 'imageMessage', content: quoted.imageMessage };
    }

    // Case 2: viewOnce wrapper
    if (quoted.viewOnceMessage?.message?.imageMessage) {
        return {
            type:    'imageMessage',
            content: quoted.viewOnceMessage.message.imageMessage,
        };
    }
    if (quoted.viewOnceMessageV2?.message?.imageMessage) {
        return {
            type:    'imageMessage',
            content: quoted.viewOnceMessageV2.message.imageMessage,
        };
    }

    return null;
}

/**
 * Download a media from a Baileys message object.
 */
async function downloadMedia(sock, mediaContent) {
    const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
    const stream = await downloadContentFromMessage(mediaContent, 'image');
    const chunks = [];
    for await (const chunk of stream) chunks.push(chunk);
    return Buffer.concat(chunks);
}

/**
 * Upload a buffer to tmpfiles.org and return a direct download URL.
 */
async function uploadToTmpFiles(buffer, filename) {
    const form = new FormData();
    form.append('file', buffer, { filename });

    const res = await axios.post(CFG.uploadUrl, form, {
        headers: form.getHeaders(),
        timeout: 60000,
    });

    if (res.data?.data?.url) {
        return res.data.data.url.replace('tmpfiles.org/', 'tmpfiles.org/dl/');
    }
    throw new Error('Failed to upload to tmpfiles.org');
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'img2vid',
    aliases:     ['animatephoto', 'i2v'],
    category:    'ai',
    description: 'Animate an image into a video using AI',
    usage:       '.img2vid <prompt> (reply to an image)',

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix } = context;

        const prompt = (args.join(' ') || '').trim() || 'Animate my photo';

        // ── Detect quoted / direct image ──────────────────────────
        let mediaContent = null;
        let mediaType    = null;

        const quotedImg = getQuotedImage(m);
        if (quotedImg) {
            mediaContent = quotedImg.content;
            mediaType    = quotedImg.type;
        } else if (m.message?.imageMessage) {
            mediaContent = m.message.imageMessage;
            mediaType    = 'imageMessage';
        }

        if (!mediaContent) {
            return reply(
                `🎬 *IMAGE TO VIDEO AI*\n\n` +
                `> Reply to an image with a prompt to animate it.\n\n` +
                `*Format:*\n` +
                `> \`${prefix}img2vid <prompt>\`\n\n` +
                `*Examples:*\n` +
                `> \`${prefix}img2vid Animate my photo\`\n` +
                `> \`${prefix}img2vid Make it dance\``,
            );
        }

        await react(sock, chatId, m.key, '⏳');
        await reply(`⏳ *Downloading image...*`);

        try {
            // ── 1. Download the image ─────────────────────────────
            const buffer = await downloadMedia(sock, mediaContent);

            // ── 2. Upload to tmpfiles.org ─────────────────────────
            await reply(`📤 *Uploading image...*`);
            const imageUrl = await uploadToTmpFiles(buffer, `img2vid_${Date.now()}.jpg`);

            // ── 3. Call Neoxr API ─────────────────────────────────
            await reply(
                `🎬 *Generating video...*\n\n` +
                `> Prompt: ${prompt}\n` +
                `> Wait 20-60 seconds...`,
            );

            const apiUrl =
                `${CFG.apiBase}` +
                `?image=${encodeURIComponent(imageUrl)}` +
                `&prompt=${encodeURIComponent(prompt)}` +
                `&apikey=${encodeURIComponent(getNeoxrKey())}`;

            const res = await axios.get(apiUrl, { timeout: CFG.timeout });

            if (!res.data?.status || !res.data?.data?.url) {
                await react(sock, chatId, m.key, '❌');
                return reply(`❌ Failed to generate video!`);
            }

            const videoUrl = res.data.data.url;

            // ── 4. Send the video ─────────────────────────────────
            await sendMessageWithChannel(sock, chatId, {
                video:   { url: videoUrl },
                caption: `🎬 *IMAGE TO VIDEO AI*\n\n> Prompt: ${prompt}`,
            }, { quoted: m });

            await react(sock, chatId, m.key, '✅');

        } catch (err) {
            console.error('[IMG2VID]', err?.message || err);
            await react(sock, chatId, m.key, '❌');
            return reply(
                `❌ *FAILED*\n\n` +
                `> ${err.message}`,
            );
        }
    },
};