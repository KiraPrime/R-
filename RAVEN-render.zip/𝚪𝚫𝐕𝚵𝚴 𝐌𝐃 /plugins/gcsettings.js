/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: 'gcset',
    aliases: ['gsetting', 'groupset', 'gpset'],
    category: 'admin',
    description: 'Change group settings (lock/unlock messages or settings)',
    usage: '.gcset <setting>',
    groupOnly: true,
    adminOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const channelInfo = context.channelInfo || {};
        const isBotAdmin = context.isBotAdmin || false;
        if (!isBotAdmin) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `❌ Bot needs to be an admin to change group settings.`,
                ...channelInfo
            }, { quoted: message });
        }
        const setting = args[0]?.toLowerCase();
        if (!setting) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `╔════════════════╗\n` +
                    `║⚙️ *GROUP SETTINGS*   ║\n` +
                    `╚════════════════╝\n\n` +
                    `📌 *Usage:* \`.gcset <option>\`\n\n` +
                    `────────────────────\n` +
                    `*💬 MESSAGE PERMISSIONS*\n` +
                    `🔒 *lock* — Only admins can send messages\n\n` +
                    `🔓 *unlock* — Everyone can send messages\n\n` +
                    `*🛠️ SETTINGS PERMISSIONS*\n` +
                    `🔒 *lockset* — Only admins can edit group info\n\n` +
                    `🔓 *unlockset* — Everyone can edit group info\n` +
                    `────────────────────`,
                ...channelInfo
            }, { quoted: message });
        }
        const settingsMap = {
            lock: { value: 'announcement', label: '🔒 Only admins can send messages' },
            unlock: { value: 'not_announcement', label: '🔓 Everyone can send messages' },
            lockset: { value: 'locked', label: '🔒 Only admins can edit group info' },
            unlockset: { value: 'unlocked', label: '🔓 Everyone can edit group info' },
        };
        const config = settingsMap[setting];
        if (!config) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `❌ Unknown setting: *${setting}*\n\nUse \`.groupsettings\` to see options.`,
                ...channelInfo
            }, { quoted: message });
        }
        try {
            await sock.groupSettingUpdate(chatId, config.value);
            return await sendMessageWithChannel(sock, chatId, {
                text: `✅ ${config.label}`,
                ...channelInfo
            }, { quoted: message });
        }
        catch (e) {
            console.error('[GROUPSETTINGS] Error:', e.message);
            return await sendMessageWithChannel(sock, chatId, {
                text: `❌ Failed to update setting: ${e.message}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};
