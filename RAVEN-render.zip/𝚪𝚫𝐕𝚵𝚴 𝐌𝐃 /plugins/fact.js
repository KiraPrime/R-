/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require('axios');
module.exports = { command: 'fact', aliases: ['randomfact', 'uselessfact'], category: 'fun', description: 'Get a random interesting fact', usage: '.fact', async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            const r = await axios.get('https://uselessfacts.jsph.pl/random.json?language=en');
            await sendMessageWithChannel(sock, chatId, { text: r.data.text }, { quoted: message });
        }
        catch (e) {
            console.error('Error fetching fact:', e);
            await sendMessageWithChannel(sock, chatId, { text: 'Sorry, I could not fetch a fact right now.' }, { quoted: message });
        }
    } };
