'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const fs    = require('fs');
const path  = require('path');
const axios = require('axios');
const {
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    proto,
} = require('@whiskeysockets/baileys');

// ══════════════════════════════════════════════════════════════════
// ─── FORWARD NEWSLETTER CONTEXT ───────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── STORE (auto-created) ─────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const DATA_DIR   = path.join(__dirname, 'husbu-data');
const STORE_PATH = path.join(DATA_DIR, 'store.json');

let _store = null;
let _saveTimer = null;

function ensureDir() {
    try { if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true }); }
    catch (e) { console.error('[HUSBU] mkdir failed:', e?.message); }
}

function loadStore() {
    ensureDir();
    try {
        if (fs.existsSync(STORE_PATH)) {
            const raw = fs.readFileSync(STORE_PATH, 'utf8').trim();
            if (raw) {
                const parsed = JSON.parse(raw);
                _store = { users: { ...(parsed.users || {}) } };
                return _store;
            }
        }
    } catch (e) {
        console.error('[HUSBU] corrupted, rebuilding:', e?.message);
        try {
            const backup = STORE_PATH + '.corrupted.' + Date.now() + '.bak';
            if (fs.existsSync(STORE_PATH)) fs.copyFileSync(STORE_PATH, backup);
        } catch {}
    }
    _store = { users: {} };
    writeStoreSync();
    return _store;
}

function writeStoreSync() {
    try {
        ensureDir();
        const tmp = STORE_PATH + '.tmp';
        fs.writeFileSync(tmp, JSON.stringify(_store, null, 2), 'utf8');
        fs.renameSync(tmp, STORE_PATH);
    } catch (e) { console.error('[HUSBU] write failed:', e?.message); }
}

function scheduleSave() {
    if (_saveTimer) clearTimeout(_saveTimer);
    _saveTimer = setTimeout(() => { _saveTimer = null; writeStoreSync(); }, 500);
    if (_saveTimer.unref) _saveTimer.unref();
}

function numOf(jid) {
    if (!jid) return '';
    return String(jid).split(':')[0].split('@')[0].replace(/[^0-9]/g, '');
}

function getUser(jid) {
    if (!_store) loadStore();
    const num = numOf(jid);
    if (!num) return null;
    if (!_store.users[num]) _store.users[num] = { husbu: null };
    return _store.users[num];
}

function setUser(jid, data) {
    const u = getUser(jid);
    if (!u) return null;
    Object.assign(u, data || {});
    scheduleSave();
    return u;
}

loadStore();
process.on('exit', () => { try { writeStoreSync(); } catch {} });
process.on('SIGINT', () => { try { writeStoreSync(); } catch {} process.exit(0); });

// ══════════════════════════════════════════════════════════════════
// ─── HUSBANDO POOL ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const HUSBU_POOL = [
    // Common (weight 50)
    { name: 'Yuji Itadori',    age: 16, height: '173 cm', weight: '80 kg', tier: 'Common',    keyword: 'Yuji Itadori aesthetic icon',                 weightChance: 50 },
    { name: 'Denji',           age: 17, height: '173 cm', weight: '65 kg', tier: 'Common',    keyword: 'Denji aesthetic icon',                         weightChance: 50 },
    { name: 'Loid Forger',     age: 28, height: '187 cm', weight: '75 kg', tier: 'Common',    keyword: 'Loid Forger aesthetic',                        weightChance: 50 },
    { name: 'Tanjiro Kamado',  age: 15, height: '165 cm', weight: '61 kg', tier: 'Common',    keyword: 'Tanjiro Kamado icon',                          weightChance: 50 },
    { name: 'Zenitsu Agatsuma',age: 16, height: '164.5 cm',weight: '58 kg',tier: 'Common',   keyword: 'Zenitsu Agatsuma aesthetic',                   weightChance: 50 },
    { name: 'Izuku Midoriya',  age: 16, height: '166 cm', weight: '60 kg', tier: 'Common',    keyword: 'Izuku Midoriya anime icon',                    weightChance: 50 },
    { name: 'Katsuki Bakugo',  age: 16, height: '172 cm', weight: '63 kg', tier: 'Common',    keyword: 'Katsuki Bakugo aesthetic',                     weightChance: 50 },
    { name: 'Tobio Kageyama',  age: 16, height: '181 cm', weight: '66 kg', tier: 'Common',    keyword: 'Tobio Kageyama icon',                          weightChance: 50 },
    { name: 'Asta',            age: 16, height: '155 cm', weight: '55 kg', tier: 'Common',    keyword: 'Asta Black Clover aesthetic',                  weightChance: 50 },
    { name: 'Toge Inumaki',    age: 17, height: '164 cm', weight: '58 kg', tier: 'Common',    keyword: 'Toge Inumaki aesthetic icon',                  weightChance: 50 },

    // Rare (weight 30)
    { name: 'Megumi Fushiguro',age: 15, height: '175 cm', weight: '60 kg', tier: 'Rare',      keyword: 'Megumi Fushiguro aesthetic icon',              weightChance: 30 },
    { name: 'Shoto Todoroki',  age: 16, height: '176 cm', weight: '62 kg', tier: 'Rare',      keyword: 'Shoto Todoroki aesthetic',                     weightChance: 30 },
    { name: 'Giyuu Tomioka',   age: 21, height: '176 cm', weight: '69 kg', tier: 'Rare',      keyword: 'Giyuu Tomioka aesthetic icon',                 weightChance: 30 },
    { name: 'Sanji',           age: 21, height: '180 cm', weight: '66 kg', tier: 'Rare',      keyword: 'Sanji one piece aesthetic',                    weightChance: 30 },
    { name: 'Roronoa Zoro',    age: 21, height: '181 cm', weight: '71 kg', tier: 'Rare',      keyword: 'Roronoa Zoro aesthetic',                       weightChance: 30 },
    { name: 'Diluc',           age: 22, height: '185 cm', weight: '72 kg', tier: 'Rare',      keyword: 'Diluc aesthetic icon',                         weightChance: 30 },
    { name: 'Kamisato Ayato',  age: 24, height: '188 cm', weight: '75 kg', tier: 'Rare',      keyword: 'Kamisato Ayato aesthetic icon',                weightChance: 30 },
    { name: 'Tengen Uzui',     age: 23, height: '198 cm', weight: '95 kg', tier: 'Rare',      keyword: 'Tengen Uzui aesthetic',                        weightChance: 30 },
    { name: 'Kyojuro Rengoku', age: 20, height: '177 cm', weight: '72 kg', tier: 'Rare',      keyword: 'Kyojuro Rengoku aesthetic',                    weightChance: 30 },

    // Epic (weight 15)
    { name: 'Levi Ackerman',   age: 30, height: '160 cm', weight: '65 kg', tier: 'Epic',      keyword: 'Levi Ackerman aesthetic icon',                 weightChance: 15 },
    { name: 'Itachi Uchiha',   age: 21, height: '178 cm', weight: '58 kg', tier: 'Epic',      keyword: 'Itachi Uchiha aesthetic icon',                 weightChance: 15 },
    { name: 'Kakashi Hatake',  age: 30, height: '181 cm', weight: '67 kg', tier: 'Epic',      keyword: 'Kakashi Hatake aesthetic',                     weightChance: 15 },
    { name: 'Zhongli',         age: 6000,height: '190 cm',weight: '80 kg', tier: 'Epic',      keyword: 'Zhongli aesthetic icon',                       weightChance: 15 },
    { name: 'Tartaglia (Childe)',age: 21,height: '185 cm',weight: '74 kg', tier: 'Epic',      keyword: 'Tartaglia Genshin aesthetic',                  weightChance: 15 },
    { name: 'Neuvillette',     age: 500,height: '188 cm', weight: '75 kg', tier: 'Epic',      keyword: 'Neuvillette aesthetic icon',                   weightChance: 15 },
    { name: 'Jing Yuan',       age: 700,height: '185 cm', weight: '75 kg', tier: 'Epic',      keyword: 'Jing Yuan honkai star rail aesthetic',         weightChance: 15 },
    { name: 'Dan Heng',        age: 25, height: '180 cm', weight: '70 kg', tier: 'Epic',      keyword: 'Dan Heng IL aesthetic icon',                   weightChance: 15 },
    { name: 'Aventurine',      age: 22, height: '183 cm', weight: '73 kg', tier: 'Epic',      keyword: 'Aventurine honkai star rail aesthetic',        weightChance: 15 },
    { name: 'Kaeya',           age: 22, height: '186 cm', weight: '75 kg', tier: 'Epic',      keyword: 'Kaeya Genshin aesthetic',                      weightChance: 15 },

    // Legendary (weight 5)
    { name: 'Gojo Satoru',     age: 28, height: '190 cm', weight: '85 kg', tier: 'Legendary', keyword: 'Gojo Satoru aesthetic icon',                   weightChance: 5 },
    { name: 'Ryomen Sukuna',   age: 1000,height: '173 cm',weight: '80 kg', tier: 'Legendary', keyword: 'Sukuna aesthetic icon',                        weightChance: 5 },
    { name: 'Toji Fushiguro',  age: 30, height: '185 cm', weight: '90 kg', tier: 'Legendary', keyword: 'Toji Fushiguro aesthetic',                     weightChance: 5 },
    { name: 'Gilgamesh',       age: 3000,height: '182 cm',weight: '68 kg', tier: 'Legendary', keyword: 'Gilgamesh Fate aesthetic',                     weightChance: 5 },
    { name: 'Sesshomaru',      age: 900,height: '185 cm', weight: '75 kg', tier: 'Legendary', keyword: 'Sesshomaru aesthetic icon',                    weightChance: 5 },
    { name: 'Alhaitham',       age: 25, height: '188 cm', weight: '76 kg', tier: 'Legendary', keyword: 'Alhaitham aesthetic icon',                     weightChance: 5 },
    { name: 'Dazai Osamu',     age: 22, height: '181 cm', weight: '67 kg', tier: 'Legendary', keyword: 'Dazai Osamu aesthetic',                        weightChance: 5 },
];

// ══════════════════════════════════════════════════════════════════
// ─── HUSBANDO IMAGE FETCH ─────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const PLACEHOLDER = 'https://i.pinimg.com/736x/8f/3e/2a/8f3e2a77ec65cdbcfad4ff3bc17e825f.jpg';

async function fetchHusbuImage(keyword) {
    try {
        const res = await axios.get(
            `https://api.cuki.biz.id/api/search/pinterest?apikey=cuki-x&query=${encodeURIComponent(keyword)}&type=image`,
            { timeout: 15000 },
        );
        const results = res.data?.data?.results;
        if (Array.isArray(results) && results.length > 0) {
            const valid = results.filter(r => r.image_url);
            if (valid.length > 0) {
                const limit = Math.min(15, valid.length);
                return valid[Math.floor(Math.random() * limit)].image_url;
            }
        }
    } catch (e) {
        console.error('[HUSBU] Pinterest API error:', e?.message);
    }
    return PLACEHOLDER;
}

async function fetchBuffer(url) {
    try {
        const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 15000 });
        return Buffer.from(res.data);
    } catch { return null; }
}

// ══════════════════════════════════════════════════════════════════
// ─── ROLL WEIGHTED ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function rollHusbu() {
    const total = HUSBU_POOL.reduce((acc, h) => acc + h.weightChance, 0);
    let r = Math.random() * total;
    for (const h of HUSBU_POOL) {
        r -= h.weightChance;
        if (r <= 0) return h;
    }
    return HUSBU_POOL[HUSBU_POOL.length - 1];
}

// ══════════════════════════════════════════════════════════════════
// ─── SEND INTERACTIVE HUSBU MESSAGE ───────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function sendHusbuMessage(sock, chatId, husbu, textContent, customButtons = null, quotedMsg = null) {
    // Get image
    let imgBuffer = null;
    if (husbu.imageUrl) imgBuffer = await fetchBuffer(husbu.imageUrl);
    if (!imgBuffer) {
        const newUrl = await fetchHusbuImage(husbu.keyword);
        husbu.imageUrl = newUrl;
        imgBuffer = (await fetchBuffer(newUrl)) || Buffer.alloc(0);
    }

    let media = null;
    try {
        media = await prepareWAMessageMedia(
            { image: imgBuffer },
            { upload: sock.waUploadToServer },
        );
    } catch (e) {
        console.error('[HUSBU] media prep failed:', e?.message);
    }

    // Build buttons
    let buttons = customButtons;
    if (!buttons) {
        if (husbu.affection < 80) {
            buttons = [
                { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🚶 Walk Together', id: '.husbuaction walk' }) },
                { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '☕ Cafe Date',     id: '.husbuaction cafe' }) },
                { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🎬 Cinema',        id: '.husbuaction cinema' }) },
                { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🛍️ Shopping',      id: '.husbuaction shopping' }) },
            ];
        } else if (husbu.affection < 100) {
            buttons = [
                { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🫂 Hug Him',       id: '.husbuaction hug' }) },
                { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '💋 Kiss Cheek',    id: '.husbuaction kiss' }) },
                { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🛏️ Sleep Together', id: '.husbuaction sleep' }) },
                { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🛁 Bathe Together', id: '.husbuaction bathe' }) },
            ];
        } else {
            if (!husbu.married) {
                buttons = [
                    { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '💍 Accept His Proposal', id: '.husbuaction marry' }) },
                    { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '💝 Ask for Money',       id: '.husbuaction gift' }) },
                ];
            } else {
                buttons = [
                    { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '👨‍👩‍👦 Family Time', id: '.husbuaction family' }) },
                    { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '💌 Tease Him',      id: '.husbuaction tease' }) },
                ];
            }
        }
    }

    let footer = '❤️ Make him fall for you!';
    if (customButtons) footer = '💭 He is waiting for your answer...';
    else if (husbu.married) footer = '❤️ You are officially his wife!';

    const msg = generateWAMessageFromContent(chatId, proto.Message.fromObject({
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2,
                },
                interactiveMessage: {
                    body:   { text: textContent },
                    footer: { text: footer },
                    header: {
                        title:    `🌟 *${husbu.tier.toUpperCase()} TIER HUSBANDO* 🌟`,
                        subtitle: husbu.name,
                        hasMediaAttachment: !!media?.imageMessage,
                        ...(media?.imageMessage ? { imageMessage: media.imageMessage } : {}),
                    },
                    contextInfo: { ...forwardInfo },
                    nativeFlowMessage: { buttons },
                },
            },
        },
    }), { quoted: quotedMsg });

    await sock.relayMessage(chatId, msg.message, { messageId: msg.key.id });
}

// ══════════════════════════════════════════════════════════════════
// ─── COMMAND: gachahusbu (main) ───────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function cmdGacha(sock, m, args, context) {
    const { chatId, reply, sender, prefix } = context;
    const user = getUser(sender);

    if (user.husbu) {
        const married = user.husbu.married;
        return reply(
            `⚠️ *You already have a Husbando!*\n\n` +
            `Name      : *${user.husbu.name}*\n` +
            `Tier      : *${user.husbu.tier}*\n` +
            `Affection : *${user.husbu.affection}/100*\n\n` +
            `Do not be greedy! Keep the one you have.${married ? ' You are already married!' : ' He is trying to win your heart!'}\n` +
            `Use *${prefix}husbuku* to interact with him.`,
        );
    }

    const sub = (args[0] || '').toLowerCase();

    if (sub !== 'start') {
        const guide =
            `💕 *HUSBU GACHA SYSTEM* 💕\n\n` +
            `Interactive virtual dating sim to win your dream anime man! Grab his attention, make him fall in love, and marry him!\n\n` +
            `*COMMANDS:*\n` +
            `• *${prefix}gachahusbu* — Open this guide\n` +
            `• *${prefix}husbuku* — Show your current husbando panel\n` +
            `• *${prefix}tinggalinhusbu* — Dump him and reset\n\n` +
            `*STORY:*\n` +
            `1. Press **Start Gacha** below to summon your man.\n` +
            `2. There are 3 relationship phases based on Affection.\n` +
            `3. *Approach Phase (< 80)*: Choose date routes. Each choice affects his feelings.\n` +
            `4. *Intimate Phase (80-99)*: More intimate actions open up. Do not cross the line too early, or he will lose interest!\n` +
            `5. *Marriage Phase (100)*: Make him propose for *exclusive rewards* (coins + limit)!`;

        const msg = generateWAMessageFromContent(chatId, proto.Message.fromObject({
            viewOnceMessage: {
                message: {
                    messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                    interactiveMessage: {
                        body:   { text: guide },
                        footer: { text: 'Press the button below to summon your future husband!' },
                        contextInfo: { ...forwardInfo },
                        nativeFlowMessage: {
                            buttons: [
                                { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🎲 Summon Husbando Now!', id: `${prefix}gachahusbu start` }) },
                            ],
                        },
                    },
                },
            },
        }), { quoted: m });

        return sock.relayMessage(chatId, msg.message, { messageId: msg.key.id });
    }

    // START — roll the husbando
    await react(sock, chatId, m.key, '🕕');

    try {
        const base = rollHusbu();
        const husbu = {
            ...base,
            affection: 50,
            married: false,
            imageUrl: await fetchHusbuImage(base.keyword),
        };

        user.husbu = husbu;
        setUser(sender, { husbu });

        const text =
            `🎉 *KYAAA! YOU GOT A NEW HUSBANDO!* 🎉\n\n` +
            `💖 *Name*      : ${husbu.name}\n` +
            `🎂 *Age*       : ${husbu.age} y.o.\n` +
            `📏 *Height*    : ${husbu.height}\n` +
            `⚖️ *Weight*    : ${husbu.weight}\n` +
            `💎 *Tier*      : ${husbu.tier}\n` +
            `💞 *Affection* : ${husbu.affection}/100\n\n` +
            `Choose an interaction below to start dating. Choose carefully — his feelings depend on it!`;

        await react(sock, chatId, m.key, '✅');
        await sendHusbuMessage(sock, chatId, husbu, text, null, m);
    } catch (err) {
        console.error('[HUSBU:start]', err?.message);
        await react(sock, chatId, m.key, '☢');
        return reply(global.mess?.error?.fitur || 'Failed to roll a husbando.');
    }
}

// ══════════════════════════════════════════════════════════════════
// ─── COMMAND: husbuku (show current husbando) ─────────────────────
// ══════════════════════════════════════════════════════════════════
async function cmdMyHusbu(sock, m, args, context) {
    const { chatId, reply, sender, prefix } = context;
    const user = getUser(sender);

    if (!user.husbu) {
        return reply(
            `⚠️ *You don't have a Husbando yet!*\n` +
            `Type *${prefix}gachahusbu* to start!`,
        );
    }

    await react(sock, chatId, m.key, '🕕');
    const husbu = user.husbu;
    const status = husbu.married ? 'Married 💍' : 'Dating 💖';

    const text =
        `📸 *YOUR HUSBANDO STATUS* 📸\n\n` +
        `💖 *Name*      : ${husbu.name}\n` +
        `🎂 *Age*       : ${husbu.age} y.o.\n` +
        `💎 *Tier*      : ${husbu.tier}\n` +
        `💞 *Affection* : ${husbu.affection}/100\n` +
        `💍 *Status*    : ${status}\n\n` +
        `Continue interacting by picking a date action below!`;

    await react(sock, chatId, m.key, '✅');
    return sendHusbuMessage(sock, chatId, husbu, text, null, m);
}

// ══════════════════════════════════════════════════════════════════
// ─── COMMAND: tinggalinhusbu (dump) ───────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function cmdDumpHusbu(sock, m, args, context) {
    const { chatId, reply, sender } = context;
    const user = getUser(sender);

    if (!user.husbu) return reply(`⚠️ *You do not even have a husbando!*`);

    const husbuName = user.husbu.name;
    user.husbu = null;
    setUser(sender, { husbu: null });

    await react(sock, chatId, m.key, '💔');
    return reply(
        `💔 *YOU DUMPED ${husbuName.toUpperCase()}!*\n\n` +
        `You packed his things and told him to leave. He stared at you with deep disappointment, turned away without a word, and disappeared into the rain.\n\n` +
        `You are officially broken up.`,
    );
}

// ══════════════════════════════════════════════════════════════════
// ─── COMMAND: husbuaction (interactive actions) ───────────────────
// ══════════════════════════════════════════════════════════════════
async function cmdHusbuAction(sock, m, args, context) {
    const { chatId, reply, sender, prefix } = context;
    const user = getUser(sender);

    if (!user.husbu) {
        await react(sock, chatId, m.key, '❌');
        return reply(`You don't have a husbando yet! Use *${prefix}gachahusbu* to get one.`);
    }

    const action = (args[0] || '').toLowerCase();
    const husbu = user.husbu;
    let affectionChange = 0;
    let responseText = '';

    // ── Sub-menu expansions (date routes) ─────────────────────
    if (action === 'jalanjalan') {
        return sendHusbuMessage(sock, chatId, husbu,
            `You and *${husbu.name}* are walking together. He looks bored. Where do you take him?`,
            [
                { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🌳 Picnic in the Park', id: '.husbuaction kencan_taman' }) },
                { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🎢 Amusement Park',    id: '.husbuaction kencan_mall' }) },
            ],
            m,
        );
    }
    if (action === 'kafe') {
        return sendHusbuMessage(sock, chatId, husbu,
            `*${husbu.name}* treats you at his favorite cafe. He asks for your drink choice.`,
            [
                { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '☕ Bitter Coffee', id: '.husbuaction kencan_kopi' }) },
                { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🍓 Strawberry Milk', id: '.husbuaction kencan_matcha' }) },
            ],
            m,
        );
    }
    if (action === 'bioskop') {
        return sendHusbuMessage(sock, chatId, husbu,
            `You go to the cinema together. He lets you pick the movie.`,
            [
                { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '💥 Action', id: '.husbuaction kencan_romantis' }) },
                { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '👻 Horror', id: '.husbuaction kencan_horor' }) },
            ],
            m,
        );
    }
    if (action === 'belanja') {
        return sendHusbuMessage(sock, chatId, husbu,
            `You go to the mall. *${husbu.name}* offers to buy you something. What do you ask for?`,
            [
                { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '👕 Couple Jacket', id: '.husbuaction kencan_baju' }) },
                { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '💍 Luxury Ring',   id: '.husbuaction kencan_perhiasan' }) },
            ],
            m,
        );
    }

    // ── Intimate menu expansions ──────────────────────────────
    if (['peluk', 'cium', 'tidur', 'mandi'].includes(action) && husbu.affection < 80) {
        affectionChange = -(Math.floor(Math.random() * 30) + 30);
        responseText = `💢 *STOP!* You were too aggressive when his feelings were still faint! *${husbu.name}* slaps your hand away, furious and disappointed! "What do you take me for?!" he yells.`;
        return processAffection(sock, chatId, m, sender, user, husbu, responseText, affectionChange, prefix);
    }

    if (action === 'peluk') {
        return sendHusbuMessage(sock, chatId, husbu,
            `You see *${husbu.name}'s* broad back. Great chance — you hug him! Where?`,
            [
                { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🤗 Hug from Behind', id: '.husbuaction intim_belakang' }) },
                { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '💪 Hold His Hand',   id: '.husbuaction intim_depan' }) },
            ],
            m,
        );
    }
    if (action === 'cium') {
        return sendHusbuMessage(sock, chatId, husbu,
            `His face is very close to yours, gazing sharply. You dare to kiss him. Where?`,
            [
                { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '😚 Cheek', id: '.husbuaction intim_kening' }) },
                { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '💋 Lips',  id: '.husbuaction intim_bibir' }) },
            ],
            m,
        );
    }
    if (action === 'tidur') {
        return sendHusbuMessage(sock, chatId, husbu,
            `Late at night, you are both in the room. He pulls you into his arms. Your reaction?`,
            [
                { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🫂 Lean on His Chest', id: '.husbuaction intim_kelon' }) },
                { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🔥 Kiss Back Passionately', id: '.husbuaction intim_panas' }) },
            ],
            m,
        );
    }
    if (action === 'mandi') {
        return sendHusbuMessage(sock, chatId, husbu,
            `*${husbu.name}* pulls you into the bathroom with him. He smiles teasingly. What do you do?`,
            [
                { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🛁 Wash His Back',  id: '.husbuaction intim_punggung' }) },
                { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🧼 Rub His Chest', id: '.husbuaction intim_bahu' }) },
            ],
            m,
        );
    }

    // ── Leaf actions (final outcomes) ─────────────────────────
    const R = (min, max) => Math.floor(Math.random() * (max - min)) + min;

    if (action === 'kencan_taman')      { affectionChange = R(10, 20); responseText = `🌳 *${husbu.name}* enjoys the cool breeze, resting on your lap in the park.`; }
    else if (action === 'kencan_mall')  { affectionChange = R(10, 25); responseText = `🎢 Amusement park was amazing! *${husbu.name}* wins a big teddy bear and gives it to you.`; }
    else if (action === 'kencan_kopi')  { affectionChange = R(10, 20); responseText = `☕ "Elegant choice," he praises you. You sip bitter coffee and chat warmly.`; }
    else if (action === 'kencan_matcha'){ affectionChange = -R(5, 15); responseText = `🍓 He buys you a sweet drink, but the conversation feels off. He looks a bit bored.`; }
    else if (action === 'kencan_romantis') { affectionChange = R(10, 25); responseText = `💥 Action movies are his favorite! He holds your hand tight during the thrilling scenes.`; }
    else if (action === 'kencan_horor') { affectionChange = R(5, 10);  responseText = `👻 *JUMPSCARE!* You flinch and hug him. He chuckles then holds you to shield you from fear.`; }
    else if (action === 'kencan_baju')  { affectionChange = R(10, 25); responseText = `👕 He buys you a matching couple jacket! He smiles proudly seeing you wear it.`; }
    else if (action === 'kencan_perhiasan') { affectionChange = -R(10, 20); responseText = `💍 "I do not have that much money this month," he sighs. He refuses and thinks you are too materialistic.`; }
    else if (action === 'intim_belakang') { affectionChange = R(10, 20); responseText = `🤗 He is surprised when you hug his waist from behind, but his ears redden. He strokes your hand softly.`; }
    else if (action === 'intim_depan')    { affectionChange = R(10, 25); responseText = `💪 You hold his hand tight. He smiles gently, squeezes back, and gazes into your eyes.`; }
    else if (action === 'intim_kening')   { affectionChange = R(5, 15);  responseText = `😚 You peck his cheek. He chuckles and kisses your forehead warmly in return.`; }
    else if (action === 'intim_bibir')    { affectionChange = R(10, 30); responseText = `💋 You kiss his lips suddenly. He widens his eyes before pulling your waist and kissing you back fiercely.`; }
    else if (action === 'intim_kelon')    { affectionChange = R(10, 25); responseText = `🫂 You rest your head on his broad chest. He strokes your hair slowly, whispering how much you mean to him.`; }
    else if (action === 'intim_panas')    { affectionChange = R(15, 35); responseText = `🔥 You gaze at him with desire. He smirks, "You asked for it..." he says in a husky voice before claiming you.`; }
    else if (action === 'intim_punggung') { affectionChange = R(10, 20); responseText = `🛁 You wash his back slowly. Your touch relaxes him and he exhales, closing his eyes.`; }
    else if (action === 'intim_bahu')     { affectionChange = R(15, 30); responseText = `🧼 As you rub his chest, he inhales sharply and grabs your hand. "You did that on purpose, didn't you?" he whispers.`; }

    // ── Marriage ──────────────────────────────────────────────
    else if (action === 'nikah') {
        if (husbu.affection < 100) return reply(`⚠️ Affection is not 100 yet! Wait until he proposes!`);
        if (husbu.married) return reply(`⚠️ You are already married!`);

        husbu.married = true;
        user.husbu = husbu;
        setUser(sender, { husbu });

        responseText =
            `💍 *YOU ACCEPTED ${husbu.name.toUpperCase()}'S PROPOSAL!* 💍\n\n` +
            `He kneels before you with a beautiful diamond ring. "Will you be my wife forever?" he asks. When you nod, he carries you and kisses you with joy!\n\n` +
            `*As his first provision, you receive:*\n` +
            `- ⚡ 5,000 Limit/Energy (rpg-pack)\n` +
            `- 💰 100,000 Coins (rpg-pack)\n\n` +
            `⚠️ Note: rewards affect the *rpg-pack* store, not this plugin.`;

        affectionChange = 0;
    }
    else if (action === 'hadiah') {
        if (husbu.affection < 100) return reply(`⚠️ Your husband is busy working, do not disturb him!`);
        affectionChange = 0;
        responseText =
            `💝 *${husbu.name}* hands you his credit card with a smile, "Use it as much as you want, darling."\n` +
            `You received 💰 5,000 Coins! (rpg-pack reward)`;
    }
    else if (['mesra', 'rayu'].includes(action)) {
        if (!husbu.married) return reply(`This action is for married couples only!`);
        affectionChange = 0;
        responseText = `👨‍👩‍👦 You both enjoy a peaceful romantic dinner. His loving gaze never fades.`;
    }
    else {
        await react(sock, chatId, m.key, '❓');
        return reply(`Unknown action. Please use the buttons.`);
    }

    // ── Apply and show result ─────────────────────────────────
    return processAffection(sock, chatId, m, sender, user, husbu, responseText, affectionChange, prefix);
}

// ══════════════════════════════════════════════════════════════════
// ─── APPLY AFFECTION ──────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function processAffection(sock, chatId, m, sender, user, husbu, responseText, affectionChange, prefix) {
    husbu.affection = Math.max(0, Math.min(100, (husbu.affection || 0) + affectionChange));

    let affectionText;
    if (affectionChange > 0) affectionText = `💞 *Affection:* +${affectionChange} (Total: ${husbu.affection}/100)`;
    else if (affectionChange === 0) affectionText = `💞 *Affection:* ${husbu.affection}/100`;
    else affectionText = `💞 *Affection:* ${affectionChange} (Total: ${husbu.affection}/100)`;

    if (husbu.affection === 100) affectionText = `💞 *Affection MAX! (100/100)*`;

    // Affection hit 0 → he leaves forever
    if (husbu.affection <= 0) {
        const leavingText =
            `💔 *${husbu.name.toUpperCase()} LEFT YOU FOREVER!* 💔\n\n` +
            `${responseText}\n\n${affectionText}\n\n` +
            `Because his affection hit 0, he packed all his things. When you tried to stop him, he slapped your hand away. "This is where we end," he said coldly before leaving.\n` +
            `You lost your husband! Use *${prefix}gachahusbu* to start over.`;

        user.husbu = null;
        setUser(sender, { husbu: null });

        await react(sock, chatId, m.key, '💔');
        return sendMessageWithChannel(sock, chatId, { text: leavingText });
    }

    // Save and show updated card
    user.husbu = husbu;
    setUser(sender, { husbu });

    const updatedText = `${responseText}\n\n${affectionText}`;
    await react(sock, chatId, m.key, husbu.affection === 100 ? '💍' : '✨');
    await sendHusbuMessage(sock, chatId, husbu, updatedText, null, m);
}

// ══════════════════════════════════════════════════════════════════
// ─── REACT HELPER ─────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch { /* ignore */ }
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'gachahusbu',
    aliases:     ['husbuaction', 'leavehusbu', 'myhusbu', 'myhusband', 'husbugacha', 'releasehusbu', 'myhusbu'],
    category:    'fun',
    description: 'Gacha your dream husbando, win his heart, marry him',
    usage:       '.gachahusbu [start] | .husbuku | .tinggalinhusbu',

    async handler(sock, m, args, context) {
        const cmd = (context.command || 'gachahusbu').toLowerCase();

        try {
            if (cmd === 'gachahusbu' || cmd === 'husbugacha') {
                return cmdGacha(sock, m, args, context);
            }
            if (cmd === 'myhusbu' || cmd === 'myhusband' || cmd === 'myhusbu') {
                return cmdMyHusbu(sock, m, args, context);
            }
            if (cmd === 'leavehusbu' || cmd === 'releasehusbu') {
                return cmdDumpHusbu(sock, m, args, context);
            }
            if (cmd === 'husbuaction') {
                return cmdHusbuAction(sock, m, args, context);
            }
        } catch (err) {
            console.error(`[HUSBU:${cmd}]`, err?.message || err);
            await react(sock, context.chatId, m.key, '☢');
            return context.reply(global.mess?.error?.fitur || 'Husbu error. Please try again.');
        }
    },
};