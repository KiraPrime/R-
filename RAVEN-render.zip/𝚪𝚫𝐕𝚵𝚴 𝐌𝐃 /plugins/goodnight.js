/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: 'goodnight',
    aliases: ['gn', 'night'],
    category: 'quotes',
    description: 'Send a random good night message',
    usage: '.goodnight',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            const shizokeys = 'shizo';
            const res = await fetch(`https://shizoapi.onrender.com/api/texts/lovenight?apikey=${shizokeys}`);
            if (!res.ok) {
                throw new Error(await res.text());
            }
            const json = await res.json();
            const goodnightMessage = json.result;
            await sendMessageWithChannel(sock, chatId, { text: goodnightMessage }, { quoted: message });
        }
        catch (error) {
            console.error('Goodnight plugin error:', error);
            await sendMessageWithChannel(sock, chatId, { text: '❌ Failed to get goodnight message. Please try again later!' }, { quoted: message });
        }
    }
};
