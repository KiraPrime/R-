'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const fs = require('fs');
const path = require('path');

// ══════════════════════════════════════════════════════════════════
// ─── FORWARD NEWSLETTER CONTEXT (mandatory on all plugins) ────────
// ══════════════════════════════════════════════════════════════════
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── INTERNAL STORE ───────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const DATA_DIR   = path.join(__dirname, 'owner-tools-data');
const STORE_PATH = path.join(DATA_DIR, 'store.json');
const MEDIA_DIR  = path.join(DATA_DIR, 'autoreply-media');

const DEFAULT_STORE = {
    global: {
        autoreplyPrivate:     false,
        globalCustomReplies:  [],
        onlyAdmin:            false,
        onlyOwnerMode:        false,
        onlyThisGroup:        null,
        prefixes:             [],
        noprefix:             false,
    },
    groups: {
        // "<jid>": {
        //   autoreply: true,
        //   customReplies: [{ trigger, reply, image, createdAt }]
        // }
    },
};

let _store = null;
let _saveTimer = null;

function ensureDir() {
    try {
        if (!fs.existsSync(DATA_DIR))  fs.mkdirSync(DATA_DIR, { recursive: true });
        if (!fs.existsSync(MEDIA_DIR)) fs.mkdirSync(MEDIA_DIR, { recursive: true });
    } catch (e) { console.error('[OWNER-TOOLS] mkdir failed:', e?.message); }
}

function loadStore() {
    ensureDir();
    try {
        if (fs.existsSync(STORE_PATH)) {
            const raw = fs.readFileSync(STORE_PATH, 'utf8').trim();
            if (raw) {
                const parsed = JSON.parse(raw);
                _store = {
                    global: { ...DEFAULT_STORE.global, ...(parsed.global || {}) },
                    groups: { ...(parsed.groups || {}) },
                };
                return _store;
            }
        }
    } catch (e) {
        console.error('[OWNER-TOOLS] store corrupted, rebuilding:', e?.message);
    }
    _store = JSON.parse(JSON.stringify(DEFAULT_STORE));
    writeStoreSync();
    return _store;
}

function writeStoreSync() {
    try {
        ensureDir();
        const tmp = STORE_PATH + '.tmp';
        fs.writeFileSync(tmp, JSON.stringify(_store, null, 2), 'utf8');
        fs.renameSync(tmp, STORE_PATH);
    } catch (e) { console.error('[OWNER-TOOLS] write failed:', e?.message); }
}

function scheduleSave() {
    if (_saveTimer) clearTimeout(_saveTimer);
    _saveTimer = setTimeout(() => { _saveTimer = null; writeStoreSync(); }, 500);
    if (_saveTimer.unref) _saveTimer.unref();
}

function getSetting(jid, key, def = null) {
    if (!_store) loadStore();
    if (!jid) return def;
    if (jid === 'global') {
        const v = _store.global?.[key];
        return v === undefined ? def : v;
    }
    const g = _store.groups?.[jid];
    if (!g) return def;
    const v = g[key];
    return v === undefined ? def : v;
}

function setSetting(jid, key, value) {
    if (!_store) loadStore();
    if (!jid) return;
    if (jid === 'global') {
        _store.global = _store.global || {};
        _store.global[key] = value;
        scheduleSave();
        return;
    }
    if (!_store.groups[jid]) _store.groups[jid] = {};
    _store.groups[jid][key] = value;
    scheduleSave();
}

loadStore();
process.on('exit', () => { try { writeStoreSync(); } catch {} });
process.on('SIGINT', () => { try { writeStoreSync(); } catch {} process.exit(0); });

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function jidToNumber(jid) {
    if (!jid) return '';
    return String(jid).split(':')[0].split('@')[0].replace(/[^0-9]/g, '');
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch { /* ignore */ }
}

function getMessageText(m) {
    return (
        m?.message?.conversation ||
        m?.message?.extendedTextMessage?.text ||
        m?.message?.imageMessage?.caption ||
        m?.message?.videoMessage?.caption ||
        ''
    );
}

async function downloadMedia(m) {
    try {
        const q = m?.quoted || m;
        const stream = await q.download?.();
        if (!stream) return null;
        if (Buffer.isBuffer(stream)) return stream;
        const chunks = [];
        for await (const ch of stream) chunks.push(ch);
        return Buffer.concat(chunks);
    } catch { return null; }
}

// ══════════════════════════════════════════════════════════════════
// ─── COMMAND: autoreply ───────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function cmdAutoreply(sock, m, args, context) {
    const { chatId, reply, isGroup, isOwner, isAdmin, prefix } = context;

    const action = (args[0] || '').toLowerCase();
    const privateAutoreply = getSetting('global', 'autoreplyPrivate', false);

    // ── Private sub-command (owner only) ──────────────────────────
    if (action === 'private') {
        if (!isOwner) return reply(global.mess?.only?.owner || 'Owner only.');
        const sub = (args[1] || '').toLowerCase();
        if (sub === 'on') {
            setSetting('global', 'autoreplyPrivate', true);
            await react(sock, chatId, m.key, '✅');
            return reply(`✅ *PRIVATE AUTOREPLY ENABLED*`);
        }
        if (sub === 'off') {
            setSetting('global', 'autoreplyPrivate', false);
            await react(sock, chatId, m.key, '❌');
            return reply(`❌ *PRIVATE AUTOREPLY DISABLED*`);
        }
        return reply(
            `📱 *PRIVATE AUTOREPLY*\n\n` +
            `Status: *${privateAutoreply ? '✅ ON' : '❌ OFF'}*\n\n` +
            `• \`${prefix}autoreply private on\`\n` +
            `• \`${prefix}autoreply private off\``,
        );
    }

    // ── Global sub-command (owner only) ───────────────────────────
    if (action === 'global') {
        if (!isOwner) return reply(global.mess?.only?.owner || 'Owner only.');
        const sub = (args[1] || '').toLowerCase();
        const list = getSetting('global', 'globalCustomReplies', []) || [];

        if (sub === 'add') {
            const full = getMessageText(m);
            const pipeIdx = full.indexOf('|');
            if (pipeIdx === -1) {
                return reply(
                    `❌ *WRONG FORMAT*\n\n` +
                    `Use: \`trigger|reply\`\n\n` +
                    `Example:\n\`${prefix}autoreply global add hello|Hi {name}!\``,
                );
            }
            const addIdx = full.toLowerCase().indexOf('global add ');
            const trigger = full.substring(addIdx + 'global add '.length, pipeIdx).trim().toLowerCase();
            const rpl = full.substring(pipeIdx + 1);
            if (!trigger || !rpl) return reply(`❌ Trigger and reply cannot be empty!`);

            const idx = list.findIndex(r => r.trigger.toLowerCase() === trigger);
            if (idx !== -1) list[idx].reply = rpl;
            else list.push({ trigger, reply: rpl });

            setSetting('global', 'globalCustomReplies', list);
            await react(sock, chatId, m.key, '✅');
            return reply(
                `✅ *GLOBAL AUTOREPLY ADDED*\n\n` +
                `• Trigger: *${trigger}*\n` +
                `• Total: *${list.length}* replies`,
            );
        }

        if (sub === 'del' || sub === 'rm') {
            const trigger = args.slice(2).join(' ').toLowerCase().trim();
            if (!trigger) return reply(`❌ Provide a trigger to delete!`);
            const idx = list.findIndex(r => r.trigger === trigger);
            if (idx === -1) return reply(`❌ Trigger \`${trigger}\` not found!`);
            list.splice(idx, 1);
            setSetting('global', 'globalCustomReplies', list);
            await react(sock, chatId, m.key, '🗑️');
            return reply(`🗑️ *GLOBAL AUTOREPLY REMOVED*\n\nTrigger *${trigger}* removed!`);
        }

        if (sub === 'list' || !sub) {
            if (list.length === 0) {
                return reply(`📋 *GLOBAL AUTOREPLY*\n\nNo data yet.\n\nUse \`${prefix}autoreply global add <trigger>|<reply>\``);
            }
            let txt = `📋 *GLOBAL AUTOREPLY*\n\nTotal: *${list.length}* replies\nApplies to: *All Groups & Private Chats*\n\n*TRIGGERS:*\n`;
            list.forEach((r, i) => {
                txt += `${i + 1}. *${r.trigger}* ${r.image ? '🖼️' : ''}\n   ↳ ${r.reply.substring(0, 30)}${r.reply.length > 30 ? '...' : ''}\n\n`;
            });
            return reply(txt.trim());
        }

        return reply(
            `📱 *GLOBAL AUTOREPLY*\n\n` +
            `> \`${prefix}autoreply global add trigger|reply\`\n` +
            `> \`${prefix}autoreply global del trigger\`\n` +
            `> \`${prefix}autoreply global list\``,
        );
    }

    // ── DM without group context ──────────────────────────────────
    if (!isGroup) {
        return reply(
            `📱 *AUTOREPLY SYSTEM*\n\n` +
            `Private Autoreply: *${privateAutoreply ? '✅ ON' : '❌ OFF'}*\n\n` +
            `*COMMANDS:*\n` +
            `• \`${prefix}autoreply private on/off\` — toggle DM\n` +
            `• \`${prefix}autoreply global add/del/list\` — global triggers\n\n` +
            `_For group settings, use this command inside a group._`,
        );
    }

    // ── Group scope (admin only) ──────────────────────────────────
    if (!isAdmin && !isOwner) {
        return reply(global.mess?.only?.admin || 'Admin only.');
    }

    const groupData = _store.groups?.[chatId] || {};
    const globalSmart = getSetting('global', 'smartTriggers', false);
    const customReplies = groupData.customReplies || [];

    // ── Status / help ─────────────────────────────────────────────
    if (!action || action === 'status') {
        const groupStatus = groupData.autoreply;
        const effective = groupStatus ?? globalSmart;
        return reply(
            `🤖 *GROUP AUTOREPLY*\n\n` +
            `Global status : *${globalSmart ? '✅ ON' : '❌ OFF'}*\n` +
            `Group status  : *${groupStatus === undefined ? 'DEFAULT' : (groupStatus ? '✅ ON' : '❌ OFF')}*\n` +
            `Private status: *${privateAutoreply ? '✅ ON' : '❌ OFF'}*\n` +
            `Effective     : *${effective ? '✅ ON' : '❌ OFF'}*\n` +
            `Custom replies: *${customReplies.length}*\n\n` +
            `*MANAGEMENT:*\n` +
            `• \`${prefix}autoreply on\`\n` +
            `• \`${prefix}autoreply off\`\n` +
            `• \`${prefix}autoreply add <trigger>|<reply>\`\n` +
            `• \`${prefix}autoreply del <trigger>\`\n` +
            `• \`${prefix}autoreply list\`\n` +
            `• \`${prefix}autoreply reset\`\n\n` +
            (isOwner
                ? `*GLOBAL (OWNER):*\n` +
                  `• \`${prefix}autoreply global add <trigger>|<reply>\`\n` +
                  `• \`${prefix}autoreply global del <trigger>\`\n` +
                  `• \`${prefix}autoreply global list\`\n` +
                  `• \`${prefix}autoreply private on/off\`\n\n`
                : '') +
            `*PLACEHOLDERS:* {name} {tag} {sender} {botname} {time} {date}`,
        );
    }

    if (action === 'on') {
        setSetting(chatId, 'autoreply', true);
        await react(sock, chatId, m.key, '✅');
        return reply(`✅ *AUTOREPLY ENABLED*`);
    }

    if (action === 'off') {
        setSetting(chatId, 'autoreply', false);
        await react(sock, chatId, m.key, '❌');
        return reply(`❌ *AUTOREPLY DISABLED*`);
    }

    if (action === 'add') {
        const full = getMessageText(m);
        const pipeIdx = full.indexOf('|');
        if (pipeIdx === -1) {
            return reply(
                `❌ *WRONG FORMAT*\n\n` +
                `Use: *trigger|reply*\n\n` +
                `Text only:\n\`${prefix}ar add hello|Hi {name}! 👋\`\n\n` +
                `With image:\n1. Reply to an image + \`${prefix}ar add trigger|caption\`\n2. Send image with caption \`${prefix}ar add trigger|caption\``,
            );
        }
        const addIdx = full.toLowerCase().indexOf('add ');
        const trigger = full.substring(addIdx + 'add '.length, pipeIdx).trim();
        const rpl = full.substring(pipeIdx + 1);
        if (!trigger) return reply(`❌ Trigger cannot be empty!`);

        // Check for image
        let imageBuffer = null;
        let imagePath = null;
        const hasQuotedImg = m?.quoted && (
            m.quoted.mtype === 'imageMessage' ||
            m.quoted.type === 'image'
        );
        const hasDirectImg = m?.mtype === 'imageMessage' || m?.type === 'image';
        if (hasQuotedImg || hasDirectImg) {
            imageBuffer = await downloadMedia(m);
        }
        if (imageBuffer) {
            const fname = `${chatId.replace('@g.us', '')}_${trigger.replace(/[^a-zA-Z0-9]/g, '_')}_${Date.now()}.jpg`;
            imagePath = path.join(MEDIA_DIR, fname);
            fs.writeFileSync(imagePath, imageBuffer);
        }

        const list = customReplies.slice();
        const idx = list.findIndex(r => r.trigger.toLowerCase() === trigger.toLowerCase());
        const entry = {
            trigger: trigger.toLowerCase(),
            reply: rpl || '',
            image: imagePath || null,
            createdAt: Date.now(),
        };
        if (idx !== -1) {
            // remove old image if different
            if (list[idx].image && list[idx].image !== imagePath) {
                try { if (fs.existsSync(list[idx].image)) fs.unlinkSync(list[idx].image); } catch {}
            }
            list[idx] = entry;
        } else {
            list.push(entry);
        }

        setSetting(chatId, 'customReplies', list);
        await react(sock, chatId, m.key, '✅');
        return reply(
            `✅ *AUTOREPLY ADDED*\n\n` +
            `• Trigger: *${trigger}*\n` +
            (rpl ? `• Reply: ${rpl.substring(0, 50)}${rpl.length > 50 ? '...' : ''}\n` : '') +
            (imagePath ? `• Image: ✅ saved\n` : '') +
            `\nTotal: *${list.length}* replies`,
        );
    }

    if (action === 'del' || action === 'rm' || action === 'remove') {
        const trigger = args.slice(1).join(' ').toLowerCase().trim();
        if (!trigger) return reply(`❌ Provide the trigger to delete!`);
        const list = customReplies.slice();
        const idx = list.findIndex(r => r.trigger === trigger);
        if (idx === -1) return reply(`❌ Trigger \`${trigger}\` not found!`);
        if (list[idx].image) {
            try { if (fs.existsSync(list[idx].image)) fs.unlinkSync(list[idx].image); } catch {}
        }
        list.splice(idx, 1);
        setSetting(chatId, 'customReplies', list);
        await react(sock, chatId, m.key, '🗑️');
        return reply(`🗑️ *AUTOREPLY REMOVED*\n\nTrigger *${trigger}* removed.\nRemaining: *${list.length}*`);
    }

    if (action === 'list') {
        let txt = `📋 *GROUP AUTOREPLY*\n\n`;
        txt += `*DEFAULT TRIGGERS:*\n`;
        txt += `• *@mention* → 👋 Hi! Did someone call the bot?\n`;
        txt += `• *p* → 💬 Please say hello first.\n`;
        txt += `• *bot* → 🤖 Bot is active and ready!\n`;
        txt += `• *assalamualaikum* → Waalaikumsalam.\n\n`;
        if (customReplies.length > 0) {
            txt += `*CUSTOM TRIGGERS:*\n`;
            customReplies.forEach(r => {
                txt += `• *${r.trigger}* ${r.image ? '🖼️' : ''}\n`;
                if (r.reply) txt += `  ↳ ${r.reply.substring(0, 35)}${r.reply.length > 35 ? '...' : ''}\n`;
            });
        } else {
            txt += `*CUSTOM TRIGGERS:*\n_None yet_\n`;
        }
        return reply(txt);
    }

    if (action === 'reset' || action === 'clear') {
        for (const r of customReplies) {
            if (r.image) {
                try { if (fs.existsSync(r.image)) fs.unlinkSync(r.image); } catch {}
            }
        }
        setSetting(chatId, 'customReplies', []);
        await react(sock, chatId, m.key, '🗑️');
        return reply(`🗑️ *AUTOREPLY RESET*`);
    }

    return reply(`❌ Invalid action. Use: on, off, private, add, del, list, reset`);
}

// ══════════════════════════════════════════════════════════════════
// ─── COMMAND: prefix ──────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function getAllPrefixes() {
    const cfg = global.xprefix || '.';
    const db = getSetting('global', 'prefixes', []) || [];
    return [...new Set([cfg, ...db])];
}

async function cmdPrefix(sock, m, args, context) {
    const { chatId, reply, isOwner, prefix, command } = context;
    if (!isOwner) return reply(global.mess?.only?.owner || 'Owner only.');

    const cmd = (command || '').toLowerCase();
    const data = {
        prefixes: getSetting('global', 'prefixes', []) || [],
        noprefix: getSetting('global', 'noprefix', false),
    };

    // ── addprefix ─────────────────────────────────────────────────
    if (cmd === 'addprefix') {
        if (args.length === 0) {
            return reply(
                `✏️ *ADD PREFIX*\n\n` +
                `Add new bot prefix(es)\n\n` +
                `Format: \`${prefix}addprefix <p1> <p2> ...\`\n` +
                `Example: \`${prefix}addprefix ! # $\`\n\n` +
                `Special: \`${prefix}addprefix <noprefix>\` — no prefix`,
            );
        }
        if (args.includes('<noprefix>') || args.includes('noprefix')) {
            setSetting('global', 'noprefix', true);
            return reply(`✅ *NOPREFIX ENABLED*`);
        }
        const newPrefixes = args.filter(p => p && p.length <= 5 && !data.prefixes.includes(p));
        if (newPrefixes.length === 0) return reply(`❌ No valid new prefixes.`);
        data.prefixes = [...new Set([...data.prefixes, ...newPrefixes])];
        setSetting('global', 'prefixes', data.prefixes);
        return reply(
            `✅ *PREFIX ADDED*\n\n` +
            `> Added: \`${newPrefixes.join('` `')}\`\n\n` +
            `*Active prefixes:*\n\`${getAllPrefixes().join('` `')}\`` +
            (data.noprefix ? `\n> + *noprefix*` : ''),
        );
    }

    // ── setprefix / gantiprefix ───────────────────────────────────
    if (cmd === 'setprefix' || cmd === 'setprefix') {
        if (args.length === 0) {
            return reply(
                `🔄 *SET PREFIX*\n\n` +
                `Replace all prefixes.\n\n` +
                `Format: \`${prefix}${cmd} <p1> <p2> ...\`\n` +
                `Special: \`${prefix}${cmd} <noprefix>\``,
            );
        }
        const hasNo = args.includes('<noprefix>') || args.includes('noprefix');
        const nps = args.filter(p => p && p.length <= 5 && p !== '<noprefix>' && p !== 'noprefix');
        data.prefixes = [...new Set(nps)];
        setSetting('global', 'prefixes', data.prefixes);
        setSetting('global', 'noprefix', hasNo);

        let txt = `✅ *PREFIX UPDATED*\n\n`;
        if (data.prefixes.length) txt += `> New: \`${data.prefixes.join('` `')}\`\n`;
        if (hasNo) txt += `> *Noprefix: ON*\n`;
        txt += `\n*Active:* \`${getAllPrefixes().join('` `')}\``;
        return reply(txt);
    }

    // ── delprefix ─────────────────────────────────────────────────
    if (cmd === 'delprefix') {
        if (args.length === 0) {
            return reply(
                `🗑️ *DEL PREFIX*\n\n` +
                `Format: \`${prefix}delprefix <p1> <p2> ...\``,
            );
        }
        if (args.includes('<noprefix>') || args.includes('noprefix')) {
            setSetting('global', 'noprefix', false);
            return reply(`✅ *NOPREFIX DISABLED*`);
        }
        const deleted = [];
        data.prefixes = data.prefixes.filter(p => {
            if (args.includes(p)) { deleted.push(p); return false; }
            return true;
        });
        setSetting('global', 'prefixes', data.prefixes);
        return reply(
            `✅ *PREFIX REMOVED*\n\n` +
            `> Deleted: \`${deleted.length ? deleted.join('` `') : 'None'}\`\n\n` +
            `*Active:* \`${getAllPrefixes().join('` `')}\``,
        );
    }

    // ── listprefix ────────────────────────────────────────────────
    if (cmd === 'listprefix') {
        const cfgPref = global.xprefix || '.';
        let txt = `📋 *LIST PREFIX*\n\n`;
        txt += `Default  : \`${cfgPref}\`\n`;
        txt += `Noprefix : ${data.noprefix ? '✅ ON' : '❌ OFF'}\n\n`;
        if (data.prefixes.length) {
            txt += `*Database:*\n`;
            data.prefixes.forEach((p, i) => { txt += `${i + 1}. \`${p}\`\n`; });
            txt += `\n`;
        }
        txt += `*Total:* ${getAllPrefixes().length}`;
        if (data.noprefix) txt += ` + noprefix`;
        txt += `\n\`${getAllPrefixes().join('` `')}\``;
        return reply(txt);
    }

    // ── resetprefix ───────────────────────────────────────────────
    if (cmd === 'resetprefix') {
        setSetting('global', 'prefixes', []);
        setSetting('global', 'noprefix', false);
        return reply(
            `✅ *PREFIX RESET*\n\n` +
            `> Only config prefix remains.\n` +
            `> Active: \`${global.xprefix || '.'}\``,
        );
    }
}

// ══════════════════════════════════════════════════════════════════
// ─── COMMAND: onlyadmin ───────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function cmdOnlyAdmin(sock, m, args, context) {
    const { chatId, reply, isOwner, prefix, command } = context;
    if (!isOwner) return reply(global.mess?.only?.owner || 'Owner only.');

    const cmd = (command || 'onlyadmin').toLowerCase();
    const current = getSetting('global', 'onlyAdmin', false);
    const arg = (args[0] || '').toLowerCase();

    // Alias shortcuts
    if (cmd === 'selfadmin' || cmd === 'publicadmin') {
        if (current) {
            setSetting('global', 'onlyAdmin', false);
            await react(sock, chatId, m.key, '❌');
            return reply(`❌ *ONLYADMIN DISABLED*`);
        }
        setSetting('global', 'onlyAdmin', true);
        await react(sock, chatId, m.key, '✅');
        return reply(
            `✅ *ONLYADMIN ENABLED*\n\n` +
            `Access:\n✅ Group admins\n✅ Owners\n❌ Regular members`,
        );
    }

    if (!arg || arg === 'status') {
        return reply(
            `🔒 *ONLYADMIN*\n\n> Status: ${current ? '✅ ON' : '❌ OFF'}\n\n` +
            `> \`${prefix}onlyadmin on\`\n> \`${prefix}onlyadmin off\``,
        );
    }

    if (arg === 'on') {
        if (current) return reply(`⚠️ OnlyAdmin is already active.`);
        setSetting('global', 'onlyAdmin', true);
        await react(sock, chatId, m.key, '✅');
        return reply(
            `✅ *ONLYADMIN ENABLED*\n\n` +
            `Access:\n✅ Group admins\n✅ Owners\n✅ Private chats\n❌ Regular group members`,
        );
    }

    if (arg === 'off') {
        if (!current) return reply(`⚠️ OnlyAdmin is already inactive.`);
        setSetting('global', 'onlyAdmin', false);
        await react(sock, chatId, m.key, '❌');
        return reply(`❌ *ONLYADMIN DISABLED*`);
    }

    return reply(`❌ Invalid argument. Use: \`on\` or \`off\``);
}

// ══════════════════════════════════════════════════════════════════
// ─── COMMAND: onlyowner ───────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function cmdOnlyOwner(sock, m, args, context) {
    const { chatId, reply, isOwner, prefix, sender } = context;
    if (!isOwner) return reply(global.mess?.only?.owner || 'Owner only.');

    const mode = (args[0] || '').toLowerCase();

    if (mode !== 'on' && mode !== 'off') {
        return reply(
            `╭───〔 ONLY OWNER MODE 〕───⬣\n│\n│ ✦ *How to use*\n│\n` +
            `│  • \`${prefix}onlyowner on\`\n` +
            `│  • \`${prefix}onlyowner off\`\n│\n` +
            `│ ✦ *Function*\n│\n` +
            `│  Only main owner, additional owners, and creator\n` +
            `│  can use the bot when active.\n│\n` +
            `╰──────────────────⬣`,
        );
    }

    const enable = mode === 'on';
    setSetting('global', 'onlyOwnerMode', enable);

    const status = enable ? '🟢 ACTIVE' : '🔴 INACTIVE';
    const msg = enable
        ? '> Only OWNER, ADDITIONAL OWNER & CREATOR can use the bot now!'
        : '> All USERS can use the bot now!';

    return sendMessageWithChannel(sock, chatId, {
        text:
            `╭───〔 ONLY OWNER MODE 〕───⬣\n│\n│ ✦ Status\n│\n│  ${status}\n│\n│ ${msg}\n│\n│ ✦ Changed by\n│  @${String(sender).split('@')[0]}\n│\n╰──────────────────⬣`,
        mentions: [sender],
    });
}

// ══════════════════════════════════════════════════════════════════
// ─── COMMAND: onlythisgrup ────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function cmdOnlyThisGroup(sock, m, args, context) {
    const { chatId, reply, isOwner, isGroup, groupMetadata } = context;
    if (!isOwner) return reply(global.mess?.only?.owner || 'Owner only.');
    if (!isGroup) return reply(global.mess?.only?.group || 'Group only.');

    const current = getSetting('global', 'onlyThisGroup', null);

    // Already locked to this group → unlock
    if (current && (current === chatId || current.jid === chatId)) {
        setSetting('global', 'onlyThisGroup', null);
        return reply(`🔓 *UNLOCKED*\n\nBot is now public again.`);
    }

    // Verify bot is admin
    if (!groupMetadata || !Array.isArray(groupMetadata.participants)) {
        return reply(`❌ Could not fetch group metadata.`);
    }
    const botJid = (sock.user?.id || '').split(':')[0] + '@s.whatsapp.net';
    const botNum = jidToNumber(botJid);
    const botP = groupMetadata.participants.find(p => jidToNumber(p.id || p.jid || '') === botNum);
    if (!botP?.admin) {
        return reply(`❌ *ACCESS DENIED*\n\nBot must be an admin of this group first.`);
    }

    const inviteCode = await sock.groupInviteCode(chatId).catch(() => null);
    if (!inviteCode) return reply(`❌ Could not fetch invite code.`);

    const inviteLink = `https://chat.whatsapp.com/${inviteCode}`;
    const groupName = groupMetadata.subject || 'Unknown Group';

    setSetting('global', 'onlyThisGroup', {
        jid: chatId,
        name: groupName,
        link: inviteLink,
    });

    return reply(
        `🔒 *LOCKED SUCCESSFULLY*\n\n` +
        `The bot will now only work in:\n*${groupName}*\n\n` +
        `Users in other groups will be redirected to:\n${inviteLink}\n\n` +
        `Type \`.onlythisgrup\` again to unlock.`,
    );
}

// ══════════════════════════════════════════════════════════════════
// ─── EVENT HOOK: autoreply triggers ───────────────────────────────
// ══════════════════════════════════════════════════════════════════
let _bound = false;
let _boundSock = null;

function resolvePlaceholders(tpl, ctx) {
    const now = new Date();
    return String(tpl)
        .replace(/{name}/gi,   ctx.name || 'User')
        .replace(/{tag}/gi,    `@${ctx.senderNumber}`)
        .replace(/{sender}/gi, ctx.senderNumber)
        .replace(/{botname}/gi, global.botName || 'Bot')
        .replace(/{time}/gi,   now.toLocaleTimeString('en-GB').slice(0, 5))
        .replace(/{date}/gi,   now.toLocaleDateString('en-GB'));
}

async function handleAutoreply(sock, raw) {
    try {
        const chatJid = raw.key?.remoteJid || '';
        const fromMe = raw.key?.fromMe;
        if (fromMe) return;

        const body = getMessageText(raw);
        if (!body) return;

        const sender = raw.key?.participant || raw.key?.remoteJid || '';
        const senderNumber = jidToNumber(sender);
        const pushName = raw.pushName || 'User';

        const isGroup = chatJid.endsWith('@g.us');
        const isPrivate = !isGroup && !chatJid.endsWith('@broadcast') && !chatJid.endsWith('@newsletter');

        // ── Private autoreply (owner global setting) ──────────────
        if (isPrivate) {
            const enabled = getSetting('global', 'autoreplyPrivate', false);
            if (enabled !== true) return;
            await runTriggers(sock, chatJid, body, sender, pushName, isPrivate);
            return;
        }

        if (!isGroup) return;

        // ── Group autoreply (per-group toggle) ────────────────────
        const enabled = getSetting(chatJid, 'autoreply', false);
        const globalEnabled = getSetting('global', 'smartTriggers', false);
        if (enabled !== true && globalEnabled !== true) return;

        await runTriggers(sock, chatJid, body, sender, pushName, false);
    } catch (e) {
        console.error('[OWNER-TOOLS-EVENT]', e?.message);
    }
}

async function runTriggers(sock, chatJid, body, sender, pushName, isPrivate) {
    const lower = String(body).toLowerCase().trim();
    const senderNumber = jidToNumber(sender);

    const ctx = {
        name: pushName,
        senderNumber,
    };

    // ── Global triggers ──────────────────────────────────────────
    const globals = getSetting('global', 'globalCustomReplies', []) || [];
    for (const r of globals) {
        if (!r?.trigger) continue;
        if (lower === r.trigger.toLowerCase() || lower.includes(r.trigger.toLowerCase())) {
            const replyText = resolvePlaceholders(r.reply || '', ctx);
            await sendMessageWithChannel(sock, chatJid, {
                text: replyText,
                mentions: [`${senderNumber}@s.whatsapp.net`],
            });
            return;
        }
    }

    // ── Group triggers (only in groups) ──────────────────────────
    if (!isPrivate) {
        const groupReplies = getSetting(chatJid, 'customReplies', []) || [];
        for (const r of groupReplies) {
            if (!r?.trigger) continue;
            if (lower === r.trigger.toLowerCase() || lower.includes(r.trigger.toLowerCase())) {
                const replyText = resolvePlaceholders(r.reply || '', ctx);
                const content = { text: replyText, mentions: [`${senderNumber}@s.whatsapp.net`] };
                if (r.image && fs.existsSync(r.image)) {
                    content.image = fs.readFileSync(r.image);
                }
                await sendMessageWithChannel(sock, chatJid, content);
                return;
            }
        }
    }
}

async function onMessagesUpsert(payload) {
    const sock = _boundSock;
    if (!sock) return;
    const messages = Array.isArray(payload?.messages) ? payload.messages : [];
    for (const raw of messages) {
        if (!raw?.message || !raw?.key) continue;
        if (raw.key.fromMe) continue;

        const chatJid = raw.key.remoteJid || '';

        // Skip command messages
        const body = getMessageText(raw);
        const prefix = global.xprefix || '.';
        if (body && body.startsWith(prefix)) continue;

        await handleAutoreply(sock, raw);
    }
}

function bindSock(sock) {
    if (_bound || !sock || !sock.ev) return;
    _bound = true;
    _boundSock = sock;
    try {
        sock.ev.on('messages.upsert', onMessagesUpsert);
        console.log('[OWNER-TOOLS] event hook registered');
    } catch (e) {
        console.error('[OWNER-TOOLS] failed to bind:', e?.message);
        _bound = false;
    }
}

function tryBindFromGlobals() {
    const candidates = [global.sock, global.conn, global.Hanz, global.client];
    for (const c of candidates) {
        if (c && c.ev) { bindSock(c); return; }
    }
}
tryBindFromGlobals();
let _retryCount = 0;
const _retryTimer = setInterval(() => {
    if (_bound) return clearInterval(_retryTimer);
    if (++_retryCount >= 10) return clearInterval(_retryTimer);
    tryBindFromGlobals();
}, 3000);
if (_retryTimer.unref) _retryTimer.unref();

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'autoreply',
    aliases:     [
        'ar', 'smarttrigger', 'smarttriggers',
        'addprefix', 'setprefix', 'setprefix',
        'delprefix', 'listprefix', 'resetprefix',
        'onlyadmin', 'selfadmin', 'publicadmin', 'adminonly',
        'onlyowner', 'onlyownerbot', 'modeowner', 'owneronly',
        'onlythisgroup', 'onlythisgroup', 'grouplock', 'lockgroup',
    ],
    category:    'owner',
    description: 'Owner tools (autoreply, prefix manager, access locks)',
    usage:       'Various — see .autoreply for the entry point',

    async handler(sock, m, args, context) {
        if (!_bound) bindSock(sock);

        const calledAs = (context.command || 'autoreply').toLowerCase();

        try {
            // ── autoreply ─────────────────────────────────────────
            if (['autoreply', 'ar', 'smarttrigger', 'smarttriggers'].includes(calledAs)) {
                return await cmdAutoreply(sock, m, args, context);
            }

            // ── prefix manager ────────────────────────────────────
            if (['addprefix', 'setprefix', 'setprefix', 'delprefix', 'listprefix', 'resetprefix'].includes(calledAs)) {
                return await cmdPrefix(sock, m, args, context);
            }

            // ── onlyadmin ─────────────────────────────────────────
            if (['onlyadmin', 'selfadmin', 'publicadmin', 'adminonly'].includes(calledAs)) {
                return await cmdOnlyAdmin(sock, m, args, context);
            }

            // ── onlyowner ─────────────────────────────────────────
            if (['onlyowner', 'onlyownerbot', 'modeowner', 'owneronly'].includes(calledAs)) {
                return await cmdOnlyOwner(sock, m, args, context);
            }

            // ── onlythisgrup ──────────────────────────────────────
            if (['onlythisgroup', 'onlythisgroup', 'grouplock', 'lockgroup'].includes(calledAs)) {
                return await cmdOnlyThisGroup(sock, m, args, context);
            }

            return context.reply(`❌ Unknown owner tool: \`${calledAs}\``);
        } catch (err) {
            console.error(`[OWNER-TOOLS:${calledAs}]`, err?.message || err);
            await react(sock, context.chatId, m.key, '❌');
            return context.reply(global.mess?.error?.fitur || 'Feature error.');
        }
    },

    // Exposed
    _getSetting: getSetting,
    _setSetting: setSetting,
    bindSock,
};