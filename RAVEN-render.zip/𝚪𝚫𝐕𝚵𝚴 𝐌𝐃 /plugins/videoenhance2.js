'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const crypto = require('crypto');

// ─── Enhancer ─────────────────────────────────────────────────────
async function hdvideo(buffer) {
    const baseApi       = 'https://api.unblurimage.ai';
    const productSerial = crypto.randomUUID().replace(/-/g, '');
    const sleep         = ms => new Promise(r => setTimeout(r, ms));

    async function jsonFetch(url, options = {}) {
        const res  = await fetch(url, options);
        const text = await res.text();
        let json;
        try {
            json = text ? JSON.parse(text) : null;
        } catch {
            return { __httpError: true, status: res.status, raw: text };
        }
        if (!res.ok) return { __httpError: true, status: res.status, raw: json };
        return json;
    }

    const uploadForm = new FormData();
    uploadForm.set('video_file_name', `cli-${Date.now()}.mp4`);

    const uploadResp = await jsonFetch(`${baseApi}/api/upscaler/v1/ai-video-enhancer/upload-video`, {
        method: 'POST',
        body: uploadForm,
    });
    if (uploadResp.__httpError || uploadResp.code !== 100000) throw new Error('Upload failed');

    const { url: uploadUrl, object_name } = uploadResp.result || {};
    if (!uploadUrl || !object_name) throw new Error('Invalid upload');

    const putRes = await fetch(uploadUrl, {
        method: 'PUT',
        headers: { 'content-type': 'video/mp4' },
        body: buffer,
    });
    if (!putRes.ok) throw new Error('Video upload failed');

    const cdnUrl = `https://cdn.unblurimage.ai/${object_name}`;

    const jobForm = new FormData();
    jobForm.set('original_video_file', cdnUrl);
    jobForm.set('resolution', '2k');
    jobForm.set('is_preview', 'false');

    const createJobResp = await jsonFetch(`${baseApi}/api/upscaler/v2/ai-video-enhancer/create-job`, {
        method: 'POST',
        body: jobForm,
        headers: {
            'product-serial': productSerial,
            authorization: '',
        },
    });
    if (createJobResp.__httpError || createJobResp.code !== 100000) throw new Error('Create job failed');

    const { job_id } = createJobResp.result || {};
    if (!job_id) throw new Error('Invalid job');

    const startTime = Date.now();
    let attempt = 0;
    let result;

    while (true) {
        attempt++;
        const jobResp = await jsonFetch(`${baseApi}/api/upscaler/v2/ai-video-enhancer/get-job/${job_id}`, {
            method: 'GET',
            headers: {
                'product-serial': productSerial,
                authorization: '',
            },
        });

        if (jobResp.__httpError) throw new Error('Get job failed');

        if (jobResp.code === 100000) {
            result = jobResp.result || {};
            if (result.output_url) break;
        }

        if (Date.now() - startTime > 600000) throw new Error('Processing timeout'); // 10 min
        await sleep(attempt === 1 ? 20000 : 10000);
    }

    return result.output_url;
}

// ─── Plugin export ────────────────────────────────────────────────
module.exports = {
    command:     'hdvideo',
    aliases:     ['videoenhance', 'enhancevideo', 've2'],
    category:    'tools',
    description: 'Enhance/upscale a video to 2K quality with AI — © 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
    usage:       '.hdvideo (reply to a video)',

    async handler(sock, message, args, context) {
        const { chatId, reply } = context;

        // ── Ensure the user replied to a video ───────────
        const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        if (!quoted || !quoted.videoMessage) {
            return reply(
                `🎬 *HD VIDEO ENHANCER*\n\n` +
                `> Enhance/upscale a video to 2K with AI\n\n` +
                `> Reply to a video and type \`.hdvideo\`\n\n` +
                `📝 *Info:*\n` +
                `> • Output resolution: 2K\n` +
                `> • Processing: 5-10 minutes\n` +
                `> • Max video size: 50 MB\n\n` +
                `⚠️ *Note:*\n` +
                `> • API server may be under maintenance\n` +
                `> • If it errors, retry later`
            );
        }

        await reply(
            `⏳ *Processing video...*\n\n` +
            `🎬 *Step 1/4:* Uploading video\n` +
            `🕐 This may take 5-10 minutes, please wait.`
        );

        try {
            // ── Download the replied video ───────────────
            const { downloadMediaMessage } = require('@whiskeysockets/baileys');
            const media = await downloadMediaMessage(
                {
                    key:     message.key,
                    message: { videoMessage: quoted.videoMessage },
                },
                'buffer',
                {},
                { reuploadRequest: sock.updateMediaMessage }
            );

            if (!media) return reply(`❌ Failed to download the video.`);

            if (media.length > 50 * 1024 * 1024) {
                return reply(
                    `❌ *VIDEO TOO LARGE*\n\n` +
                    `> Max size: 50 MB\n` +
                    `> Your video: ${(media.length / 1024 / 1024).toFixed(2)} MB\n\n` +
                    `> Try with a smaller video.`
                );
            }

            await reply(
                `🎬 *Step 2/4:* Sending to AI server\n` +
                `📦 Size: ${(media.length / 1024 / 1024).toFixed(2)} MB`
            );

            const resultUrl = await hdvideo(media);

            await reply(
                `🎬 *Step 3/4:* Downloading enhanced video\n` +
                `🔗 Link received, downloading...`
            );

            const response    = await fetch(resultUrl);
            const videoBuffer = Buffer.from(await response.arrayBuffer());

            await reply(
                `🎬 *Step 4/4:* Sending result...\n` +
                `📁 Result size: ${(videoBuffer.length / 1024 / 1024).toFixed(2)} MB`
            );

            await sock.sendMessage(
                chatId,
                {
                    video: videoBuffer,
                    caption:
                        `✅ *VIDEO ENHANCED!*\n\n` +
                        `🎬 Quality: 2K\n` +
                        `📊 Size: ${(videoBuffer.length / 1024 / 1024).toFixed(2)} MB\n\n` +
                        `> Sharper, cleaner video — enjoy!`,
                },
                { quoted: message }
            );
        } catch (error) {
            console.error('[HDVIDEO]', error);

            let errorMsg = `❌ *ERROR*\n\n> ${error.message}\n\n`;

            if (error.message.includes('fetch') || error.message.includes('404')) {
                errorMsg +=
                    `💡 *API seems down:*\n` +
                    `> • Server https://api.unblurimage.ai unreachable (404)\n` +
                    `> • Try again later or with another video\n` +
                    `> • Check the source channel for API status\n\n`;
            }

            errorMsg +=
                `📝 *Suggestions:*\n` +
                `> • Try \`.upscale\` for images\n` +
                `> • Or retry later`;

            return reply(errorMsg);
        }
    },

    // Expose helper for future use
    _hdvideo: hdvideo,
};