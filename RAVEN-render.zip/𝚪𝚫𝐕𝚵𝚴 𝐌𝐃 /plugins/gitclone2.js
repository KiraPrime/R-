/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require('axios');
module.exports = {
    command: 'gitclone2',
    aliases: ['githubdl2', 'clone2'],
    category: 'download',
    description: 'Download a GitHub repository as a ZIP file',
    usage: '.gitclone2 <github-link>',
    async handler(sock, message, args, context) {
        const { chatId } = context;
        const regex = new RegExp('(?:https|git)(?://|@)github.com[/:]([^/:]+)/(.+)', 'i');
        try {
            const link = args[0];
            if (!link) {
                return await sendMessageWithChannel(sock, chatId, {
                    text: `❌ *Missing Link!*\n\nExample: .gitclone2 https://github.com/GlobalTechInfo/MEGA-MD`
                }, { quoted: message });
            }
            if (!regex.test(link)) {
                return await sendMessageWithChannel(sock, chatId, { text: '⚠️ *Invalid GitHub link!*' }, { quoted: message });
            }
            // eslint-disable-next-line prefer-const
            let [_, user, repo] = link.match(regex) || [];
            repo = repo.replace(/.git$/, '');
            const url = `https://api.github.com/repos/${user}/${repo}/zipball`;
            const { default: _axios } = await require('axios');
            const _response = _axios.head;
            const headRes = await axios.head(url);
            const contentDisposition = headRes.headers['content-disposition'];
            let filename = `${repo}.zip`;
            if (contentDisposition) {
                const match = contentDisposition.match(/attachment; filename=(.*)/);
                if (match)
                    filename = match[1];
            }
            await sendMessageWithChannel(sock, chatId, { text: `✳️ *Wait, sending repository...*` }, { quoted: message });
            await sendMessageWithChannel(sock, chatId, {
                document: { url },
                fileName: filename,
                mimetype: 'application/zip',
                caption: `📦 *Repository:* ${user}/${repo}\n✨ *Cloned by 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃*`
            }, { quoted: message });
        }
        catch (err) {
            console.error('Gitclone Error:', err);
            await sendMessageWithChannel(sock, chatId, { text: '❌ *Failed to download the repository.* Make sure it is public.' }, { quoted: message });
        }
    }
};
