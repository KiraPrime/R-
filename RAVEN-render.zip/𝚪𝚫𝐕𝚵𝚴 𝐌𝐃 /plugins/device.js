'use strict';

/*
  DEVICE INFO — Detect device type from a Baileys message ID
  Channel: https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
*/

// Detect device info from a message ID
function getDeviceInfo(id) {
    id = typeof id === 'string' ? id : '';

    return {
        isBaileys: id.startsWith('BAE5') && id.length === 16,

        deviceC:
            id.length > 21
                ? 'Android'
                : id.startsWith('3A')
                    ? 'IPhone'
                    : 'WhatsApp web'
    };
}

// Plugin export
module.exports = {
    command: 'device',
    aliases: ['deviceinfo', 'devinfo'],
    category: 'general',
    description: 'Detect the device type used to send a message',
    usage: '.device (reply to a message)',

    async handler(sock, message, args, context) {
        const { chatId, reply } = context;

        try {
            // Determine which message to analyze
            const targetId =
                message.message?.extendedTextMessage?.contextInfo?.stanzaId ||
                message.key?.id ||
                '';

            if (!targetId) {
                return reply('❌ No message ID found.');
            }

            const info = getDeviceInfo(targetId);

            return reply(
                `📱 *DEVICE INFO*\n\n` +
                `> 🆔 Message ID: \`${targetId}\`\n` +
                `> 📲 Device: *${info.deviceC}*\n` +
                `> 🤖 Baileys: *${info.isBaileys ? '✅ Yes' : '❌ No'}*`
            );
        } catch (e) {
            console.error('[DEVICE]', e?.message);
            return reply(`❌ Error: ${e.message}`);
        }
    },

    _getDeviceInfo: getDeviceInfo,
};