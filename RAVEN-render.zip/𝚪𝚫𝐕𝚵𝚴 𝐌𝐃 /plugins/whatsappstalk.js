'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const moment    = require('moment-timezone');
const PhoneNum  = require('awesome-phonenumber');

// ══════════════════════════════════════════════════════════════════
// ─── FORWARD NEWSLETTER CONTEXT ───────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── CONFIG ───────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const CFG = {
    timezone: 'Africa/Libreville',
    fallbackPp: 'https://telegra.ph/file/70e8de9b1879568954f09.jpg',
};

const regionNames = new Intl.DisplayNames(['en'], { type: 'region' });

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function cleanNumber(input) {
    if (!input) return null;
    const digits = String(input).replace(/\D/g, '');
    return digits ? digits + '@s.whatsapp.net' : null;
}

function getMentions(m) {
    const ctx =
        m?.message?.extendedTextMessage?.contextInfo ||
        m?.message?.imageMessage?.contextInfo ||
        null;
    return ctx?.mentionedJid || [];
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'wastalk',
    aliases:     ['whatsappstalk', 'wastalker'],
    category:    'stalker',
    description: 'Stalk a WhatsApp number (name, status, business info)',
    usage:       '.wastalk <number | @tag>',

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix, command, quoted, sender } = context;

        // ── Resolve target number ─────────────────────────────────
        let raw = null;

        if (quoted?.sender)              raw = quoted.sender;
        else if (getMentions(m).length)  raw = getMentions(m)[0];
        else if (args[0])                raw = args.join(' ');

        if (!raw) {
            return reply(
                `⚠️ *USAGE*\n\n` +
                `> \`${prefix}${command} @tag\`\n` +
                `> \`${prefix}${command} 241xxxx\``,
            );
        }

        const num = cleanNumber(raw);
        if (!num) return reply(`❌ Invalid number.`);

        try {
            // ── Check if user exists ──────────────────────────────
            const onWa = await sock.onWhatsApp(num);
            if (!onWa || !onWa[0]?.exists) {
                return reply(`❌ User does not exist on WhatsApp.`);
            }

            // ── Profile picture ───────────────────────────────────
            let img = CFG.fallbackPp;
            try {
                const pp = await sock.profilePictureUrl(num, 'image');
                if (pp) img = pp;
            } catch {}

            // ── Status (about) ────────────────────────────────────
            let bio = {};
            try { bio = await sock.fetchStatus(num); } catch {}

            // ── Name ──────────────────────────────────────────────
            let name = 'Unknown';
            try {
                name = await sock.getName(num) || num.split('@')[0];
            } catch {}

            // ── Business profile ──────────────────────────────────
            let business = null;
            try { business = await sock.getBusinessProfile(num); } catch {}

            // ── Phone number formatting + country ─────────────────
            let format, country;
            try {
                format = PhoneNum('+' + num.split('@')[0]);
                if (!format.isValid()) {
                    console.log('[WASTALK] phone number invalid for:', num);
                }
                country = regionNames.of(format.getRegionCode('mobile'));
            } catch {
                format = null;
                country = 'Unknown';
            }

            const formattedNumber = format
                ? format.getNumber('international')
                : num.split('@')[0];

            // ── Build the response ────────────────────────────────
            let res =
                `\t\t\t\t*▾ WHATSAPP ▾*\n\n` +
                `*° Country :* ${country ? country.toUpperCase() : '-'}\n` +
                `*° Name :* ${name}\n` +
                `*° Formatted Number :* ${formattedNumber}\n` +
                `*° URL :* wa.me/${num.split('@')[0]}\n` +
                `*° Mention :* @${num.split('@')[0]}\n` +
                `*° Status :* ${bio?.status || '-'}\n` +
                `*° Status Date :* ${bio?.setAt ? moment(bio.setAt).tz(CFG.timezone).format('LLLL') : '-'}\n\n`;

            if (business) {
                res +=
                    `\t\t\t\t*▾ BUSINESS INFO ▾*\n\n` +
                    `*° Business ID :* ${business.wid || '-'}\n` +
                    `*° Website :* ${business.website || '-'}\n` +
                    `*° Email :* ${business.email || '-'}\n` +
                    `*° Category :* ${business.category || '-'}\n` +
                    `*° Address :* ${business.address || '-'}\n` +
                    `*° Timezone :* ${business.business_hours?.timezone || '-'}\n` +
                    `*° Description :* ${business.description || '-'}`;
            } else {
                res += `*Standard WhatsApp Account*`;
            }

            // ── Send ──────────────────────────────────────────────
            await sendMessageWithChannel(sock, chatId, {
                image:    { url: img },
                caption:  res,
                mentions: [num],
            }, { quoted: m });

        } catch (err) {
            console.error('[WASTALK]', err?.message || err);
            return reply(`❌ Failed to stalk this user.`);
        }
    },
};