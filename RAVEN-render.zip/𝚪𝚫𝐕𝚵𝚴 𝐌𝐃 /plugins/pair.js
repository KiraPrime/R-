'use strict';

// .pair <number> — request a WhatsApp pairing code in the current chat.
const startpairing = require('../pair');
const fs = require('fs');
const path = require('path');

const PAIRING_ROOT = path.join(__dirname, '..', 'richstore', 'pairing');
const MAX_SESSIONS = 700;

function normalizeNumber(value) {
    return String(value || '').replace(/[^0-9]/g, '');
}

function sessionCount() {
    if (!fs.existsSync(PAIRING_ROOT)) return 0;
    return fs.readdirSync(PAIRING_ROOT, { withFileTypes: true })
        .filter(entry => entry.isDirectory() && /^\d+@s\.whatsapp\.net$/.test(entry.name))
        .length;
}

module.exports = {
    command: 'pair',
    aliases: ['pairing'],
    category: 'owner',
    description: 'Generate a code to connect a new WhatsApp number',
    usage: '.pair 241xxxxxxxx',
    async handler(sock, message, args, context) {
        const { reply } = context;
        const number = normalizeNumber(args[0]);
        if (!/^\d{7,15}$/.test(number) || number.startsWith('0')) {
            return reply('❌ Usage: `.pair 241xxxxxxxx`\nUse an international number with digits only.');
        }
        if (sessionCount() >= MAX_SESSIONS) {
            return reply(`❌ Limit reached: ${MAX_SESSIONS} persistent sessions maximum.`);
        }

        const target = `${number}@s.whatsapp.net`;
        let replied = false;
        const sendResult = async (code, error) => {
            if (replied) return;
            replied = true;
            if (error) {
                return reply(`Unable to generate a code for *${number}*.\n\n${error.message}\n\nSession conservée, aucune suppression automatique.`);
            }
            return reply(
                `Your WhatsApp pairing code for *${number}* is ready:\n\n` +
                `*${code}*\n\n` +
                `Open WhatsApp → Linked devices → Link a device → Link with phone number instead, then enter this code.`
            );
        };

        try {
            // The callback sends the only user-facing result when WhatsApp is ready.
            startpairing(target, sendResult).catch(error => sendResult(null, error));
        } catch (error) {
            await sendResult(null, error);
        }
    },
};
