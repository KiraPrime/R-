/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require('axios');
module.exports = {
    command: 'quote2',
    aliases: ['quotes2', 'randomquote'],
    category: 'quotes',
    description: 'Get a random inspirational quote',
    usage: '.quote2',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            const res = await axios.get('https://discardapi.dpdns.org/api/quotes/random?apikey=guru');
            if (!res.data || res.data.status !== true) {
                return await sendMessageWithChannel(sock, chatId, { text: '❌ Failed to fetch quote.' }, { quoted: message });
            }
            const quote = res.data.result?.quote || 'No quote found.';
            const _creator = res.data.creator || 'Unknown';
            const replyText = `💬 *Random Quote*\n\n${quote}`;
            await sendMessageWithChannel(sock, chatId, { text: replyText }, { quoted: message });
        }
        catch (err) {
            console.error('Quote plugin error:', err);
            await sendMessageWithChannel(sock, chatId, { text: '❌ Error while fetching quote.' }, { quoted: message });
        }
    }
};
