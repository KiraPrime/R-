/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require('axios');
const { fileTypeFromBuffer } = require('file-type');
module.exports = {
    command: 'fetch',
    aliases: ['get', 'download'],
    category: 'tools',
    description: 'Download a file directly from a URL',
    usage: '.fetch <url>',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const url = args[0];
        if (!url || !url.startsWith('http')) {
            return await sendMessageWithChannel(sock, chatId, { text: 'Provide a valid URL starting with http/https.' });
        }
        try {
            await sendMessageWithChannel(sock, chatId, { text: '📡 *Fetching data...*' });
            const res = await axios.get(url, { responseType: 'arraybuffer' });
            const buffer = Buffer.from(res.data, 'binary');
            const type = await fileTypeFromBuffer(buffer);
            if (!type) {
                return await sendMessageWithChannel(sock, chatId, { text: buffer.toString().slice(0, 1000) });
            }
            if (type.mime.startsWith('image/')) {
                await sendMessageWithChannel(sock, chatId, { image: buffer });
            }
            else if (type.mime.startsWith('video/')) {
                await sendMessageWithChannel(sock, chatId, { video: buffer });
            }
            else if (type.mime.startsWith('audio/')) {
                await sendMessageWithChannel(sock, chatId, { audio: buffer, mimetype: type.mime });
            }
            else {
                await sendMessageWithChannel(sock, chatId, { document: buffer, mimetype: type.mime, fileName: `file.${type.ext}` });
            }
        }
        catch (err) {
            await sendMessageWithChannel(sock, chatId, { text: '❌ Failed to fetch. URL might be private or invalid.' });
        }
    }
};
