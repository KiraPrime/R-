'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
function validateOwner(message, isOwner) {
    if (!isOwner) return false;
    if (message.key?.fromMe) return true;

    const senderNumber = (message.key?.participant || message.key?.remoteJid || '')
        .replace(/[^0-9]/g, '') || '';
    const ownerNumbers = global.owner || [];

    const isInOwnerList = ownerNumbers.some(owner => {
        const cleanOwner = String(owner).replace(/[^0-9]/g, '');
        return senderNumber.includes(cleanOwner) || cleanOwner.includes(senderNumber);
    });
    if (!isInOwnerList) return false;
    if (!senderNumber) return false;

    return true;
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'selfmode',
    aliases:     ['self', 'mode'],
    category:    'owner',
    description: 'Enable self mode (only owner & bot can access) — © 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
    usage:       '.self',

    async handler(sock, message, args, context) {
        const { chatId, reply, isOwner, setSetting } = context;

        try {
            const isRealOwner = validateOwner(message, isOwner);
            if (!isRealOwner) {
                return reply('🚫 *ACCESS DENIED*\n\n> Only the owner can change the bot mode!');
            }

            const currentMode = global.botMode || 'PUBLIC';

            if (currentMode.toLowerCase() === 'self') {
                return reply('ℹ️ Bot is already in *self* mode.');
            }

            global.botMode = 'SELF';
            sock.public = false;
            setSetting('bot', 'botMode', 'self');

            const responseText =
                `🔒 *SELF MODE ENABLED*\n\n` +
                `> Bot will now only respond to:\n` +
                `> • The bot owner\n` +
                `> • The bot itself (fromMe)\n\n` +
                `_Use .public to restore public access_`;

            await reply(responseText);
            console.log(`[Mode] Changed to SELF by ${message.pushName} (${message.key?.participant || message.key?.remoteJid})`);
        } catch (error) {
            console.error('[SELF ERROR]', error);
            await reply(`❌ An error occurred: ${error.message}`);
        }
    },

    // Expose helper for future use
    _validateOwner: validateOwner,
};