/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: 'archivechat',
    aliases: ['archive', 'unarchive', 'unarchivechat'],
    category: 'owner',
    description: 'Archive or unarchive the current chat',
    usage: '.archivechat <archive|unarchive>',
    ownerOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const channelInfo = context.channelInfo || {};
        const rawText = context.rawText || '';
        // Auto-detect from command name
        const isUnarchive = rawText.toLowerCase().startsWith('.unarchive');
        const action = args[0]?.toLowerCase() || (isUnarchive ? 'unarchive' : 'archive');
        if (!['archive', 'unarchive'].includes(action)) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `*📦 ARCHIVE CHAT*\n\n*Usage:*\n• \`.archivechat archive\` — Archive this chat\n• \`.archivechat unarchive\` — Unarchive this chat\n\n_Or use aliases: \`.archive\` / \`.unarchive\`_`,
                ...channelInfo
            }, { quoted: message });
        }
        const shouldArchive = action === 'archive';
        try {
            const lastMsg = message;
            await sock.chatModify({
                archive: shouldArchive,
                lastMessages: [
                    {
                        key: lastMsg.key,
                        messageTimestamp: lastMsg.messageTimestamp
                    }
                ]
            }, chatId);
            await sendMessageWithChannel(sock, chatId, {
                text: shouldArchive
                    ? `📦 *Chat archived!*`
                    : `📂 *Chat unarchived!*`,
                ...channelInfo
            }, { quoted: message });
        }
        catch (e) {
            console.error('[ARCHIVECHAT] Error:', e.message);
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Failed to ${action} chat: ${e.message}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};
