'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function jidToNumber(jid) {
    if (!jid) return '';
    return String(jid).split(':')[0].split('@')[0].replace(/[^0-9]/g, '');
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch { /* ignore */ }
}

/**
 * Check whether a given JID is an admin of groupMeta.
 */
function isParticipantAdmin(groupMeta, jid) {
    if (!groupMeta?.participants || !jid) return false;
    const num = jidToNumber(jid);
    if (!num) return false;
    for (const p of groupMeta.participants) {
        const pNum = jidToNumber(p.id || p.jid || p.phoneNumber || '');
        if (pNum && pNum === num) {
            return ['admin', 'superadmin'].includes(p.admin);
        }
    }
    return false;
}

/**
 * Check whether a given JID is already in the group.
 */
function isParticipantInGroup(groupMeta, num) {
    if (!groupMeta?.participants || !num) return false;
    for (const p of groupMeta.participants) {
        const pNum = jidToNumber(p.id || p.jid || p.phoneNumber || '');
        if (pNum && pNum === num) return true;
    }
    return false;
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'add',
    aliases:     ['addmember', 'invite'],
    category:    'group',
    description: 'Add members to a group (supports multiple numbers + invite link)',
    usage:       '.add <number1> [number2]... [group_link]',

    async handler(sock, m, args, context) {
        const { chatId, reply, isGroup, sender, prefix } = context;

        // ── No args → show help ───────────────────────────────────
        if (!args || args.length === 0) {
            return reply(
                `👥 *ADD MEMBER*\n\n` +
                `> How to use:\n` +
                `> 1. In group: \`${prefix}add <number>\`\n` +
                `> 2. Multiple: \`${prefix}add <number1> <number2> ...\`\n` +
                `> 3. In DM: \`${prefix}add <number> <group_link>\`\n\n` +
                `> Examples:\n` +
                `> \`${prefix}add 6281234567890\`\n` +
                `> \`${prefix}add 628123 628456 628789\`\n` +
                `> \`${prefix}add 628123 https://chat.whatsapp.com/xxx\`\n\n` +
                `> Requirements:\n` +
                `> - Bot must be admin in the target group\n` +
                `> - The executor must be admin (if using a link in DM)`,
            );
        }

        // ── Parse arguments ───────────────────────────────────────
        let targetGroup = isGroup ? chatId : null;
        const targetNumbers = [];

        for (const arg of args) {
            const linkMatch = String(arg).match(/chat\.whatsapp\.com\/([a-zA-Z0-9]+)/);
            if (linkMatch) {
                try {
                    const groupInfo = await sock.groupGetInviteInfo(linkMatch[1]);
                    targetGroup = groupInfo.id;
                } catch {
                    return reply(`❌ *FAILED*\n\n> Invalid or expired group link!`);
                }
            } else if (String(arg).includes('@g.us')) {
                targetGroup = arg;
            } else {
                let num = String(arg).replace(/[^0-9]/g, '');
                if (num.startsWith('0')) num = '62' + num.slice(1);
                if (num.length >= 10) targetNumbers.push(num);
            }
        }

        if (targetNumbers.length === 0) {
            return reply(`❌ *FAILED*\n\n> Please provide valid numbers!`);
        }
        if (!targetGroup) {
            return reply(
                `❌ *FAILED*\n\n> Run this in a group or include a group link!\n\n` +
                `\`${prefix}add <number> <group_link>\``,
            );
        }

        // ── Fetch group metadata ──────────────────────────────────
        let groupMeta;
        try {
            groupMeta = await sock.groupMetadata(targetGroup);
        } catch {
            return reply(`❌ *FAILED*\n\n> Cannot access the target group.`);
        }

        // ── Verify bot is admin ───────────────────────────────────
        const botJid = (sock.user?.id || '').split(':')[0] + '@s.whatsapp.net';
        if (!isParticipantAdmin(groupMeta, botJid)) {
            return reply(
                `❌ *FAILED*\n\n> Bot is not admin in group *${groupMeta.subject || 'Unknown'}*!`,
            );
        }

        // ── If invoked from DM, verify sender is admin of target group ──
        if (!isGroup) {
            if (!isParticipantAdmin(groupMeta, sender)) {
                return reply(
                    `❌ *FAILED*\n\n> You are not admin in group *${groupMeta.subject || 'Unknown'}*!`,
                );
            }
        }

        // ── Filter numbers ────────────────────────────────────────
        const validNumbers = [];
        const alreadyInGroup = [];

        for (const num of targetNumbers) {
            if (isParticipantInGroup(groupMeta, num)) {
                alreadyInGroup.push(num);
            } else {
                validNumbers.push(num + '@s.whatsapp.net');
            }
        }

        if (validNumbers.length === 0) {
            return reply(`❌ *FAILED*\n\n> All numbers are already in the group!`);
        }

        await react(sock, chatId, m.key, '🕕');

        // ── Apply ─────────────────────────────────────────────────
        try {
            const results = await sock.groupParticipantsUpdate(targetGroup, validNumbers, 'add');

            const successList = [];
            const invitedList = [];
            const failedList = [];

            for (const res of results || []) {
                const num = (res.content?.attrs?.phone_number || '')
                    .replace('@s.whatsapp.net', '')
                    .replace(/[^0-9]/g, '');

                if (res.status === '200') successList.push(num);
                else if (res.status === '408') invitedList.push(num);
                else failedList.push({ num, status: res.status });
            }

            // ── Build reply ───────────────────────────────────────
            let resultText = `🥗 @${(sender || '').split('@')[0]} added members to the group\n\n`;

            if (successList.length > 0) {
                resultText += `Added *${successList.length}* member(s):\n`;
                successList.forEach(n => { resultText += `• @${n}\n`; });
                resultText += `\n`;
            }

            if (invitedList.length > 0) {
                resultText += `📨 *Invited *${invitedList.length}* member(s):*\n`;
                invitedList.forEach(n => { resultText += `• @${n}\n`; });
                resultText += `\n`;
            }

            if (failedList.length > 0) {
                resultText += `❌ *FAILED (${failedList.length}):*\n`;
                failedList.forEach(f => { resultText += `• @${f.num} (${f.status})\n`; });
                resultText += `\n`;
            }

            if (alreadyInGroup.length > 0) {
                resultText += `⏭️ *Already in group (${alreadyInGroup.length}):*\n`;
                alreadyInGroup.forEach(n => { resultText += `• @${n}\n`; });
            }

            const allMentions = [
                ...successList.map(n => n + '@s.whatsapp.net'),
                ...invitedList.map(n => n + '@s.whatsapp.net'),
                ...failedList.map(f => f.num + '@s.whatsapp.net'),
                ...alreadyInGroup.map(n => n + '@s.whatsapp.net'),
                sender,
            ];

            await react(
                sock, chatId, m.key,
                (successList.length > 0 || invitedList.length > 0) ? '✅' : '❌',
            );

            await sendMessageWithChannel(sock, chatId, {
                text: resultText,
                mentions: allMentions,
            });

        } catch (error) {
            console.error('[ADD]', error?.message || error);
            await react(sock, chatId, m.key, '❌');

            const msg = String(error?.message || '').toLowerCase();
            if (msg.includes('not-authorized')) {
                return reply(`❌ *FAILED*\n\n> Bot does not have permission to add members!`);
            }
            if (msg.includes('forbidden')) {
                return reply(`❌ *FAILED*\n\n> Bot has no access to this group!`);
            }
            return reply(global.mess?.error?.fitur || 'Feature error. Please try again.');
        }
    },
};