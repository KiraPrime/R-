/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: 'tinyurl',
    aliases: ['shorten', 'tiny'],
    category: 'tools',
    description: 'Shorten a URL using TinyURL',
    usage: '.tinyurl <url>',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const query = args?.join(' ')?.trim();
        if (!query) {
            return await sendMessageWithChannel(sock, chatId, { text: '*Please provide a URL to shorten.*\nExample: .tinyurl https://example.com' }, { quoted: message });
        }
        try {
            const response = await fetch(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(query)}`);
            const shortUrl = await response.text();
            if (!shortUrl) {
                return await sendMessageWithChannel(sock, chatId, { text: '❌ Error: Could not generate a short URL.' }, { quoted: message });
            }
            const output = `✨ *YOUR SHORT URL*\n\n` +
                `🔗 *Original Link:*\n${query}\n\n` +
                `✂️ *Shortened URL:*\n${shortUrl}`;
            await sendMessageWithChannel(sock, chatId, { text: output }, { quoted: message });
        }
        catch (err) {
            console.error('TinyURL plugin error:', err);
            await sendMessageWithChannel(sock, chatId, { text: '❌ Failed to shorten URL.' }, { quoted: message });
        }
    }
};
