'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const S = require("./rimuru-store");
async function handler(sock,m,args,ctx={}){
 const me=S.get(ctx.sender||m.sender,ctx.pushname||m.pushName);
 const reply=(text,opts)=>ctx.reply?ctx.reply(text,opts):sock.sendMessage(ctx.chatId||m.key?.remoteJid,{text,...(opts||{})});
 const lines=Object.entries(me.inventory).filter(([,v])=>v>0).map(([k,v])=>`• ${k}: *${v}*`);return reply(`🎒 *INVENTORY*\n\n${lines.length?lines.join("\n"):"Your inventory is empty."}`);
}
module.exports={command:"inventory",aliases:['inv'],category:"rpg",description:'Show your inventory',handler};
