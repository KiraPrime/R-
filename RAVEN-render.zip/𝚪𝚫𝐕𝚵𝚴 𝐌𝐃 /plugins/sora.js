/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require('axios');
module.exports = {
    command: 'sora',
    aliases: ['txt2video', 'aiVideo'],
    category: 'ai',
    description: 'Generate AI video from text prompt',
    usage: '.sora <prompt>',
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        try {
            const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            const quotedText = quoted?.conversation || quoted?.extendedTextMessage?.text || '';
            const input = args.join(' ') || quotedText;
            if (!input) {
                await sendMessageWithChannel(sock, chatId, {
                    text: 'Provide a prompt. Example: .sora anime girl with short blue hair',
                    ...channelInfo
                }, { quoted: message });
                return;
            }
            const apiUrl = `https://okatsu-rolezapiiz.vercel.app/ai/txt2video?text=${encodeURIComponent(input)}`;
            const { data } = await axios.get(apiUrl, { timeout: 60000, headers: { 'user-agent': 'Mozilla/5.0' } });
            const videoUrl = data?.videoUrl || data?.result || data?.data?.videoUrl;
            if (!videoUrl) {
                throw new Error('No videoUrl in API response');
            }
            await sendMessageWithChannel(sock, chatId, {
                video: { url: videoUrl },
                mimetype: 'video/mp4',
                caption: `Prompt: ${input}`,
                ...channelInfo
            }, { quoted: message });
        }
        catch (error) {
            console.error('[SORA] error:', error?.message || error);
            await sendMessageWithChannel(sock, chatId, {
                text: 'Failed to generate video. Try a different prompt later.',
                ...channelInfo
            }, { quoted: message });
        }
    }
};
