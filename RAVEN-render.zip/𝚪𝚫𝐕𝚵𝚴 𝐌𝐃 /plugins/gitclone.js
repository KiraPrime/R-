/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: 'gitclone',
    aliases: ['githubdl', 'clone'],
    category: 'download',
    description: 'Download a GitHub repository as zip',
    usage: '.gitclone <url> OR <username> <repo>',
    async handler(sock, message, args) {
        const chatId = message.key.remoteJid;
        if (!args || args.length === 0) {
            return sendMessageWithChannel(sock, chatId, {
                text: '*🌟 Please provide a GitHub URL or username and repository name.*\n\n*Example usage:*\n\n.clone https://github.com/GlobalTechInfo/MEGA-MD\n\n.clone GlobalTechInfo MEGA-MD'
            });
        }
        let url = '';
        let repoName = '';
        if (args[0].startsWith('http')) {
            const inputUrl = args[0].replace(/\.git$/, '');
            const parts = inputUrl.split('/');
            repoName = parts[parts.length - 1];
            url = inputUrl;
            if (!url.endsWith('/'))
                url += '/';
            url += 'archive/refs/heads/main.zip';
        }
        else if (args.length >= 2) {
            const username = args[0];
            const repo = args[1];
            repoName = repo;
            url = `https://github.com/${username}/${repo}/archive/refs/heads/main.zip`;
        }
        else {
            return sendMessageWithChannel(sock, chatId, {
                text: '*Missing repository info.*\n\n*Example usage:*\n\n.clone https://github.com/GlobalTechInfo/MEGA-MD\n\n.clone GlobalTechInfo MEGA-MD'
            });
        }
        await sendMessageWithChannel(sock, chatId, { text: '⏱️ Preparing repository zip...' });
        try {
            await sendMessageWithChannel(sock, chatId, {
                document: { url },
                fileName: `${repoName }.zip`,
                mimetype: 'application/zip'
            });
        }
        catch (e) {
            console.error(e);
            await sendMessageWithChannel(sock, chatId, {
                text: '❌ Failed to fetch the repository. Please make sure the repository exists and try again.'
            });
        }
    }
};
