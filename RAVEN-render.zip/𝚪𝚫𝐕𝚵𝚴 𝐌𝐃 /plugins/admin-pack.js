'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const { isBotAdmin, isUserAdmin } = require('../lib/admin-check.js');

// ══════════════════════════════════════════════════════════════════
// ─── FORWARD NEWSLETTER CONTEXT (mandatory on all plugins) ────────
// ══════════════════════════════════════════════════════════════════
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const ADMIN_MEDIA = { promote: 'https://k.top4top.io/p_3938tc0d70.jpg', demote: 'https://a.top4top.io/p_3938jsyv60.jpg', kick: 'https://a.top4top.io/p_3938iwn1r0.jpg' };

function jidToNumber(jid) {
    if (!jid) return '';
    return String(jid).split(':')[0].split('@')[0].replace(/[^0-9]/g, '');
}

function findParticipantByNumber(participants, targetJid) {
    if (!Array.isArray(participants) || !targetJid) return null;
    const targetNum = jidToNumber(targetJid);
    if (!targetNum) return null;
    for (const p of participants) {
        const pNum = jidToNumber(p.id || p.jid || p.phoneNumber || p.lid || '');
        if (pNum && pNum === targetNum) return p;
    }
    return null;
}

function getMentions(m) {
    const ctx =
        m?.message?.extendedTextMessage?.contextInfo ||
        m?.message?.imageMessage?.contextInfo ||
        m?.message?.videoMessage?.contextInfo ||
        m?.message?.documentMessage?.contextInfo ||
        null;
    return ctx?.mentionedJid || [];
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch { /* ignore */ }
}

/**
 * Resolve target JID from quoted message OR mention.
 */
function resolveTarget(m) {
    const realQuoted = m?.quoted;
    if (realQuoted && realQuoted.sender) return realQuoted.sender;
    const mentions = getMentions(m);
    if (mentions.length > 0) return mentions[0];
    return null;
}

// ══════════════════════════════════════════════════════════════════
// ─── MODE: KICK (single target) ───────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function modeKick(sock, m, args, context) {
    const { chatId, reply, sender, groupMetadata, prefix } = context;

    const targetJid = resolveTarget(m);
    if (!targetJid) {
        return reply(
            `❌ *TARGET NOT FOUND*\n\n` +
            `> Reply to a message or mention a user!\n` +
            `> Example: \`${prefix}kick @user\``,
        );
    }

    const botJid       = (sock.user?.id || '').split(':')[0] + '@s.whatsapp.net';
    const targetNumber = jidToNumber(targetJid);
    const botNumber_   = jidToNumber(botJid);
    const senderNumber = jidToNumber(sender);

    if (targetNumber === botNumber_) {
        return reply(`❌ *FAILED*\n\n> Cannot kick the bot itself!`);
    }
    if (targetNumber === senderNumber) {
        return reply(`❌ *FAILED*\n\n> Cannot kick yourself!`);
    }

    const targetParticipant = findParticipantByNumber(groupMetadata.participants, targetJid);
    if (!targetParticipant) {
        return reply(`❌ *FAILED*\n\n> User not found in this group!`);
    }
    if (targetParticipant.admin) {
        return reply(`❌ *FAILED*\n\n> Cannot kick a group admin!`);
    }

    const idToKick = targetParticipant.id || targetParticipant.jid || targetJid;
    await sock.groupParticipantsUpdate(chatId, [idToKick], 'remove');

    await sendMessageWithChannel(sock, chatId, {
        image: { url: ADMIN_MEDIA.kick },
        caption: `✅ @${targetNumber} has been removed from this group.`,
        mentions: [targetJid],
    });
    return true;
}

// ══════════════════════════════════════════════════════════════════
// ─── MODE: KICKALL (all non-admins) ───────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function modeKickAll(sock, m, args, context) {
    const { chatId, reply, prefix } = context;

    // Require explicit 'member' argument (safety)
    if (args[0]?.toLowerCase() !== 'member') {
        return reply(
`╭─〔 MASS KICK 📡 〕─\n` +
`│ ❍ ⚔️ CLEANUP MODE\n` +
`│ ❍ Usage :\n` +
`│ ❍ • ${prefix}kickall member\n` +
`│ ❍ ⚠️ Will remove all\n` +
`│ ❍ non-admin members\n` +
`╰────────────────────\n\n` +
`USE IT WISELY`,
        );
    }

    await react(sock, chatId, m.key, '⏳');

    try {
        const group = await sock.groupMetadata(chatId);
        const botJid = (sock.user?.id || '').split(':')[0] + '@s.whatsapp.net';
        const botNum = jidToNumber(botJid);

        const targets = group.participants.filter(p => {
            const pNum = jidToNumber(p.id || p.jid || p.phoneNumber || '');
            if (!pNum) return false;
            if (p.admin) return false;
            if (pNum === botNum) return false;
            return true;
        });

        if (targets.length === 0) {
            await react(sock, chatId, m.key, '❌');
            return reply(`❌ *FAILED*\n\n> No members to kick.`);
        }

        let ok = 0;
        let fail = 0;
        for (const user of targets) {
            try {
                const id = user.id || user.jid;
                if (!id) { fail++; continue; }
                await sock.groupParticipantsUpdate(chatId, [id], 'remove');
                ok++;
                await new Promise(r => setTimeout(r, 400));
            } catch { fail++; }
        }

        await react(sock, chatId, m.key, ok > 0 ? '✅' : '❌');

        return reply(
`╭─〔 KICKALL SUCCESS 📡 〕─\n` +
`│ ❍ CLEANUP REPORT\n` +
`│ ❍  Removed : ${ok}\n` +
`│ ❍  Failed : ${fail}\n` +
`│ ❍  Group is cleaner now\n` +
`╰────────────────────\n\n` +
`> MEMBER PURGED`,
        );
    } catch (e) {
        await react(sock, chatId, m.key, '❌');
        return reply(
            `╭━━〔 ❌ ERROR SYSTEM 〕━━⬣\n` +
            `┃\n` +
            `┃ ${e.message}\n` +
            `┃\n` +
            `╰━━━━━━━━━━━━━━━━⬣`,
        );
    }
}

// ══════════════════════════════════════════════════════════════════
// ─── MODE: PROMOTE ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function modePromote(sock, m, args, context) {
    const { chatId, reply, groupMetadata, prefix } = context;

    const target = resolveTarget(m);
    if (!target) {
        return reply(
            `❌ *TARGET NOT FOUND*\n\n` +
            `> Reply to a message or mention a user!\n` +
            `> Example: \`${prefix}promote @user\``,
        );
    }

    const participant = findParticipantByNumber(groupMetadata.participants, target);
    if (!participant) {
        return reply(`❌ *FAILED*\n\n> User not found in this group!`);
    }
    if (participant.admin) {
        return reply(`❌ *FAILED*\n\n> User is already an admin!`);
    }

    const id = participant.id || participant.jid || target;
    await sock.groupParticipantsUpdate(chatId, [id], 'promote');

    await sendMessageWithChannel(sock, chatId, {
        image: { url: ADMIN_MEDIA.promote },
        caption: `✅ @${jidToNumber(target)} is now an admin!`,
        mentions: [target],
    });
    return true;
}

// ══════════════════════════════════════════════════════════════════
// ─── MODE: DEMOTE ─────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function modeDemote(sock, m, args, context) {
    const { chatId, reply, groupMetadata, prefix } = context;

    const target = resolveTarget(m);
    if (!target) {
        return reply(
            `❌ *TARGET NOT FOUND*\n\n` +
            `> Reply to a message or mention a user!\n` +
            `> Example: \`${prefix}demote @user\``,
        );
    }

    const participant = findParticipantByNumber(groupMetadata.participants, target);
    if (!participant) {
        return reply(`❌ *FAILED*\n\n> User not found in this group!`);
    }
    if (!participant.admin) {
        return reply(`❌ *FAILED*\n\n> User is not an admin!`);
    }
    if (participant.admin === 'superadmin') {
        return reply(`❌ *FAILED*\n\n> Cannot demote the group owner!`);
    }

    const id = participant.id || participant.jid || target;
    await sock.groupParticipantsUpdate(chatId, [id], 'demote');

    await sendMessageWithChannel(sock, chatId, {
        image: { url: ADMIN_MEDIA.demote },
        caption: `@${jidToNumber(target)} is no longer an admin.`,
        mentions: [target],
    });
    return true;
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'kick',
    aliases:     [
        // kick
        'remove',
        // kickall
        'kickall',
        'cleargroup',
        // promote
        'promote',
        'makeadmin',
        // demote
        'demote',
        'unadmin',
        'downgrade',
    ],
    category:    'group',
    description: 'Group admin management (kick, kickall, promote, demote)',
    usage:       '.kick @user | .kickall | .promote @user | .demote @user',

    async handler(sock, m, args, context) {
        const { chatId, reply, isGroup, isOwner, groupMetadata, sender } = context;

        // ── Common guards ─────────────────────────────────────────
        if (!isGroup) {
            return reply(global.mess?.only?.group || 'This command only works in groups.');
        }
        if (!groupMetadata || !Array.isArray(groupMetadata.participants)) {
            return reply(global.mess?.error?.fitur || 'Could not read group metadata.');
        }

        // ─── 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 style admin checks (local, robust) ────────────
        const userIsAdmin = isUserAdmin(sender, groupMetadata);
        const botIsAdmin_ = isBotAdmin(sock, groupMetadata);

        if (!userIsAdmin && !isOwner) {
            return reply(global.mess?.only?.admin || 'Admin only.');
        }
        if (!botIsAdmin_) {
            return reply(global.mess?.only?.badmin || 'Bot must be admin to use this.');
        }

        const calledAs = (context.command || 'kick').toLowerCase();

        const KICKALL = ['kickall', 'cleargroup'];
        const PROMOTE = ['promote', 'makeadmin'];
        const DEMOTE  = ['demote', 'unadmin', 'downgrade'];

        try {
            if (KICKALL.includes(calledAs)) return await modeKickAll(sock, m, args, context);
            if (PROMOTE.includes(calledAs)) return await modePromote(sock, m, args, context);
            if (DEMOTE.includes(calledAs))  return await modeDemote(sock, m, args, context);
            return await modeKick(sock, m, args, context);
        } catch (error) {
            console.error(`[ADMIN-PACK:${calledAs}]`, error?.message || error);
            await react(sock, chatId, m.key, '❌');
            return reply(global.mess?.error?.fitur || 'Feature error. Please try again.');
        }
    },
};