'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const axios    = require('axios');
const fs       = require('fs-extra');
const os       = require('os');
const path     = require('path');
const crypto   = require('crypto');
const sharp    = require('sharp');
const ffmpeg   = require('fluent-ffmpeg');
const webp     = require('node-webpmux');
const { promisify } = require('util');
const writeFile = promisify(fs.writeFile);
const unlink    = promisify(fs.unlink);

let TGS = null;
try {
    TGS = require('tgs-to');
} catch {
    console.warn('[TGS] Module "tgs-to" missing — .tgs command disabled. Install with: npm i tgs-to');
}

// ══════════════════════════════════════════════════════════════════
// ─── CONFIG ───────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const CFG = {
    // ═══════════════════════════════════════════════════════════════
    // 🔑 METS TON TOKEN TELEGRAM ICI (obtenu via @BotFather)
    // ═══════════════════════════════════════════════════════════════
    telegramBotToken: '8713046430:AAEPQZT8DTD40gQRbjJBR1r6dCSy0eKa2cc',

    defaultAuthor:   'RAVEN-MD',
    maxPackSize:     30,
    downloadTimeout: 30000,
    maxFileSize:     12 * 1024 * 1024,
    fontFile:        '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
};

// ══════════════════════════════════════════════════════════════════
// ─── FORWARD NEWSLETTER CONTEXT ───────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── STICKER UTILS ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function escapeXml(unsafe) {
    if (!unsafe) return '';
    return String(unsafe).replace(/[&<>'"]/g, c => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        "'": '&apos;',
        '"': '&quot;',
    })[c]);
}

function makeTextSVG(width, author, title) {
    const padding        = 16;
    const fontSizeTitle  = Math.max(28, Math.floor(width / 14));
    const fontSizeAuthor = Math.max(18, Math.floor(width / 22));
    const bgHeight       = fontSizeTitle + fontSizeAuthor + padding * 2;

    const svg = `
<svg width="${width}" height="${bgHeight}" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="g" x1="0" x2="0" y1="0" y2="1">
      <stop offset="0" stop-color="rgba(0,0,0,0.6)"/>
      <stop offset="1" stop-color="rgba(0,0,0,0.35)"/>
    </linearGradient>
  </defs>
  <rect x="0" y="0" width="${width}" height="${bgHeight}" fill="url(#g)"/>
  <text x="${padding}" y="${padding + fontSizeTitle}" font-family="sans-serif" font-size="${fontSizeTitle}" fill="#ffffff" font-weight="700">${escapeXml(title)}</text>
  <text x="${padding}" y="${padding + fontSizeTitle + fontSizeAuthor + 4}" font-family="sans-serif" font-size="${fontSizeAuthor}" fill="#ffffff" opacity="0.9">${escapeXml(author)}</text>
</svg>`;
    return Buffer.from(svg);
}

async function imageToStickerStatic(buffer, author = '', title = '') {
    const base = await sharp(buffer)
        .rotate()
        .resize(512, 512, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
        .webp({ quality: 90 })
        .toBuffer();

    if (!author && !title) return base;

    const svg = makeTextSVG(512, author || '', title || '');
    return sharp(base)
        .composite([{ input: svg, gravity: 'south' }])
        .webp({ quality: 90 })
        .toBuffer();
}

async function mediaToStickerAnimated(buffer, mime = '', author = '', title = '') {
    const tmpIn  = path.join(os.tmpdir(), `tgs_in_${Date.now()}`);
    const tmpOut = path.join(os.tmpdir(), `tgs_out_${Date.now()}.webp`);
    await writeFile(tmpIn, buffer);

    let vf;
    if (author || title) {
        const safeTitle  = String(title  || '').replace(/:/g, '\\:').replace(/'/g, "\\'");
        const safeAuthor = String(author || '').replace(/:/g, '\\:').replace(/'/g, "\\'");
        vf = `drawtext=fontfile=${CFG.fontFile}:text='${safeTitle}':fontcolor=white:fontsize=48:box=1:boxcolor=black@0.5:boxborderw=5:x=10:y=h-110,` +
             `drawtext=fontfile=${CFG.fontFile}:text='${safeAuthor}':fontcolor=white:fontsize=32:box=1:boxcolor=black@0.5:boxborderw=5:x=10:y=h-50`;
    } else {
        vf = 'scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000';
    }

    await new Promise((resolve, reject) => {
        ffmpeg(tmpIn)
            .outputOptions([
                '-vcodec', 'libwebp',
                '-lossless', '0',
                '-qscale', '75',
                '-preset', 'default',
                '-loop', '0',
                '-an',
                '-vsync', '0',
                '-s', '512:512',
            ])
            .videoFilters(vf)
            .on('end', () => resolve())
            .on('error', reject)
            .save(tmpOut);
    });

    const outBuffer = await fs.promises.readFile(tmpOut);
    await Promise.all([unlink(tmpIn).catch(() => {}), unlink(tmpOut).catch(() => {})]);
    return outBuffer;
}

async function createStickerFromMedia(media, author = '', title = '') {
    if (!media || !media.buffer) throw new Error('Media buffer missing');

    const mime = (media.mime || '').toLowerCase();

    if (mime.startsWith('image/') && !mime.includes('gif') && !mime.includes('webp')) {
        const buf = await imageToStickerStatic(media.buffer, author, title);
        return { buffer: buf, animated: false };
    }

    if (mime === 'image/webp') {
        return { buffer: media.buffer, animated: false };
    }

    if (mime.startsWith('video/') || mime.includes('gif')) {
        const buf = await mediaToStickerAnimated(media.buffer, mime, author, title);
        return { buffer: buf, animated: true };
    }

    if (media.fileName && /\.(jpe?g|png|gif|mp4|webm|webp)$/i.test(media.fileName)) {
        const ext = path.extname(media.fileName).slice(1).toLowerCase();
        if (['mp4', 'webm', 'gif'].includes(ext)) {
            const buf = await mediaToStickerAnimated(media.buffer, mime, author, title);
            return { buffer: buf, animated: true };
        }
        const buf = await imageToStickerStatic(media.buffer, author, title);
        return { buffer: buf, animated: false };
    }

    throw new Error('Unsupported format for sticker conversion');
}

async function sendSticker(sock, jid, stickerBuffer, quoted = null) {
    return sendMessageWithChannel(sock, jid, {
        sticker: stickerBuffer,
        mimetype: 'image/webp',
    }, quoted ? { quoted } : undefined);
}

// ══════════════════════════════════════════════════════════════════
// ─── TELEGRAM FETCHER ─────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function extractPackName(url) {
    const m = String(url).match(/addstickers\/([A-Za-z0-9_]+)/);
    if (!m) throw new Error('Invalid Telegram pack link (expected addstickers/Name)');
    return m[1];
}

async function getTelegramStickerEntries(packUrl, opts = {}) {
    const { token, limit = 30 } = opts;
    if (!token) throw new Error('Missing TELEGRAM_BOT_TOKEN (set it in CFG.telegramBotToken)');

    const packName = extractPackName(packUrl);
    const apiBase  = `https://api.telegram.org/bot${token}`;

    const res = await axios.get(`${apiBase}/getStickerSet`, {
        params: { name: packName },
        timeout: 20000,
    });

    if (!res.data?.ok) throw new Error(res.data?.description || 'Telegram API error');

    const set      = res.data.result;
    const title    = set.title || packName;
    const stickers = (set.stickers || []).slice(0, limit);

    const entries = await Promise.all(stickers.map(async (st, i) => {
        try {
            const fileRes = await axios.get(`${apiBase}/getFile`, {
                params: { file_id: st.file_id },
                timeout: 20000,
            });
            const fp = fileRes.data?.result?.file_path;
            if (!fp) throw new Error('file_path missing');
            return {
                url:       `https://api.telegram.org/file/bot${token}/${fp}`,
                extension: st.is_animated ? 'tgs' : st.is_video ? 'webm' : 'webp',
                emoji:     st.emoji || '',
                index:     i,
            };
        } catch (e) {
            console.warn(`[TGS] sticker ${i} fetch failed:`, e.message);
            return null;
        }
    }));

    return {
        title,
        entries: entries.filter(Boolean),
    };
}

// ══════════════════════════════════════════════════════════════════
// ─── EXIF BUILDER ─────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function addExif(buffer, pack, author) {
    const img = new webp.Image();
    const metadata = {
        'sticker-pack-id':        crypto.randomBytes(16).toString('hex'),
        'sticker-pack-name':      pack,
        'sticker-pack-publisher': author,
        emojis:                   ['✨'],
    };
    const header = Buffer.from([
        0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00,
        0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00,
    ]);
    const data = Buffer.from(JSON.stringify(metadata));
    const exif = Buffer.concat([header, data]);
    exif.writeUIntLE(data.length, 14, 4);
    await img.load(buffer);
    img.exif = exif;
    return img.save(null);
}

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function parseInput(args) {
    const parts = args.join(' ').trim().split('|').map(p => p.trim());
    return {
        link:   parts[0],
        author: (parts[1] || CFG.defaultAuthor).slice(0, 40),
        pack:   parts[2] ? parts[2].slice(0, 40) : null,
    };
}

async function downloadStickerFile(entry, token, http = axios) {
    try {
        const response = await http.get(entry.url, {
            responseType: 'arraybuffer',
            timeout: CFG.downloadTimeout,
            maxContentLength: CFG.maxFileSize,
            maxBodyLength: CFG.maxFileSize,
        });
        return Buffer.from(response.data);
    } catch (error) {
        const reason = String(error.response?.status || error.message || 'download failed');
        throw new Error(token ? reason.replace(String(token), '[TOKEN]') : reason);
    }
}

async function convertToWhatsAppSticker(entry, source, work, index) {
    const extension = String(entry.extension || 'tgs').toLowerCase();

    if (extension === 'tgs') {
        if (!TGS) throw new Error('tgs-to module not installed');
        const input  = path.join(work, `${index}.tgs`);
        const output = path.join(work, `${index}.webp`);
        await fs.writeFile(input, source);
        await new TGS(input).convertToWebp(output);
        return fs.readFile(output);
    }

    if (extension === 'webp') return source;

    const mime = extension === 'webm' ? 'video/webm'
               : extension === 'mp4'  ? 'video/mp4'
               : extension === 'png'  ? 'image/png'
               : 'image/jpeg';

    const result = await createStickerFromMedia({
        buffer: source,
        mime,
        fileName: `telegram-sticker.${extension}`,
    });
    return result.buffer;
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'tgs',
    aliases:     ['telegramsticker', 'tgsticker'],
    category:    'tools',
    description: 'Import a Telegram sticker pack as WhatsApp stickers (TGS, WebP, WebM)',
    usage:       '.tgs <pack_url> | author | pack_name',

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix } = context;

        if (!TGS) {
            return reply(
                `❌ *TGS MODULE MISSING*\n\n` +
                `> Install: \`npm i tgs-to\``,
            );
        }

        if (!CFG.telegramBotToken) {
            return reply(
                `❌ *TELEGRAM TOKEN MISSING*\n\n` +
                `> Open \`plugins/tgs.js\` and set \`CFG.telegramBotToken\` with your bot token from @BotFather.`,
            );
        }

        if (!args.length) {
            return reply(
                `📦 *TGS — TELEGRAM STICKER IMPORT*\n\n` +
                `> Usage: \`${prefix}tgs <pack_url> | author | pack_name\`\n\n` +
                `*Example:*\n` +
                `> \`${prefix}tgs https://t.me/addstickers/Anime | Raven | Anime\``,
            );
        }

        const input = parseInput(args);
        const work  = await fs.mkdtemp(path.join(os.tmpdir(), 'raven-tgs-'));
        const token = String(CFG.telegramBotToken).trim();

        try {
            await reply(`⏳ Reading Telegram pack...`);

            const stickerSet = await getTelegramStickerEntries(input.link, {
                token,
                limit: CFG.maxPackSize,
            });

            const pack    = input.pack || String(stickerSet.title || 'Telegram Pack').slice(0, 40);
            const entries = stickerSet.entries || [];

            if (entries.length === 0) {
                throw new Error('No stickers found in this pack.');
            }

            let sent   = 0;
            let failed = 0;

            for (let index = 0; index < entries.length; index += 1) {
                try {
                    const source  = await downloadStickerFile(entries[index], token);
                    const sticker = await convertToWhatsAppSticker(entries[index], source, work, index);
                    const final   = await addExif(sticker, pack, input.author).catch(() => sticker);
                    await sendSticker(sock, chatId, final, m);
                    sent += 1;
                } catch (error) {
                    failed += 1;
                    console.warn(`[TGS] sticker ${index + 1} skipped:`, error.message || error);
                }
            }

            if (!sent) {
                throw new Error('No sticker could be converted. Make sure FFmpeg is available on the server.');
            }

            await sendMessageWithChannel(sock, chatId, {
                text:
                    `✅ ${sent}/${entries.length} sticker(s) sent` +
                    (failed ? ` (${failed} skipped)` : '') + `\n` +
                    `👤 Author: ${input.author}\n` +
                    `📦 Pack: ${pack}`,
            }, { quoted: m });

        } catch (error) {
            console.error('[TGS ERROR]', error.message || error);
            await reply(`❌ ${error.message || error}`);
        } finally {
            await fs.remove(work).catch(() => {});
        }
    },

    // Exposed for testing
    _test: { parseInput, downloadStickerFile, convertToWhatsAppSticker, addExif },
};