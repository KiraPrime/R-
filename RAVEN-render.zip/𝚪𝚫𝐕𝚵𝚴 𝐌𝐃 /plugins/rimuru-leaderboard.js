'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const S = require("./rimuru-store");
async function handler(sock,m,args,ctx={}){
 const me=S.get(ctx.sender||m.sender,ctx.pushname||m.pushName);
 const reply=(text,opts)=>ctx.reply?ctx.reply(text,opts):sock.sendMessage(ctx.chatId||m.key?.remoteJid,{text,...(opts||{})});
 const top=Object.values(S.load()).sort((a,b)=>(b.cash||0)-(a.cash||0)).slice(0,10);return reply(`🏆 *CASH LEADERBOARD*\n\n${top.length?top.map((u,i)=>`${i+1}. ${u.name} — *$${S.money(u.cash)}*`).join("\n"):"No users yet."}`);
}
module.exports={command:"leaderboard",aliases:['topcash'],category:"rpg",description:'Show the cash leaderboard',handler};
