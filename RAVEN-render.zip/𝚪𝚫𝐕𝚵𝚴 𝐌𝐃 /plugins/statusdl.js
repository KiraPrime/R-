/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
module.exports = {
    command: 'dlstatus',
    aliases: ['swdl', 'statusdl'],
    category: 'download',
    description: 'Download quoted Status updates',
    usage: 'Reply to a status and type .dlstatus',
    ownerOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const m = message.message;
        const type = Object.keys(m)[0];
        const contextInfo = m[type]?.contextInfo;
        if (!contextInfo || contextInfo.remoteJid !== 'status@broadcast') {
            return await sendMessageWithChannel(sock, chatId, {
                text: "Please reply/quote a Status update to download it."
            }, { quoted: message });
        }
        const quotedMsg = contextInfo.quotedMessage;
        if (!quotedMsg)
            return;
        try {
            const quotedType = Object.keys(quotedMsg)[0];
            const mediaData = quotedMsg[quotedType];
            if (quotedType === 'conversation' || quotedType === 'extendedTextMessage') {
                const text = quotedMsg.conversation || quotedMsg.extendedTextMessage?.text;
                return await sendMessageWithChannel(sock, chatId, { text: `📝 *Status Text:*\n\n${text}` }, { quoted: message });
            }
            const stream = await downloadContentFromMessage(mediaData, quotedType.replace('Message', ''));
            let buffer = Buffer.from([]);
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }
            if (quotedType === 'imageMessage') {
                await sendMessageWithChannel(sock, chatId, { image: buffer, caption: mediaData.caption || '' }, { quoted: message });
            }
            else if (quotedType === 'videoMessage') {
                await sendMessageWithChannel(sock, chatId, { video: buffer, caption: mediaData.caption || '' }, { quoted: message });
            }
        }
        catch (e) {
            console.error('SW Download Error:', e);
            await sendMessageWithChannel(sock, chatId, { text: "❌ Failed to download status media." }, { quoted: message });
        }
    }
};
