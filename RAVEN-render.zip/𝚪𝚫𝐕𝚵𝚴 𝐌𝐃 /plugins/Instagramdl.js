'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const axios = require('axios');

// ══════════════════════════════════════════════════════════════════
// ─── INSTAGRAM SCRAPER ────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function instagramDownloader(url) {
    const endpoint = 'https://api.azbry.com/api/download/instagramv2';
    const response = await axios.get(endpoint, {
        params: { url: url },
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        },
    });

    const data = response.data;
    if (!data || !data.status || !Array.isArray(data.links) || data.links.length === 0) {
        throw new Error('Failed to fetch media from Instagram API');
    }

    const media = data.links.map((item) => {
        const itemType = String(item.type || '').toLowerCase();
        const itemUrl  = String(item.url  || '').toLowerCase();
        const isVideo  = itemType === 'video' || itemType === 'mp4' || itemUrl.includes('.mp4');
        return {
            type:      isVideo ? 'video' : 'image',
            url:       item.url,
            thumbnail: item.thumbnail || '',
        };
    });

    const firstLink  = data.links[0] || {};
    const captionText = firstLink.text && firstLink.text !== 'null' ? firstLink.text.trim() : '';
    const authorName  = data.author && data.author !== 'Unknown' ? data.author : '-';
    const thumbUrl    = firstLink.thumbnail || data.thumbnail || '';

    return {
        status:    true,
        username:  authorName,
        title:     captionText || authorName,
        caption:   captionText,
        thumbnail: thumbUrl,
        avatar:    data.avatar || '',
        media:     media,
    };
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const IG_REGEX = /instagram\.com\/(p|reel|reels|stories|tv)\//i;

module.exports = {
    command:     'instagramdl',
    aliases:     ['igdl', 'ig', 'insta'],
    category:    'download',
    description: 'Download Instagram video / photo — © 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
    usage:       '.instagramdl <url>',

    async handler(sock, message, args, context) {
        const { chatId, reply, prefix } = context;
        const url = (args.join(' ') || '').trim();

        if (!url) {
            return reply(
                `📸 *INSTAGRAM DOWNLOADER*\n\n` +
                `> \`${prefix}igdl <url>\`\n\n` +
                `*Examples:*\n` +
                `> \`${prefix}igdl https://www.instagram.com/reel/xxx\`\n` +
                `> \`${prefix}igdl https://www.instagram.com/p/xxx\``
            );
        }

        if (!IG_REGEX.test(url)) {
            return reply(`❌ Invalid URL. Use an Instagram link (reel / post / story).`);
        }

        await sock.sendMessage(chatId, { react: { text: '🕕', key: message.key } }).catch(() => {});

        try {
            const result = await instagramDownloader(url);

            if (!result?.media?.length) {
                await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } }).catch(() => {});
                return reply(`❌ Failed to fetch media. Try another link.`);
            }

            const isStory = url.includes('/stories/');
            let caption = `📸 *Instagram ${isStory ? 'Story' : 'Downloader'}*\n\n`;

            if (result.username && result.username !== '-') {
                caption += `👤 *Author*: @${result.username}\n`;
            }
            if (result.caption) {
                caption += `📝 *Caption*:\n${result.caption}\n`;
            }
            caption = caption.trim();

            for (const item of result.media) {
                if (item.type === 'video' || item.type === 'mp4') {
                    await sock.sendMessage(
                        chatId,
                        { video: { url: item.url }, caption },
                        { quoted: message }
                    );
                } else {
                    await sock.sendMessage(
                        chatId,
                        { image: { url: item.url }, caption },
                        { quoted: message }
                    );
                }
                caption = '';
            }

            await sock.sendMessage(chatId, { react: { text: '✅', key: message.key } }).catch(() => {});
        } catch (err) {
            await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } }).catch(() => {});
            return reply(`❌ *DOWNLOAD FAILED*\n\n> ${err.message}`);
        }
    },

    // Expose helper for future use
    _instagramDownloader: instagramDownloader,
};