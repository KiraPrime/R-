/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require('axios');
async function fetchWithRetries(url, retries = 3, delay = 2000) {
    let attempt = 0;
    while (attempt < retries) {
        try {
            const { data } = await axios.get(url);
            return data;
        }
        catch (err) {
            attempt++;
            console.error(`[WHY] Attempt ${attempt} failed:`, err.message);
            if (attempt >= retries)
                throw new Error('Max retries reached');
            await new Promise(r => setTimeout(r, delay));
        }
    }
}
module.exports = {
    command: 'why',
    aliases: ['whyme', 'question'],
    category: 'fun',
    description: 'Get a random “why” question from the API',
    usage: '.why',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            const data = await fetchWithRetries('https://nekos.life/api/v2/why');
            if (!data?.why?.trim()) {
                return await sendMessageWithChannel(sock, chatId, { text: '❌ Invalid response from API. Try again.' }, { quoted: message });
            }
            await sendMessageWithChannel(sock, chatId, { text: `🤔 *Why?*\n\n${data.why}` }, { quoted: message });
        }
        catch (error) {
            console.error('Why plugin error:', error);
            await sendMessageWithChannel(sock, chatId, { text: '❌ Failed to fetch question. Try again later.' }, { quoted: message });
        }
    }
};
