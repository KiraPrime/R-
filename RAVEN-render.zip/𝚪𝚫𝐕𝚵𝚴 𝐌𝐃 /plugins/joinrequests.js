/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: 'joinrequests',
    aliases: ['gcreqs', 'groupreqs', 'pendingjoins', 'approvejoin', 'rejectjoin'],
    category: 'group',
    description: 'View, approve or reject group join requests',
    usage: '.joinrequests — list pending\n.approvejoin <number|all>\n.rejectjoin <number|all>',
    groupOnly: true,
    adminOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const channelInfo = context.channelInfo || {};
        const rawText = (context.rawText || '').toLowerCase();
        const isApprove = rawText.startsWith('.approvejoin');
        const isReject = rawText.startsWith('.rejectjoin');
        // List pending requests
        if (!isApprove && !isReject) {
            try {
                const requests = await sock.groupRequestParticipantsList(chatId);
                if (!requests || requests.length === 0) {
                    return await sendMessageWithChannel(sock, chatId, {
                        text: `📋 *Join Requests*\n\n_No pending join requests._`,
                        ...channelInfo
                    }, { quoted: message });
                }
                const list = requests.map((r, i) => `${i + 1}. +${r.jid.split('@')[0]}`).join('\n');
                return await sendMessageWithChannel(sock, chatId, {
                    text: `╔═══════════════════════╗\n` +
                        `║   📋 *JOIN REQUESTS*    ║\n` +
                        `╚═══════════════════════╝\n\n` +
                        `${list}\n\n` +
                        `──────────────────────────\n` +
                        `*Total:* ${requests.length} pending\n\n` +
                        `• \`.approvejoin all\` — approve all\n` +
                        `• \`.rejectjoin all\` — reject all\n` +
                        `• \`.approvejoin 923001234567\` — approve one`,
                    ...channelInfo
                }, { quoted: message });
            }
            catch (e) {
                return await sendMessageWithChannel(sock, chatId, {
                    text: `❌ Failed to fetch requests: ${e.message}`,
                    ...channelInfo
                }, { quoted: message });
            }
        }
        // Approve or reject
        const action = isApprove ? 'approve' : 'reject';
        const input = args[0]?.toLowerCase();
        try {
            let targets = [];
            if (input === 'all') {
                const requests = await sock.groupRequestParticipantsList(chatId);
                if (!requests || requests.length === 0) {
                    return await sendMessageWithChannel(sock, chatId, {
                        text: `⚠️ No pending join requests.`,
                        ...channelInfo
                    }, { quoted: message });
                }
                targets = requests.map((r) => r.jid);
            }
            else if (input) {
                const num = input.replace(/[^0-9]/g, '');
                targets = [`${num}@s.whatsapp.net`];
            }
            else {
                return await sendMessageWithChannel(sock, chatId, {
                    text: `❌ Provide a number or \`all\`.\n\nExample: \`.${isApprove ? 'approvejoin' : 'rejectjoin'} all\``,
                    ...channelInfo
                }, { quoted: message });
            }
            await sock.groupRequestParticipantsUpdate(chatId, targets, action);
            const icon = isApprove ? '✅' : '❌';
            const verb = isApprove ? 'Approved' : 'Rejected';
            await sendMessageWithChannel(sock, chatId, {
                text: `${icon} *${verb}* ${targets.length === 1 ? `+${targets[0].split('@')[0]}` : `${targets.length} request(s)`}`,
                ...channelInfo
            }, { quoted: message });
        }
        catch (e) {
            console.error('[JOINREQUESTS] Error:', e.message);
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Failed to ${action}: ${e.message}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};
