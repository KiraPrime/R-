/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require('axios');
const triviaGames = {};
module.exports = {
    command: 'trivia',
    aliases: ['quiz'],
    category: 'games',
    description: 'Start a trivia game or answer the question',
    usage: '.trivia [answer]',
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        if (args.length === 0) {
            if (triviaGames[chatId]) {
                await sendMessageWithChannel(sock, chatId, {
                    text: 'A trivia game is already in progress!',
                    ...channelInfo
                }, { quoted: message });
                return;
            }
            try {
                const response = await axios.get('https://opentdb.com/api.php?amount=1&type=multiple');
                const questionData = response.data.results[0];
                triviaGames[chatId] = {
                    question: questionData.question,
                    correctAnswer: questionData.correct_answer,
                    options: [...questionData.incorrect_answers, questionData.correct_answer].sort(),
                };
                await sendMessageWithChannel(sock, chatId, {
                    text: `🎯 *Trivia Time!*\n\n*Question:* ${triviaGames[chatId].question}\n\n*Options:*\n${triviaGames[chatId].options.join('\n')}\n\nUse .trivia <answer> to answer!`,
                    ...channelInfo
                }, { quoted: message });
            }
            catch (error) {
                await sendMessageWithChannel(sock, chatId, {
                    text: 'Error fetching trivia question. Try again later.',
                    ...channelInfo
                }, { quoted: message });
            }
        }
        else {
            if (!triviaGames[chatId]) {
                await sendMessageWithChannel(sock, chatId, {
                    text: 'No trivia game is in progress. Use .trivia to start one!',
                    ...channelInfo
                }, { quoted: message });
                return;
            }
            const game = triviaGames[chatId];
            const answer = args.join(' ');
            if (answer.toLowerCase() === game.correctAnswer.toLowerCase()) {
                await sendMessageWithChannel(sock, chatId, {
                    text: `✅ Correct! The answer is *${game.correctAnswer}*`,
                    ...channelInfo
                }, { quoted: message });
            }
            else {
                await sendMessageWithChannel(sock, chatId, {
                    text: `❌ Wrong! The correct answer was *${game.correctAnswer}*`,
                    ...channelInfo
                }, { quoted: message });
            }
            delete triviaGames[chatId];
        }
    }
};
