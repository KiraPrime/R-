'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const { Client } = require('ssh2');

// ══════════════════════════════════════════════════════════════════
// ─── FORWARD NEWSLETTER CONTEXT (mandatory on all plugins) ────────
// ══════════════════════════════════════════════════════════════════
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── CONFIG ───────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const CFG = {
    sshUser: 'root',
    sshPort: 22,
    // Remote script executed on the target VPS
    remoteScript: 'bash <(curl -s https://raw.githubusercontent.com/veryLinh/Theme-Autoinstaller/main/install.sh)',
    // Interactive inputs sent to the script's stdin
    scriptInputs: ['skyzodev\n', '2\n', 'y\n', 'x\n'],
};

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch { /* ignore */ }
}

function redactIp(ip) {
    if (!ip || typeof ip !== 'string') return '?.?.?.?';
    const parts = ip.split('.');
    if (parts.length === 4) return `${parts[0]}.${parts[1]}.*.*`;
    return ip.slice(0, 4) + '***';
}

// ══════════════════════════════════════════════════════════════════
// ─── CORE: SSH UNINSTALL ──────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function runSshUninstall(ip, password, onDone) {
    const conn = new Client();

    conn.on('ready', () => {
        conn.exec(CFG.remoteScript, (err, stream) => {
            if (err) {
                try { conn.end(); } catch {}
                return onDone({ ok: false, reason: 'exec', error: err });
            }

            stream.on('close', () => {
                try { conn.end(); } catch {}
                onDone({ ok: true });
            });

            stream.on('data', (data) => {
                // Log truncated output for debugging (no credentials)
                const out = data.toString().slice(0, 300);
                console.log('[UNINSTALL-THEME]', out);
                for (const input of CFG.scriptInputs) {
                    try { stream.write(input); } catch {}
                }
            });

            stream.stderr.on('data', (data) => {
                console.log('[UNINSTALL-THEME STDERR]', data.toString().slice(0, 300));
            });
        });
    });

    conn.on('error', (err) => {
        console.error('[UNINSTALL-THEME SSH]', err?.message || err);
        onDone({ ok: false, reason: 'connection', error: err });
    });

    // Connect — credentials kept only in memory
    try {
        conn.connect({
            host: ip,
            port: CFG.sshPort,
            username: CFG.sshUser,
            password,
            readyTimeout: 20000,
        });
    } catch (e) {
        onDone({ ok: false, reason: 'connect-throw', error: e });
    }
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'uninstalltheme',
    aliases:     ['uinstalltema', 'uninstalltema', 'removetema', 'removetheme', 'deletetheme'],
    category:    'panel',
    description: 'Uninstall a Pterodactyl theme via SSH (owner only)',
    usage:       '.uninstalltheme <ip>|<password>',

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix, isOwner } = context;

        // ── Owner only ────────────────────────────────────────────
        if (!isOwner) {
            return reply(global.mess?.only?.owner || 'Owner only.');
        }

        // ── Parse args ────────────────────────────────────────────
        const text = (args.join(' ') || '').trim();

        if (!text) {
            return reply(
                `╭┈┈⬡「 🗑️ *UNINSTALL THEME* 」\n` +
                `┃ Usage: \`${prefix}uninstalltheme <ip>|<password>\`\n` +
                `╰┈┈⬡\n\n` +
                `> \`Example: ${prefix}uninstalltheme 192.168.1.1|secretpass\``,
            );
        }

        const parts = text.split('|');
        if (parts.length < 2) {
            return reply(`❌ Wrong format! Use: \`ip|password\``);
        }

        const ipvps = parts[0].trim();
        const passwd = parts[1].trim();

        if (!ipvps || !passwd) {
            return reply(`❌ Missing IP or password.`);
        }

        // ── Store in memory only (no disk write) ──────────────────
        global.installtema = { vps: ipvps, pwvps: passwd };

        await react(sock, chatId, m.key, '🕕');
        await reply(
            `🕕 *UNINSTALLING THEME...*\n\n` +
            `> This can take 1–10 minutes. Please wait.`,
        );

        // ── Run SSH ───────────────────────────────────────────────
        runSshUninstall(ipvps, passwd, async (result) => {
            if (result.ok) {
                await react(sock, chatId, m.key, '✅');
                try {
                    await sendMessageWithChannel(sock, chatId, {
                        text:
                            `╭┈┈⬡「 ✅ *UNINSTALL THEME* 」\n` +
                            `┃ Status: *Success*\n` +
                            `┃ IP    : ${redactIp(ipvps)}\n` +
                            `╰┈┈⬡\n\n` +
                            `> _Theme uninstalled successfully._`,
                    });
                } catch (e) {
                    console.error('[UNINSTALL-THEME] send success failed:', e?.message);
                }
            } else if (result.reason === 'connection') {
                await react(sock, chatId, m.key, '❌');
                try {
                    await reply(
                        `❌ *CONNECTION FAILED*\n\n` +
                        `> Invalid IP or password.`,
                    );
                } catch { /* ignore */ }
            } else {
                await react(sock, chatId, m.key, '☢');
                try {
                    await reply(global.mess?.error?.fitur || 'Uninstall error.');
                } catch { /* ignore */ }
            }

            // Clear credentials from memory after use
            try { delete global.installtema; } catch {}
        });
    },
};