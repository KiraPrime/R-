/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: 'ship',
    aliases: ['couple'],
    category: 'group',
    description: 'Randomly ship two members in the group',
    usage: '.ship',
    groupOnly: true,
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        try {
            const participants = await sock.groupMetadata(chatId);
            const ps = participants.participants.map((v) => v.id);
            const firstUser = ps[Math.floor(Math.random() * ps.length)];
            let secondUser;
            do {
                secondUser = ps[Math.floor(Math.random() * ps.length)];
            } while (secondUser === firstUser);
            const formatMention = (id) => `@${ id.split('@')[0]}`;
            await sendMessageWithChannel(sock, chatId, {
                text: `${formatMention(firstUser)} ❤️ ${formatMention(secondUser)}\nCongratulations 💖🍻`,
                mentions: [firstUser, secondUser],
                ...channelInfo
            });
        }
        catch (error) {
            console.error('Error in ship command:', error);
            await sendMessageWithChannel(sock, chatId, {
                text: '❌ Failed to ship! Make sure this is a group.',
                ...channelInfo
            }, { quoted: message });
        }
    }
};
