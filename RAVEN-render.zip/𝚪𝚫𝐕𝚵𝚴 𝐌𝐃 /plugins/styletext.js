/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const pkg = require('api-qasim');
const QasimAny = pkg;
module.exports = {
    command: 'stext',
    aliases: ['fancytext', 'textstyle', 'styletext'],
    category: 'menu',
    description: 'Style text in different fancy formats',
    usage: '.stext <text>',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const text = args.join(' ');
        try {
            if (!text || text.trim() === '') {
                await sendMessageWithChannel(sock, chatId, {
                    text: "*Please provide a text to style.*\nExample: .stext Hello"
                }, { quoted: message });
                return;
            }
            const styledResult = await QasimAny.styletext(text);
            if (!Array.isArray(styledResult) || styledResult.length === 0) {
                throw new Error('No styled text found.');
            }
            let messageText = 'Reply with choosen number:\n\n';
            styledResult.forEach((item, index) => {
                const styledText = item.result || item;
                messageText += `*${index + 1}.* ${styledText}\n`;
            });
            const sentMsg = await sendMessageWithChannel(sock, chatId, {
                text: messageText
            }, { quoted: message });
            sock.styletext = sock.styletext || {};
            sock.styletext[sentMsg.key.id] = styledResult;
            const listener = async ({ messages }) => {
                const m = messages[0];
                if (!m.message || !m.key || !m.key.remoteJid)
                    return;
                if (m.key.remoteJid !== chatId)
                    return;
                let isQuoted = false;
                if (m.message.extendedTextMessage &&
                    m.message.extendedTextMessage.contextInfo &&
                    m.message.extendedTextMessage.contextInfo.quotedMessage) {
                    const quotedId = m.message.extendedTextMessage.contextInfo.stanzaId
                        || m.message.extendedTextMessage.contextInfo.quotedMessageKey?.id;
                    if (quotedId === sentMsg.key.id)
                        isQuoted = true;
                }
                let userReply = m.message.conversation || '';
                if (m.message.extendedTextMessage && m.message.extendedTextMessage.text)
                    userReply = m.message.extendedTextMessage.text;
                if (!userReply)
                    return;
                if (!isQuoted && m.message.conversation !== sentMsg.key.id)
                    return;
                const choice = parseInt(userReply.trim(), 10);
                if (!isNaN(choice) && choice >= 1 && choice <= styledResult.length) {
                    const selectedText = styledResult[choice - 1].result || styledResult[choice - 1];
                    await sendMessageWithChannel(sock, m.key.remoteJid, { text: selectedText }, { quoted: m });
                    delete sock.styletext[sentMsg.key.id];
                    sock.ev.off('messages.upsert', listener);
                }
                else {
                    await sendMessageWithChannel(sock, m.key.remoteJid, {
                        text: `Invalid selection. Please choose a number between 1 and ${styledResult.length}.`
                    }, { quoted: m });
                }
            };
            sock.ev.on('messages.upsert', listener);
        }
        catch (error) {
            console.error('Error in styleTextCommand:', error);
            await sendMessageWithChannel(sock, chatId, {
                text: '❌ Failed to style the text. Please try again later.'
            }, { quoted: message });
        }
    }
};
