'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const axios = require('axios');

// ══════════════════════════════════════════════════════════════════
// ─── FORWARD NEWSLETTER CONTEXT ───────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── CONFIG ───────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const CFG = {
    // Cuki API key — get it from https://api.cuki.biz.id
    cukiApiKey: 'cuki-x',
    apiBase:    'https://api.cuki.biz.id/api/ai/wormgpt',
    timeout:    30000,
};

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {}
}

function getCukiKey() {
    return global.apiKeys?.cuki || CFG.cukiApiKey;
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'wormgpt',
    aliases:     ['worm'],
    category:    'ai',
    description: 'Chat with WormGPT (uncensored AI)',
    usage:       '.wormgpt <question>',

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix } = context;

        const text = (args.join(' ') || '').trim();

        if (!text) {
            return reply(
                `🐛 *WORM GPT*\n\n` +
                `> Send a question\n\n` +
                `\`Example: ${prefix}wormgpt introduce yourself\``,
            );
        }

        await react(sock, chatId, m.key, '🕕');

        try {
            const url = `${CFG.apiBase}?apikey=${encodeURIComponent(getCukiKey())}&question=${encodeURIComponent(text)}`;
            const { data } = await axios.get(url, { timeout: CFG.timeout });

            if (!data?.status || !data?.data?.response) {
                throw new Error('No response from WormGPT API');
            }

            await react(sock, chatId, m.key, '✅');
            await sendMessageWithChannel(sock, chatId, {
                text: String(data.data.response),
            }, { quoted: m });

        } catch (error) {
            console.error('[WORMGPT]', error?.message || error);
            await react(sock, chatId, m.key, '☢');
            return reply(global.mess?.error?.fitur || 'WormGPT error. Please try again.');
        }
    },
};