'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const crypto = require('crypto');

// ══════════════════════════════════════════════════════════════════
// ─── FORWARD NEWSLETTER CONTEXT ───────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── CONFIG ───────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const CFG = {
    challengeUrl: 'https://twittermedia.b-cdn.net/challenge/',
    viewerUrl:    'https://twittermedia.b-cdn.net/viewer/',
    timeout:      30000,
    ua:           'Mozilla/5.0 (Linux; Android 10)',
};

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {}
}

function buildCaption(p, username) {
    const now = new Date().toLocaleDateString('en-GB');

    return (
        `🧭 *X (TWITTER) PROFILE LOOKUP*\n\n` +
        `👤 *Display name* : ${p.name || 'Not found'}\n` +
        `🔖 *Username*     : @${username}\n` +
        `${p.verified ? '✅ *Verified account*' : '❌ *Not verified*'}\n` +
        `📝 *Bio*          :\n${p.bio ? `"${p.bio}"` : '(no bio)'}\n\n` +
        `📊 *ACCOUNT STATS*\n` +
        `━━━━━━━━━━━━━━━━━━\n` +
        `📈 *Tweets*    : ${p.stats?.tweets ?? 0}\n` +
        `👁️ *Following* : ${p.stats?.following ?? 0}\n` +
        `⭐ *Followers* : ${p.stats?.followers ?? 0}\n` +
        `━━━━━━━━━━━━━━━━━━\n\n` +
        `📌 _Data retrieved on ${now}._`
    );
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'twitterstalk',
    aliases:     ['xstalk', 'tstalk', 'twitterinfo'],
    category:    'stalker',
    description: 'Look up an X (Twitter) profile by username',
    usage:       '.twitterstalk <username>',

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix, command } = context;

        const input = (args.join(' ') || '').trim();

        if (!input) {
            return reply(`⚠️ *USAGE*\n\n> \`${prefix}${command} <username>\`\n> Example: \`${prefix}${command} mrbeast\``);
        }

        const username = input.replace(/^@/, '').trim();

        await react(sock, chatId, m.key, '⏳');

        try {
            // ── 1) Fetch challenge ────────────────────────────────
            const chRes = await fetch(CFG.challengeUrl, {
                headers: {
                    'User-Agent': CFG.ua,
                    'Accept':     'application/json',
                    'Origin':     'https://snaplytics.io',
                    'Referer':    'https://snaplytics.io/',
                },
            });

            const ch = await chRes.json();
            if (!ch?.challenge_id) throw new Error('Challenge request failed');

            // ── 2) Compute challenge solution ─────────────────────
            const hash = crypto
                .createHash('sha256')
                .update(String(ch.timestamp) + ch.random_value)
                .digest('hex')
                .slice(0, 8);

            // ── 3) Fetch profile ──────────────────────────────────
            const dataRes = await fetch(
                `${CFG.viewerUrl}?data=${encodeURIComponent(username)}&type=profile`,
                {
                    headers: {
                        'User-Agent':           CFG.ua,
                        'Accept':               'application/json',
                        'Origin':               'https://snaplytics.io',
                        'Referer':              'https://snaplytics.io/',
                        'X-Challenge-ID':       ch.challenge_id,
                        'X-Challenge-Solution': hash,
                    },
                }
            );

            const json = await dataRes.json();
            if (!json?.profile) throw new Error('Profile not found');

            const p = json.profile;
            const caption = buildCaption(p, username);

            // ── 4) Send ───────────────────────────────────────────
            if (p.banner_url) {
                await sendMessageWithChannel(sock, chatId, {
                    image:   { url: p.banner_url },
                    caption,
                }, { quoted: m });
            } else if (p.avatar_url) {
                await sendMessageWithChannel(sock, chatId, {
                    image:   { url: p.avatar_url },
                    caption,
                }, { quoted: m });
            } else {
                await sendMessageWithChannel(sock, chatId, { text: caption }, { quoted: m });
            }

            await react(sock, chatId, m.key, '✅');

        } catch (e) {
            console.error('[TWITTERSTALK]', e?.message || e);
            await react(sock, chatId, m.key, '❌');
            return reply(
                `🍂 *FAILED TO FETCH X PROFILE*\n\n` +
                `📩 ${e.message}`,
            );
        }
    },
};