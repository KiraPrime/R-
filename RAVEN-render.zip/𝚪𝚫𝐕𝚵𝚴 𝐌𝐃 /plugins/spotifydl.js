'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const axios = require('axios');

// ══════════════════════════════════════════════════════════════════
// ─── FORWARD NEWSLETTER CONTEXT ───────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── CONFIG ───────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const CFG = {
    apiBase: 'https://api.nexray.eu.cc/downloader/spotify',
    timeout: 45000,
};

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {}
}

function isSpotifyTrackUrl(url) {
    return /open\.spotify\.com\/track/i.test(String(url || ''));
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'spdl',
    aliases:     ['spotifydl', 'spotify'],
    category:    'download',
    description: 'Download a Spotify track as MP3',
    usage:       '.spdl <spotify_track_url>',

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix } = context;

        const url = (args.join(' ') || '').trim();

        // ── Validate URL ──────────────────────────────────────────
        if (!url || !isSpotifyTrackUrl(url)) {
            return reply(
                `❌ *SPOTIFY LINK MISSING OR INVALID*\n\n` +
                `> Provide a valid Spotify **track** URL.\n\n` +
                `\`Example: ${prefix}spdl https://open.spotify.com/track/3RY0NyQQXxuAiyk5eAS4fC\``,
            );
        }

        await react(sock, chatId, m.key, '🕕');

        try {
            const apiUrl = `${CFG.apiBase}?url=${encodeURIComponent(url)}`;
            const res    = await axios.get(apiUrl, { timeout: CFG.timeout });
            const data   = res.data;

            if (!data?.status || !data?.result?.url) {
                await react(sock, chatId, m.key, '❌');
                return reply(
                    `⚠️ *DOWNLOAD FAILED*\n\n` +
                    `> The server did not return a valid download URL.`,
                );
            }

            const { title, artist, url: downloadUrl } = data.result;
            const filename = `${artist || 'Spotify'} - ${title || 'Audio'}.mp3`;

            await sendMessageWithChannel(sock, chatId, {
                audio:    { url: downloadUrl },
                mimetype: 'audio/mpeg',
                fileName: filename,
                ptt:      false,
            }, { quoted: m });

            await react(sock, chatId, m.key, '✅');

        } catch (error) {
            console.error('[SPOTIFYDL]', error?.message || error);
            await react(sock, chatId, m.key, '❌');
            return reply(
                `😔 *SYSTEM ERROR*\n\n` +
                `> Failed to process the Spotify link. Please try again later.`,
            );
        }
    },
};