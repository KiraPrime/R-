'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const S = require("./rimuru-store");
async function handler(sock,m,args,ctx={}){
 const me=S.get(ctx.sender||m.sender,ctx.pushname||m.pushName);
 const reply=(text,opts)=>ctx.reply?ctx.reply(text,opts):sock.sendMessage(ctx.chatId||m.key?.remoteJid,{text,...(opts||{})});
 return reply(`💰 *BALANCE*\n\n👤 ${me.name}\n💵 Cash: *$${S.money(me.cash)}*\n📈 Level: *${me.level}*\n✨ EXP: *${S.money(me.exp)}*`);
}
module.exports={command:"balance",aliases:['money', 'cash', 'wallet'],category:"rpg",description:'Show your cash balance',handler};
