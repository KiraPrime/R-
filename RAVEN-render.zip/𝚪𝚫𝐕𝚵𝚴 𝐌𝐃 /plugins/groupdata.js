/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: 'gcmtdata',
    aliases: ['gcinfo', 'groupinfo', 'gcmetadata', 'groupdata'],
    category: 'group',
    description: 'Get detailed info about the current group',
    usage: '.gcinfo',
    groupOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const channelInfo = context.channelInfo || {};
        try {
            const meta = await sock.groupMetadata(chatId);
            const admins = meta.participants.filter((p) => p.admin).map((p) => `  • @${p.id.split('@')[0]}`).join('\n');
            const created = meta.creation
                ? new Date(meta.creation * 1000).toLocaleDateString()
                : 'Unknown';
            const memberCount = meta.participants.length;
            const adminCount = meta.participants.filter((p) => p.admin).length;
            await sendMessageWithChannel(sock, chatId, {
                text: `╔═══════════════════════╗\n` +
                    `║    📊 *GROUP INFO*       ║\n` +
                    `╚═══════════════════════╝\n\n` +
                    `*📛 Name:* ${meta.subject}\n` +
                    `*📝 Description:*\n${meta.desc || '_No description_'}\n\n` +
                    `*👥 Members:* ${memberCount}\n` +
                    `*👑 Admins:* ${adminCount}\n` +
                    `*📅 Created:* ${created}\n` +
                    `*🆔 JID:* \`${meta.id}\`\n\n` +
                    `*👑 Admin List:*\n${admins || '_None_'}`,
                mentions: meta.participants.filter((p) => p.admin).map((p) => p.id),
                ...channelInfo
            }, { quoted: message });
        }
        catch (e) {
            console.error('[GROUPMETADATA] Error:', e.message);
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Failed to fetch group info: ${e.message}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};
