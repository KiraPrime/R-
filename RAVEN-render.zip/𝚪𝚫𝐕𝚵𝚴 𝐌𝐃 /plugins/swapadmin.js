'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════

/**
 * Extract a clean phone-based JID from a Baileys participant object.
 * Handles: { id, jid, phoneNumber, lid } without the full 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 LID resolver.
 */
function getParticipantJid(p) {
    if (!p) return '';
    // Prefer real phone-based jid
    if (p.jid && !p.jid.endsWith('@lid')) return p.jid;
    if (p.phoneNumber && !p.phoneNumber.endsWith('@lid')) return p.phoneNumber;
    if (p.id && !p.id.endsWith('@lid')) return p.id;
    // Fallback: convert LID suffix to standard JID suffix
    const raw = p.id || p.jid || p.lid || '';
    return raw.endsWith('@lid') ? raw.replace('@lid', '@s.whatsapp.net') : raw;
}

/**
 * Extract the bare number from a JID.
 */
function jidToNumber(jid) {
    if (!jid) return '';
    return String(jid).split(':')[0].split('@')[0].replace(/[^0-9]/g, '');
}

/**
 * Local owner check based on Raven globals (setting/config.js).
 * Returns true if the given JID's number matches an owner entry.
 */
function isOwnerJid(jid) {
    if (!jid) return false;
    const num = jidToNumber(jid);
    if (!num) return false;

    // Collect candidate owner sources
    const sources = [];

    if (Array.isArray(global.owner))         sources.push(...global.owner);
    if (typeof global.owner === 'string')    sources.push(global.owner);
    if (Array.isArray(global.DEVELOPER))     sources.push(...global.DEVELOPER);
    if (global.ownernumber)                  sources.push(global.ownernumber);
    if (global.ownername)                    sources.push(global.ownername);
    if (global.creator)                      sources.push(global.creator);

    for (const entry of sources) {
        if (!entry) continue;
        const clean = String(entry).split(':')[0].split('@')[0].replace(/[^0-9]/g, '');
        if (!clean) continue;
        if (
            num === clean ||
            num.endsWith(clean) ||
            clean.endsWith(num)
        ) return true;
    }
    return false;
}

async function react(sock, chatId, msgKey, emoji) {
    try {
        await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } });
    } catch { /* ignore */ }
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'swapadmin',
    aliases:     ['swapadmin'],
    category:    'group',
    description: 'Demote all admins and promote bot owners to admin',
    usage:       '.swapadmin',

    async handler(sock, m, args, context) {
        const { chatId, reply, isGroup, isOwner, groupMetadata } = context;

        // ── Guards ────────────────────────────────────────────────
        if (!isGroup) {
            return reply(global.mess?.only?.group || 'This command only works in groups.');
        }
        if (!isOwner) {
            return reply(global.mess?.only?.owner || 'Owner only.');
        }
        if (!groupMetadata || !Array.isArray(groupMetadata.participants)) {
            return reply(global.mess?.error?.fitur || 'Feature error. Could not read group metadata.');
        }

        await react(sock, chatId, m.key, '🕕');

        try {
            const participants   = groupMetadata.participants;
            const groupCreator   = groupMetadata.owner || groupMetadata.subjectOwner || null;
            const botJid         = (sock.user?.id || '').split(':')[0] + '@s.whatsapp.net';

            // ── Scan participants ─────────────────────────────────
            const currentAdmins  = [];
            const ownersInGroup  = [];

            for (const p of participants) {
                const jid = getParticipantJid(p);
                if (!jid) continue;

                if (p.admin === 'admin' || p.admin === 'superadmin') {
                    currentAdmins.push(jid);
                }
                if (isOwnerJid(jid)) {
                    ownersInGroup.push(jid);
                }
            }

            // ── Abort if no bot owner is in the group ────────────
            if (ownersInGroup.length === 0) {
                await react(sock, chatId, m.key, '☢');
                return reply(
                    `❌ *SWAP ADMIN FAILED*\n\n` +
                    `Sorry, this feature cannot run because *no bot Owner* was detected in this group.\n\n` +
                    `This feature needs at least one bot Owner in the group to promote after old admins are demoted.`,
                );
            }

            // ── Compute demote list ───────────────────────────────
            const toDemote = [];
            for (const adminJid of currentAdmins) {
                if (adminJid === botJid) continue;
                if (adminJid === groupCreator) continue;

                const pData = participants.find(x => getParticipantJid(x) === adminJid);
                if (pData && pData.admin === 'superadmin') continue;

                if (ownersInGroup.includes(adminJid)) continue;

                toDemote.push(adminJid);
            }

            // ── Compute promote list ──────────────────────────────
            const toPromote = [];
            for (const ownerJid of ownersInGroup) {
                if (!currentAdmins.includes(ownerJid)) toPromote.push(ownerJid);
            }

            // ── Apply changes ─────────────────────────────────────
            if (toDemote.length > 0) {
                await sock.groupParticipantsUpdate(chatId, toDemote, 'demote');
            }
            if (toPromote.length > 0) {
                await sock.groupParticipantsUpdate(chatId, toPromote, 'promote');
            }

            // ── Build reply ───────────────────────────────────────
            let replyText = `✅ *SWAP ADMIN COMPLETED*\n\n`;
            replyText += `Hello everyone! The admin roster of this group has been updated as requested. Here is the summary:\n\n`;

            if (toDemote.length > 0) {
                replyText += `*Demoted admins:*\n`;
                toDemote.forEach(v => { replyText += `- @${v.split('@')[0]}\n`; });
                replyText += `\n`;
            } else {
                replyText += `*Demoted admins:*\n- No admins were demoted\n\n`;
            }

            replyText += `*Owners promoted to admin:*\n`;
            ownersInGroup.forEach(v => { replyText += `- @${v.split('@')[0]}\n`; });

            replyText += `\nAs a note, the *Group Creator* and the *Bot* were not demoted thanks to system protection. Thanks for understanding!`;

            await react(sock, chatId, m.key, '✅');

            await sendMessageWithChannel(sock, chatId, {
                text: replyText,
                mentions: [...toDemote, ...ownersInGroup],
            });

        } catch (error) {
            console.error('[SWAPADMIN]', error?.message || error);
            await react(sock, chatId, m.key, '☢');
            return reply(global.mess?.error?.fitur || 'Feature error. Please try again.');
        }
    },
};