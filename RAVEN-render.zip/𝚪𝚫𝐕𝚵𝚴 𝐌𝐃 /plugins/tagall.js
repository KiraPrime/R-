/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: 'tagall',
    aliases: ['everyone', 'all'],
    category: 'admin',
    description: 'Tag all group members with their usernames',
    usage: '.tagall',
    groupOnly: true,
    adminOnly: true,
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        try {
            const groupMetadata = await sock.groupMetadata(chatId);
            const participants = groupMetadata.participants;
            if (!participants || participants.length === 0) {
                await sendMessageWithChannel(sock, chatId, {
                    text: 'No participants found in the group.',
                    ...channelInfo
                }, { quoted: message });
                return;
            }
            let messageText = '🔊 *Hello Everyone:*\n\n';
            participants.forEach((participant) => {
                messageText += `@${participant.id.split('@')[0]}\n`;
            });
            await sendMessageWithChannel(sock, chatId, {
                text: messageText,
                mentions: participants.map((p) => p.id),
                ...channelInfo
            });
        }
        catch (error) {
            console.error('Error in tagall command:', error);
            await sendMessageWithChannel(sock, chatId, {
                text: 'Failed to tag all members.',
                ...channelInfo
            }, { quoted: message });
        }
    }
};
