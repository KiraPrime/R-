/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const BASE = 'https://shizoapi.onrender.com/api/pies';
const VALID_COUNTRIES = ['china', 'indonesia', 'japan', 'korea', 'hijab'];
async function fetchPiesImageBuffer(country) {
    const url = `${BASE}/${country}?apikey=shizo`;
    const res = await fetch(url);
    if (!res.ok)
        throw new Error(`HTTP ${res.status}`);
    const contentType = res.headers.get('content-type') || '';
    if (!contentType.includes('image'))
        throw new Error('API did not return an image');
    return res.arrayBuffer().then(b => Buffer.from(b));
}
module.exports = {
    command: 'pies',
    aliases: ['pie'],
    category: 'images',
    description: 'Get a pies image from a specific country',
    usage: `.pies <country>\nAvailable countries: ${VALID_COUNTRIES.join(', ')}`,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const sub = (args[0] || '').toLowerCase();
        if (!sub) {
            await sendMessageWithChannel(sock, chatId, {
                text: `Usage: .pies <country>\nCountries: ${VALID_COUNTRIES.join(', ')}`
            }, { quoted: message });
            return;
        }
        if (!VALID_COUNTRIES.includes(sub)) {
            await sendMessageWithChannel(sock, chatId, {
                text: `Unsupported country: ${sub}. Try one of: ${VALID_COUNTRIES.join(', ')}`
            }, { quoted: message });
            return;
        }
        try {
            const imageBuffer = await fetchPiesImageBuffer(sub);
            await sendMessageWithChannel(sock, chatId, {
                image: imageBuffer,
                caption: `🍰 pies: ${sub}`
            }, { quoted: message });
        }
        catch (err) {
            console.error('Pies Command Error:', err);
            await sendMessageWithChannel(sock, chatId, {
                text: '❌ Failed to fetch image. Please try again.'
            }, { quoted: message });
        }
    }
};
