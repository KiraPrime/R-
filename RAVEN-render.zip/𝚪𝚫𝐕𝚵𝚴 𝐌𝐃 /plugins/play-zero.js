'use strict';
/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const ytdl  = require('ytdl-core');
const yts   = require('yt-search');
const fs    = require('fs');
const path  = require('path');

// ══════════════════════════════════════════════════════════════════
// ─── TEMP DIR ─────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const tempDir = path.join(__dirname, '..', 'temp');
if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

// ══════════════════════════════════════════════════════════════════
// ─── DOWNLOAD AUDIO ───────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function downloadAudio(url, title) {
    return new Promise((resolve, reject) => {
        try {
            const ts = Date.now();
            const safeTitle = String(title).replace(/[^\w\s]/gi, '').slice(0, 60);
            const outputPath = path.join(tempDir, `${ts}_${safeTitle}.mp3`);

            const stream = ytdl(url, {
                filter: 'audioonly',
                quality: 'highestaudio',
                requestOptions: {
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    },
                },
            });

            const writeStream = fs.createWriteStream(outputPath);
            stream.pipe(writeStream);

            writeStream.on('finish', () => {
                try {
                    const audioBuffer = fs.readFileSync(outputPath);
                    fs.unlinkSync(outputPath);
                    resolve(audioBuffer);
                } catch (e) { reject(e); }
            });

            writeStream.on('error', reject);
            stream.on('error', reject);
        } catch (err) {
            reject(err);
        }
    });
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT (ΓΔVEN MD format) ──────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'play-zero',
    aliases:     ['playzero', 'play0', 'pzero'],
    category:    'music',
    description: 'Download & play YouTube audio directly (no API) — © 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
    usage:       '.play-zero <song title | youtube link>',

    async handler(sock, message, args, context) {
        const { chatId, reply, prefix } = context;
        const query = (args.join(' ') || '').trim();

        if (!query) {
            return reply(
                `🎵 *PLAY ZERO*\n\n` +
                `> Example: \`${prefix}play-zero multo\`\n` +
                `> Example: \`${prefix}play-zero https://youtube.com/watch?v=xxxxx\``
            );
        }

        try { await sock.sendMessage(chatId, { react: { text: '🎧', key: message.key } }); } catch {}

        try {
            await reply(`🎵 *Gaven:* Darling~ looking for your song... wait a moment 🦋`);

            let videoUrl, videoInfo;

            // ── Detect URL vs keyword ────────────────────────
            if (query.includes('youtube.com') || query.includes('youtu.be')) {
                videoUrl = query;
                videoInfo = await ytdl.getInfo(videoUrl);
            } else {
                const searchResult = await yts(query);
                if (!searchResult.videos.length) throw new Error('Song not found');
                videoUrl = searchResult.videos[0].url;
                videoInfo = await ytdl.getInfo(videoUrl);
            }

            const details     = videoInfo.videoDetails;
            const title       = details.title;
            const duration    = details.lengthSeconds;
            const views       = details.viewCount;
            const channel     = details.author.name;
            const thumbnail   = details.thumbnails.pop().url;

            const durationMin  = Math.floor(duration / 60);
            const durationSec  = duration % 60;
            const durationText = `${durationMin}:${String(durationSec).padStart(2, '0')}`;
            const viewText     = new Intl.NumberFormat('en-US').format(views);

            await reply(`📥 *Downloading:* ${title}\n⏱️ *Duration:* ${durationText}\n\nWait a moment darling~`);

            const audioBuffer = await downloadAudio(videoUrl, title);

            // ── Send cover + caption ─────────────────────────
            const caption =
                `🎵 *${title}*\n\n` +
                `👤 *Artist:* ${channel}\n` +
                `⏱️ *Duration:* ${durationText}\n` +
                `👁️ *Views:* ${viewText}\n\n` +
                `🦋 *Gaven:* Enjoy darling~ replay if you like it! 💕`;

            await sock.sendMessage(
                chatId,
                { image: { url: thumbnail }, caption },
                { quoted: message }
            );

            // ── Send audio ───────────────────────────────────
            await sock.sendMessage(
                chatId,
                {
                    audio: audioBuffer,
                    mimetype: 'audio/mpeg',
                    ptt: false,
                    fileName: `${title}.mp3`,
                },
                { quoted: message }
            );

            await sock.sendMessage(chatId, { react: { text: '✅', key: message.key } }).catch(() => {});
        } catch (err) {
            console.error('[PlayZero]', err);
            await sock.sendMessage(chatId, { react: { text: '✘', key: message.key } }).catch(() => {});

            const errorMsg = err.message || String(err);

            if (errorMsg.includes('getaddrinfo') || errorMsg.includes('ENOTFOUND')) {
                return reply(`❌ *Error:* Network issue, please try again darling~ 🗿`);
            }
            if (errorMsg.includes('signature')) {
                return reply(`❌ *Error:* YouTube is updating, please try again later darling~ 🦋`);
            }
            return reply(`❌ *Error:* ${errorMsg.substring(0, 100)}\n\n> Please try again later darling~`);
        }
    },
};