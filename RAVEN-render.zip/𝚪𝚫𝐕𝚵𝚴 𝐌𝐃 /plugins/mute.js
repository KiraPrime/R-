/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: 'mute',
    aliases: ['silence'],
    category: 'admin',
    description: 'Mute the group for a specified duration',
    usage: '.mute [duration in minutes]',
    groupOnly: true,
    adminOnly: true,
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        const durationInMinutes = args[0] ? parseInt(args[0], 10) : undefined;
        try {
            await sock.groupSettingUpdate(chatId, 'announcement');
            if (durationInMinutes !== undefined && durationInMinutes > 0) {
                const durationInMilliseconds = durationInMinutes * 60 * 1000;
                await sendMessageWithChannel(sock, chatId, {
                    text: `The group has been muted for ${durationInMinutes} minutes.`,
                    ...channelInfo
                }, { quoted: message });
                setTimeout(async () => {
                    try {
                        await sock.groupSettingUpdate(chatId, 'not_announcement');
                        await sendMessageWithChannel(sock, chatId, {
                            text: 'The group has been unmuted.',
                            ...channelInfo
                        });
                    }
                    catch (unmuteError) {
                        console.error('Error unmuting group:', unmuteError);
                    }
                }, durationInMilliseconds);
            }
            else {
                await sendMessageWithChannel(sock, chatId, {
                    text: 'The group has been muted.',
                    ...channelInfo
                }, { quoted: message });
            }
        }
        catch (error) {
            console.error('Error muting/unmuting the group:', error);
            await sendMessageWithChannel(sock, chatId, {
                text: 'An error occurred while muting/unmuting the group. Please try again.',
                ...channelInfo
            }, { quoted: message });
        }
    }
};
