/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: '8ball',
    aliases: ['eightball', 'magic8ball'],
    category: 'fun',
    description: 'Ask the magic 8-ball a question',
    usage: '.8ball Will I be rich?',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            const question = args.join(' ');
            if (!question) {
                await sendMessageWithChannel(sock, chatId, {
                    text: '🎱 Please ask a question!'
                }, { quoted: message });
                return;
            }
            const eightBallResponses = [
                "Yes, definitely!",
                "No way!",
                "Ask again later.",
                "It is certain.",
                "Very doubtful.",
                "Without a doubt.",
                "My reply is no.",
                "Signs point to yes."
            ];
            const randomResponse = eightBallResponses[Math.floor(Math.random() * eightBallResponses.length)];
            await sendMessageWithChannel(sock, chatId, {
                text: `🎱 *Question:* ${question}\n\n*Answer:* ${randomResponse}`
            }, { quoted: message });
        }
        catch (error) {
            console.error('Error in 8ball command:', error);
            await sendMessageWithChannel(sock, chatId, {
                text: '❌ Something went wrong with the magic 8-ball!'
            }, { quoted: message });
        }
    }
};
