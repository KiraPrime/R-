/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require('axios');
module.exports = {
    command: 'reverse',
    aliases: ['revt', 'reversetext'],
    category: 'tools',
    description: 'Reverse any text',
    usage: '.reverse <text>',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const textToReverse = args?.join(' ')?.trim();
        if (!textToReverse) {
            return await sendMessageWithChannel(sock, chatId, { text: 'Please provide text to reverse.\nExample: .reverse Hello World' }, { quoted: message });
        }
        try {
            const apiUrl = `https://discardapi.dpdns.org/api/tools/reverse?apikey=guru&text=${encodeURIComponent(textToReverse)}`;
            const { data } = await axios.get(apiUrl, { timeout: 10000 });
            if (!data?.status || !data.result) {
                return await sendMessageWithChannel(sock, chatId, { text: '❌ Failed to reverse the text.' }, { quoted: message });
            }
            const reply = `*Reversed:* ${data.result}`;
            await sendMessageWithChannel(sock, chatId, { text: reply }, { quoted: message });
        }
        catch (error) {
            console.error('Reverse plugin error:', error);
            if (error.code === 'ECONNABORTED') {
                await sendMessageWithChannel(sock, chatId, { text: '❌ Request timed out. Please try again.' }, { quoted: message });
            }
            else {
                await sendMessageWithChannel(sock, chatId, { text: '❌ Failed to reverse the text.' }, { quoted: message });
            }
        }
    }
};
