/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️
           
Original dev: Kira Dev 
*/
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require('axios');
module.exports = {
    command: 'cyberimg',
    aliases: ['cyber', 'cyberspace'],
    category: 'images',
    description: 'Get a random cyberspace image',
    usage: '.cyberimg',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            const res = await axios.get('https://raw.githubusercontent.com/GlobalTechInfo/Database/main/images/cyberspace.json');
            if (!res.data || !Array.isArray(res.data) || res.data.length === 0) {
                return await sendMessageWithChannel(sock, chatId, { text: '❌ Failed to fetch image.' }, { quoted: message });
            }
            const randomImage = res.data[Math.floor(Math.random() * res.data.length)];
            await sendMessageWithChannel(sock, chatId, { image: { url: randomImage }, caption: '🌐 Cyberspace Image' }, { quoted: message });
        }
        catch (err) {
            console.error('Cyberspace image plugin error:', err);
            await sendMessageWithChannel(sock, chatId, { text: '❌ Error while fetching image.' }, { quoted: message });
        }
    }
};
