'use strict';

const SUPPORTED_LANGUAGES = ['en', 'fr'];
const DEFAULT_LANGUAGE = 'en';

let PLUGIN_TRANSLATIONS = {};
try { PLUGIN_TRANSLATIONS = require('./plugin-translations.json'); } catch { PLUGIN_TRANSLATIONS = {}; }

const MESSAGES = {
  en: {
    languageCurrent: (lang) => `🌐 Current language: *${lang === 'fr' ? 'French' : 'English'}*\nUse *.lang en* or *.lang fr* to change it.`,
    languageChanged: (lang) => `✅ Language changed to *${lang === 'fr' ? 'French' : 'English'}*.`,
    languageInvalid: '❌ Unsupported language. Available languages: *en* (English) and *fr* (French).',
    banned: '🚫 You are banned, @USER',
    linkForbidden: '🚫 *Link forbidden!* @USER',
    locked: (name, link) => `🔒 *BOT LOCKED TO ANOTHER GROUP*\n\nThis bot is currently restricted to:\n*${name || 'Unknown'}*\n\nJoin here: ${link || ''}`,
    pluginError: (command, error) => `❌ Error in *.${command}*\n${error}`,
    featureError: '⚠️ Feature error. Please try again.',
  },
  fr: {
    languageCurrent: () => '🌐 Langue actuelle : *français*\nUtilise *.lang en* ou *.lang fr* pour la modifier.',
    languageChanged: (lang) => `✅ Langue changée en *${lang === 'fr' ? 'français' : 'anglais'}*.`,
    languageInvalid: '❌ Langue non prise en charge. Langues disponibles : *en* (anglais) et *fr* (français).',
    banned: '🚫 Tu es banni(e), @USER',
    linkForbidden: '🚫 *Lien interdit !* @USER',
    locked: (name, link) => `🔒 *BOT VERROUILLÉ SUR UN AUTRE GROUPE*\n\nLe bot est actuellement limité à :\n*${name || 'Inconnu'}*\n\nRejoins-le ici : ${link || ''}`,
    pluginError: (command, error) => `❌ Erreur dans *.${command}*\n${error}`,
    featureError: '⚠️ Erreur de fonctionnalité. Réessaie plus tard.',
  },
};

// Legacy strings found in imported plugins. They are normalized at the reply boundary
// so old plugins cannot leak Indonesian/Portuguese text when the bot is in English.
const LEGACY_REPLACEMENTS = [
  [/Contoh penggunaan:/gi, { en: 'Usage example:', fr: 'Exemple d’utilisation :' }],
  [/Gunakan perintah berikut:/gi, { en: 'Use the following command:', fr: 'Utilise la commande suivante :' }],
  [/Contoh:/gi, { en: 'Example:', fr: 'Exemple :' }],
  [/Tidak ada respon dari server\.?/gi, { en: 'The server returned no response.', fr: 'Le serveur n’a renvoyé aucune réponse.' }],
  [/Gagal melakukan bypass\.?/gi, { en: 'Bypass failed.', fr: 'Échec du contournement.' }],
  [/URL tidak valid\. Gunakan link CapCut\.?/gi, { en: 'Invalid URL. Use a CapCut link.', fr: 'URL invalide. Utilise un lien CapCut.' }],
  [/Gagal mengambil video\. Coba link lain\.?/gi, { en: 'Could not fetch the video. Try another link.', fr: 'Impossible de récupérer la vidéo. Essaie un autre lien.' }],
  [/Format Salah!/gi, { en: 'Invalid format!', fr: 'Format invalide !' }],
  [/Wallpaper untuk kata kunci \"([^\"]*)\" tidak ditemukan\.?/gi, { en: 'No wallpaper found for the keyword "$1".', fr: 'Aucun fond d’écran trouvé pour le mot-clé « $1 ».' }],
  [/URL gambar tidak valid atau tidak dapat dimuat\.?/gi, { en: 'The image URL is invalid or could not be loaded.', fr: 'L’URL de l’image est invalide ou ne peut pas être chargée.' }],
  [/GAGAL/gi, { en: 'FAILED', fr: 'ÉCHEC' }],
  [/Mencari dan mengunduh wallpaper HD dari Wallcraft/gi, { en: 'Search and download HD wallpapers from Wallcraft', fr: 'Rechercher et télécharger des fonds d’écran HD depuis Wallcraft' }],
  [/Tidak ada hasil ditemukan\.?/gi, { en: 'No results found.', fr: 'Aucun résultat trouvé.' }],
  [/Tidak bisa mengambil daftar lagu NCS\.?/gi, { en: 'Could not retrieve the NCS track list.', fr: 'Impossible de récupérer la liste des morceaux NCS.' }],
  [/Gagal mengambil link download lagu\.?/gi, { en: 'Could not retrieve the song download link.', fr: 'Impossible de récupérer le lien de téléchargement du morceau.' }],
  [/Gagal mengirim file audio\./gi, { en: 'Could not send the audio file.', fr: 'Impossible d’envoyer le fichier audio.' }],
  [/Failed to fetch image\./gi, { en: 'Failed to fetch image.', fr: 'Échec de récupération de l’image.' }],
  [/Only group admins or bot owner can clear this chat\./gi, { en: 'Only group admins or bot owner can clear this chat.', fr: 'Seuls les administrateurs du groupe ou le propriétaire du bot peuvent effacer cette conversation.' }],
  [/This command only works in groups\./gi, { en: 'This command only works in groups.', fr: 'Cette commande fonctionne uniquement dans les groupes.' }],
  [/Please try again later\.?/gi, { en: 'Please try again later.', fr: 'Réessaie plus tard.' }],
  [/Mencari lagu NCS\.\.\./gi, { en: 'Searching for an NCS song...', fr: 'Recherche d’un morceau NCS...' }],
  [/Sedang mencari lagu di NCS\.io\.\.\./gi, { en: 'Searching for a song on NCS.io...', fr: 'Recherche d’un morceau sur NCS.io...' }],
  [/Akun \*@([^*]+)\* tidak ditemukan/gi, { en: 'Account *@$1* not found', fr: 'Compte *@$1* introuvable' }],
];

function normalizeLanguage(value) {
  const lang = String(value || '').trim().toLowerCase().split(/[-_]/)[0];
  return SUPPORTED_LANGUAGES.includes(lang) ? lang : DEFAULT_LANGUAGE;
}
function getLanguage(chatId, getSetting) {
  try { return normalizeLanguage(getSetting?.(chatId, 'language', DEFAULT_LANGUAGE)); }
  catch { return DEFAULT_LANGUAGE; }
}
function message(lang, key, ...args) {
  const locale = MESSAGES[normalizeLanguage(lang)] || MESSAGES[DEFAULT_LANGUAGE];
  const value = locale[key] ?? MESSAGES[DEFAULT_LANGUAGE][key] ?? key;
  return typeof value === 'function' ? value(...args) : value;
}
function localizeText(value, lang = DEFAULT_LANGUAGE) {
  if (value === undefined || value === null) return value;
  let text = String(value);
  const locale = normalizeLanguage(lang);
  if (locale === 'fr' && Object.prototype.hasOwnProperty.call(PLUGIN_TRANSLATIONS, text)) {
    return PLUGIN_TRANSLATIONS[text];
  }
  for (const [pattern, translations] of LEGACY_REPLACEMENTS) {
    text = text.replace(pattern, (...match) => {
      let replacement = translations[locale] || translations.en;
      const captures = match.slice(1, -2);
      captures.forEach((capture, index) => { replacement = replacement.replace(`$${index + 1}`, capture || ''); });
      return replacement;
    });
  }
  return text;
}
module.exports = { SUPPORTED_LANGUAGES, DEFAULT_LANGUAGE, normalizeLanguage, getLanguage, message, localizeText };
