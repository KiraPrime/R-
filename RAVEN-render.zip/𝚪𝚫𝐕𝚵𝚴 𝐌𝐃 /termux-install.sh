#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

if [ "$(uname -o 2>/dev/null || true)" != "Android" ] && [ -z "${TERMUX_VERSION:-}" ]; then
  echo "Ce script est prévu pour Termux sur Android."
fi

pkg update -y
pkg upgrade -y
pkg install -y nodejs-lts ffmpeg python clang make pkg-config git tmux

# Évite les erreurs liées à l'installation de modules natifs sur Termux.
export npm_config_build_from_source=false
npm install --legacy-peer-deps
python -m pip install --upgrade yt-dlp
npm install -g pm2

chmod +x termux-install.sh
mkdir -p richstore/pairing

echo
echo "Installation Termux terminée."
echo "Démarrage interactif : npm start"
echo "Le programme demande : Envoie ton numéro WhatsApp sans le +"
echo "Démarrage avec numéro : npm start -- --phone 24160123456"
echo "Mode persistant Termux : pm2 start ecosystem.config.cjs"
echo "Voir les logs : pm2 logs raven-md"
