# RAVEN MD — mode Telegram

## Démarrage

Le démarrage suit le fonctionnement de la version qui marche : `npm start` lance `index.js`. Ce fichier vérifie le mot de passe de démarrage, puis appelle `bot.js`, qui lance la connexion Telegram avec Telegraf.

```bash
npm install
npm start
```

Lors du premier démarrage, le programme demande le mot de passe défini dans `token.js` (`startupPassword`). Une fois authentifié, l’état est conservé dans `richstore/auth.json`; les démarrages suivants lancent directement le bot Telegram.

Le bot répond ensuite aux commandes Telegram, notamment `/start` et `/connect`.

## PM2

```bash
npm run start:pm2
pm2 save
npm run logs:pm2
```

Le fichier `ecosystem.config.cjs` utilise également `index.js`, comme la version fonctionnelle de référence.
