/**
 * 𝚪𝚫𝐕𝚵𝚴 — Message Handler (𝚪𝚫𝐕𝚵𝚴 𝐌𝐃)
 *
 * Ce fichier ne contient PLUS de switch/case.
 * Chaque commande vit dans son propre fichier dans /plugins/.
 * Les plugins sont chargés au démarrage et hot-reloadés automatiquement.
 *
 * Features:
 *   - Dynamic prefixes (from owner-tools-pack store)
 *   - NoPrefix mode support
 *   - OnlyOwner / OnlyAdmin / OnlyThisGroup access locks
 *   - Rich context object for plugins
 *   - Plugin lazy event binding (welcome, goodbye, antibot, autoreply…)
 *   - Interactive button router (menu categories, lists, buttons)
 */

require('./setting/config');

const {
    generateWAMessageFromContent,
    proto,
} = require('@whiskeysockets/baileys');

const { getContentType } = require('@whiskeysockets/baileys');
const fs   = require('fs');
const path = require('path');
const util = require('util');
const chalk = require('chalk');

const { smsg, runtime, getBuffer, fetchJson, sleep, getGroupAdmins } = require('./allfunc/storage');
const { getSetting, setSetting } = require('./Settings.js');
const sessionConfig = require('./lib/session-config');
const { getLanguage, message, localizeText } = require('./i18n');

// Images envoyées aléatoirement avec les réponses de commandes.
// Les commandes qui possèdent leur propre média restent inchangées.
const _fileJsonCache = new Map();
function readJsonCached(filePath, fallback = []) {
    try {
        const stat = fs.statSync(filePath);
        const hit = _fileJsonCache.get(filePath);
        if (hit && hit.mtimeMs === stat.mtimeMs) return hit.value;
        const value = JSON.parse(fs.readFileSync(filePath, 'utf8') || '[]');
        _fileJsonCache.set(filePath, { mtimeMs: stat.mtimeMs, value });
        return value;
    } catch { return fallback; }
}
const _groupMetadataCache = new WeakMap();
async function getGroupMetadataCached(sock, jid) {
    if (!jid || !jid.endsWith('@g.us')) return {};
    let cache = _groupMetadataCache.get(sock);
    if (!cache) { cache = new Map(); _groupMetadataCache.set(sock, cache); }
    const now = Date.now();
    const hit = cache.get(jid);
    if (hit?.promise) return hit.promise;
    if (hit && hit.expiresAt > now) return hit.value;
    const promise = sock.groupMetadata(jid).catch(() => ({}));
    cache.set(jid, { promise, expiresAt: now + 60_000, value: hit?.value || {} });
    const value = await promise;
    cache.set(jid, { value, expiresAt: Date.now() + 60_000 });
    return value;
}

const RANDOM_COMMAND_IMAGES = [
    'https://g.top4top.io/p_3939u4lgq1.jpg','https://f.top4top.io/p_3939b1lhd1.jpg','https://h.top4top.io/p_3939v7o2b1.jpg','https://j.top4top.io/p_3939faytr1.jpg','https://i.top4top.io/p_39391nz8p1.jpg','https://k.top4top.io/p_3939vyxpi1.jpg','https://l.top4top.io/p_39393pj871.jpg','https://k.top4top.io/p_3939ig7qg1.jpg','https://a.top4top.io/p_3939py9811.jpg','https://l.top4top.io/p_3939iaofi1.jpg','https://b.top4top.io/p_3939jia9l1.jpg','https://c.top4top.io/p_39390ajaq1.jpg','https://d.top4top.io/p_3939uwwkj1.jpg','https://e.top4top.io/p_3939fmy6b1.jpg','https://e.top4top.io/p_3939okww71.jpg','https://f.top4top.io/p_3939aryje1.jpg','https://h.top4top.io/p_3939c0jam1.jpg','https://g.top4top.io/p_3939j8ncc1.jpg','https://i.top4top.io/p_3939abhty1.jpg','https://k.top4top.io/p_3939xhf0r1.jpg','https://l.top4top.io/p_3939gjbyv1.jpg','https://a.top4top.io/p_3939jowah1.jpg','https://b.top4top.io/p_3939jr4h41.jpg','https://c.top4top.io/p_3939kmmae1.jpg','https://d.top4top.io/p_3939nodr51.jpg','https://e.top4top.io/p_3939jxg411.jpg','https://f.top4top.io/p_3939zmtbc1.jpg','https://g.top4top.io/p_39398kew61.jpg','https://h.top4top.io/p_3939h31go1.jpg','https://i.top4top.io/p_39394fsmy1.jpg','https://j.top4top.io/p_39390bot91.jpg','https://l.top4top.io/p_3939ozqxy1.jpg','https://k.top4top.io/p_39396imfr1.jpg','https://a.top4top.io/p_3939x12tb1.jpg','https://b.top4top.io/p_3939ncul91.jpg','https://c.top4top.io/p_39397f24n1.jpg','https://d.top4top.io/p_3939x07s61.jpg','https://f.top4top.io/p_39391qpjg1.jpg','https://g.top4top.io/p_3939dhalr1.jpg','https://h.top4top.io/p_39390pf181.jpg','https://l.top4top.io/p_3939rkno71.jpg','https://l.top4top.io/p_3940ei27a1.jpg','https://a.top4top.io/p_3940vz3ea1.jpg','https://b.top4top.io/p_39407ornu1.jpg','https://c.top4top.io/p_39407q83w1.jpg','https://f.top4top.io/p_3940xagtb1.jpg','https://g.top4top.io/p_3940opbah1.jpg'
];
const RANDOM_IMAGE_EXCLUDED_COMMANDS = new Set(['kick', 'kickall', 'cleargroup', 'promote', 'makeadmin', 'demote', 'unadmin', 'downgrade', 'owner', 'menu']);

function getRandomCommandImage(commandName) {
    if (RANDOM_IMAGE_EXCLUDED_COMMANDS.has(String(commandName || '').toLowerCase())) return null;
    return RANDOM_COMMAND_IMAGES[Math.floor(Math.random() * RANDOM_COMMAND_IMAGES.length)];
}
const _randomReplyCache = new Map();
async function getRandomCommandImageBuffer(imageUrl) {
    if (!imageUrl) return null;
    if (_randomReplyCache.has(imageUrl)) return _randomReplyCache.get(imageUrl);
    try {
        const response = await fetch(imageUrl, { signal: AbortSignal.timeout(20000) });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const buffer = Buffer.from(await response.arrayBuffer());
        if (!buffer.length) throw new Error('empty image');
        _randomReplyCache.set(imageUrl, buffer);
        return buffer;
    } catch (err) {
        console.error(chalk?.yellow?.(`[REPLY MEDIA] ${imageUrl}: ${err.message}`) || err.message);
        return null;
    }
}

// ═════════════════════════════════════════════════════════════════════════
// ─── OWNER-TOOLS STORE HELPERS ───────────────────────────────────────────
// ═════════════════════════════════════════════════════════════════════════
const _OWNER_TOOLS_STORE = path.join(__dirname, 'plugins', 'owner-tools-data', 'store.json');
let _ownerToolsCache = null;
let _ownerToolsCacheMtime = 0;

function loadOwnerToolsStore() {
    try {
        if (!fs.existsSync(_OWNER_TOOLS_STORE)) return null;
        const stat = fs.statSync(_OWNER_TOOLS_STORE);
        if (_ownerToolsCache && stat.mtimeMs === _ownerToolsCacheMtime) {
            return _ownerToolsCache;
        }
        const raw = fs.readFileSync(_OWNER_TOOLS_STORE, 'utf8').trim();
        if (!raw) return null;
        _ownerToolsCache = JSON.parse(raw);
        _ownerToolsCacheMtime = stat.mtimeMs;
        return _ownerToolsCache;
    } catch { return null; }
}

function getActivePrefixes() {
    const list = [global.xprefix || '.'];
    const store = loadOwnerToolsStore();
    const dbPrefixes = store?.global?.prefixes || [];
    for (const p of dbPrefixes) {
        if (p && !list.includes(p)) list.push(p);
    }
    return list;
}

function isNoPrefixEnabled() {
    const store = loadOwnerToolsStore();
    return store?.global?.noprefix === true;
}

function getAccessMode(key, def = null) {
    const store = loadOwnerToolsStore();
    const v = store?.global?.[key];
    return v === undefined ? def : v;
}

// ═════════════════════════════════════════════════════════════════════════
// ─── PLUGIN LOADER ───────────────────────────────────────────────────────
// ═════════════════════════════════════════════════════════════════════════
const commands = new Map(); // command → plugin
const aliases  = new Map(); // alias   → command

function loadPlugins() {
    const root = path.join(__dirname, 'plugins');
    if (!fs.existsSync(root)) return;
    const files = [];
    const walk = (dir) => {
        for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
            const fp = path.join(dir, entry.name);
            if (entry.isDirectory() && entry.name !== 'node_modules') walk(fp);
            else if (entry.isFile() && entry.name.endsWith('.js')) files.push(fp);
        }
    };
    walk(root);
    // Les plugins historiques sont imbriqués ; les fichiers racine sont prioritaires.
    files.sort((a, b) => b.split(path.sep).length - a.split(path.sep).length);
    let ok = 0;
    for (const fp of files) {
        const file = path.relative(root, fp);
        try {
            delete require.cache[require.resolve(fp)];
            const plug = require(fp);
            const p = plug.default || plug;
            if (!p || !p.command || typeof p.handler !== 'function') continue;
            const names = Array.isArray(p.command) ? p.command : [p.command];
            const key = String(names[0]).toLowerCase();
            // Une commande racine déjà chargée garde la priorité sur une copie héritée.
            if (commands.has(key) && !file.includes(`${path.sep}plugins${path.sep}`)) continue;
            commands.set(key, p);
            for (const a of [...(p.aliases || []), ...names.slice(1)]) {
                aliases.set(String(a).toLowerCase(), key);
            }
            ok++;
        } catch (e) {
            console.error(chalk.red(`[PLUGIN] Erreur ${file}: ${e.message}`));
        }
    }
    console.log(chalk.green(`[PLUGINS] ✅ ${ok}/${files.length} plugins chargés`));
}
loadPlugins();

// Hot-reload
try {
    fs.watch(path.join(__dirname, 'plugins'), (evt, filename) => {
        if (filename && filename.endsWith('.js')) {
            const fp = path.join(__dirname, 'plugins', filename);
            try {
                delete require.cache[require.resolve(fp)];
                const plug = require(fp);
                const p    = plug.default || plug;
                if (p?.command && typeof p.handler === 'function') {
                    commands.set(p.command.toLowerCase(), p);
                    for (const a of (p.aliases || [])) aliases.set(a.toLowerCase(), p.command.toLowerCase());
                    console.log(chalk.cyan(`[PLUGIN] 🔄 Reload: ${filename}`));
                }
            } catch (e) {
                console.error(chalk.red(`[PLUGIN] Reload erreur ${filename}: ${e.message}`));
            }
        }
    });
} catch { /* ignore */ }

// ═════════════════════════════════════════════════════════════════════════
// ─── MAIN HANDLER ────────────────────────────────────────────────────────
// ═════════════════════════════════════════════════════════════════════════
module.exports = async (sock, m, chatUpdate, store) => {
    const from = m.key.remoteJid;

    try {
        // ── Extract message text ─────────────────────────────────────────
        const body = (
            m.mtype === 'conversation'               ? m.message?.conversation :
            m.mtype === 'extendedTextMessage'        ? m.message?.extendedTextMessage?.text :
            m.mtype === 'imageMessage'               ? m.message?.imageMessage?.caption :
            m.mtype === 'videoMessage'               ? m.message?.videoMessage?.caption :
            m.mtype === 'documentMessage'            ? m.message?.documentMessage?.caption || '' :
            m.mtype === 'buttonsResponseMessage'     ? m.message?.buttonsResponseMessage?.selectedButtonId :
            m.mtype === 'listResponseMessage'        ? m.message?.listResponseMessage?.singleSelectReply?.selectedRowId :
            m.mtype === 'templateButtonReplyMessage' ? m.message?.templateButtonReplyMessage?.selectedId :
            m.mtype === 'viewOnceMessage'            ? (m.message?.viewOnceMessage?.message?.imageMessage?.caption ||
                                                        m.message?.viewOnceMessage?.message?.videoMessage?.caption || '') :
            m.mtype === 'protocolMessage'            ? '' :
            ''
        ) || '';

        // ── Prefix resolution (dynamic) ──────────────────────────────────
        const activePrefixes = getActivePrefixes();
        const noprefix = isNoPrefixEnabled();

        let matchedPrefix = null;
        for (const p of activePrefixes) {
            if (p && body.startsWith(p)) { matchedPrefix = p; break; }
        }

        const isCmd = matchedPrefix !== null;
        const prefix = matchedPrefix || (global.xprefix || '.');

        let cmdName = '';
        let args = [];
        if (isCmd) {
            const parts = body.slice(matchedPrefix.length).trim().split(/ +/);
            cmdName = (parts.shift() || '').toLowerCase();
            args    = parts;
        } else if (noprefix) {
            const parts = body.trim().split(/ +/);
            const maybe = (parts[0] || '').toLowerCase();
            if (commands.has(maybe) || aliases.has(maybe)) {
                cmdName = maybe;
                args    = parts.slice(1);
            }
        }

        // ── Common variables ─────────────────────────────────────────────
        let owner   = [];
        let Premium = [];
        try {
            owner   = readJsonCached('./allfunc/owner.json', []);
            Premium = readJsonCached('./allfunc/premium.json', []);
        } catch { /* ignore */ }

        const botRaw = sock.user?.id || sock.user?.jid || sock.user?.lid || '';
        const botNumber = await sock.decodeJid(botRaw);
        const baseIsOwner = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender);
        const sessionId = sessionConfig.normalizeJid(botNumber);
        const isSessionOwner = sessionConfig.isSessionOwner(sessionId, m.sender);
        const isOwner   = baseIsOwner || isSessionOwner;
        const isPremium = [botNumber, ...Premium].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender);

        const sender        = m.isGroup ? (m.key.participant || m.participant) : m.key.remoteJid;
        const pushname      = m.pushName || 'User';
        const quoted        = m.quoted || m;
        const mime          = (quoted.msg || quoted).mimetype || '';

        const groupMetadata = m.isGroup ? await getGroupMetadataCached(sock, from) : {};
        const participants  = groupMetadata?.participants || [];

        const _num = (j) => String(j || '').split(':')[0].split('@')[0].replace(/[^0-9]/g, '');
        const botIds = [
            botNumber,
            sock.user?.id,
            sock.user?.jid,
            sock.user?.lid,
            sock.user?.phoneNumber,
        ];
        const senderIds = [m.sender, sender, m.key?.participant, m.participant];

        const _isAdminNum = (ids) => {
            const targets = new Set(ids.map(_num).filter(Boolean));
            if (!targets.size) return false;
            return participants.some(p => {
                const participantIds = [p.id, p.jid, p.phoneNumber, p.lid, p.phone]
                    .map(_num)
                    .filter(Boolean);
                return participantIds.some((id) => targets.has(id)) &&
                    (p.admin === 'admin' || p.admin === 'superadmin');
            });
        };

        const isBotAdmin = m.isGroup ? _isAdminNum(botIds) : false;
        const isAdmin    = m.isGroup ? _isAdminNum(senderIds) : false;

        // ── Reply helper: attach channel CTA + external ad ───────────────
        const CHANNEL_URL = global.link || 'https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w';

        const commandForReplyMedia = commands.has(cmdName)
            ? cmdName
            : (aliases.get(cmdName) || cmdName);
        // Les images aléatoires sont réservées aux clics de catégories du menu.
        const randomReplyImage = null;
        const randomReplyImageBuffer = null;

        const forwardInfo = {
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: '120363410293871779@newsletter',
                newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
                serverMessageId: -1,
            },
        };

        function sendMessageWithChannel(sockRef, jid, content, options) {
            if (!content || typeof content !== 'object' || content.react) {
                return sockRef.sendMessage(jid, content, options);
            }
            return sockRef.sendMessage(jid, {
                ...content,
                contextInfo: {
                    ...(content.contextInfo || {}),
                    ...forwardInfo,
                },
            }, options);
        }

        async function sendWithChannelBtn(text) {
            const jid = m.chat || from;
            const baseOptions = { quoted: m };
            // Keep the requested random image URLs. Do not pre-download them;
            // Baileys handles the URL and this also keeps the archive smaller.
            if (randomReplyImage) {
                try {
                    return await sendMessageWithChannel(sock, jid, {
                        image: randomReplyImageBuffer || { url: randomReplyImage },
                        caption: String(text ?? ''),
                        mentions: sender ? [sender] : [],
                    }, baseOptions);
                } catch (err) {
                    console.error(chalk.yellow(`[REPLY MEDIA] ${err?.message || err}`));
                }
            }
            try {
                return await sendMessageWithChannel(sock, jid, {
                    text: String(text ?? ''),
                    mentions: sender ? [sender] : [],
                }, baseOptions);
            } catch (err) {
                console.error(chalk.yellow(`[REPLY TEXT] ${err?.message || err}`));
                return sock.sendMessage(jid, { text: String(text ?? '') });
            }
        }

        const language = getLanguage(m.chat || from, getSetting);
        const reply = (text) => sendWithChannelBtn(localizeText(text, language));
        // Legacy plugins often call m.reply directly. Route those replies through
        // the same localized boundary so imported plugins cannot leak other languages.
        m.reply = (text) => reply(text);
        m.lang = language;

        // ═════════════════════════════════════════════════════════════════
        // ─── INTERACTIVE BUTTON ROUTER ───────────────────────────────────
        // Doit tourner AVANT tous les autres checks (banned, autobio, etc.)
        // pour capter les clics sur boutons/listes et les router vers
        // menu.js (ou autre plugin qui expose handleInteractive).
        // ═════════════════════════════════════════════════════════════════
        try {
            const msg = m.message || {};
            const hasInteractive = !!(
                msg.interactiveResponseMessage ||
                msg.viewOnceMessage?.message?.interactiveResponseMessage ||
                msg.viewOnceMessageV2?.message?.interactiveResponseMessage ||
                msg.viewOnceMessageV2Extension?.message?.interactiveResponseMessage ||
                msg.listResponseMessage ||
                msg.buttonsResponseMessage ||
                msg.templateButtonReplyMessage
            );

            if (hasInteractive) {
                // Parcourt tous les plugins qui exposent handleInteractive
                for (const [name, plug] of commands) {
                    if (plug && typeof plug.handleInteractive === 'function') {
                        const handled = await plug.handleInteractive(sock, m, {
                            chatId:    m.chat,
                            sender,
                            pushname,
                            isGroup:   m.isGroup,
                            isOwner,
                            isPremium,
                            isAdmin,
                            isBotAdmin,
                            groupMetadata,
                            prefix,
                            reply,
                            from,
                            m,
                            store,
                        });
                        if (handled) return; // ⛔ stop, déjà traité
                    }
                }
            }
        } catch (e) {
            console.error(chalk.red(`[ROUTER interactive] ${e?.message}`));
        }

        // ── Self / public mode ──────────────────────────────────────────
        // .ces doit rester accessible pour réclamer une session encore vierge.
        const isCesCommand = cmdName === 'ces' || aliases.get(cmdName) === 'ces';
        if (!sock.public && !isOwner && !isCesCommand) return;

        // ── Banned ───────────────────────────────────────────────────────
        if (getSetting(m.sender, 'banned', false)) {
            await sock.sendMessage(m.chat, {
                text: message(language, 'banned').replace('USER', m.sender.split('@')[0]),
                mentions: [m.sender]
            }, { quoted: m });
            return;
        }

        // ── Auto features ────────────────────────────────────────────────
        if (getSetting(m.sender,  'autobio',       true))  sock.updateProfileStatus('ᴏʀᴇᴋɪ xᴅ ɪs ᴏɴ ғɪʀᴇ').catch(() => {});
        if (getSetting(m.chat,    'autoTyping',    false)) sock.sendPresenceUpdate('composing', from);
        if (getSetting(m.chat,    'autoRecording', false)) sock.sendPresenceUpdate('recording',  from);
        if (getSetting(m.sender,  'autoread',      false)) sock.readMessages([m.key]).catch(() => {});

        if (getSetting(m.chat, 'autoReact', false)) {
            const emojis = ['😁','😂','🤣','😊','😍','😎','🤩','❤️','💪','🔥','⚡','🎉','👏'];
            await sock.sendMessage(m.chat, {
                react: { text: emojis[Math.floor(Math.random() * emojis.length)], key: m.key }
            }).catch(() => {});
        }

        // ── Anti-link (case.js level) ────────────────────────────────────
        if (getSetting(m.chat, 'antilink', false) && m.isGroup && !isAdmin && !isOwner) {
            if (/(https?:\/\/[^\s]+)/gi.test(body)) {
                await sock.sendMessage(m.chat, {
                    text: message(language, 'linkForbidden').replace('USER', m.sender.split('@')[0]),
                    mentions: [m.sender]
                }, { quoted: m });
                await sock.sendMessage(m.chat, { delete: m.key }).catch(() => {});
                return;
            }
        }

        // ── Log commands ─────────────────────────────────────────────────
        if (isCmd) {
            const groupName = m.isGroup ? groupMetadata?.subject : 'DM';
            console.log(
                chalk.bgWhite.black('[𝚪𝚫𝐕𝚵𝚴]'),
                chalk.bgGreen.black(new Date().toLocaleTimeString()),
                chalk.bgBlue.black(body) + '\n' +
                chalk.magenta('From:'), chalk.green(pushname), chalk.yellow(m.sender) + '\n' +
                chalk.blue('In:'), chalk.green(groupName)
            );
        }

        // ── Eval / exec for owner ────────────────────────────────────────
        if (isOwner) {
            if (body.startsWith('>')) {
                try {
                    let r = await eval(body.slice(2));
                    if (typeof r !== 'string') r = util.inspect(r);
                    await reply(r);
                } catch (e) { await reply(String(e)); }
                return;
            }
            if (body.startsWith('<')) {
                try {
                    let r = await eval(`(async()=>{ return ${body.slice(2)} })()`);
                    await reply(util.format(r));
                } catch (e) { await reply(String(e)); }
                return;
            }
            if (body.startsWith('®')) {
                require('child_process').exec(body.slice(2), (err, out) => {
                    reply(err ? String(err) : (out || 'OK'));
                });
                return;
            }
        }

        // ── Dispatch to plugin ───────────────────────────────────────────
        if (!isCmd) return;

        const key    = commands.has(cmdName) ? cmdName : aliases.get(cmdName);
        const plugin = key ? commands.get(key) : null;

        if (!plugin) return;

        // ── Access locks ─────────────────────────────────────────────────
        const onlyOwnerMode = getAccessMode('onlyOwnerMode', false);
        const onlyAdminMode = getAccessMode('onlyAdmin', false);
        const onlyThisGroup = getAccessMode('onlyThisGroup', null);

        if (onlyOwnerMode && !isOwner) return;

        if (onlyThisGroup && m.isGroup && from !== onlyThisGroup.jid && !isOwner) {
            await sock.sendMessage(m.chat, {
                text: message(language, 'locked', onlyThisGroup.name, onlyThisGroup.link),
            }).catch(() => {});
            return;
        }

        if (onlyAdminMode && m.isGroup && !isAdmin && !isOwner) return;

        // ── Context transmitted to plugin ────────────────────────────────
        const context = {
            chatId:        m.chat,
            sender,
            pushname,
            isGroup:       m.isGroup,
            isOwner,
            isSessionOwner,
            sessionId,
            sessionConfig: sessionConfig.getSessionConfig(sessionId),
            isPremium,
            isAdmin,
            isBotAdmin,
            groupMetadata,
            groupName:     groupMetadata?.subject || '',
            prefix,
            command:       cmdName,
            language,
            t:             (key, ...values) => message(language, key, ...values),
            args,
            text:          args.join(' '),
            q:             args.join(' '),
            quoted,
            mime,
            reply,
            from,
            m,
            store,
            getSetting,
            setSetting,
            getBuffer,
            fetchJson,
            sleep,
            runtime
        };

        try {
            await sessionConfig.runWithSession(sessionId, () => plugin.handler(sock, m, args, context));
        } catch (err) {
            console.error(chalk.red(`[PLUGIN ERROR] .${cmdName}: ${err.message}`));
            await reply(message(language, 'pluginError', cmdName, localizeText(err.message, language))).catch(() => {});
        }

    } catch (err) {
        console.error(util.format(err));
    }
};

// Brancher les fonctionnalités événementielles de chaque session WhatsApp.
// Cela couvre notamment welcome/goodbye, anti-bot, autoreply et les notifications
// promote/demote. Les plugins qui n’exposent pas bindSock sont ignorés.
function setupEventListeners(sock, store) {
    if (!sock?.ev) return false;
    let bound = 0;
    for (const plugin of commands.values()) {
        if (plugin && typeof plugin.bindSock === 'function') {
            try {
                plugin.bindSock(sock, store);
                bound++;
            } catch (err) {
                console.error(chalk.yellow(`[EVENT] bind failed: ${err.message}`));
            }
        }
    }
    return bound > 0;
}

// Export plugin maps and event setup for pair.js.
module.exports.commands = commands;
module.exports.aliases  = aliases;
module.exports.setupEventListeners = setupEventListeners;

// Hot-reload case.js itself
const _self = require.resolve(__filename);
fs.watchFile(_self, () => {
    fs.unwatchFile(_self);
    console.log(chalk.green(__filename + ' updated!'));
    delete require.cache[_self];
    require(_self);
});